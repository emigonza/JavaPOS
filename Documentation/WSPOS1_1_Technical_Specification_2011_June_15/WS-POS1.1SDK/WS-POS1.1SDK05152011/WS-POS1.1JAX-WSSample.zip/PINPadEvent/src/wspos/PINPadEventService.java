/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package wspos;

import javax.xml.datatype.XMLGregorianCalendar;
import org.nrf_arts.unifiedpos.pinpadevents.*;
import javax.jws.WebService;
import java.util.HashMap;

/**
 *
 * @author hideon
 */
@WebService(serviceName = "PINPadEventService", endpointInterface = "org.nrf_arts.unifiedpos.pinpadevents.PINPadEvent", targetNamespace = "http://www.nrf-arts.org/UnifiedPOS/PINPadEvents/")
public class PINPadEventService implements PINPadEvent {

    private static HashMap<Integer, String> convert;

    static {
        convert = new HashMap<Integer, String>();
        convert.put(Status.POWER_OFF, "PowerOff");
        convert.put(Status.POWER_OFFLINE, "PowerOffline");
        convert.put(Status.POWER_OFF_OFFLINE, "PowerOffOffline");
        convert.put(Status.POWER_ONLINE, "PowerOnline");
        convert.put(Status.UPDATE_FIRMWARE_COMPLETE, "UpdateFirmwareComplete");
        convert.put(Status.UPDATE_FIRMWARE_COMPLETE_DEVICE_NOT_RESTORED, "UpdateFirmwareCompleteDeviceNotRestored");
        convert.put(Status.UPDATE_FIRMWARE_FAILED_DEVICE_NEEDS_FIRMWARE, "UpdateFirmwareFailedDeviceNeedsFirmware");
        convert.put(Status.UPDATE_FIRMWARE_FAILED_DEVICE_OK, "UpdateFirmwareFailedDeviceOk");
        convert.put(Status.UPDATE_FIRMWARE_FAILED_DEVICE_UNKNOWN, "UpdateFirmwareFailedDeviceUnknown");
        convert.put(Status.UPDATE_FIRMWARE_FAILED_DEVICE_UNRECOVERABLE, "UpdateFirmwareFailedDeviceUnrecoverable");
        convert.put(Status.UPDATE_FIRMWARE_PROGRESS, "UpdateFirmwareProgress");
    }

    //
    // PINPadEvent Member
    //

    public void dataEvent(String source, Integer eventID, XMLGregorianCalendar timeStamp, Integer status) {
        //throw new UnsupportedOperationException("Not supported yet.");
        System.out.println(eventID + ", " + timeStamp + ", DataEvent, " + status);
    }

    public DirectIOData directIOEvent(String source, Integer eventID, XMLGregorianCalendar timeStamp, Integer eventNumber, Integer data, Object obj) {
        //throw new UnsupportedOperationException("Not supported yet.");
        System.out.println(eventID + ", " + timeStamp + ", DirectIOEvent, " + eventNumber + ", " + data + ", " + obj);
        DirectIOData res = new DirectIOData();
        res.setData(data);
        res.setObj(obj);
        return res;
    }

    public ErrorResponse errorEvent(String source, Integer eventID, XMLGregorianCalendar timeStamp, ErrorCode errorCode, Integer errorCodeExtended, ErrorLocus errorLocus, ErrorResponse errorResponse) {
        //throw new UnsupportedOperationException("Not supported yet.");
        System.out.println(eventID + ", " + timeStamp + ", ErrorEvent, " + errorCode + ", " + errorCodeExtended + ", " + errorLocus + ", " + errorResponse);
        return ErrorResponse.CLEAR;
    }

    public void statusUpdateEvent(String source, Integer eventID, XMLGregorianCalendar timeStamp, Integer status) {
        //throw new UnsupportedOperationException("Not supported yet.");
        int p = Status.UPDATE_FIRMWARE_PROGRESS;
        String s = (status > p && status < p + 100) ? convert.get(p) + " + " + (status - p) : convert.get(status);
        System.out.println(eventID + ", " + timeStamp + ", StatusUpdateEvent, " + s);
    }
}
