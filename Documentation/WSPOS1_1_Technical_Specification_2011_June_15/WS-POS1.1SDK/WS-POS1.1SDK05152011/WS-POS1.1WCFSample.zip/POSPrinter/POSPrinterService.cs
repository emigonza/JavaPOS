﻿using UnifiedPOS.POSPrinter;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Text.RegularExpressions;

namespace Wspos
{
    [ServiceBehavior(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/", InstanceContextMode = InstanceContextMode.Single)]
    public class POSPrinterService : POSPrinter, IDisposable
    {
        #region POSPrinter Enumration Converter

        private static Dictionary<Enum, Enum> Convert = new Dictionary<Enum, Enum>()
            {
                { Microsoft.PointOfService.PowerReporting.Advanced, PowerReporting.Advanced },
                { Microsoft.PointOfService.PowerReporting.None, PowerReporting.None },
                { Microsoft.PointOfService.PowerReporting.Standard, PowerReporting.Standard },
                { PowerReporting.Advanced, Microsoft.PointOfService.PowerReporting.Advanced },
                { PowerReporting.None, Microsoft.PointOfService.PowerReporting.None },
                { PowerReporting.Standard, Microsoft.PointOfService.PowerReporting.Standard },

                { Microsoft.PointOfService.PowerNotification.Disabled, PowerNotification.Disabled },
                { Microsoft.PointOfService.PowerNotification.Enabled, PowerNotification.Enabled },
                { PowerNotification.Disabled, Microsoft.PointOfService.PowerNotification.Disabled },
                { PowerNotification.Enabled, Microsoft.PointOfService.PowerNotification.Enabled },

                { Microsoft.PointOfService.PowerState.Off, PowerState.Off },
                { Microsoft.PointOfService.PowerState.Offline, PowerState.Offline },
                { Microsoft.PointOfService.PowerState.OffOffline, PowerState.OffOffline },
                { Microsoft.PointOfService.PowerState.Online, PowerState.Online },
                { Microsoft.PointOfService.PowerState.Unknown, PowerState.Unknown },
                { PowerState.Off, Microsoft.PointOfService.PowerState.Off },
                { PowerState.Offline, Microsoft.PointOfService.PowerState.Offline },
                { PowerState.OffOffline, Microsoft.PointOfService.PowerState.OffOffline },
                { PowerState.Online, Microsoft.PointOfService.PowerState.Online },
                { PowerState.Unknown, Microsoft.PointOfService.PowerState.Unknown },

                { Microsoft.PointOfService.ControlState.Busy, ControlState.Busy },
                { Microsoft.PointOfService.ControlState.Closed, ControlState.Closed },
                { Microsoft.PointOfService.ControlState.Error, ControlState.Error },
                { Microsoft.PointOfService.ControlState.Idle, ControlState.Idle },
                { ControlState.Busy, Microsoft.PointOfService.ControlState.Busy },
                { ControlState.Closed, Microsoft.PointOfService.ControlState.Closed },
                { ControlState.Error, Microsoft.PointOfService.ControlState.Error },
                { ControlState.Idle, Microsoft.PointOfService.ControlState.Idle },

                { Microsoft.PointOfService.HealthCheckLevel.External, HealthCheckLevel.External },
                { Microsoft.PointOfService.HealthCheckLevel.Interactive, HealthCheckLevel.Interactive },
                { Microsoft.PointOfService.HealthCheckLevel.Internal, HealthCheckLevel.Internal },
                { HealthCheckLevel.External, Microsoft.PointOfService.HealthCheckLevel.External },
                { HealthCheckLevel.Interactive, Microsoft.PointOfService.HealthCheckLevel.Interactive },
                { HealthCheckLevel.Internal, Microsoft.PointOfService.HealthCheckLevel.Internal },

                { Microsoft.PointOfService.CompareFirmwareResult.Different, CompareFirmwareResult.Different },
                { Microsoft.PointOfService.CompareFirmwareResult.Newer, CompareFirmwareResult.Newer },
                { Microsoft.PointOfService.CompareFirmwareResult.Older, CompareFirmwareResult.Older },
                { Microsoft.PointOfService.CompareFirmwareResult.Same, CompareFirmwareResult.Same },
                { Microsoft.PointOfService.CompareFirmwareResult.Unknown, CompareFirmwareResult.Unknown },
                { CompareFirmwareResult.Different, Microsoft.PointOfService.CompareFirmwareResult.Different },
                { CompareFirmwareResult.Newer, Microsoft.PointOfService.CompareFirmwareResult.Newer },
                { CompareFirmwareResult.Older, Microsoft.PointOfService.CompareFirmwareResult.Older },
                { CompareFirmwareResult.Same, Microsoft.PointOfService.CompareFirmwareResult.Same },
                { CompareFirmwareResult.Unknown, Microsoft.PointOfService.CompareFirmwareResult.Unknown },

                { Microsoft.PointOfService.ErrorCode.Busy, UnifiedPOS.POSPrinter.ErrorCode.Busy },
                { Microsoft.PointOfService.ErrorCode.Claimed, UnifiedPOS.POSPrinter.ErrorCode.Claimed },
                { Microsoft.PointOfService.ErrorCode.Closed, UnifiedPOS.POSPrinter.ErrorCode.Closed },
                { Microsoft.PointOfService.ErrorCode.Deprecated, UnifiedPOS.POSPrinter.ErrorCode.Deprecated },
                { Microsoft.PointOfService.ErrorCode.Disabled, UnifiedPOS.POSPrinter.ErrorCode.Disabled },
                { Microsoft.PointOfService.ErrorCode.Exists, UnifiedPOS.POSPrinter.ErrorCode.Exists },
                { Microsoft.PointOfService.ErrorCode.Extended, UnifiedPOS.POSPrinter.ErrorCode.Extended },
                { Microsoft.PointOfService.ErrorCode.Failure, UnifiedPOS.POSPrinter.ErrorCode.Failure },
                { Microsoft.PointOfService.ErrorCode.Illegal, UnifiedPOS.POSPrinter.ErrorCode.Illegal },
                { Microsoft.PointOfService.ErrorCode.NoExist, UnifiedPOS.POSPrinter.ErrorCode.NoExist },
                { Microsoft.PointOfService.ErrorCode.NoHardware, UnifiedPOS.POSPrinter.ErrorCode.NoHardware },
                { Microsoft.PointOfService.ErrorCode.NoService, UnifiedPOS.POSPrinter.ErrorCode.NoService },
                { Microsoft.PointOfService.ErrorCode.NotClaimed, UnifiedPOS.POSPrinter.ErrorCode.NotClaimed },
                { Microsoft.PointOfService.ErrorCode.Offline, UnifiedPOS.POSPrinter.ErrorCode.Offline },
                { Microsoft.PointOfService.ErrorCode.Success, UnifiedPOS.POSPrinter.ErrorCode.Success },
                { Microsoft.PointOfService.ErrorCode.Timeout, UnifiedPOS.POSPrinter.ErrorCode.Timeout },
                { UnifiedPOS.POSPrinter.ErrorCode.Busy, Microsoft.PointOfService.ErrorCode.Busy },
                { UnifiedPOS.POSPrinter.ErrorCode.Claimed, Microsoft.PointOfService.ErrorCode.Claimed },
                { UnifiedPOS.POSPrinter.ErrorCode.Closed, Microsoft.PointOfService.ErrorCode.Closed },
                { UnifiedPOS.POSPrinter.ErrorCode.Deprecated, Microsoft.PointOfService.ErrorCode.Deprecated },
                { UnifiedPOS.POSPrinter.ErrorCode.Disabled, Microsoft.PointOfService.ErrorCode.Disabled },
                { UnifiedPOS.POSPrinter.ErrorCode.Exists, Microsoft.PointOfService.ErrorCode.Exists },
                { UnifiedPOS.POSPrinter.ErrorCode.Extended, Microsoft.PointOfService.ErrorCode.Extended },
                { UnifiedPOS.POSPrinter.ErrorCode.Failure, Microsoft.PointOfService.ErrorCode.Failure },
                { UnifiedPOS.POSPrinter.ErrorCode.Illegal, Microsoft.PointOfService.ErrorCode.Illegal },
                { UnifiedPOS.POSPrinter.ErrorCode.NoExist, Microsoft.PointOfService.ErrorCode.NoExist },
                { UnifiedPOS.POSPrinter.ErrorCode.NoHardware, Microsoft.PointOfService.ErrorCode.NoHardware },
                { UnifiedPOS.POSPrinter.ErrorCode.NoService, Microsoft.PointOfService.ErrorCode.NoService },
                { UnifiedPOS.POSPrinter.ErrorCode.NotClaimed, Microsoft.PointOfService.ErrorCode.NotClaimed },
                { UnifiedPOS.POSPrinter.ErrorCode.Offline, Microsoft.PointOfService.ErrorCode.Offline },
                { UnifiedPOS.POSPrinter.ErrorCode.Success, Microsoft.PointOfService.ErrorCode.Success },
                { UnifiedPOS.POSPrinter.ErrorCode.Timeout, Microsoft.PointOfService.ErrorCode.Timeout },

                { Microsoft.PointOfService.CharacterSetCapability.Alpha, CharacterSetCapability.Alpha },
                { Microsoft.PointOfService.CharacterSetCapability.Ascii, CharacterSetCapability.Ascii },
                { Microsoft.PointOfService.CharacterSetCapability.Kana, CharacterSetCapability.Kana },
                { Microsoft.PointOfService.CharacterSetCapability.Kanji, CharacterSetCapability.Kanji },
                { Microsoft.PointOfService.CharacterSetCapability.Unicode, CharacterSetCapability.Unicode },
                { CharacterSetCapability.Alpha, Microsoft.PointOfService.CharacterSetCapability.Alpha },
                { CharacterSetCapability.Ascii, Microsoft.PointOfService.CharacterSetCapability.Ascii },
                { CharacterSetCapability.Kana, Microsoft.PointOfService.CharacterSetCapability.Kana },
                { CharacterSetCapability.Kanji, Microsoft.PointOfService.CharacterSetCapability.Kanji },
                { CharacterSetCapability.Unicode, Microsoft.PointOfService.CharacterSetCapability.Unicode },

                { Microsoft.PointOfService.PrinterCartridgeNotify.Disabled, PrinterCartridgeNotify.Disabled },
                { Microsoft.PointOfService.PrinterCartridgeNotify.Enabled, PrinterCartridgeNotify.Enabled },
                { PrinterCartridgeNotify.Disabled, Microsoft.PointOfService.PrinterCartridgeNotify.Disabled },
                { PrinterCartridgeNotify.Enabled, Microsoft.PointOfService.PrinterCartridgeNotify.Enabled },

                { Microsoft.PointOfService.PrinterErrorLevel.Fatal, PrinterErrorLevel.Fatal },
                { Microsoft.PointOfService.PrinterErrorLevel.None, PrinterErrorLevel.None },
                { Microsoft.PointOfService.PrinterErrorLevel.Recoverable, PrinterErrorLevel.Recoverable },
                { PrinterErrorLevel.Fatal, Microsoft.PointOfService.PrinterErrorLevel.Fatal },
                { PrinterErrorLevel.None, Microsoft.PointOfService.PrinterErrorLevel.None },
                { PrinterErrorLevel.Recoverable, Microsoft.PointOfService.PrinterErrorLevel.Recoverable },

                { Microsoft.PointOfService.PrinterStation.Journal, PrinterStation.Journal },
                { Microsoft.PointOfService.PrinterStation.None, PrinterStation.None },
                { Microsoft.PointOfService.PrinterStation.Receipt, PrinterStation.Receipt },
                { Microsoft.PointOfService.PrinterStation.Slip, PrinterStation.Slip },
                { Microsoft.PointOfService.PrinterStation.TwoReceiptJournal, PrinterStation.TwoReceiptJournal },
                { Microsoft.PointOfService.PrinterStation.TwoSlipJournal, PrinterStation.TwoSlipJournal },
                { Microsoft.PointOfService.PrinterStation.TwoSlipReceipt, PrinterStation.TwoSlipReceipt },
                { PrinterStation.Journal, Microsoft.PointOfService.PrinterStation.Journal },
                { PrinterStation.None, Microsoft.PointOfService.PrinterStation.None },
                { PrinterStation.Receipt, Microsoft.PointOfService.PrinterStation.Receipt },
                { PrinterStation.Slip, Microsoft.PointOfService.PrinterStation.Slip },
                { PrinterStation.TwoReceiptJournal, Microsoft.PointOfService.PrinterStation.TwoReceiptJournal },
                { PrinterStation.TwoSlipJournal, Microsoft.PointOfService.PrinterStation.TwoSlipJournal },
                { PrinterStation.TwoSlipReceipt, Microsoft.PointOfService.PrinterStation.TwoSlipReceipt },

                { Microsoft.PointOfService.MapMode.Dots, MapMode.Dots },
                { Microsoft.PointOfService.MapMode.English, MapMode.English },
                { Microsoft.PointOfService.MapMode.Metric, MapMode.Metric },
                { Microsoft.PointOfService.MapMode.Twips, MapMode.Twips },
                { MapMode.Dots, Microsoft.PointOfService.MapMode.Dots },
                { MapMode.English, Microsoft.PointOfService.MapMode.English },
                { MapMode.Metric, Microsoft.PointOfService.MapMode.Metric },
                { MapMode.Twips, Microsoft.PointOfService.MapMode.Twips },

                { Microsoft.PointOfService.PageModePrintDirection.BottomToTop, PageModePrintDirection.BottomToTop },
                { Microsoft.PointOfService.PageModePrintDirection.LeftToRight, PageModePrintDirection.LeftToRight },
                { Microsoft.PointOfService.PageModePrintDirection.None, PageModePrintDirection.None },
                { Microsoft.PointOfService.PageModePrintDirection.RightToLeft, PageModePrintDirection.RightToLeft },
                { Microsoft.PointOfService.PageModePrintDirection.TopToBottom, PageModePrintDirection.TopToBottom },
                { PageModePrintDirection.BottomToTop, Microsoft.PointOfService.PageModePrintDirection.BottomToTop },
                { PageModePrintDirection.LeftToRight, Microsoft.PointOfService.PageModePrintDirection.LeftToRight },
                { PageModePrintDirection.None, Microsoft.PointOfService.PageModePrintDirection.None },
                { PageModePrintDirection.RightToLeft, Microsoft.PointOfService.PageModePrintDirection.RightToLeft },
                { PageModePrintDirection.TopToBottom, Microsoft.PointOfService.PageModePrintDirection.TopToBottom },

                { Microsoft.PointOfService.Rotation.Left90, Rotation.Left90 },
                { Microsoft.PointOfService.Rotation.Normal, Rotation.Normal },
                { Microsoft.PointOfService.Rotation.Right90, Rotation.Right90 },
                { Microsoft.PointOfService.Rotation.Rotate180, Rotation.Rotate180 },
                { Rotation.Left90, Microsoft.PointOfService.Rotation.Left90 },
                { Rotation.Normal, Microsoft.PointOfService.Rotation.Normal },
                { Rotation.Right90, Microsoft.PointOfService.Rotation.Right90 },
                { Rotation.Rotate180, Microsoft.PointOfService.Rotation.Rotate180 },

                { Microsoft.PointOfService.PrinterCartridgeStates.Cleaning, PrinterCartridgeStates.Cleaning },
                { Microsoft.PointOfService.PrinterCartridgeStates.Empty, PrinterCartridgeStates.Empty },
                { Microsoft.PointOfService.PrinterCartridgeStates.NearEnd, PrinterCartridgeStates.NearEnd },
                { Microsoft.PointOfService.PrinterCartridgeStates.OK, PrinterCartridgeStates.OK },
                { Microsoft.PointOfService.PrinterCartridgeStates.Removed, PrinterCartridgeStates.Removed },
                { Microsoft.PointOfService.PrinterCartridgeStates.Unknown, PrinterCartridgeStates.Unknown },
                { PrinterCartridgeStates.Cleaning, Microsoft.PointOfService.PrinterCartridgeStates.Cleaning },
                { PrinterCartridgeStates.Empty, Microsoft.PointOfService.PrinterCartridgeStates.Empty },
                { PrinterCartridgeStates.NearEnd, Microsoft.PointOfService.PrinterCartridgeStates.NearEnd },
                { PrinterCartridgeStates.OK, Microsoft.PointOfService.PrinterCartridgeStates.OK },
                { PrinterCartridgeStates.Removed, Microsoft.PointOfService.PrinterCartridgeStates.Removed },
                { PrinterCartridgeStates.Unknown, Microsoft.PointOfService.PrinterCartridgeStates.Unknown },

                { Microsoft.PointOfService.PrinterSide.Opposite, PrinterSide.Opposite },
                { Microsoft.PointOfService.PrinterSide.Side1, PrinterSide.Side1 },
                { Microsoft.PointOfService.PrinterSide.Side2, PrinterSide.Side2 },
                { Microsoft.PointOfService.PrinterSide.Unknown, PrinterSide.Unknown },
                { PrinterSide.Opposite, Microsoft.PointOfService.PrinterSide.Opposite },
                { PrinterSide.Side1, Microsoft.PointOfService.PrinterSide.Side1 },
                { PrinterSide.Side2, Microsoft.PointOfService.PrinterSide.Side2 },
                { PrinterSide.Unknown, Microsoft.PointOfService.PrinterSide.Unknown },

                { Microsoft.PointOfService.PageModePrintControl.Cancel, PageModePrintControl.Cancel },
                { Microsoft.PointOfService.PageModePrintControl.Normal, PageModePrintControl.Normal },
                { Microsoft.PointOfService.PageModePrintControl.PageMode, PageModePrintControl.PageMode },
                { Microsoft.PointOfService.PageModePrintControl.PrintSave, PageModePrintControl.PrintSave },
                { PageModePrintControl.Cancel, Microsoft.PointOfService.PageModePrintControl.Cancel },
                { PageModePrintControl.Normal, Microsoft.PointOfService.PageModePrintControl.Normal },
                { PageModePrintControl.PageMode, Microsoft.PointOfService.PageModePrintControl.PageMode },
                { PageModePrintControl.PrintSave, Microsoft.PointOfService.PageModePrintControl.PrintSave },

                { Microsoft.PointOfService.BarCodeTextPosition.Above, BarCodeTextPosition.Above },
                { Microsoft.PointOfService.BarCodeTextPosition.Below, BarCodeTextPosition.Below },
                { Microsoft.PointOfService.BarCodeTextPosition.None, BarCodeTextPosition.None },
                { BarCodeTextPosition.Above, Microsoft.PointOfService.BarCodeTextPosition.Above },
                { BarCodeTextPosition.Below, Microsoft.PointOfService.BarCodeTextPosition.Below },
                { BarCodeTextPosition.None, Microsoft.PointOfService.BarCodeTextPosition.None },

                { Microsoft.PointOfService.PrinterLogoLocation.Bottom, PrinterLogoLocation.Bottom },
                { Microsoft.PointOfService.PrinterLogoLocation.Top, PrinterLogoLocation.Top },
                { PrinterLogoLocation.Bottom, Microsoft.PointOfService.PrinterLogoLocation.Bottom },
                { PrinterLogoLocation.Top, Microsoft.PointOfService.PrinterLogoLocation.Top },

                { Microsoft.PointOfService.PrinterTransactionControl.Normal, PrinterTransactionControl.Normal },
                { Microsoft.PointOfService.PrinterTransactionControl.Transaction, PrinterTransactionControl.Transaction },
                { PrinterTransactionControl.Normal, Microsoft.PointOfService.PrinterTransactionControl.Normal },
                { PrinterTransactionControl.Transaction, Microsoft.PointOfService.PrinterTransactionControl.Transaction },
            };

        private static Dictionary<Enum, Enum> EventConvert = new Dictionary<Enum, Enum>()
            {
                { Microsoft.PointOfService.ErrorCode.Busy, UnifiedPOS.POSPrinterEvents.ErrorCode.Busy },
                { Microsoft.PointOfService.ErrorCode.Claimed, UnifiedPOS.POSPrinterEvents.ErrorCode.Claimed },
                { Microsoft.PointOfService.ErrorCode.Closed, UnifiedPOS.POSPrinterEvents.ErrorCode.Closed },
                { Microsoft.PointOfService.ErrorCode.Deprecated, UnifiedPOS.POSPrinterEvents.ErrorCode.Deprecated },
                { Microsoft.PointOfService.ErrorCode.Disabled, UnifiedPOS.POSPrinterEvents.ErrorCode.Disabled },
                { Microsoft.PointOfService.ErrorCode.Exists, UnifiedPOS.POSPrinterEvents.ErrorCode.Exists },
                { Microsoft.PointOfService.ErrorCode.Extended, UnifiedPOS.POSPrinterEvents.ErrorCode.Extended },
                { Microsoft.PointOfService.ErrorCode.Failure, UnifiedPOS.POSPrinterEvents.ErrorCode.Failure },
                { Microsoft.PointOfService.ErrorCode.Illegal, UnifiedPOS.POSPrinterEvents.ErrorCode.Illegal },
                { Microsoft.PointOfService.ErrorCode.NoExist, UnifiedPOS.POSPrinterEvents.ErrorCode.NoExist },
                { Microsoft.PointOfService.ErrorCode.NoHardware, UnifiedPOS.POSPrinterEvents.ErrorCode.NoHardware },
                { Microsoft.PointOfService.ErrorCode.NoService, UnifiedPOS.POSPrinterEvents.ErrorCode.NoService },
                { Microsoft.PointOfService.ErrorCode.NotClaimed, UnifiedPOS.POSPrinterEvents.ErrorCode.NotClaimed },
                { Microsoft.PointOfService.ErrorCode.Offline, UnifiedPOS.POSPrinterEvents.ErrorCode.Offline },
                { Microsoft.PointOfService.ErrorCode.Success, UnifiedPOS.POSPrinterEvents.ErrorCode.Success },
                { Microsoft.PointOfService.ErrorCode.Timeout, UnifiedPOS.POSPrinterEvents.ErrorCode.Timeout },
                { UnifiedPOS.POSPrinterEvents.ErrorCode.Busy, Microsoft.PointOfService.ErrorCode.Busy },
                { UnifiedPOS.POSPrinterEvents.ErrorCode.Claimed, Microsoft.PointOfService.ErrorCode.Claimed },
                { UnifiedPOS.POSPrinterEvents.ErrorCode.Closed, Microsoft.PointOfService.ErrorCode.Closed },
                { UnifiedPOS.POSPrinterEvents.ErrorCode.Deprecated, Microsoft.PointOfService.ErrorCode.Deprecated },
                { UnifiedPOS.POSPrinterEvents.ErrorCode.Disabled, Microsoft.PointOfService.ErrorCode.Disabled },
                { UnifiedPOS.POSPrinterEvents.ErrorCode.Exists, Microsoft.PointOfService.ErrorCode.Exists },
                { UnifiedPOS.POSPrinterEvents.ErrorCode.Extended, Microsoft.PointOfService.ErrorCode.Extended },
                { UnifiedPOS.POSPrinterEvents.ErrorCode.Failure, Microsoft.PointOfService.ErrorCode.Failure },
                { UnifiedPOS.POSPrinterEvents.ErrorCode.Illegal, Microsoft.PointOfService.ErrorCode.Illegal },
                { UnifiedPOS.POSPrinterEvents.ErrorCode.NoExist, Microsoft.PointOfService.ErrorCode.NoExist },
                { UnifiedPOS.POSPrinterEvents.ErrorCode.NoHardware, Microsoft.PointOfService.ErrorCode.NoHardware },
                { UnifiedPOS.POSPrinterEvents.ErrorCode.NoService, Microsoft.PointOfService.ErrorCode.NoService },
                { UnifiedPOS.POSPrinterEvents.ErrorCode.NotClaimed, Microsoft.PointOfService.ErrorCode.NotClaimed },
                { UnifiedPOS.POSPrinterEvents.ErrorCode.Offline, Microsoft.PointOfService.ErrorCode.Offline },
                { UnifiedPOS.POSPrinterEvents.ErrorCode.Success, Microsoft.PointOfService.ErrorCode.Success },
                { UnifiedPOS.POSPrinterEvents.ErrorCode.Timeout, Microsoft.PointOfService.ErrorCode.Timeout },

                { Microsoft.PointOfService.ErrorLocus.Input, UnifiedPOS.POSPrinterEvents.ErrorLocus.Input },
                { Microsoft.PointOfService.ErrorLocus.InputData, UnifiedPOS.POSPrinterEvents.ErrorLocus.InputData },
                { Microsoft.PointOfService.ErrorLocus.Output, UnifiedPOS.POSPrinterEvents.ErrorLocus.Output },
                { UnifiedPOS.POSPrinterEvents.ErrorLocus.Input, Microsoft.PointOfService.ErrorLocus.Input },
                { UnifiedPOS.POSPrinterEvents.ErrorLocus.InputData, Microsoft.PointOfService.ErrorLocus.InputData },
                { UnifiedPOS.POSPrinterEvents.ErrorLocus.Output, Microsoft.PointOfService.ErrorLocus.Output },

                { Microsoft.PointOfService.ErrorResponse.Clear, UnifiedPOS.POSPrinterEvents.ErrorResponse.Clear },
                { Microsoft.PointOfService.ErrorResponse.ContinueInput, UnifiedPOS.POSPrinterEvents.ErrorResponse.ContinueInput },
                { Microsoft.PointOfService.ErrorResponse.Retry, UnifiedPOS.POSPrinterEvents.ErrorResponse.Retry },
                { UnifiedPOS.POSPrinterEvents.ErrorResponse.Clear, Microsoft.PointOfService.ErrorResponse.Clear },
                { UnifiedPOS.POSPrinterEvents.ErrorResponse.ContinueInput, Microsoft.PointOfService.ErrorResponse.ContinueInput },
                { UnifiedPOS.POSPrinterEvents.ErrorResponse.Retry, Microsoft.PointOfService.ErrorResponse.Retry },
            };

        #endregion

        private string deviceControlDescription = "";
        private UposVersion deviceControlVersion = new UposVersion() { Major = 1, Minor = 13, Build = 1 };
        private UnifiedPOS.POSPrinterEvents.POSPrinterEvent deviceEvent;
        private Microsoft.PointOfService.PosPrinter device;
        private Regex pattern = new Regex("\\\\u([0-9a-fA-F]{4})|(\\\\\\\\)|(\\\\n)|(\\\\r)|(\\\\t)|(\\\\f)|(\\\\b)", RegexOptions.Compiled);

        private string ProcessEscapeSequence(string data)
        {
            Match m = pattern.Match(data);
            StringBuilder s = new StringBuilder();
            int start = 0;
            while (m.Success)
            {
                s.Append(data.Substring(start, m.Index - start));
                if (m.Groups[1].Length > 0)
                {
                    s.Append(System.Convert.ToChar(System.Convert.ToInt32(m.Groups[1].Value, 16)));
                }
                else if (m.Groups[2].Length > 0)
                {
                    s.Append("\\");
                }
                else if (m.Groups[3].Length > 0)
                {
                    s.Append("\n");
                }
                else if (m.Groups[4].Length > 0)
                {
                    s.Append("\r");
                }
                else if (m.Groups[5].Length > 0)
                {
                    s.Append("\t");
                }
                else if (m.Groups[6].Length > 0)
                {
                    s.Append("\f");
                }
                else if (m.Groups[7].Length > 0)
                {
                    s.Append("\b");
                }
                start = m.Index + m.Length;
                m = m.NextMatch();
            }
            s.Append(data.Substring(start));
            return s.ToString();
        }

        #region Constructor

        public POSPrinterService()
        {
            try
            {
                Microsoft.PointOfService.PosExplorer posExplorer = new Microsoft.PointOfService.PosExplorer();
                Microsoft.PointOfService.DeviceCollection deviceCollection = posExplorer.GetDevices("PosPrinter");
                if (deviceCollection.Count > 0)
                {
                    device = (Microsoft.PointOfService.PosPrinter)posExplorer.CreateInstance(deviceCollection[0]);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        #endregion

        #region POSPrinter Member

        public bool GetCapCompareFirmwareVersion()
        {
            //throw new NotImplementedException();
            return device.CapCompareFirmwareVersion;
        }

        public PowerReporting GetCapPowerReporting()
        {
            //throw new NotImplementedException();
            return (PowerReporting)Convert[device.CapPowerReporting];
        }

        public bool GetCapStatisticsReporting()
        {
            //throw new NotImplementedException();
            return device.CapStatisticsReporting;
        }

        public bool GetCapUpdateFirmware()
        {
            //throw new NotImplementedException();
            return device.CapUpdateFirmware;
        }

        public bool GetCapUpdateStatistics()
        {
            //throw new NotImplementedException();
            return device.CapUpdateStatistics;
        }

        public string GetCheckHealthText()
        {
            //throw new NotImplementedException();
            return device.CheckHealthText;
        }

        public bool GetClaimed()
        {
            //throw new NotImplementedException();
            return device.Claimed;
        }

        public bool GetDeviceEnabled()
        {
            //throw new NotImplementedException();
            return device.DeviceEnabled;
        }

        public void SetDeviceEnabled(bool DeviceEnabled)
        {
            //throw new NotImplementedException();
            device.DeviceEnabled = DeviceEnabled;
        }

        public bool GetFreezeEvents()
        {
            //throw new NotImplementedException();
            return device.FreezeEvents;
        }

        public void SetFreezeEvents(bool FreezeEvents)
        {
            //throw new NotImplementedException();
            device.FreezeEvents = FreezeEvents;
        }

        public int GetOutputID()
        {
            //throw new NotImplementedException();
            return device.OutputId;
        }

        public PowerNotification GetPowerNotify()
        {
            //throw new NotImplementedException();
            return (PowerNotification)Convert[device.PowerNotify];
        }

        public void SetPowerNotify(PowerNotification PowerNotify)
        {
            //throw new NotImplementedException();
            device.PowerNotify = (Microsoft.PointOfService.PowerNotification)Convert[PowerNotify];
        }

        public PowerState GetPowerState()
        {
            //throw new NotImplementedException();
            return (PowerState)Convert[device.PowerState];
        }

        public ControlState GetState()
        {
            //throw new NotImplementedException();
            return (ControlState)Convert[device.State];
        }

        public string GetDeviceControlDescription()
        {
            //throw new NotImplementedException();
            return deviceControlDescription;
        }

        public UposVersion GetDeviceControlVersion()
        {
            //throw new NotImplementedException();
            return deviceControlVersion;
        }

        public string GetDeviceServiceDescription()
        {
            //throw new NotImplementedException();
            return device.ServiceObjectDescription;
        }

        public UposVersion GetDeviceServiceVersion()
        {
            //throw new NotImplementedException();
            Version value = device.ServiceObjectVersion;
            return new UposVersion() { Build = value.Build, Major = value.Major, Minor = value.Minor };
        }

        public string GetPhysicalDeviceDescription()
        {
            //throw new NotImplementedException();
            return device.DeviceDescription;
        }

        public string GetPhysicalDeviceName()
        {
            //throw new NotImplementedException();
            return device.DeviceName;
        }

        public CharacterSetCapability GetCapCharacterSet()
        {
            //throw new NotImplementedException();
            return (CharacterSetCapability)Convert[device.CapCharacterSet];
        }

        public bool GetCapConcurrentJrnRec()
        {
            //throw new NotImplementedException();
            return device.CapConcurrentJrnRec;
        }

        public bool GetCapConcurrentJrnSlp()
        {
            //throw new NotImplementedException();
            return device.CapConcurrentJrnSlp;
        }

        public bool GetCapConcurrentPageMode()
        {
            //throw new NotImplementedException();
            return device.CapConcurrentPageMode;
        }

        public bool GetCapConcurrentRecSlp()
        {
            //throw new NotImplementedException();
            return device.CapConcurrentRecSlp;
        }

        public bool GetCapCoverSensor()
        {
            //throw new NotImplementedException();
            return device.CapCoverSensor;
        }

        public bool GetCapMapCharacterSet()
        {
            //throw new NotImplementedException();
            return device.CapMapCharacterSet;
        }

        public bool GetCapTransaction()
        {
            //throw new NotImplementedException();
            return device.CapTransaction;
        }

        public bool GetCapJrnPresent()
        {
            //throw new NotImplementedException();
            return device.CapJrnPresent;
        }

        public bool GetCapJrn2Color()
        {
            //throw new NotImplementedException();
            return device.CapJrn2Color;
        }

        public bool GetCapJrnBold()
        {
            //throw new NotImplementedException();
            return device.CapJrnBold;
        }

        public bool GetCapJrnDhigh()
        {
            //throw new NotImplementedException();
            return device.CapJrnDHigh;
        }

        public bool GetCapJrnDwide()
        {
            //throw new NotImplementedException();
            return device.CapJrnDWide;
        }

        public bool GetCapJrnDwideDhigh()
        {
            //throw new NotImplementedException();
            return device.CapJrnDWideDHigh;
        }

        public bool GetCapJrnEmptySensor()
        {
            //throw new NotImplementedException();
            return device.CapJrnEmptySensor;
        }

        public bool GetCapJrnItalic()
        {
            //throw new NotImplementedException();
            return device.CapJrnItalic;
        }

        public bool GetCapJrnNearEndSensor()
        {
            //throw new NotImplementedException();
            return device.CapJrnNearEndSensor;
        }

        public bool GetCapJrnUnderline()
        {
            //throw new NotImplementedException();
            return device.CapJrnUnderline;
        }

        public int GetCapJrnCartridgeSensor()
        {
            //throw new NotImplementedException();
            return (int)device.CapJrnCartridgeSensor;
        }

        public int GetCapJrnColor()
        {
            //throw new NotImplementedException();
            return (int)device.CapJrnColor;
        }

        public bool GetCapRecPresent()
        {
            //throw new NotImplementedException();
            return device.CapRecPresent;
        }

        public bool GetCapRec2Color()
        {
            //throw new NotImplementedException();
            return device.CapRec2Color;
        }

        public bool GetCapRecBarCode()
        {
            //throw new NotImplementedException();
            return device.CapRecBarCode;
        }

        public bool GetCapRecBitmap()
        {
            //throw new NotImplementedException();
            return device.CapRecBitmap;
        }

        public bool GetCapRecBold()
        {
            //throw new NotImplementedException();
            return device.CapRecBold;
        }

        public bool GetCapRecDhigh()
        {
            //throw new NotImplementedException();
            return device.CapRecDHigh;
        }

        public bool GetCapRecDwide()
        {
            //throw new NotImplementedException();
            return device.CapRecDWide;
        }

        public bool GetCapRecDwideDhigh()
        {
            //throw new NotImplementedException();
            return device.CapRecDWideDHigh;
        }

        public bool GetCapRecEmptySensor()
        {
            //throw new NotImplementedException();
            return device.CapRecEmptySensor;
        }

        public bool GetCapRecItalic()
        {
            //throw new NotImplementedException();
            return device.CapRecItalic;
        }

        public bool GetCapRecLeft90()
        {
            //throw new NotImplementedException();
            return device.CapRecLeft90;
        }

        public bool GetCapRecNearEndSensor()
        {
            //throw new NotImplementedException();
            return device.CapRecNearEndSensor;
        }

        public bool GetCapRecPapercut()
        {
            //throw new NotImplementedException();
            return device.CapRecPaperCut;
        }

        public bool GetCapRecRight90()
        {
            //throw new NotImplementedException();
            return device.CapRecRight90;
        }

        public bool GetCapRecRotate180()
        {
            //throw new NotImplementedException();
            return device.CapRecRotate180;
        }

        public bool GetCapRecStamp()
        {
            //throw new NotImplementedException();
            return device.CapRecStamp;
        }

        public bool GetCapRecUnderline()
        {
            //throw new NotImplementedException();
            return device.CapRecUnderline;
        }

        public int GetCapRecCartridgeSensor()
        {
            //throw new NotImplementedException();
            return (int)device.CapRecCartridgeSensor;
        }

        public int GetCapRecColor()
        {
            //throw new NotImplementedException();
            return (int)device.CapRecColor;
        }

        public int GetCapRecMarkFeed()
        {
            //throw new NotImplementedException();
            return (int)device.CapRecMarkFeed;
        }

        public bool GetCapRecPageMode()
        {
            //throw new NotImplementedException();
            return device.CapRecPageMode;
        }

        public int GetCapRecRuledLine()
        {
            //throw new NotImplementedException();
            return PrinterLineDirection.None;
        }

        public bool GetCapSlpPresent()
        {
            //throw new NotImplementedException();
            return device.CapSlpPresent;
        }

        public bool GetCapSlpFullslip()
        {
            //throw new NotImplementedException();
            return device.CapSlpFullSlip;
        }

        public bool GetCapSlp2Color()
        {
            //throw new NotImplementedException();
            return device.CapSlp2Color;
        }

        public bool GetCapSlpBarCode()
        {
            //throw new NotImplementedException();
            return device.CapSlpBarCode;
        }

        public bool GetCapSlpBitmap()
        {
            //throw new NotImplementedException();
            return device.CapSlpBitmap;
        }

        public bool GetCapSlpBold()
        {
            //throw new NotImplementedException();
            return device.CapSlpBold;
        }

        public bool GetCapSlpDhigh()
        {
            //throw new NotImplementedException();
            return device.CapSlpDHigh;
        }

        public bool GetCapSlpDwide()
        {
            //throw new NotImplementedException();
            return device.CapSlpDWide;
        }

        public bool GetCapSlpDwideDhigh()
        {
            //throw new NotImplementedException();
            return device.CapSlpDWideDHigh;
        }

        public bool GetCapSlpEmptySensor()
        {
            //throw new NotImplementedException();
            return device.CapSlpEmptySensor;
        }

        public bool GetCapSlpItalic()
        {
            //throw new NotImplementedException();
            return device.CapSlpItalic;
        }

        public bool GetCapSlpLeft90()
        {
            //throw new NotImplementedException();
            return device.CapSlpLeft90;
        }

        public bool GetCapSlpNearEndSensor()
        {
            //throw new NotImplementedException();
            return device.CapSlpNearEndSensor;
        }

        public bool GetCapSlpRight90()
        {
            //throw new NotImplementedException();
            return device.CapSlpRight90;
        }

        public bool GetCapSlpRotate180()
        {
            //throw new NotImplementedException();
            return device.CapSlpRotate180;
        }

        public bool GetCapSlpUnderline()
        {
            //throw new NotImplementedException();
            return device.CapSlpUnderline;
        }

        public bool GetCapSlpBothSidesPrint()
        {
            //throw new NotImplementedException();
            return device.CapSlpBothSidesPrint;
        }

        public int GetCapSlpCartridgeSensor()
        {
            //throw new NotImplementedException();
            return (int)device.CapSlpCartridgeSensor;
        }

        public int GetCapSlpColor()
        {
            //throw new NotImplementedException();
            return (int)device.CapSlpColor;
        }

        public bool GetCapSlpPageMode()
        {
            //throw new NotImplementedException();
            return device.CapSlpPageMode;
        }

        public int GetCapSlpRuledLine()
        {
            //throw new NotImplementedException();
            return PrinterLineDirection.None;
        }

        public bool GetAsyncMode()
        {
            //throw new NotImplementedException();
            return device.AsyncMode;
        }

        public void SetAsyncMode(bool AsyncMode)
        {
            //throw new NotImplementedException();
            device.AsyncMode = AsyncMode;
        }

        public PrinterCartridgeNotify GetCartridgeNotify()
        {
            //throw new NotImplementedException();
            return (PrinterCartridgeNotify)Convert[device.CartridgeNotify];
        }

        public void SetCartridgeNotify(PrinterCartridgeNotify CartridgeNotify)
        {
            //throw new NotImplementedException();
            device.CartridgeNotify = (Microsoft.PointOfService.PrinterCartridgeNotify)Convert[CartridgeNotify];
        }

        public int GetCharacterSet()
        {
            //throw new NotImplementedException();
            return device.CharacterSet;
        }

        public void SetCharacterSet(int CharacterSet)
        {
            //throw new NotImplementedException();
            device.CharacterSet = CharacterSet;
        }

        public CharacterSetList GetCharacterSetList()
        {
            //throw new NotImplementedException();
            CharacterSetList value = new CharacterSetList();
            value.AddRange(device.CharacterSetList);
            return value;
        }

        public bool GetCoverOpen()
        {
            //throw new NotImplementedException();
            return device.CoverOpen;
        }

        public PrinterErrorLevel GetErrorLevel()
        {
            //throw new NotImplementedException();
            return (PrinterErrorLevel)Convert[device.ErrorLevel];
        }

        public PrinterStation GetErrorStation()
        {
            //throw new NotImplementedException();
            return (PrinterStation)Convert[device.ErrorStation];
        }

        public string GetErrorString()
        {
            //throw new NotImplementedException();
            return device.ErrorString;
        }

        public FontTypefaceList GetFontTypefaceList()
        {
            //throw new NotImplementedException();
            FontTypefaceList value = new FontTypefaceList();
            value.AddRange(device.FontTypefaceList);
            return value;
        }

        public bool GetFlagWhenIdle()
        {
            //throw new NotImplementedException();
            return device.FlagWhenIdle;
        }

        public void SetFlagWhenIdle(bool FlagWhenIdle)
        {
            //throw new NotImplementedException();
            device.FlagWhenIdle = FlagWhenIdle;
        }

        public bool GetMapCharacterSet()
        {
            //throw new NotImplementedException();
            return device.MapCharacterSet;
        }

        public void SetMapCharacterSet(bool MapCharacterSet)
        {
            //throw new NotImplementedException();
            device.MapCharacterSet = MapCharacterSet;
        }

        public MapMode GetMapMode()
        {
            //throw new NotImplementedException();
            return (MapMode)Convert[device.MapMode];
        }

        public void SetMapMode(MapMode MapMode)
        {
            //throw new NotImplementedException();
            device.MapMode = (Microsoft.PointOfService.MapMode)Convert[MapMode];
        }

        public Point GetPageModeArea()
        {
            //throw new NotImplementedException();
            System.Drawing.Point value = device.PageModeArea;
            return new Point() { X = value.X, Y = value.Y };
        }

        public int GetPageModeDescriptor()
        {
            //throw new NotImplementedException();
            return (int)device.PageModeDescriptor;
        }

        public int GetPageModeHorizontalPosition()
        {
            //throw new NotImplementedException();
            return device.PageModeHorizontalPosition;
        }

        public void SetPageModeHorizontalPosition(int PageModeHorizontalPosition)
        {
            //throw new NotImplementedException();
            device.PageModeHorizontalPosition = PageModeHorizontalPosition;
        }

        public Rectangle GetPageModePrintArea()
        {
            //throw new NotImplementedException();
            System.Drawing.Rectangle value = device.PageModePrintArea;
            return new Rectangle() { Height = value.Height, Width = value.Width, X = value.X, Y = value.Y };
        }

        public void SetPageModePrintArea(Rectangle PageModePrintArea)
        {
            //throw new NotImplementedException();
            device.PageModePrintArea = new System.Drawing.Rectangle(PageModePrintArea.X, PageModePrintArea.Y, PageModePrintArea.Width, PageModePrintArea.Height);
        }

        public PageModePrintDirection GetPageModePrintDirection()
        {
            //throw new NotImplementedException();
            return (PageModePrintDirection)Convert[device.PageModePrintDirection];
        }

        public void SetPageModePrintDirection(PageModePrintDirection PageModePrintDirection)
        {
            //throw new NotImplementedException();
            device.PageModePrintDirection = (Microsoft.PointOfService.PageModePrintDirection)Convert[PageModePrintDirection];
        }

        public PrinterStation GetPageModeStation()
        {
            //throw new NotImplementedException();
            return (PrinterStation)Convert[device.PageModeStation];
        }

        public void SetPageModeStation(PrinterStation PageModeStation)
        {
            //throw new NotImplementedException();
            device.PageModeStation = (Microsoft.PointOfService.PrinterStation)Convert[PageModeStation];
        }

        public int GetPageModeVerticalPosition()
        {
            //throw new NotImplementedException();
            return device.PageModeVerticalPosition;
        }

        public void SetPageModeVerticalPosition(int PageModeVerticalPosition)
        {
            //throw new NotImplementedException();
            device.PageModeVerticalPosition = PageModeVerticalPosition;
        }

        public Rotation GetRotateSpecial()
        {
            //throw new NotImplementedException();
            return (Rotation)Convert[device.RotateSpecial];
        }

        public void SetRotateSpecial(Rotation RotateSpecial)
        {
            //throw new NotImplementedException();
            device.RotateSpecial = (Microsoft.PointOfService.Rotation)Convert[RotateSpecial];
        }

        public int GetJrnLineChars()
        {
            //throw new NotImplementedException();
            return device.JrnLineChars;
        }

        public void SetJrnLineChars(int JrnLineChars)
        {
            //throw new NotImplementedException();
            device.JrnLineChars = JrnLineChars;
        }

        public LineCharsList GetJrnLineCharsList()
        {
            //throw new NotImplementedException();
            LineCharsList value = new LineCharsList();
            value.AddRange(device.JrnLineCharsList);
            return value;
        }

        public int GetJrnLineHeight()
        {
            //throw new NotImplementedException();
            return device.JrnLineHeight;
        }

        public void SetJrnLineHeight(int JrnLineHeight)
        {
            //throw new NotImplementedException();
            device.JrnLineHeight = JrnLineHeight;
        }

        public int GetJrnLineSpacing()
        {
            //throw new NotImplementedException();
            return device.JrnLineSpacing;
        }

        public void SetJrnLineSpacing(int JrnLineSpacing)
        {
            //throw new NotImplementedException();
            device.JrnLineSpacing = JrnLineSpacing;
        }

        public int GetJrnLineWidth()
        {
            //throw new NotImplementedException();
            return device.JrnLineWidth;
        }

        public bool GetJrnLetterQuality()
        {
            //throw new NotImplementedException();
            return device.JrnLetterQuality;
        }

        public void SetJrnLetterQuality(bool JrnLetterQuality)
        {
            //throw new NotImplementedException();
            device.JrnLetterQuality = JrnLetterQuality;
        }

        public bool GetJrnEmpty()
        {
            //throw new NotImplementedException();
            return device.JrnEmpty;
        }

        public bool GetJrnNearEnd()
        {
            //throw new NotImplementedException();
            return device.JrnNearEnd;
        }

        public PrinterCartridgeStates GetJrnCartridgeState()
        {
            //throw new NotImplementedException();
            return (PrinterCartridgeStates)Convert[device.JrnCartridgeState];
        }

        public int GetJrnCurrentCartridge()
        {
            //throw new NotImplementedException();
            return (int)device.JrnCurrentCartridge;
        }

        public void SetJrnCurrentCartridge(int JrnCurrentCartridge)
        {
            //throw new NotImplementedException();
            device.JrnCurrentCartridge = (Microsoft.PointOfService.PrinterColors)JrnCurrentCartridge;
        }

        public int GetRecLineChars()
        {
            //throw new NotImplementedException();
            return device.RecLineChars;
        }

        public void SetRecLineChars(int RecLineChars)
        {
            //throw new NotImplementedException();
            device.RecLineChars = RecLineChars;
        }

        public LineCharsList GetRecLineCharsList()
        {
            //throw new NotImplementedException();
            LineCharsList value = new LineCharsList();
            value.AddRange(device.RecLineCharsList);
            return value;
        }

        public int GetRecLineHeight()
        {
            //throw new NotImplementedException();
            return device.RecLineHeight;
        }

        public void SetRecLineHeight(int RecLineHeight)
        {
            //throw new NotImplementedException();
            device.RecLineHeight = RecLineHeight;
        }

        public int GetRecLineSpacing()
        {
            //throw new NotImplementedException();
            return device.RecLineSpacing;
        }

        public void SetRecLineSpacing(int RecLineSpacing)
        {
            //throw new NotImplementedException();
            device.RecLineSpacing = RecLineSpacing;
        }

        public int GetRecLineWidth()
        {
            //throw new NotImplementedException();
            return device.RecLineWidth;
        }

        public bool GetRecLetterQuality()
        {
            //throw new NotImplementedException();
            return device.RecLetterQuality;
        }

        public void SetRecLetterQuality(bool RecLetterQuality)
        {
            //throw new NotImplementedException();
            device.RecLetterQuality = RecLetterQuality;
        }

        public bool GetRecEmpty()
        {
            //throw new NotImplementedException();
            return device.RecEmpty;
        }

        public bool GetRecNearEnd()
        {
            //throw new NotImplementedException();
            return device.RecNearEnd;
        }

        public int GetRecSidewaysMaxChars()
        {
            //throw new NotImplementedException();
            return device.RecSidewaysMaxChars;
        }

        public int GetRecSidewaysMaxLines()
        {
            //throw new NotImplementedException();
            return device.RecSidewaysMaxLines;
        }

        public int GetRecLinesToPaperCut()
        {
            //throw new NotImplementedException();
            return device.RecLinesToPaperCut;
        }

        public RotationList GetRecBarCodeRotationList()
        {
            //throw new NotImplementedException();
            RotationList value = new RotationList();
            value.AddRange(from el in device.RecBarCodeRotationList select (Rotation)Convert[el]);
            return value;
        }

        public RotationList GetRecBitmapRotationList()
        {
            //throw new NotImplementedException();
            RotationList value = new RotationList();
            value.AddRange(from el in device.RecBitmapRotationList select (Rotation)Convert[el]);
            return value;
        }

        public PrinterCartridgeStates GetRecCartridgeState()
        {
            //throw new NotImplementedException();
            return (PrinterCartridgeStates)Convert[device.RecCartridgeState];
        }

        public int GetRecCurrentCartridge()
        {
            //throw new NotImplementedException();
            return (int)device.RecCurrentCartridge;
        }

        public void SetRecCurrentCartridge(int RecCurrentCartridge)
        {
            //throw new NotImplementedException();
            device.RecCurrentCartridge = (Microsoft.PointOfService.PrinterColors)RecCurrentCartridge;
        }

        public int GetSlpLineChars()
        {
            //throw new NotImplementedException();
            return device.SlpLineChars;
        }

        public void SetSlpLineChars(int SlpLineChars)
        {
            //throw new NotImplementedException();
            device.SlpLineChars = SlpLineChars;
        }

        public LineCharsList GetSlpLineCharsList()
        {
            //throw new NotImplementedException();
            LineCharsList value = new LineCharsList();
            value.AddRange(device.SlpLineCharsList);
            return value;
        }

        public int GetSlpLineHeight()
        {
            //throw new NotImplementedException();
            return device.SlpLineHeight;
        }

        public void SetSlpLineHeight(int SlpLineHeight)
        {
            //throw new NotImplementedException();
            device.SlpLineHeight = SlpLineHeight;
        }

        public int GetSlpLineSpacing()
        {
            //throw new NotImplementedException();
            return device.SlpLineSpacing;
        }

        public void SetSlpLineSpacing(int SlpLineSpacing)
        {
            //throw new NotImplementedException();
            device.SlpLineSpacing = SlpLineSpacing;
        }

        public int GetSlpLineWidth()
        {
            //throw new NotImplementedException();
            return device.SlpLineWidth;
        }

        public bool GetSlpLetterQuality()
        {
            //throw new NotImplementedException();
            return device.SlpLetterQuality;
        }

        public void SetSlpLetterQuality(bool SlpLetterQuality)
        {
            //throw new NotImplementedException();
            device.SlpLetterQuality = SlpLetterQuality;
        }

        public bool GetSlpEmpty()
        {
            //throw new NotImplementedException();
            return device.SlpEmpty;
        }

        public bool GetSlpNearEnd()
        {
            //throw new NotImplementedException();
            return device.SlpNearEnd;
        }

        public int GetSlpSidewaysMaxLines()
        {
            //throw new NotImplementedException();
            return device.SlpSidewaysMaxLines;
        }

        public int GetSlpSidewaysMaxChars()
        {
            //throw new NotImplementedException();
            return device.SlpSidewaysMaxChars;
        }

        public int GetSlpMaxLines()
        {
            //throw new NotImplementedException();
            return device.SlpMaxLines;
        }

        public int GetSlpLinesNearEndToEnd()
        {
            //throw new NotImplementedException();
            return device.SlpLinesNearEndToEnd;
        }

        public RotationList GetSlpBarCodeRotationList()
        {
            //throw new NotImplementedException();
            RotationList value = new RotationList();
            value.AddRange(from el in device.SlpBarCodeRotationList select (Rotation)Convert[el]);
            return value;
        }

        public RotationList GetSlpBitmapRotationList()
        {
            //throw new NotImplementedException();
            RotationList value = new RotationList();
            value.AddRange(from el in device.SlpBitmapRotationList select (Rotation)Convert[el]);
            return value;
        }

        public PrinterSide GetSlpPrintSide()
        {
            //throw new NotImplementedException();
            return (PrinterSide)Convert[device.SlpPrintSide];
        }

        public PrinterCartridgeStates GetSlpCartridgeState()
        {
            //throw new NotImplementedException();
            return (PrinterCartridgeStates)Convert[device.SlpCartridgeState];
        }

        public int GetSlpCurrentCartridge()
        {
            //throw new NotImplementedException();
            return (int)device.SlpCurrentCartridge;
        }

        public void SetSlpCurrentCartridge(int SlpCurrentCartridge)
        {
            //throw new NotImplementedException();
            device.SlpCurrentCartridge = (Microsoft.PointOfService.PrinterColors)SlpCurrentCartridge;
        }

        public void Open(string EndpointAddress)
        {
            //throw new NotImplementedException();
            device.Open();
            if (EndpointAddress != null)
            {
                ChannelFactory<UnifiedPOS.POSPrinterEvents.POSPrinterEvent> factory =
                    new ChannelFactory<UnifiedPOS.POSPrinterEvents.POSPrinterEvent>("POSPrinterEventPort", new EndpointAddress(EndpointAddress));
                deviceEvent = factory.CreateChannel();

                device.DirectIOEvent += new Microsoft.PointOfService.DirectIOEventHandler(device_DirectIOEvent);
                device.ErrorEvent += new Microsoft.PointOfService.DeviceErrorEventHandler(device_ErrorEvent);
                device.OutputCompleteEvent += new Microsoft.PointOfService.OutputCompleteEventHandler(device_OutputCompleteEvent);
                device.StatusUpdateEvent += new Microsoft.PointOfService.StatusUpdateEventHandler(device_StatusUpdateEvent);
            }
        }

        public void Close(string EndpointAddress)
        {
            //throw new NotImplementedException();
            device.Close();
            if (deviceEvent != null)
            {
                device.DirectIOEvent -= device_DirectIOEvent;
                device.ErrorEvent -= device_ErrorEvent;
                device.OutputCompleteEvent -= device_OutputCompleteEvent;
                device.StatusUpdateEvent -= device_StatusUpdateEvent;

                ((IClientChannel)deviceEvent).Close();
                deviceEvent = null;
            }
        }

        public void Claim(int Timeout)
        {
            //throw new NotImplementedException();
            device.Claim(Timeout);
        }

        public void Release()
        {
            //throw new NotImplementedException();
            device.Release();
        }

        public void CheckHealth(HealthCheckLevel Level)
        {
            //throw new NotImplementedException();
            device.CheckHealth((Microsoft.PointOfService.HealthCheckLevel)Convert[Level]);
        }

        public void ClearOutput()
        {
            //throw new NotImplementedException();
            device.ClearOutput();
        }

        public DirectIOData DirectIO(int Command, int Data, object Obj)
        {
            //throw new NotImplementedException();
            Microsoft.PointOfService.DirectIOData value = device.DirectIO(Command, Data, Obj);
            return new DirectIOData() { Data = value.Data, Obj = value.Object };
        }

        public CompareFirmwareResult CompareFirmwareVersion(string FirmwareFileName)
        {
            //throw new NotImplementedException();
            return (CompareFirmwareResult)Convert[device.CompareFirmwareVersion(FirmwareFileName)];
        }

        public void ResetStatistics(StatisticList StatisticsBuffer)
        {
            //throw new NotImplementedException();
            var value = from el in StatisticsBuffer select el.Name;
            switch (value.Count())
            {
                case 0:
                    device.ResetStatistics();
                    break;
                case 1:
                    string name = value.First();
                    switch (name)
                    {
                        case StatisticCategories.All:
                            device.ResetStatistics(Microsoft.PointOfService.StatisticCategories.All);
                            break;
                        case StatisticCategories.Manufacturer:
                            device.ResetStatistics(Microsoft.PointOfService.StatisticCategories.Manufacturer);
                            break;
                        case StatisticCategories.Upos:
                            device.ResetStatistics(Microsoft.PointOfService.StatisticCategories.Upos);
                            break;
                        default:
                            device.ResetStatistic(name);
                            break;
                    }
                    break;
                default:
                    device.ResetStatistics(value.ToArray());
                    break;
            }
        }

        public string RetrieveStatistics(StatisticList StatisticsBuffer)
        {
            //throw new NotImplementedException();
            string res = null;
            var value = from el in StatisticsBuffer select el.Name;
            switch (value.Count())
            {
                case 0:
                    res = device.RetrieveStatistics();
                    break;
                case 1:
                    string name = value.First();
                    switch (name)
                    {
                        case StatisticCategories.All:
                            res = device.RetrieveStatistics(Microsoft.PointOfService.StatisticCategories.All);
                            break;
                        case StatisticCategories.Manufacturer:
                            res = device.RetrieveStatistics(Microsoft.PointOfService.StatisticCategories.Manufacturer);
                            break;
                        case StatisticCategories.Upos:
                            res = device.RetrieveStatistics(Microsoft.PointOfService.StatisticCategories.Upos);
                            break;
                        default:
                            res = device.RetrieveStatistic(name);
                            break;
                    }
                    break;
                default:
                    res = device.RetrieveStatistics(value.ToArray());
                    break;
            }
            return res;
        }

        public void UpdateFirmware(string FirmwareFileName)
        {
            //throw new NotImplementedException();
            device.UpdateFirmware(FirmwareFileName);
        }

        public void UpdateStatistics(StatisticList StatisticsBuffer)
        {
            //throw new NotImplementedException();
            var value = from el in StatisticsBuffer select new Microsoft.PointOfService.Statistic(el.Name, el.Value);
            switch (value.Count())
            {
                case 0:
                    device.UpdateStatistics(value.ToArray());
                    break;
                case 1:
                    Microsoft.PointOfService.Statistic statistic = value.First();
                    switch (statistic.Name)
                    {
                        case StatisticCategories.All:
                            device.UpdateStatistics(Microsoft.PointOfService.StatisticCategories.All, statistic.Value);
                            break;
                        case StatisticCategories.Manufacturer:
                            device.UpdateStatistics(Microsoft.PointOfService.StatisticCategories.Manufacturer, statistic.Value);
                            break;
                        case StatisticCategories.Upos:
                            device.UpdateStatistics(Microsoft.PointOfService.StatisticCategories.Upos, statistic.Value);
                            break;
                        default:
                            device.UpdateStatistic(statistic.Name, statistic.Value);
                            break;
                    }
                    break;
                default:
                    device.UpdateStatistics(value.ToArray());
                    break;
            }
        }

        public void BeginInsertion(int Timeout)
        {
            //throw new NotImplementedException();
            device.BeginInsertion(Timeout);
        }

        public void BeginRemoval(int Timeout)
        {
            //throw new NotImplementedException();
            device.BeginRemoval(Timeout);
        }

        public void ChangePrintSide(PrinterSide Side)
        {
            //throw new NotImplementedException();
            device.ChangePrintSide((Microsoft.PointOfService.PrinterSide)Convert[Side]);
        }

        public void ClearPrintArea()
        {
            //throw new NotImplementedException();
            device.ClearPrintArea();
        }

        public void CutPaper(int Percentage)
        {
            //throw new NotImplementedException();
            device.CutPaper(Percentage);
        }

        public void DrawRuledLine(PrinterStation Station, PositionList PositionList, int LineDirection, int LineWidth, PrinterLineStyle LineStyle, int LineColor)
        {
            //throw new NotImplementedException();
            throw new FaultException<UposException>(new UposException() { ErrorCode = ErrorCode.Illegal }, "The printer does not support drawing ruled lines.", new FaultCode("Server"));
        }

        public void EndInsertion()
        {
            //throw new NotImplementedException();
            device.EndInsertion();
        }

        public void EndRemoval()
        {
            //throw new NotImplementedException();
            device.EndRemoval();
        }

        public void MarkFeed(int Type)
        {
            //throw new NotImplementedException();
            device.MarkFeed((Microsoft.PointOfService.PrinterMarkFeeds)Type);
        }

        public void PageModePrint(PageModePrintControl Control)
        {
            //throw new NotImplementedException();
            device.PageModePrint((Microsoft.PointOfService.PageModePrintControl)Convert[Control]);
        }

        public void PrintBarCode(PrinterStation Station, string Data, int Symbology, int Height, int Width, int Alignment, BarCodeTextPosition TextPosition)
        {
            //throw new NotImplementedException();
            device.PrintBarCode((Microsoft.PointOfService.PrinterStation)Convert[Station], Data, (Microsoft.PointOfService.BarCodeSymbology)Symbology, Height, Width, Alignment, (Microsoft.PointOfService.BarCodeTextPosition)Convert[TextPosition]);
        }

        public void PrintBitmap(PrinterStation Station, string FileName, int Width, int Alignment)
        {
            //throw new NotImplementedException();
            device.PrintBitmap((Microsoft.PointOfService.PrinterStation)Convert[Station], FileName, Width, Alignment);
        }

        public void PrintImmediate(PrinterStation Station, string Data)
        {
            //throw new NotImplementedException();
            device.PrintImmediate((Microsoft.PointOfService.PrinterStation)Convert[Station], ProcessEscapeSequence(Data));
        }

        public void PrintMemoryBitmap(PrinterStation Station, byte[] Data, BitmapType type, int Width, int Alignment)
        {
            //throw new NotImplementedException();
            System.Drawing.Bitmap value = new System.Drawing.Bitmap(new System.IO.MemoryStream(Data));
            device.PrintMemoryBitmap((Microsoft.PointOfService.PrinterStation)Convert[Station], value, Width, Alignment);
        }

        public void PrintNormal(PrinterStation Station, string Data)
        {
            //throw new NotImplementedException();
            device.PrintNormal((Microsoft.PointOfService.PrinterStation)Convert[Station], ProcessEscapeSequence(Data));
        }

        public void PrintTwoNormal(PrinterStation Station, string Data1, string Data2)
        {
            //throw new NotImplementedException();
            device.PrintTwoNormal((Microsoft.PointOfService.PrinterStation)Convert[Station], ProcessEscapeSequence(Data1), ProcessEscapeSequence(Data2));
        }

        public void RotatePrint(PrinterStation Station, int Rotation)
        {
            //throw new NotImplementedException();
            device.RotatePrint((Microsoft.PointOfService.PrinterStation)Convert[Station], (Microsoft.PointOfService.PrintRotation)Rotation);
        }

        public void SetBitmap(int BitmapNumber, PrinterStation Station, string FileName, int Width, int Alignment)
        {
            //throw new NotImplementedException();
            device.SetBitmap(BitmapNumber, (Microsoft.PointOfService.PrinterStation)Convert[Station], FileName, Width, Alignment);
        }

        public void SetLogo(PrinterLogoLocation Location, string Data)
        {
            //throw new NotImplementedException();
            device.SetLogo((Microsoft.PointOfService.PrinterLogoLocation)Convert[Location], ProcessEscapeSequence(Data));
        }

        public void TransactionPrint(PrinterStation Station, PrinterTransactionControl Control)
        {
            //throw new NotImplementedException();
            device.TransactionPrint((Microsoft.PointOfService.PrinterStation)Convert[Station], (Microsoft.PointOfService.PrinterTransactionControl)Convert[Control]);
        }

        public void ValidateData(PrinterStation Station, string Data)
        {
            //throw new NotImplementedException();
            device.ValidateData((Microsoft.PointOfService.PrinterStation)Convert[Station], ProcessEscapeSequence(Data));
        }

        #endregion

        #region POSPrinterEvent Member

        private void device_DirectIOEvent(object sender, Microsoft.PointOfService.DirectIOEventArgs e)
        {
            //throw new NotImplementedException();
            if (deviceEvent != null)
            {
                UnifiedPOS.POSPrinterEvents.DirectIOData value = deviceEvent.DirectIOEvent(sender.ToString(), e.EventId, e.TimeStamp, e.EventNumber, e.Data, e.Object);
                e.Data = value.Data;
                e.Object = value.Obj;
            }
        }

        private void device_ErrorEvent(object sender, Microsoft.PointOfService.DeviceErrorEventArgs e)
        {
            //throw new NotImplementedException();
            if (deviceEvent != null)
            {
                UnifiedPOS.POSPrinterEvents.ErrorResponse value = deviceEvent.ErrorEvent(sender.ToString(), e.EventId, e.TimeStamp, (UnifiedPOS.POSPrinterEvents.ErrorCode)EventConvert[e.ErrorCode], e.ErrorCodeExtended, (UnifiedPOS.POSPrinterEvents.ErrorLocus)EventConvert[e.ErrorLocus], (UnifiedPOS.POSPrinterEvents.ErrorResponse)EventConvert[e.ErrorResponse]);
                e.ErrorResponse = (Microsoft.PointOfService.ErrorResponse)EventConvert[value];
            }
        }

        private void device_OutputCompleteEvent(object sender, Microsoft.PointOfService.OutputCompleteEventArgs e)
        {
            //throw new NotImplementedException();
            if (deviceEvent != null)
            {
                deviceEvent.OutputCompleteEvent(sender.ToString(), e.EventId, e.TimeStamp, e.OutputId);
            }
        }

        private void device_StatusUpdateEvent(object sender, Microsoft.PointOfService.StatusUpdateEventArgs e)
        {
            //throw new NotImplementedException();
            if (deviceEvent != null)
            {
                deviceEvent.StatusUpdateEvent(sender.ToString(), e.EventId, e.TimeStamp, e.Status);
            }
        }

        #endregion

        #region IDisposable Member

        public void Dispose()
        {
            //throw new NotImplementedException();
            if (device != null)
            {
                try
                {
                    device.Close();
                }
                catch
                {
                }
                finally
                {
                    device = null;
                }
            }
            if (deviceEvent != null)
            {
                try
                {
                    ((IClientChannel)deviceEvent).Close();
                }
                catch
                {
                }
                finally
                {
                    deviceEvent = null;
                }
            }
        }

        #endregion

    }
}