
package org.nrf_arts.unifiedpos.beltevents;

public class Status {

    public static final int AUTO_STOP = 11;
    public static final int EMERGENCY_STOP = 12;
    public static final int LIGHT_BARRIER_BACKWARD_INTERRUPTED = 17;
    public static final int LIGHT_BARRIER_BACKWARD_OK = 18;
    public static final int LIGHT_BARRIER_FORWARD_INTERRUPTED = 19;
    public static final int LIGHT_BARRIER_FORWARD_OK = 20;
    public static final int MOTOR_FUSE_DEFECT = 16;
    public static final int MOTOR_OVERHEATING = 15;
    public static final int POWER_OFF = 2002;
    public static final int POWER_OFFLINE = 2003;
    public static final int POWER_OFF_OFFLINE = 2004;
    public static final int POWER_ONLINE = 2001;
    public static final int SAFETY_STOP = 13;
    public static final int SECURITY_FLAP_BACKWARD_CLOSED = 22;
    public static final int SECURITY_FLAP_BACKWARD_OPENED = 21;
    public static final int SECURITY_FLAP_FORWARD_CLOSED = 24;
    public static final int SECURITY_FLAP_FORWARD_OPENED = 23;
    public static final int TIMEOUT_STOP = 14;
    public static final int UPDATE_FIRMWARE_COMPLETE = 2200;
    public static final int UPDATE_FIRMWARE_COMPLETE_DEVICE_NOT_RESTORED = 2205;
    public static final int UPDATE_FIRMWARE_FAILED_DEVICE_NEEDS_FIRMWARE = 2203;
    public static final int UPDATE_FIRMWARE_FAILED_DEVICE_OK = 2201;
    public static final int UPDATE_FIRMWARE_FAILED_DEVICE_UNKNOWN = 2204;
    public static final int UPDATE_FIRMWARE_FAILED_DEVICE_UNRECOVERABLE = 2202;
    public static final int UPDATE_FIRMWARE_PROGRESS = 2100;

}
