﻿using UnifiedPOS.LineDisplayEvents;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace Wspos
{
    [ServiceBehavior(Namespace="http://www.nrf-arts.org/UnifiedPOS/LineDisplayEvents/")]
    public class LineDisplayEventService : LineDisplayEvent
    {
        private static Dictionary<int, string> Convert = new Dictionary<int, string>()
            {
                { Status.PowerOff, "PowerOff" },
                { Status.PowerOffline, "PowerOffline" },
                { Status.PowerOffOffline, "PowerOffOffline" },
                { Status.PowerOnline, "PowerOnline" },
                { Status.UpdateFirmwareComplete, "UpdateFirmwareComplete" },
                { Status.UpdateFirmwareCompleteDeviceNotRestored, "UpdateFirmwareCompleteDeviceNotRestored" },
                { Status.UpdateFirmwareFailedDeviceNeedsFirmware, "UpdateFirmwareFailedDeviceNeedsFirmware" },
                { Status.UpdateFirmwareFailedDeviceOk, "UpdateFirmwareFailedDeviceOk" },
                { Status.UpdateFirmwareFailedDeviceUnknown, "UpdateFirmwareFailedDeviceUnknown" },
                { Status.UpdateFirmwareFailedDeviceUnrecoverable, "UpdateFirmwareFailedDeviceUnrecoverable" },
                { Status.UpdateFirmwareProgress, "UpdateFirmwareProgress" },
            };

        #region LineDisplayEvent Member

        public DirectIOData DirectIOEvent(string Source, int EventID, DateTime TimeStamp, int EventNumber, int Data, object Obj)
        {
            //throw new NotImplementedException();
            Console.WriteLine("{0}, {1}, DirectIOEvent, {2}, {3}, {4}", EventID, TimeStamp, EventNumber, Data, Obj);
            return new DirectIOData() { Data = Data, Obj = Obj };
        }

        public void StatusUpdateEvent(string Source, int EventID, DateTime TimeStamp, int Status)
        {
            //throw new NotImplementedException();
            int p = UnifiedPOS.LineDisplayEvents.Status.UpdateFirmwareProgress;
            Console.WriteLine("{0}, {1}, StatusUpdateEvent, {2}", EventID, TimeStamp, (Status > p && Status < p + 100) ? Convert[p] + " + " + (Status - p) : Convert[Status]);
        }

        #endregion
    }
}
