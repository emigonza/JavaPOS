﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace UnifiedPOS.POSPrinter
{
    [ServiceContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/")]
    public interface POSPrinter
    {

        //
        // Common Properties
        //

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetAutoDisableResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        // int GetAutoDisable();

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetAutoDisableResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        // void SetAutoDisable(int AutoDisable);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapCompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapCompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetCapCompareFirmwareVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapPowerReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapPowerReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        PowerReporting GetCapPowerReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapStatisticsReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapStatisticsReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetCapStatisticsReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapUpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapUpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetCapUpdateFirmware();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapUpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapUpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetCapUpdateStatistics();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCheckHealthText", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCheckHealthTextResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        string GetCheckHealthText();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetClaimed", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetClaimedResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetClaimed();

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetDataCount", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetDataCountResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        // int GetDataCount();

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetDataEventEnabledResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        // bool GetDataEventEnabled();

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetDataEventEnabledResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        // void SetDataEventEnabled(bool DataEventEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetDeviceEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void SetDeviceEnabled(bool DeviceEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetFreezeEvents();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void SetFreezeEvents(bool FreezeEvents);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetOutputID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetOutputIDResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        int GetOutputID();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        PowerNotification GetPowerNotify();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void SetPowerNotify(PowerNotification PowerNotify);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetPowerState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetPowerStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        PowerState GetPowerState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        ControlState GetState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetDeviceControlDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetDeviceControlDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        string GetDeviceControlDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetDeviceControlVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetDeviceControlVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        UposVersion GetDeviceControlVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetDeviceServiceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetDeviceServiceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        string GetDeviceServiceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetDeviceServiceVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetDeviceServiceVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        UposVersion GetDeviceServiceVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetPhysicalDeviceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetPhysicalDeviceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        string GetPhysicalDeviceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetPhysicalDeviceName", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetPhysicalDeviceNameResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        string GetPhysicalDeviceName();

        //
        // Specific Properties
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapCharacterSet", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapCharacterSetResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        CharacterSetCapability GetCapCharacterSet();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapConcurrentJrnRec", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapConcurrentJrnRecResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetCapConcurrentJrnRec();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapConcurrentJrnSlp", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapConcurrentJrnSlpResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetCapConcurrentJrnSlp();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapConcurrentPageMode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapConcurrentPageModeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetCapConcurrentPageMode();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapConcurrentRecSlp", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapConcurrentRecSlpResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetCapConcurrentRecSlp();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapCoverSensor", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapCoverSensorResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetCapCoverSensor();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapMapCharacterSet", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapMapCharacterSetResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetCapMapCharacterSet();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapTransaction", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapTransactionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetCapTransaction();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapJrnPresent", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapJrnPresentResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetCapJrnPresent();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapJrn2Color", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapJrn2ColorResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetCapJrn2Color();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapJrnBold", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapJrnBoldResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetCapJrnBold();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapJrnDhigh", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapJrnDhighResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetCapJrnDhigh();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapJrnDwide", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapJrnDwideResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetCapJrnDwide();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapJrnDwideDhigh", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapJrnDwideDhighResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetCapJrnDwideDhigh();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapJrnEmptySensor", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapJrnEmptySensorResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetCapJrnEmptySensor();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapJrnItalic", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapJrnItalicResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetCapJrnItalic();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapJrnNearEndSensor", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapJrnNearEndSensorResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetCapJrnNearEndSensor();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapJrnUnderline", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapJrnUnderlineResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetCapJrnUnderline();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapJrnCartridgeSensor", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapJrnCartridgeSensorResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        int GetCapJrnCartridgeSensor();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapJrnColor", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapJrnColorResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        int GetCapJrnColor();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapRecPresent", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapRecPresentResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetCapRecPresent();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapRec2Color", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapRec2ColorResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetCapRec2Color();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapRecBarCode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapRecBarCodeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetCapRecBarCode();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapRecBitmap", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapRecBitmapResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetCapRecBitmap();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapRecBold", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapRecBoldResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetCapRecBold();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapRecDhigh", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapRecDhighResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetCapRecDhigh();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapRecDwide", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapRecDwideResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetCapRecDwide();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapRecDwideDhigh", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapRecDwideDhighResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetCapRecDwideDhigh();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapRecEmptySensor", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapRecEmptySensorResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetCapRecEmptySensor();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapRecItalic", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapRecItalicResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetCapRecItalic();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapRecLeft90", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapRecLeft90Response")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetCapRecLeft90();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapRecNearEndSensor", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapRecNearEndSensorResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetCapRecNearEndSensor();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapRecPapercut", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapRecPapercutResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetCapRecPapercut();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapRecRight90", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapRecRight90Response")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetCapRecRight90();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapRecRotate180", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapRecRotate180Response")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetCapRecRotate180();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapRecStamp", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapRecStampResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetCapRecStamp();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapRecUnderline", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapRecUnderlineResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetCapRecUnderline();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapRecCartridgeSensor", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapRecCartridgeSensorResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        int GetCapRecCartridgeSensor();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapRecColor", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapRecColorResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        int GetCapRecColor();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapRecMarkFeed", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapRecMarkFeedResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        int GetCapRecMarkFeed();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapRecPageMode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapRecPageModeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetCapRecPageMode();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapRecRuledLine", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapRecRuledLineResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        int GetCapRecRuledLine();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapSlpPresent", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapSlpPresentResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetCapSlpPresent();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapSlpFullslip", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapSlpFullslipResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetCapSlpFullslip();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapSlp2Color", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapSlp2ColorResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetCapSlp2Color();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapSlpBarCode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapSlpBarCodeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetCapSlpBarCode();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapSlpBitmap", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapSlpBitmapResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetCapSlpBitmap();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapSlpBold", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapSlpBoldResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetCapSlpBold();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapSlpDhigh", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapSlpDhighResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetCapSlpDhigh();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapSlpDwide", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapSlpDwideResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetCapSlpDwide();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapSlpDwideDhigh", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapSlpDwideDhighResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetCapSlpDwideDhigh();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapSlpEmptySensor", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapSlpEmptySensorResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetCapSlpEmptySensor();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapSlpItalic", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapSlpItalicResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetCapSlpItalic();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapSlpLeft90", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapSlpLeft90Response")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetCapSlpLeft90();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapSlpNearEndSensor", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapSlpNearEndSensorResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetCapSlpNearEndSensor();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapSlpRight90", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapSlpRight90Response")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetCapSlpRight90();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapSlpRotate180", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapSlpRotate180Response")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetCapSlpRotate180();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapSlpUnderline", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapSlpUnderlineResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetCapSlpUnderline();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapSlpBothSidesPrint", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapSlpBothSidesPrintResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetCapSlpBothSidesPrint();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapSlpCartridgeSensor", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapSlpCartridgeSensorResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        int GetCapSlpCartridgeSensor();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapSlpColor", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapSlpColorResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        int GetCapSlpColor();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapSlpPageMode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapSlpPageModeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetCapSlpPageMode();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapSlpRuledLine", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCapSlpRuledLineResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        int GetCapSlpRuledLine();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetAsyncMode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetAsyncModeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetAsyncMode();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetAsyncMode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetAsyncModeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void SetAsyncMode(bool AsyncMode);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCartridgeNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCartridgeNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        PrinterCartridgeNotify GetCartridgeNotify();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetCartridgeNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetCartridgeNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void SetCartridgeNotify(PrinterCartridgeNotify CartridgeNotify);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCharacterSet", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCharacterSetResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        int GetCharacterSet();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetCharacterSet", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetCharacterSetResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void SetCharacterSet(int CharacterSet);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCharacterSetList", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCharacterSetListResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        CharacterSetList GetCharacterSetList();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCoverOpen", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetCoverOpenResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetCoverOpen();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetErrorLevel", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetErrorLevelResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        PrinterErrorLevel GetErrorLevel();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetErrorStation", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetErrorStationResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        PrinterStation GetErrorStation();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetErrorString", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetErrorStringResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        string GetErrorString();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetFontTypefaceList", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetFontTypefaceListResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        FontTypefaceList GetFontTypefaceList();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetFlagWhenIdle", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetFlagWhenIdleResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetFlagWhenIdle();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetFlagWhenIdle", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetFlagWhenIdleResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void SetFlagWhenIdle(bool FlagWhenIdle);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetMapCharacterSet", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetMapCharacterSetResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetMapCharacterSet();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetMapCharacterSet", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetMapCharacterSetResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void SetMapCharacterSet(bool MapCharacterSet);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetMapMode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetMapModeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        MapMode GetMapMode();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetMapMode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetMapModeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void SetMapMode(MapMode MapMode);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetPageModeArea", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetPageModeAreaResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        Point GetPageModeArea();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetPageModeDescriptor", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetPageModeDescriptorResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        int GetPageModeDescriptor();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetPageModeHorizontalPosition", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetPageModeHorizontalPositionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        int GetPageModeHorizontalPosition();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetPageModeHorizontalPosition", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetPageModeHorizontalPositionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void SetPageModeHorizontalPosition(int PageModeHorizontalPosition);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetPageModePrintArea", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetPageModePrintAreaResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        Rectangle GetPageModePrintArea();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetPageModePrintArea", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetPageModePrintAreaResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void SetPageModePrintArea(Rectangle PageModePrintArea);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetPageModePrintDirection", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetPageModePrintDirectionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        PageModePrintDirection GetPageModePrintDirection();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetPageModePrintDirection", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetPageModePrintDirectionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void SetPageModePrintDirection(PageModePrintDirection PageModePrintDirection);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetPageModeStation", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetPageModeStationResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        PrinterStation GetPageModeStation();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetPageModeStation", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetPageModeStationResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void SetPageModeStation(PrinterStation PageModeStation);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetPageModeVerticalPosition", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetPageModeVerticalPositionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        int GetPageModeVerticalPosition();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetPageModeVerticalPosition", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetPageModeVerticalPositionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void SetPageModeVerticalPosition(int PageModeVerticalPosition);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetRotateSpecial", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetRotateSpecialResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        Rotation GetRotateSpecial();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetRotateSpecial", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetRotateSpecialResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void SetRotateSpecial(Rotation RotateSpecial);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetJrnLineChars", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetJrnLineCharsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        int GetJrnLineChars();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetJrnLineChars", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetJrnLineCharsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void SetJrnLineChars(int JrnLineChars);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetJrnLineCharsList", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetJrnLineCharsListResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        LineCharsList GetJrnLineCharsList();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetJrnLineHeight", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetJrnLineHeightResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        int GetJrnLineHeight();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetJrnLineHeight", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetJrnLineHeightResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void SetJrnLineHeight(int JrnLineHeight);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetJrnLineSpacing", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetJrnLineSpacingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        int GetJrnLineSpacing();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetJrnLineSpacing", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetJrnLineSpacingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void SetJrnLineSpacing(int JrnLineSpacing);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetJrnLineWidth", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetJrnLineWidthResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        int GetJrnLineWidth();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetJrnLetterQuality", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetJrnLetterQualityResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetJrnLetterQuality();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetJrnLetterQuality", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetJrnLetterQualityResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void SetJrnLetterQuality(bool JrnLetterQuality);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetJrnEmpty", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetJrnEmptyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetJrnEmpty();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetJrnNearEnd", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetJrnNearEndResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetJrnNearEnd();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetJrnCartridgeState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetJrnCartridgeStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        PrinterCartridgeStates GetJrnCartridgeState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetJrnCurrentCartridge", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetJrnCurrentCartridgeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        int GetJrnCurrentCartridge();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetJrnCurrentCartridge", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetJrnCurrentCartridgeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void SetJrnCurrentCartridge(int JrnCurrentCartridge);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetRecLineChars", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetRecLineCharsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        int GetRecLineChars();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetRecLineChars", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetRecLineCharsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void SetRecLineChars(int RecLineChars);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetRecLineCharsList", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetRecLineCharsListResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        LineCharsList GetRecLineCharsList();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetRecLineHeight", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetRecLineHeightResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        int GetRecLineHeight();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetRecLineHeight", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetRecLineHeightResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void SetRecLineHeight(int RecLineHeight);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetRecLineSpacing", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetRecLineSpacingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        int GetRecLineSpacing();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetRecLineSpacing", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetRecLineSpacingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void SetRecLineSpacing(int RecLineSpacing);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetRecLineWidth", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetRecLineWidthResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        int GetRecLineWidth();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetRecLetterQuality", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetRecLetterQualityResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetRecLetterQuality();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetRecLetterQuality", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetRecLetterQualityResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void SetRecLetterQuality(bool RecLetterQuality);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetRecEmpty", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetRecEmptyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetRecEmpty();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetRecNearEnd", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetRecNearEndResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetRecNearEnd();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetRecSidewaysMaxChars", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetRecSidewaysMaxCharsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        int GetRecSidewaysMaxChars();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetRecSidewaysMaxLines", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetRecSidewaysMaxLinesResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        int GetRecSidewaysMaxLines();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetRecLinesToPaperCut", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetRecLinesToPaperCutResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        int GetRecLinesToPaperCut();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetRecBarCodeRotationList", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetRecBarCodeRotationListResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        RotationList GetRecBarCodeRotationList();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetRecBitmapRotationList", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetRecBitmapRotationListResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        RotationList GetRecBitmapRotationList();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetRecCartridgeState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetRecCartridgeStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        PrinterCartridgeStates GetRecCartridgeState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetRecCurrentCartridge", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetRecCurrentCartridgeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        int GetRecCurrentCartridge();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetRecCurrentCartridge", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetRecCurrentCartridgeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void SetRecCurrentCartridge(int RecCurrentCartridge);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetSlpLineChars", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetSlpLineCharsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        int GetSlpLineChars();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetSlpLineChars", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetSlpLineCharsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void SetSlpLineChars(int SlpLineChars);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetSlpLineCharsList", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetSlpLineCharsListResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        LineCharsList GetSlpLineCharsList();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetSlpLineHeight", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetSlpLineHeightResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        int GetSlpLineHeight();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetSlpLineHeight", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetSlpLineHeightResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void SetSlpLineHeight(int SlpLineHeight);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetSlpLineSpacing", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetSlpLineSpacingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        int GetSlpLineSpacing();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetSlpLineSpacing", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetSlpLineSpacingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void SetSlpLineSpacing(int SlpLineSpacing);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetSlpLineWidth", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetSlpLineWidthResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        int GetSlpLineWidth();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetSlpLetterQuality", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetSlpLetterQualityResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetSlpLetterQuality();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetSlpLetterQuality", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetSlpLetterQualityResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void SetSlpLetterQuality(bool SlpLetterQuality);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetSlpEmpty", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetSlpEmptyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetSlpEmpty();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetSlpNearEnd", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetSlpNearEndResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        bool GetSlpNearEnd();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetSlpSidewaysMaxLines", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetSlpSidewaysMaxLinesResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        int GetSlpSidewaysMaxLines();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetSlpSidewaysMaxChars", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetSlpSidewaysMaxCharsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        int GetSlpSidewaysMaxChars();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetSlpMaxLines", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetSlpMaxLinesResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        int GetSlpMaxLines();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetSlpLinesNearEndToEnd", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetSlpLinesNearEndToEndResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        int GetSlpLinesNearEndToEnd();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetSlpBarCodeRotationList", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetSlpBarCodeRotationListResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        RotationList GetSlpBarCodeRotationList();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetSlpBitmapRotationList", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetSlpBitmapRotationListResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        RotationList GetSlpBitmapRotationList();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetSlpPrintSide", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetSlpPrintSideResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        PrinterSide GetSlpPrintSide();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetSlpCartridgeState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetSlpCartridgeStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        PrinterCartridgeStates GetSlpCartridgeState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetSlpCurrentCartridge", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/GetSlpCurrentCartridgeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        int GetSlpCurrentCartridge();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetSlpCurrentCartridge", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetSlpCurrentCartridgeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void SetSlpCurrentCartridge(int SlpCurrentCartridge);

        //
        // Common Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/Open", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/OpenResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void Open(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/Close", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/CloseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void Close(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/Claim", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/ClaimResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void Claim(int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/Release", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/ReleaseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void Release();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/CheckHealth", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/CheckHealthResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void CheckHealth(HealthCheckLevel Level);

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/ClearInput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/ClearInputResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        // void ClearInput();

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/ClearInputProperties", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/ClearInputPropertiesResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        // void ClearInputProperties();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/ClearOutput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/ClearOutputResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void ClearOutput();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/DirectIO", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/DirectIOResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        DirectIOData DirectIO(int Command, int Data, object Obj);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/CompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/CompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        CompareFirmwareResult CompareFirmwareVersion(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/ResetStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/ResetStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void ResetStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/RetrieveStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/RetrieveStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        string RetrieveStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void UpdateFirmware(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void UpdateStatistics(StatisticList StatisticsBuffer);

        //
        // Specific Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/BeginInsertion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/BeginInsertionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void BeginInsertion(int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/BeginRemoval", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/BeginRemovalResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void BeginRemoval(int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/ChangePrintSide", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/ChangePrintSideResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void ChangePrintSide(PrinterSide Side);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/ClearPrintArea", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/ClearPrintAreaResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void ClearPrintArea();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/CutPaper", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/CutPaperResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void CutPaper(int Percentage);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/DrawRuledLine", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/DrawRuledLineResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void DrawRuledLine(PrinterStation Station, PositionList PositionList, int LineDirection, int LineWidth, PrinterLineStyle LineStyle, int LineColor);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/EndInsertion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/EndInsertionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void EndInsertion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/EndRemoval", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/EndRemovalResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void EndRemoval();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/MarkFeed", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/MarkFeedResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void MarkFeed(int Type);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/PageModePrint", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/PageModePrintResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void PageModePrint(PageModePrintControl Control);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/PrintBarCode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/PrintBarCodeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void PrintBarCode(PrinterStation Station, string Data, int Symbology, int Height, int Width, int Alignment, BarCodeTextPosition TextPosition);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/PrintBitmap", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/PrintBitmapResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void PrintBitmap(PrinterStation Station, string FileName, int Width, int Alignment);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/PrintImmediate", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/PrintImmediateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void PrintImmediate(PrinterStation Station, string Data);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/PrintMemoryBitmap", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/PrintMemoryBitmapResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void PrintMemoryBitmap(PrinterStation Station, byte[] Data, BitmapType Type, int Width, int Alignment);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/PrintNormal", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/PrintNormalResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void PrintNormal(PrinterStation Station, string Data);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/PrintTwoNormal", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/PrintTwoNormalResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void PrintTwoNormal(PrinterStation Station, string Data1, string Data2);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/RotatePrint", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/RotatePrintResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void RotatePrint(PrinterStation Station, int Rotation);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetBitmap", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetBitmapResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void SetBitmap(int BitmapNumber, PrinterStation Station, string FileName, int Width, int Alignment);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetLogo", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/SetLogoResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void SetLogo(PrinterLogoLocation Location, string Data);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/TransactionPrint", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/TransactionPrintResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void TransactionPrint(PrinterStation Station, PrinterTransactionControl Control);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/ValidateData", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/ValidateDataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/UposException", Name = "UposException")]
        void ValidateData(PrinterStation Station, string Data);
    }

    //
    // Common Data Types
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/")]
    public class DirectIOData
    {
        [DataMember]
        public int Data { get; set; }
        [DataMember]
        public object Obj { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/")]
    public class UposException
    {
        [DataMember]
        public ErrorCode ErrorCode { get; set; }
        [DataMember]
        public int ErrorCodeExtended { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/")]
    public class UposVersion
    {
        [DataMember]
        public int Major { get; set; }
        [DataMember]
        public int Minor { get; set; }
        [DataMember]
        public int Build { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/")]
    public class Statistic
    {
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public string Value { get; set; }
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/", ItemName = "Statistic")]
    public class StatisticList : List<Statistic>
    {
    }

    //
    // Common Enumerations
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/")]
    public enum CompareFirmwareResult
    {
        [EnumMember]
        Different,
        [EnumMember]
        Newer,
        [EnumMember]
        Older,
        [EnumMember]
        Same,
        [EnumMember]
        Unknown,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/")]
    public enum ControlState
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Closed,
        [EnumMember]
        Error,
        [EnumMember]
        Idle,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/")]
    public enum ErrorCode
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Claimed,
        [EnumMember]
        Closed,
        [EnumMember]
        Deprecated,
        [EnumMember]
        Disabled,
        [EnumMember]
        Exists,
        [EnumMember]
        Extended,
        [EnumMember]
        Failure,
        [EnumMember]
        Illegal,
        [EnumMember]
        NoExist,
        [EnumMember]
        NoHardware,
        [EnumMember]
        NoService,
        [EnumMember]
        NotClaimed,
        [EnumMember]
        Offline,
        [EnumMember]
        Success,
        [EnumMember]
        Timeout,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/")]
    public enum HealthCheckLevel
    {
        [EnumMember]
        External,
        [EnumMember]
        Interactive,
        [EnumMember]
        Internal,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/")]
    public enum PowerNotification
    {
        [EnumMember]
        Disabled,
        [EnumMember]
        Enabled,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/")]
    public enum PowerReporting
    {
        [EnumMember]
        Advanced,
        [EnumMember]
        None,
        [EnumMember]
        Standard,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/")]
    public enum PowerState
    {
        [EnumMember]
        Off,
        [EnumMember]
        Offline,
        [EnumMember]
        OffOffline,
        [EnumMember]
        Online,
        [EnumMember]
        Unknown,
    }

    /*
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/")]
    public enum StatisticCategories
    {
        [EnumMember]
        All,
        [EnumMember]
        Manufacturer,
        [EnumMember]
        Upos,
    }
    */
    public class StatisticCategories
    {
        public const string All = "";
        public const string Manufacturer = "M_";
        public const string Upos = "U_";
    }

    //
    // Specific Data Types
    //

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/", ItemName = "CharacterSet")]
    public class CharacterSetList : List<int>
    {
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/", ItemName = "FontTypeface")]
    public class FontTypefaceList : List<string>
    {
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/", ItemName = "LineChars")]
    public class LineCharsList : List<int>
    {
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/")]
    public class Point
    {
        [DataMember]
        public int X { get; set; }
        [DataMember]
        public int Y { get; set; }
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/", ItemName = "Position")]
    public class PositionList : List<int>
    {
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/")]
    public class Rectangle
    {
        [DataMember]
        public int Height { get; set; }
        [DataMember]
        public int Width { get; set; }
        [DataMember]
        public int X { get; set; }
        [DataMember]
        public int Y { get; set; }
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/", ItemName = "Rotation")]
    public class RotationList : List<Rotation>
    {
    }

    //
    // Specific Enumerations
    //

    /*
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/")]
    public enum BarCodeSymbology
    {
        [EnumMember]
        Aztec,
        [EnumMember]
        Cca,
        [EnumMember]
        Ccb,
        [EnumMember]
        Ccc,
        [EnumMember]
        Codabar,
        [EnumMember]
        Code128,
        [EnumMember]
        Code128Parsed,
        [EnumMember]
        Code39,
        [EnumMember]
        Code93,
        [EnumMember]
        DataMatrix,
        [EnumMember]
        Ean128,
        [EnumMember]
        Ean13S,
        [EnumMember]
        Ean8S,
        [EnumMember]
        EanJan13,
        [EnumMember]
        EanJan8,
        [EnumMember]
        Gs1DataBar,
        [EnumMember]
        Gs1DataBarExpanded,
        [EnumMember]
        Gs1DataBarExpandedStacked,
        [EnumMember]
        Gs1DataBarStackedOmnidirectional,
        [EnumMember]
        Itf,
        [EnumMember]
        Maxicode,
        [EnumMember]
        MicroPDF417,
        [EnumMember]
        MicroQRCode,
        [EnumMember]
        Ocra,
        [EnumMember]
        Ocrb,
        [EnumMember]
        Other,
        [EnumMember]
        Pdf417,
        [EnumMember]
        QRCode,
        [EnumMember]
        Rss14,
        [EnumMember]
        RssExpanded,
        [EnumMember]
        TF,
        [EnumMember]
        Unknown,
        [EnumMember]
        Upca,
        [EnumMember]
        Upcas,
        [EnumMember]
        Upcd1,
        [EnumMember]
        Upcd2,
        [EnumMember]
        Upcd3,
        [EnumMember]
        Upcd4,
        [EnumMember]
        Upcd5,
        [EnumMember]
        Upce,
        [EnumMember]
        Upces,
    }
    */
    public class BarCodeSymbology
    {
        public const int Aztec = 206;
        public const int Cca = 151;
        public const int Ccb = 152;
        public const int Ccc = 153;
        public const int Codabar = 107;
        public const int Code128 = 110;
        public const int Code128Parsed = 123;
        public const int Code39 = 108;
        public const int Code93 = 109;
        public const int DataMatrix = 203;
        public const int Ean128 = 120;
        public const int Ean13S = 119;
        public const int Ean8S = 118;
        public const int EanJan13 = 104;
        public const int EanJan8 = 103;
        public const int Gs1DataBar = 131;
        public const int Gs1DataBarExpanded = 132;
        public const int Gs1DataBarExpandedStacked = 134;
        public const int Gs1DataBarStackedOmnidirectional = 133;
        public const int Itf = 106;
        public const int Maxicode = 202;
        public const int MicroPDF417 = 207;
        public const int MicroQRCode = 205;
        public const int Ocra = 121;
        public const int Ocrb = 122;
        public const int Other = 501;
        public const int Pdf417 = 201;
        public const int QRCode = 204;
        public const int Rss14 = 131;
        public const int RssExpanded = 132;
        public const int TF = 105;
        public const int Unknown = 0;
        public const int Upca = 101;
        public const int Upcas = 111;
        public const int Upcd1 = 113;
        public const int Upcd2 = 114;
        public const int Upcd3 = 115;
        public const int Upcd4 = 116;
        public const int Upcd5 = 117;
        public const int Upce = 102;
        public const int Upces = 112;
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/")]
    public enum BarCodeTextPosition
    {
        [EnumMember]
        Above,
        [EnumMember]
        Below,
        [EnumMember]
        None,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/")]
    public enum BitmapType
    {
        [EnumMember]
        Bmp,
        [EnumMember]
        Gif,
        [EnumMember]
        Jpeg,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/")]
    public enum CharacterSetCapability
    {
        [EnumMember]
        Alpha,
        [EnumMember]
        Ascii,
        [EnumMember]
        Kana,
        [EnumMember]
        Kanji,
        [EnumMember]
        Unicode,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/")]
    public enum MapMode
    {
        [EnumMember]
        Dots,
        [EnumMember]
        English,
        [EnumMember]
        Metric,
        [EnumMember]
        Twips,
    }

    /*
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/")]
    public enum PageModeDescriptors
    {
        [EnumMember]
        Barcode,
        [EnumMember]
        BarcodeRotate,
        [EnumMember]
        Bitmap,
        [EnumMember]
        BitmapRotate,
        [EnumMember]
        None,
        [EnumMember]
        Opaque,
    }
    */
    public class PageModeDescriptors
    {
        public const int Barcode = 2;
        public const int BarcodeRotate = 8;
        public const int Bitmap = 1;
        public const int BitmapRotate = 4;
        public const int None = 0;
        public const int Opaque = 16;
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/")]
    public enum PageModePrintControl
    {
        [EnumMember]
        Cancel,
        [EnumMember]
        Normal,
        [EnumMember]
        PageMode,
        [EnumMember]
        PrintSave,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/")]
    public enum PageModePrintDirection
    {
        [EnumMember]
        BottomToTop,
        [EnumMember]
        LeftToRight,
        [EnumMember]
        None,
        [EnumMember]
        RightToLeft,
        [EnumMember]
        TopToBottom,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/")]
    public enum PrinterCartridgeNotify
    {
        [EnumMember]
        Disabled,
        [EnumMember]
        Enabled,
    }

    /*
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/")]
    public enum PrinterCartridgeSensors
    {
        [EnumMember]
        Cleaning,
        [EnumMember]
        Empty,
        [EnumMember]
        NearEnd,
        [EnumMember]
        None,
        [EnumMember]
        Removed,
    }
    */
    public class PrinterCartridgeSensors
    {
        public const int Cleaning = 8;
        public const int Empty = 2;
        public const int NearEnd = 4;
        public const int None = 0;
        public const int Removed = 1;
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/")]
    public enum PrinterCartridgeStates
    {
        [EnumMember]
        Cleaning,
        [EnumMember]
        Empty,
        [EnumMember]
        NearEnd,
        [EnumMember]
        OK,
        [EnumMember]
        Removed,
        [EnumMember]
        Unknown,
    }

    /*    
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/")]
    public enum PrinterColors
    {
        [EnumMember]
        Custom1,
        [EnumMember]
        Custom2,
        [EnumMember]
        Custom3,
        [EnumMember]
        Custom4,
        [EnumMember]
        Custom5,
        [EnumMember]
        Custom6,
        [EnumMember]
        Cyan,
        [EnumMember]
        Full,
        [EnumMember]
        Magenta,
        [EnumMember]
        None,
        [EnumMember]
        Primary,
        [EnumMember]
        Yellow,
    }
    */
    public class PrinterColors
    {
        public const int Custom1 = 2;
        public const int Custom2 = 4;
        public const int Custom3 = 8;
        public const int Custom4 = 16;
        public const int Custom5 = 32;
        public const int Custom6 = 64;
        public const int Cyan = 256;
        public const int Full = -2147483648;
        public const int Magenta = 512;
        public const int None = 0;
        public const int Primary = 1;
        public const int Yellow = 1024;
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/")]
    public enum PrinterErrorLevel
    {
        [EnumMember]
        Fatal,
        [EnumMember]
        None,
        [EnumMember]
        Recoverable,
    }

    /*
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/")]
    public enum PrinterLineDirection
    {
        [EnumMember]
        Horizontal,
        [EnumMember]
        None,
        [EnumMember]
        Vertical,
    }
    */
    public class PrinterLineDirection
    {
        public const int Horizontal = 1;
        public const int None = 0;
        public const int Vertical = 2;
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/")]
    public enum PrinterLineStyle
    {
        [EnumMember]
        BrokenLine,
        [EnumMember]
        ChainLine,
        [EnumMember]
        DoubleSolidLine,
        [EnumMember]
        SingleSolidLine,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/")]
    public enum PrinterLogoLocation
    {
        [EnumMember]
        Bottom,
        [EnumMember]
        Top,
    }

    /*
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/")]
    public enum PrinterMarkFeeds
    {
        [EnumMember]
        CurrentTopOfForm,
        [EnumMember]
        Cutter,
        [EnumMember]
        NextTopOfForm,
        [EnumMember]
        None,
        [EnumMember]
        Takeup,
    }
    */
    public class PrinterMarkFeeds
    {
        public const int CurrentTopOfForm = 4;
        public const int Cutter = 2;
        public const int NextTopOfForm = 8;
        public const int None = 0;
        public const int Takeup = 1;
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/")]
    public enum PrinterSide
    {
        [EnumMember]
        Opposite,
        [EnumMember]
        Side1,
        [EnumMember]
        Side2,
        [EnumMember]
        Unknown,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/")]
    public enum PrinterStation
    {
        [EnumMember]
        Journal,
        [EnumMember]
        None,
        [EnumMember]
        Receipt,
        [EnumMember]
        Slip,
        [EnumMember]
        TwoReceiptJournal,
        [EnumMember]
        TwoSlipJournal,
        [EnumMember]
        TwoSlipReceipt,
    }

    /*
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/")]
    public enum PrintRotation
    {
        [EnumMember]
        Barcode,
        [EnumMember]
        Bitmap,
        [EnumMember]
        Left90,
        [EnumMember]
        Normal,
        [EnumMember]
        Right90,
        [EnumMember]
        Rotate180,
    }
    */
    public class PrintRotation
    {
        public const int Barcode = 4096;
        public const int Bitmap = 8192;
        public const int Left90 = 258;
        public const int Normal = 1;
        public const int Right90 = 257;
        public const int Rotate180 = 259;
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/")]
    public enum PrinterTransactionControl
    {
        [EnumMember]
        Normal,
        [EnumMember]
        Transaction,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/")]
    public enum Rotation
    {
        [EnumMember]
        Left90,
        [EnumMember]
        Normal,
        [EnumMember]
        Right90,
        [EnumMember]
        Rotate180,
    }

    //
    // Constants
    //

    /*
    public class Constants
    {
        public const int CharacterSetAnsi = 999;
        public const int CharacterSetAscii = 998;
        public const int CharacterSetUnicode = 997;
        public const int ExtendedErrorBadFormat = 207;
        public const int ExtendedErrorCoverOpen = 201;
        public const int ExtendedErrorFirmwareBadFile = 281;
        public const int ExtendedErrorJournalCartridgeEmpty = 209;
        public const int ExtendedErrorJournalCartridgeRemoved = 208;
        public const int ExtendedErrorJournalEmpty = 202;
        public const int ExtendedErrorJournalHeadCleaning = 210;
        public const int ExtendedErrorReceiptCartridgeEmpty = 212;
        public const int ExtendedErrorReceiptCartridgeRemoved = 211;
        public const int ExtendedErrorReceiptEmpty = 203;
        public const int ExtendedErrorReceiptHeadCleaning = 213;
        public const int ExtendedErrorSlipCartridgeEmpty = 215;
        public const int ExtendedErrorSlipCartridgeRemoved = 214;
        public const int ExtendedErrorSlipEmpty = 204;
        public const int ExtendedErrorSlipForm = 205;
        public const int ExtendedErrorSlipHeadCleaning = 216;
        public const int ExtendedErrorStatistics = 280;
        public const int ExtendedErrorStatisticsDependency = 282;
        public const int ExtendedErrorTooBig = 206;
        public const int PrinterBarCodeCenter = -2;
        public const int PrinterBarCodeLeft = -1;
        public const int PrinterBarCodeRight = -3;
        public const int PrinterBitmapAsIs = -11;
        public const int PrinterBitmapCenter = -2;
        public const int PrinterBitmapLeft = -1;
        public const int PrinterBitmapRight = -3;
        public const int PrinterCutPaperFullCut = 100;
        public const string StatisticCommunicationErrorCount = "CommunicationErrorCount";
        public const string StatisticDeviceCategory = "DeviceCategory";
        public const string StatisticFirmwareRevision = "FirmwareRevision";
        public const string StatisticHoursPoweredCount = "HoursPoweredCount";
        public const string StatisticInstallationDate = "InstallationDate";
        public const string StatisticInterface = "Interface";
        public const string StatisticManufactureDate = "ManufactureDate";
        public const string StatisticManufacturerName = "ManufacturerName";
        public const string StatisticMechanicalRevision = "MechanicalRevision";
        public const string StatisticModelName = "ModelName";
        public const string StatisticSerialNumber = "SerialNumber";
        public const string StatisticUnifiedPOSVersion = "UnifiedPOSVersion";
        public const string StatisticBarcodePrintedCount = "BarcodePrintedCount";
        public const string StatisticFailedPaperCutCount = "FailedPaperCutCount";
        public const string StatisticFailedPrintSideChangeCount = "FailedPrintSideChangeCount";
        public const string StatisticFormInsertionCount = "FormInsertionCount";
        public const string StatisticHomeErrorCount = "HomeErrorCount";
        public const string StatisticJournalCharacterPrintedCount = "JournalCharacterPrintedCount";
        public const string StatisticJournalCoverOpenCount = "JournalCoverOpenCount";
        public const string StatisticJournalLinePrintedCount = "JournalLinePrintedCount";
        public const string StatisticMaximumTempReachedCount = "MaximumTempReachedCount";
        public const string StatisticNVRAMWriteCount = "NVRAMWriteCount";
        public const string StatisticPaperCutCount = "PaperCutCount";
        public const string StatisticPrinterFaultCount = "PrinterFaultCount";
        public const string StatisticPrintSideChangeCount = "PrintSideChangeCount";
        public const string StatisticReceiptCharacterPrintedCount = "ReceiptCharacterPrintedCount";
        public const string StatisticReceiptCoverOpenCount = "ReceiptCoverOpenCount";
        public const string StatisticReceiptLineFeedCount = "ReceiptLineFeedCount";
        public const string StatisticReceiptLinePrintedCount = "ReceiptLinePrintedCount";
        public const string StatisticSlipCharacterPrintedCount = "SlipCharacterPrintedCount";
        public const string StatisticSlipCoverOpenCount = "SlipCoverOpenCount";
        public const string StatisticSlipLineFeedCount = "SlipLineFeedCount";
        public const string StatisticSlipLinePrintedCount = "SlipLinePrintedCount";
        public const string StatisticStampFiredCount = "StampFiredCount";
        public const int WaitForever = -1;
    }
    */

    public class CharacterSet
    {
        public const int Ansi = 999;
        public const int Ascii = 998;
        public const int Unicode = 997;
    }

    public class ExtendedError
    {
        public const int BadFormat = 207;
        public const int CoverOpen = 201;
        public const int FirmwareBadFile = 281;
        public const int JournalCartridgeEmpty = 209;
        public const int JournalCartridgeRemoved = 208;
        public const int JournalEmpty = 202;
        public const int JournalHeadCleaning = 210;
        public const int ReceiptCartridgeEmpty = 212;
        public const int ReceiptCartridgeRemoved = 211;
        public const int ReceiptEmpty = 203;
        public const int ReceiptHeadCleaning = 213;
        public const int SlipCartridgeEmpty = 215;
        public const int SlipCartridgeRemoved = 214;
        public const int SlipEmpty = 204;
        public const int SlipForm = 205;
        public const int SlipHeadCleaning = 216;
        public const int Statistics = 280;
        public const int StatisticsDependency = 282;
        public const int TooBig = 206;
    }

    public class PrinterBarCode
    {
        public const int Center = -2;
        public const int Left = -1;
        public const int Right = -3;
    }

    public class PrinterBitmap
    {
        public const int AsIs = -11;
        public const int Center = -2;
        public const int Left = -1;
        public const int Right = -3;
    }

    public class PrinterCutPaper
    {
        public const int FullCut = 100;
    }

    public class StatisticProperties
    {
        public const string CommunicationErrorCount = "CommunicationErrorCount";
        public const string DeviceCategory = "DeviceCategory";
        public const string FirmwareRevision = "FirmwareRevision";
        public const string HoursPoweredCount = "HoursPoweredCount";
        public const string InstallationDate = "InstallationDate";
        public const string Interface = "Interface";
        public const string ManufactureDate = "ManufactureDate";
        public const string ManufacturerName = "ManufacturerName";
        public const string MechanicalRevision = "MechanicalRevision";
        public const string ModelName = "ModelName";
        public const string SerialNumber = "SerialNumber";
        public const string UnifiedPOSVersion = "UnifiedPOSVersion";
        public const string BarcodePrintedCount = "BarcodePrintedCount";
        public const string FailedPaperCutCount = "FailedPaperCutCount";
        public const string FailedPrintSideChangeCount = "FailedPrintSideChangeCount";
        public const string FormInsertionCount = "FormInsertionCount";
        public const string HomeErrorCount = "HomeErrorCount";
        public const string JournalCharacterPrintedCount = "JournalCharacterPrintedCount";
        public const string JournalCoverOpenCount = "JournalCoverOpenCount";
        public const string JournalLinePrintedCount = "JournalLinePrintedCount";
        public const string MaximumTempReachedCount = "MaximumTempReachedCount";
        public const string NVRAMWriteCount = "NVRAMWriteCount";
        public const string PaperCutCount = "PaperCutCount";
        public const string PrinterFaultCount = "PrinterFaultCount";
        public const string PrintSideChangeCount = "PrintSideChangeCount";
        public const string ReceiptCharacterPrintedCount = "ReceiptCharacterPrintedCount";
        public const string ReceiptCoverOpenCount = "ReceiptCoverOpenCount";
        public const string ReceiptLineFeedCount = "ReceiptLineFeedCount";
        public const string ReceiptLinePrintedCount = "ReceiptLinePrintedCount";
        public const string SlipCharacterPrintedCount = "SlipCharacterPrintedCount";
        public const string SlipCoverOpenCount = "SlipCoverOpenCount";
        public const string SlipLineFeedCount = "SlipLineFeedCount";
        public const string SlipLinePrintedCount = "SlipLinePrintedCount";
        public const string StampFiredCount = "StampFiredCount";
    }

    public class Wait
    {
        public const int Forever = -1;
    }
}
