﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace UnifiedPOS.ItemDispenser
{
    [ServiceContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/")]
    public interface ItemDispenser
    {

        //
        // Common Properties
        //

        //[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/GetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/GetAutoDisableResponse")]
        //[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/UposException", Name = "UposException")]
        //bool GetAutoDisable();

        //[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/SetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/SetAutoDisableResponse")]
        //[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/UposException", Name = "UposException")]
        //void SetAutoDisable(bool AutoDisable);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/GetCapCompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/GetCapCompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/UposException", Name = "UposException")]
        bool GetCapCompareFirmwareVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/GetCapPowerReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/GetCapPowerReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/UposException", Name = "UposException")]
        PowerReporting GetCapPowerReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/GetCapStatisticsReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/GetCapStatisticsReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/UposException", Name = "UposException")]
        bool GetCapStatisticsReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/GetCapUpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/GetCapUpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/UposException", Name = "UposException")]
        bool GetCapUpdateFirmware();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/GetCapUpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/GetCapUpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/UposException", Name = "UposException")]
        bool GetCapUpdateStatistics();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/GetCheckHealthText", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/GetCheckHealthTextResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/UposException", Name = "UposException")]
        string GetCheckHealthText();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/GetClaimed", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/GetClaimedResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/UposException", Name = "UposException")]
        bool GetClaimed();

        //[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/GetDataCount", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/GetDataCountResponse")]
        //[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/UposException", Name = "UposException")]
        //int GetDataCount();

        //[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/GetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/GetDataEventEnabledResponse")]
        //[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/UposException", Name = "UposException")]
        //bool GetDataEventEnabled();

        //[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/SetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/SetDataEventEnabledResponse")]
        //[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/UposException", Name = "UposException")]
        //void SetDataEventEnabled(bool DataEventEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/GetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/GetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/UposException", Name = "UposException")]
        bool GetDeviceEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/SetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/SetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/UposException", Name = "UposException")]
        void SetDeviceEnabled(bool DeviceEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/GetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/GetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/UposException", Name = "UposException")]
        bool GetFreezeEvents();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/SetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/SetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/UposException", Name = "UposException")]
        void SetFreezeEvents(bool FreezeEvents);

        //[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/GetOutputID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/GetOutputIDResponse")]
        //[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/UposException", Name = "UposException")]
        //int GetOutputID();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/GetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/GetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/UposException", Name = "UposException")]
        PowerNotification GetPowerNotify();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/SetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/SetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/UposException", Name = "UposException")]
        void SetPowerNotify(PowerNotification PowerNotify);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/GetPowerState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/GetPowerStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/UposException", Name = "UposException")]
        PowerState GetPowerState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/GetState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/GetStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/UposException", Name = "UposException")]
        ControlState GetState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/GetDeviceControlDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/GetDeviceControlDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/UposException", Name = "UposException")]
        string GetDeviceControlDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/GetDeviceControlVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/GetDeviceControlVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/UposException", Name = "UposException")]
        UposVersion GetDeviceControlVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/GetDeviceServiceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/GetDeviceServiceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/UposException", Name = "UposException")]
        string GetDeviceServiceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/GetDeviceServiceVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/GetDeviceServiceVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/UposException", Name = "UposException")]
        UposVersion GetDeviceServiceVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/GetPhysicalDeviceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/GetPhysicalDeviceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/UposException", Name = "UposException")]
        string GetPhysicalDeviceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/GetPhysicalDeviceName", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/GetPhysicalDeviceNameResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/UposException", Name = "UposException")]
        string GetPhysicalDeviceName();

        //
        // Specific Properties
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/GetCapEmptySensor", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/GetCapEmptySensorResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/UposException", Name = "UposException")]
        bool GetCapEmptySensor();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/GetCapIndividualSlotStatus", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/GetCapIndividualSlotStatusResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/UposException", Name = "UposException")]
        bool GetCapIndividualSlotStatus();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/GetCapJamSensor", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/GetCapJamSensorResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/UposException", Name = "UposException")]
        bool GetCapJamSensor();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/GetCapNearEmptySensor", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/GetCapNearEmptySensorResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/UposException", Name = "UposException")]
        bool GetCapNearEmptySensor();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/GetDispenserStatus", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/GetDispenserStatusResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/UposException", Name = "UposException")]
        ItemDispenserStatus GetDispenserStatus();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/GetMaxSlots", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/GetMaxSlotsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/UposException", Name = "UposException")]
        int GetMaxSlots();

        //
        // Common Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/Open", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/OpenResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/UposException", Name = "UposException")]
        void Open(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/Close", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/CloseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/UposException", Name = "UposException")]
        void Close(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/Claim", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/ClaimResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/UposException", Name = "UposException")]
        void Claim(int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/Release", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/ReleaseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/UposException", Name = "UposException")]
        void Release();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/CheckHealth", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/CheckHealthResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/UposException", Name = "UposException")]
        void CheckHealth(HealthCheckLevel Level);

        //[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/ClearInput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/ClearInputResponse")]
        //[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/UposException", Name = "UposException")]
        //void ClearInput();

        //[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/ClearInputProperties", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/ClearInputPropertiesResponse")]
        //[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/UposException", Name = "UposException")]
        //void ClearInputProperties();

        //[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/ClearOutput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/ClearOutputResponse")]
        //[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/UposException", Name = "UposException")]
        //void ClearOutput();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/DirectIO", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/DirectIOResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/UposException", Name = "UposException")]
        DirectIOData DirectIO(int Command, int Data, object Obj);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/CompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/CompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/UposException", Name = "UposException")]
        CompareFirmwareResult CompareFirmwareVersion(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/ResetStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/ResetStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/UposException", Name = "UposException")]
        void ResetStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/RetrieveStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/RetrieveStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/UposException", Name = "UposException")]
        string RetrieveStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/UpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/UpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/UposException", Name = "UposException")]
        void UpdateFirmware(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/UpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/UpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/UposException", Name = "UposException")]
        void UpdateStatistics(StatisticList StatisticsBuffer);

        //
        // Specific Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/AdjustItemCount", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/AdjustItemCountResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/UposException", Name = "UposException")]
        void AdjustItemCount(int ItemCount, int SlotNumber);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/DispenseItem", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/DispenseItemResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/UposException", Name = "UposException")]
        int DispenseItem(int NumItem, int SlotNumber);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/ReadItemCount", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/ReadItemCountResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/UposException", Name = "UposException")]
        int ReadItemCount(int SlotNumber);

    }

    //
    // Common Data Types
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/")]
    public class DirectIOData
    {
        [DataMember]
        public int Data { get; set; }
        [DataMember]
        public object Obj { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/")]
    public class UposException
    {
        [DataMember]
        public ErrorCode ErrorCode { get; set; }
        [DataMember]
        public int ErrorCodeExtended { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/")]
    public class UposVersion
    {
        [DataMember]
        public int Major { get; set; }
        [DataMember]
        public int Minor { get; set; }
        [DataMember]
        public int Build { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/")]
    public class Statistic
    {
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public string Value { get; set; }
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/", ItemName = "Statistic")]
    public class StatisticList : List<Statistic>
    {
    }

    //
    // Common Enumerations
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/")]
    public enum CompareFirmwareResult
    {
        [EnumMember]
        Different,
        [EnumMember]
        Newer,
        [EnumMember]
        Older,
        [EnumMember]
        Same,
        [EnumMember]
        Unknown,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/")]
    public enum ControlState
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Closed,
        [EnumMember]
        Error,
        [EnumMember]
        Idle,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/")]
    public enum ErrorCode
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Claimed,
        [EnumMember]
        Closed,
        [EnumMember]
        Deprecated,
        [EnumMember]
        Disabled,
        [EnumMember]
        Exists,
        [EnumMember]
        Extended,
        [EnumMember]
        Failure,
        [EnumMember]
        Illegal,
        [EnumMember]
        NoExist,
        [EnumMember]
        NoHardware,
        [EnumMember]
        NoService,
        [EnumMember]
        NotClaimed,
        [EnumMember]
        Offline,
        [EnumMember]
        Success,
        [EnumMember]
        Timeout,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/")]
    public enum HealthCheckLevel
    {
        [EnumMember]
        External,
        [EnumMember]
        Interactive,
        [EnumMember]
        Internal,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/")]
    public enum PowerNotification
    {
        [EnumMember]
        Disabled,
        [EnumMember]
        Enabled,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/")]
    public enum PowerReporting
    {
        [EnumMember]
        Advanced,
        [EnumMember]
        None,
        [EnumMember]
        Standard,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/")]
    public enum PowerState
    {
        [EnumMember]
        Off,
        [EnumMember]
        Offline,
        [EnumMember]
        OffOffline,
        [EnumMember]
        Online,
        [EnumMember]
        Unknown,
    }

    /*
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/")]
    public enum StatisticCategories
    {
        [EnumMember]
        All,
        [EnumMember]
        Manufacturer,
        [EnumMember]
        Upos,
    }
    */
    public class StatisticCategories
    {
        public const string All = "";
        public const string Manufacturer = "M_";
        public const string Upos = "U_";
    }

    //
    // Specific Data Types
    //

    //
    // Specific Enumerations
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ItemDispenser/")]
    public enum ItemDispenserStatus
    {
        [EnumMember]
        Ok,
        [EnumMember]
        Empty,
        [EnumMember]
        NearEmpty,
        [EnumMember]
        Jam,
    }

    //
    // Constants
    //

    public class ExtendedError
    {
        public const int FirmwareBadFile = 281;
        public const int Statistics = 280;
        public const int StatisticsDependency = 282;
    }

    public class StatisticProperties
    {
        public const string CommunicationErrorCount = "CommunicationErrorCount";
        public const string DeviceCategory = "DeviceCategory";
        public const string FirmwareRevision = "FirmwareRevision";
        public const string HoursPoweredCount = "HoursPoweredCount";
        public const string InstallationDate = "InstallationDate";
        public const string Interface = "Interface";
        public const string ManufactureDate = "ManufactureDate";
        public const string ManufacturerName = "ManufacturerName";
        public const string MechanicalRevision = "MechanicalRevision";
        public const string ModelName = "ModelName";
        public const string SerialNumber = "SerialNumber";
        public const string UnifiedPOSVersion = "UnifiedPOSVersion";
    }

    public class Wait
    {
        public const int Forever = -1;
    }
}
