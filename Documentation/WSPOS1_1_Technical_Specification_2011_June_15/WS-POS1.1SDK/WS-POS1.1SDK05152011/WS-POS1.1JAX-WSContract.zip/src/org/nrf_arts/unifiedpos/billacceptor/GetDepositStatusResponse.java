
package org.nrf_arts.unifiedpos.billacceptor;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="GetDepositStatusResult" type="{http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/}DepositStatus" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "getDepositStatusResult"
})
@XmlRootElement(name = "GetDepositStatusResponse")
public class GetDepositStatusResponse {

    @XmlElement(name = "GetDepositStatusResult")
    protected DepositStatus getDepositStatusResult;

    /**
     * Gets the value of the getDepositStatusResult property.
     * 
     * @return
     *     possible object is
     *     {@link DepositStatus }
     *     
     */
    public DepositStatus getGetDepositStatusResult() {
        return getDepositStatusResult;
    }

    /**
     * Sets the value of the getDepositStatusResult property.
     * 
     * @param value
     *     allowed object is
     *     {@link DepositStatus }
     *     
     */
    public void setGetDepositStatusResult(DepositStatus value) {
        this.getDepositStatusResult = value;
    }

}
