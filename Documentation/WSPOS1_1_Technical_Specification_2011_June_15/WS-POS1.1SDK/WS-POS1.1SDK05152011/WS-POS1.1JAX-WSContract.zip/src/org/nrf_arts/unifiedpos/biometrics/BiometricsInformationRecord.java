
package org.nrf_arts.unifiedpos.biometrics;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for BiometricsInformationRecord complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BiometricsInformationRecord">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="BiometricDataBlockSize" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="CreatedTime" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="DataType" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="FormatId" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="FormatOwner" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="Purpose" type="{http://www.nrf-arts.org/UnifiedPOS/Biometrics/}BIRPurpose" minOccurs="0"/>
 *         &lt;element name="SensorType" type="{http://www.nrf-arts.org/UnifiedPOS/Biometrics/}SensorType" minOccurs="0"/>
 *         &lt;element name="Version" type="{http://www.nrf-arts.org/UnifiedPOS/Biometrics/}UposVersion" minOccurs="0"/>
 *         &lt;element name="BiometricDataBlock" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BiometricsInformationRecord", propOrder = {
    "biometricDataBlockSize",
    "createdTime",
    "dataType",
    "formatId",
    "formatOwner",
    "purpose",
    "sensorType",
    "version",
    "biometricDataBlock"
})
public class BiometricsInformationRecord {

    @XmlElement(name = "BiometricDataBlockSize")
    protected Integer biometricDataBlockSize;
    @XmlElement(name = "CreatedTime")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar createdTime;
    @XmlElement(name = "DataType")
    protected Integer dataType;
    @XmlElement(name = "FormatId")
    protected Integer formatId;
    @XmlElement(name = "FormatOwner")
    protected Integer formatOwner;
    @XmlElement(name = "Purpose")
    protected BIRPurpose purpose;
    @XmlElement(name = "SensorType")
    protected SensorType sensorType;
    @XmlElement(name = "Version", nillable = true)
    protected UposVersion version;
    @XmlElement(name = "BiometricDataBlock", nillable = true)
    protected byte[] biometricDataBlock;

    /**
     * Gets the value of the biometricDataBlockSize property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getBiometricDataBlockSize() {
        return biometricDataBlockSize;
    }

    /**
     * Sets the value of the biometricDataBlockSize property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setBiometricDataBlockSize(Integer value) {
        this.biometricDataBlockSize = value;
    }

    /**
     * Gets the value of the createdTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getCreatedTime() {
        return createdTime;
    }

    /**
     * Sets the value of the createdTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setCreatedTime(XMLGregorianCalendar value) {
        this.createdTime = value;
    }

    /**
     * Gets the value of the dataType property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getDataType() {
        return dataType;
    }

    /**
     * Sets the value of the dataType property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setDataType(Integer value) {
        this.dataType = value;
    }

    /**
     * Gets the value of the formatId property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getFormatId() {
        return formatId;
    }

    /**
     * Sets the value of the formatId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setFormatId(Integer value) {
        this.formatId = value;
    }

    /**
     * Gets the value of the formatOwner property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getFormatOwner() {
        return formatOwner;
    }

    /**
     * Sets the value of the formatOwner property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setFormatOwner(Integer value) {
        this.formatOwner = value;
    }

    /**
     * Gets the value of the purpose property.
     * 
     * @return
     *     possible object is
     *     {@link BIRPurpose }
     *     
     */
    public BIRPurpose getPurpose() {
        return purpose;
    }

    /**
     * Sets the value of the purpose property.
     * 
     * @param value
     *     allowed object is
     *     {@link BIRPurpose }
     *     
     */
    public void setPurpose(BIRPurpose value) {
        this.purpose = value;
    }

    /**
     * Gets the value of the sensorType property.
     * 
     * @return
     *     possible object is
     *     {@link SensorType }
     *     
     */
    public SensorType getSensorType() {
        return sensorType;
    }

    /**
     * Sets the value of the sensorType property.
     * 
     * @param value
     *     allowed object is
     *     {@link SensorType }
     *     
     */
    public void setSensorType(SensorType value) {
        this.sensorType = value;
    }

    /**
     * Gets the value of the version property.
     * 
     * @return
     *     possible object is
     *     {@link UposVersion }
     *     
     */
    public UposVersion getVersion() {
        return version;
    }

    /**
     * Sets the value of the version property.
     * 
     * @param value
     *     allowed object is
     *     {@link UposVersion }
     *     
     */
    public void setVersion(UposVersion value) {
        this.version = value;
    }

    /**
     * Gets the value of the biometricDataBlock property.
     *
     * @return
     *     possible object is
     *     {@link byte[] }
     *
     */
    public byte[] getBiometricDataBlock() {
        return biometricDataBlock;
    }

    /**
     * Sets the value of the biometricDataBlock property.
     *
     * @param value
     *     allowed object is
     *     {@link byte[] }
     *
     */
    public void setBiometricDataBlock(byte[] value) {
        this.biometricDataBlock = value;
    }

}
