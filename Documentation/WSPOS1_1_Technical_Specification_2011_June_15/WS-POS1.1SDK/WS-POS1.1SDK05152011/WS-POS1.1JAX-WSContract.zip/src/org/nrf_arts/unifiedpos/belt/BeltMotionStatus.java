
package org.nrf_arts.unifiedpos.belt;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for BeltMotionStatus.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="BeltMotionStatus">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="Backward"/>
 *     &lt;enumeration value="Emergency"/>
 *     &lt;enumeration value="Forward"/>
 *     &lt;enumeration value="MotorFault"/>
 *     &lt;enumeration value="Stopped"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "BeltMotionStatus")
@XmlEnum
public enum BeltMotionStatus {

    @XmlEnumValue("Backward")
    BACKWARD("Backward"),
    @XmlEnumValue("Emergency")
    EMERGENCY("Emergency"),
    @XmlEnumValue("Forward")
    FORWARD("Forward"),
    @XmlEnumValue("MotorFault")
    MOTOR_FAULT("MotorFault"),
    @XmlEnumValue("Stopped")
    STOPPED("Stopped");
    private final String value;

    BeltMotionStatus(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static BeltMotionStatus fromValue(String v) {
        for (BeltMotionStatus c: BeltMotionStatus.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
