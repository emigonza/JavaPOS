/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package wspos;

import java.net.URL;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import jpos.events.DataEvent;
import jpos.events.DirectIOEvent;
import jpos.events.ErrorEvent;
import jpos.events.StatusUpdateEvent;
import org.nrf_arts.unifiedpos.checkscanner.*;
import javax.jws.WebService;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.namespace.QName;
import javax.xml.ws.Service;

/**
 *
 * @author hideon
 */
@WebService(serviceName = "CheckScannerService", endpointInterface = "org.nrf_arts.unifiedpos.checkscanner.CheckScanner", targetNamespace = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/")
public class CheckScannerService implements CheckScanner, jpos.events.DataListener, jpos.events.DirectIOListener, jpos.events.ErrorListener, jpos.events.StatusUpdateListener {

    //
    // MICR Enumration Converter
    //

    private static HashMap<Enum, Integer> jposConst;
    private static HashMap<Integer, PowerReporting> powerReporting;
    private static HashMap<Integer, PowerNotification> powerNotification;
    private static HashMap<Integer, PowerState> powerState;
    private static HashMap<Integer, ControlState> controlState;
    private static HashMap<Integer, HealthCheckLevel> healthCheckLevel;
    private static HashMap<Integer, CompareFirmwareResult> compareFirmwareResult;
    private static HashMap<Integer, ErrorCode> errorCode;
    private static HashMap<Integer, CheckImageClear> checkImageClear;
    private static HashMap<Integer, CheckImageLocate> checkImageLocate;
    private static HashMap<Integer, ImageMemoryStatus> imageMemoryStatus;
    private static HashMap<Integer, MapMode> mapMode;

    private static HashMap<Enum, Integer> jposEventConst;
    private static HashMap<Integer, org.nrf_arts.unifiedpos.checkscannerevents.ErrorCode> eventErrorCode;
    private static HashMap<Integer, org.nrf_arts.unifiedpos.checkscannerevents.ErrorLocus> eventErrorLocus;
    private static HashMap<Integer, org.nrf_arts.unifiedpos.checkscannerevents.ErrorResponse> eventErrorResponse;

    static {
        jposConst = new HashMap<Enum, Integer>();
        jposConst.put(PowerReporting.ADVANCED, jpos.CheckScanner.JPOS_PR_ADVANCED);
        jposConst.put(PowerReporting.NONE, jpos.CheckScanner.JPOS_PR_NONE);
        jposConst.put(PowerReporting.STANDARD, jpos.CheckScanner.JPOS_PR_STANDARD);
        jposConst.put(PowerNotification.DISABLED, jpos.CheckScanner.JPOS_PN_DISABLED);
        jposConst.put(PowerNotification.ENABLED, jpos.CheckScanner.JPOS_PN_ENABLED);
        jposConst.put(PowerState.OFF, jpos.CheckScanner.JPOS_PS_OFF);
        jposConst.put(PowerState.OFFLINE, jpos.CheckScanner.JPOS_PS_OFFLINE);
        jposConst.put(PowerState.OFF_OFFLINE, jpos.CheckScanner.JPOS_PS_OFF_OFFLINE);
        jposConst.put(PowerState.ONLINE, jpos.CheckScanner.JPOS_PS_ONLINE);
        jposConst.put(PowerState.UNKNOWN, jpos.CheckScanner.JPOS_PS_UNKNOWN);
        jposConst.put(ControlState.BUSY, jpos.CheckScanner.JPOS_S_BUSY);
        jposConst.put(ControlState.CLOSED, jpos.CheckScanner.JPOS_S_CLOSED);
        jposConst.put(ControlState.ERROR, jpos.CheckScanner.JPOS_S_ERROR);
        jposConst.put(ControlState.IDLE, jpos.CheckScanner.JPOS_S_IDLE);
        jposConst.put(HealthCheckLevel.EXTERNAL, jpos.CheckScanner.JPOS_CH_EXTERNAL);
        jposConst.put(HealthCheckLevel.INTERACTIVE, jpos.CheckScanner.JPOS_CH_INTERACTIVE);
        jposConst.put(HealthCheckLevel.INTERNAL, jpos.CheckScanner.JPOS_CH_INTERNAL);
        jposConst.put(CompareFirmwareResult.DIFFERENT, jpos.CheckScanner.JPOS_CFV_FIRMWARE_DIFFERENT);
        jposConst.put(CompareFirmwareResult.NEWER, jpos.CheckScanner.JPOS_CFV_FIRMWARE_NEWER);
        jposConst.put(CompareFirmwareResult.OLDER, jpos.CheckScanner.JPOS_CFV_FIRMWARE_OLDER);
        jposConst.put(CompareFirmwareResult.SAME, jpos.CheckScanner.JPOS_CFV_FIRMWARE_SAME);
        jposConst.put(CompareFirmwareResult.UNKNOWN, jpos.CheckScanner.JPOS_CFV_FIRMWARE_UNKNOWN);
        jposConst.put(ErrorCode.BUSY, jpos.CheckScanner.JPOS_E_BUSY);
        jposConst.put(ErrorCode.CLAIMED, jpos.CheckScanner.JPOS_E_CLAIMED);
        jposConst.put(ErrorCode.CLOSED, jpos.CheckScanner.JPOS_E_CLOSED);
        jposConst.put(ErrorCode.DEPRECATED, jpos.CheckScanner.JPOS_E_DEPRECATED);
        jposConst.put(ErrorCode.DISABLED, jpos.CheckScanner.JPOS_E_DISABLED);
        jposConst.put(ErrorCode.EXISTS, jpos.CheckScanner.JPOS_E_EXISTS);
        jposConst.put(ErrorCode.EXTENDED, jpos.CheckScanner.JPOS_E_EXTENDED);
        jposConst.put(ErrorCode.FAILURE, jpos.CheckScanner.JPOS_E_FAILURE);
        jposConst.put(ErrorCode.ILLEGAL, jpos.CheckScanner.JPOS_E_ILLEGAL);
        jposConst.put(ErrorCode.NO_EXIST, jpos.CheckScanner.JPOS_E_NOEXIST);
        jposConst.put(ErrorCode.NO_HARDWARE, jpos.CheckScanner.JPOS_E_NOHARDWARE);
        jposConst.put(ErrorCode.NO_SERVICE, jpos.CheckScanner.JPOS_E_NOSERVICE);
        jposConst.put(ErrorCode.NOT_CLAIMED, jpos.CheckScanner.JPOS_E_NOTCLAIMED);
        jposConst.put(ErrorCode.OFFLINE, jpos.CheckScanner.JPOS_E_OFFLINE);
        jposConst.put(ErrorCode.SUCCESS, 0);
        jposConst.put(ErrorCode.TIMEOUT, jpos.CheckScanner.JPOS_E_TIMEOUT);
        jposConst.put(CheckImageClear.ALL, jpos.CheckScannerConst.CHK_CLR_ALL);
        jposConst.put(CheckImageClear.FILE_ID, jpos.CheckScannerConst.CHK_CLR_BY_FILEID);
        jposConst.put(CheckImageClear.FILE_INDEX, jpos.CheckScannerConst.CHK_CLR_BY_FILEINDEX);
        jposConst.put(CheckImageClear.IMAGE_TAG_DATA, jpos.CheckScannerConst.CHK_CLR_BY_IMAGETAGDATA);
        jposConst.put(CheckImageLocate.FILE_ID, jpos.CheckScannerConst.CHK_LOCATE_BY_FILEID);
        jposConst.put(CheckImageLocate.FILE_INDEX, jpos.CheckScannerConst.CHK_LOCATE_BY_FILEINDEX);
        jposConst.put(CheckImageLocate.IMAGE_TAG_DATA, jpos.CheckScannerConst.CHK_LOCATE_BY_IMAGETAGDATA);
        jposConst.put(ImageMemoryStatus.EMPTY, jpos.CheckScannerConst.CHK_IMS_EMPTY);
        jposConst.put(ImageMemoryStatus.FULL, jpos.CheckScannerConst.CHK_IMS_FULL);
        jposConst.put(ImageMemoryStatus.OK, jpos.CheckScannerConst.CHK_IMS_OK);
        jposConst.put(MapMode.DOTS, jpos.CheckScannerConst.CHK_MM_DOTS);
        jposConst.put(MapMode.ENGLISH, jpos.CheckScannerConst.CHK_MM_ENGLISH);
        jposConst.put(MapMode.METRIC, jpos.CheckScannerConst.CHK_MM_METRIC);
        jposConst.put(MapMode.TWIPS, jpos.CheckScannerConst.CHK_MM_TWIPS);

        powerReporting = new HashMap<Integer, PowerReporting>();
        powerReporting.put(jpos.CheckScanner.JPOS_PR_ADVANCED, PowerReporting.ADVANCED);
        powerReporting.put(jpos.CheckScanner.JPOS_PR_NONE, PowerReporting.NONE);
        powerReporting.put(jpos.CheckScanner.JPOS_PR_STANDARD, PowerReporting.STANDARD);

        powerNotification = new HashMap<Integer, PowerNotification>();
        powerNotification.put(jpos.CheckScanner.JPOS_PN_DISABLED, PowerNotification.DISABLED);
        powerNotification.put(jpos.CheckScanner.JPOS_PN_ENABLED, PowerNotification.ENABLED);

        powerState = new HashMap<Integer, PowerState>();
        powerState.put(jpos.CheckScanner.JPOS_PS_OFF, PowerState.OFF);
        powerState.put(jpos.CheckScanner.JPOS_PS_OFFLINE, PowerState.OFFLINE);
        powerState.put(jpos.CheckScanner.JPOS_PS_OFF_OFFLINE, PowerState.OFF_OFFLINE);
        powerState.put(jpos.CheckScanner.JPOS_PS_ONLINE, PowerState.ONLINE);
        powerState.put(jpos.CheckScanner.JPOS_PS_UNKNOWN, PowerState.UNKNOWN);

        controlState = new HashMap<Integer, ControlState>();
        controlState.put(jpos.CheckScanner.JPOS_S_BUSY, ControlState.BUSY);
        controlState.put(jpos.CheckScanner.JPOS_S_CLOSED, ControlState.CLOSED);
        controlState.put(jpos.CheckScanner.JPOS_S_ERROR, ControlState.ERROR);
        controlState.put(jpos.CheckScanner.JPOS_S_IDLE, ControlState.IDLE);

        healthCheckLevel = new HashMap<Integer, HealthCheckLevel>();
        healthCheckLevel.put(jpos.CheckScanner.JPOS_CH_EXTERNAL, HealthCheckLevel.EXTERNAL);
        healthCheckLevel.put(jpos.CheckScanner.JPOS_CH_INTERACTIVE, HealthCheckLevel.INTERACTIVE);
        healthCheckLevel.put(jpos.CheckScanner.JPOS_CH_INTERNAL, HealthCheckLevel.INTERNAL);

        compareFirmwareResult = new HashMap<Integer, CompareFirmwareResult>();
        compareFirmwareResult.put(jpos.CheckScanner.JPOS_CFV_FIRMWARE_DIFFERENT, CompareFirmwareResult.DIFFERENT);
        compareFirmwareResult.put(jpos.CheckScanner.JPOS_CFV_FIRMWARE_NEWER, CompareFirmwareResult.NEWER);
        compareFirmwareResult.put(jpos.CheckScanner.JPOS_CFV_FIRMWARE_OLDER, CompareFirmwareResult.OLDER);
        compareFirmwareResult.put(jpos.CheckScanner.JPOS_CFV_FIRMWARE_SAME, CompareFirmwareResult.SAME);
        compareFirmwareResult.put(jpos.CheckScanner.JPOS_CFV_FIRMWARE_UNKNOWN, CompareFirmwareResult.UNKNOWN);

        errorCode = new HashMap<Integer, ErrorCode>();
        errorCode.put(jpos.CheckScanner.JPOS_E_BUSY, ErrorCode.BUSY);
        errorCode.put(jpos.CheckScanner.JPOS_E_CLAIMED, ErrorCode.CLAIMED);
        errorCode.put(jpos.CheckScanner.JPOS_E_CLOSED, ErrorCode.CLOSED);
        errorCode.put(jpos.CheckScanner.JPOS_E_DEPRECATED, ErrorCode.DEPRECATED);
        errorCode.put(jpos.CheckScanner.JPOS_E_DISABLED, ErrorCode.DISABLED);
        errorCode.put(jpos.CheckScanner.JPOS_E_EXISTS, ErrorCode.EXISTS);
        errorCode.put(jpos.CheckScanner.JPOS_E_EXTENDED, ErrorCode.EXTENDED);
        errorCode.put(jpos.CheckScanner.JPOS_E_FAILURE, ErrorCode.FAILURE);
        errorCode.put(jpos.CheckScanner.JPOS_E_ILLEGAL, ErrorCode.ILLEGAL);
        errorCode.put(jpos.CheckScanner.JPOS_E_NOEXIST, ErrorCode.NO_EXIST);
        errorCode.put(jpos.CheckScanner.JPOS_E_NOHARDWARE, ErrorCode.NO_HARDWARE);
        errorCode.put(jpos.CheckScanner.JPOS_E_NOSERVICE, ErrorCode.NO_SERVICE);
        errorCode.put(jpos.CheckScanner.JPOS_E_NOTCLAIMED, ErrorCode.NOT_CLAIMED);
        errorCode.put(jpos.CheckScanner.JPOS_E_OFFLINE, ErrorCode.OFFLINE);
        errorCode.put(0, ErrorCode.SUCCESS);
        errorCode.put(jpos.CheckScanner.JPOS_E_TIMEOUT, ErrorCode.TIMEOUT);

        checkImageClear = new HashMap<Integer, CheckImageClear>();
        checkImageClear.put(jpos.CheckScannerConst.CHK_CLR_ALL, CheckImageClear.ALL);
        checkImageClear.put(jpos.CheckScannerConst.CHK_CLR_BY_FILEID, CheckImageClear.FILE_ID);
        checkImageClear.put(jpos.CheckScannerConst.CHK_CLR_BY_FILEINDEX, CheckImageClear.FILE_INDEX);
        checkImageClear.put(jpos.CheckScannerConst.CHK_CLR_BY_IMAGETAGDATA, CheckImageClear.IMAGE_TAG_DATA);

        checkImageLocate = new HashMap<Integer, CheckImageLocate>();
        checkImageLocate.put(jpos.CheckScannerConst.CHK_LOCATE_BY_FILEID, CheckImageLocate.FILE_ID);
        checkImageLocate.put(jpos.CheckScannerConst.CHK_LOCATE_BY_FILEINDEX, CheckImageLocate.FILE_INDEX);
        checkImageLocate.put(jpos.CheckScannerConst.CHK_LOCATE_BY_IMAGETAGDATA, CheckImageLocate.IMAGE_TAG_DATA);

        imageMemoryStatus = new HashMap<Integer, ImageMemoryStatus>();
        imageMemoryStatus.put(jpos.CheckScannerConst.CHK_IMS_EMPTY, ImageMemoryStatus.EMPTY);
        imageMemoryStatus.put(jpos.CheckScannerConst.CHK_IMS_FULL, ImageMemoryStatus.FULL);
        imageMemoryStatus.put(jpos.CheckScannerConst.CHK_IMS_OK, ImageMemoryStatus.OK);

        mapMode =  new HashMap<Integer, MapMode>();
        mapMode.put(jpos.CheckScannerConst.CHK_MM_DOTS, MapMode.DOTS);
        mapMode.put(jpos.CheckScannerConst.CHK_MM_ENGLISH, MapMode.ENGLISH);
        mapMode.put(jpos.CheckScannerConst.CHK_MM_METRIC, MapMode.METRIC);
        mapMode.put(jpos.CheckScannerConst.CHK_MM_TWIPS, MapMode.TWIPS);

        jposEventConst = new HashMap<Enum, Integer>();
        jposEventConst.put(org.nrf_arts.unifiedpos.checkscannerevents.ErrorCode.BUSY, jpos.CheckScanner.JPOS_E_BUSY);
        jposEventConst.put(org.nrf_arts.unifiedpos.checkscannerevents.ErrorCode.CLAIMED, jpos.CheckScanner.JPOS_E_CLAIMED);
        jposEventConst.put(org.nrf_arts.unifiedpos.checkscannerevents.ErrorCode.CLOSED, jpos.CheckScanner.JPOS_E_CLOSED);
        jposEventConst.put(org.nrf_arts.unifiedpos.checkscannerevents.ErrorCode.DEPRECATED, jpos.CheckScanner.JPOS_E_DEPRECATED);
        jposEventConst.put(org.nrf_arts.unifiedpos.checkscannerevents.ErrorCode.DISABLED, jpos.CheckScanner.JPOS_E_DISABLED);
        jposEventConst.put(org.nrf_arts.unifiedpos.checkscannerevents.ErrorCode.EXISTS, jpos.CheckScanner.JPOS_E_EXISTS);
        jposEventConst.put(org.nrf_arts.unifiedpos.checkscannerevents.ErrorCode.EXTENDED, jpos.CheckScanner.JPOS_E_EXTENDED);
        jposEventConst.put(org.nrf_arts.unifiedpos.checkscannerevents.ErrorCode.FAILURE, jpos.CheckScanner.JPOS_E_FAILURE);
        jposEventConst.put(org.nrf_arts.unifiedpos.checkscannerevents.ErrorCode.ILLEGAL, jpos.CheckScanner.JPOS_E_ILLEGAL);
        jposEventConst.put(org.nrf_arts.unifiedpos.checkscannerevents.ErrorCode.NO_EXIST, jpos.CheckScanner.JPOS_E_NOEXIST);
        jposEventConst.put(org.nrf_arts.unifiedpos.checkscannerevents.ErrorCode.NO_HARDWARE, jpos.CheckScanner.JPOS_E_NOHARDWARE);
        jposEventConst.put(org.nrf_arts.unifiedpos.checkscannerevents.ErrorCode.NO_SERVICE, jpos.CheckScanner.JPOS_E_NOSERVICE);
        jposEventConst.put(org.nrf_arts.unifiedpos.checkscannerevents.ErrorCode.NOT_CLAIMED, jpos.CheckScanner.JPOS_E_NOTCLAIMED);
        jposEventConst.put(org.nrf_arts.unifiedpos.checkscannerevents.ErrorCode.OFFLINE, jpos.CheckScanner.JPOS_E_OFFLINE);
        jposEventConst.put(org.nrf_arts.unifiedpos.checkscannerevents.ErrorCode.SUCCESS, 0);
        jposEventConst.put(org.nrf_arts.unifiedpos.checkscannerevents.ErrorCode.TIMEOUT, jpos.CheckScanner.JPOS_E_TIMEOUT);
        jposEventConst.put(org.nrf_arts.unifiedpos.checkscannerevents.ErrorLocus.INPUT, jpos.CheckScanner.JPOS_EL_INPUT);
        jposEventConst.put(org.nrf_arts.unifiedpos.checkscannerevents.ErrorLocus.INPUT_DATA, jpos.CheckScanner.JPOS_EL_INPUT_DATA);
        jposEventConst.put(org.nrf_arts.unifiedpos.checkscannerevents.ErrorLocus.OUTPUT, jpos.CheckScanner.JPOS_EL_OUTPUT);
        jposEventConst.put(org.nrf_arts.unifiedpos.checkscannerevents.ErrorResponse.CLEAR, jpos.CheckScanner.JPOS_ER_CLEAR);
        jposEventConst.put(org.nrf_arts.unifiedpos.checkscannerevents.ErrorResponse.CONTINUE_INPUT, jpos.CheckScanner.JPOS_ER_CONTINUEINPUT);
        jposEventConst.put(org.nrf_arts.unifiedpos.checkscannerevents.ErrorResponse.RETRY, jpos.CheckScanner.JPOS_ER_RETRY);

        eventErrorCode = new HashMap<Integer, org.nrf_arts.unifiedpos.checkscannerevents.ErrorCode>();
        eventErrorCode.put(jpos.CheckScanner.JPOS_E_BUSY, org.nrf_arts.unifiedpos.checkscannerevents.ErrorCode.BUSY);
        eventErrorCode.put(jpos.CheckScanner.JPOS_E_CLAIMED, org.nrf_arts.unifiedpos.checkscannerevents.ErrorCode.CLAIMED);
        eventErrorCode.put(jpos.CheckScanner.JPOS_E_CLOSED, org.nrf_arts.unifiedpos.checkscannerevents.ErrorCode.CLOSED);
        eventErrorCode.put(jpos.CheckScanner.JPOS_E_DEPRECATED, org.nrf_arts.unifiedpos.checkscannerevents.ErrorCode.DEPRECATED);
        eventErrorCode.put(jpos.CheckScanner.JPOS_E_DISABLED, org.nrf_arts.unifiedpos.checkscannerevents.ErrorCode.DISABLED);
        eventErrorCode.put(jpos.CheckScanner.JPOS_E_EXISTS, org.nrf_arts.unifiedpos.checkscannerevents.ErrorCode.EXISTS);
        eventErrorCode.put(jpos.CheckScanner.JPOS_E_EXTENDED, org.nrf_arts.unifiedpos.checkscannerevents.ErrorCode.EXTENDED);
        eventErrorCode.put(jpos.CheckScanner.JPOS_E_FAILURE, org.nrf_arts.unifiedpos.checkscannerevents.ErrorCode.FAILURE);
        eventErrorCode.put(jpos.CheckScanner.JPOS_E_ILLEGAL, org.nrf_arts.unifiedpos.checkscannerevents.ErrorCode.ILLEGAL);
        eventErrorCode.put(jpos.CheckScanner.JPOS_E_NOEXIST, org.nrf_arts.unifiedpos.checkscannerevents.ErrorCode.NO_EXIST);
        eventErrorCode.put(jpos.CheckScanner.JPOS_E_NOHARDWARE, org.nrf_arts.unifiedpos.checkscannerevents.ErrorCode.NO_HARDWARE);
        eventErrorCode.put(jpos.CheckScanner.JPOS_E_NOSERVICE, org.nrf_arts.unifiedpos.checkscannerevents.ErrorCode.NO_SERVICE);
        eventErrorCode.put(jpos.CheckScanner.JPOS_E_NOTCLAIMED, org.nrf_arts.unifiedpos.checkscannerevents.ErrorCode.NOT_CLAIMED);
        eventErrorCode.put(jpos.CheckScanner.JPOS_E_OFFLINE, org.nrf_arts.unifiedpos.checkscannerevents.ErrorCode.OFFLINE);
        eventErrorCode.put(0, org.nrf_arts.unifiedpos.checkscannerevents.ErrorCode.SUCCESS);
        eventErrorCode.put(jpos.CheckScanner.JPOS_E_TIMEOUT, org.nrf_arts.unifiedpos.checkscannerevents.ErrorCode.TIMEOUT);

        eventErrorLocus = new HashMap<Integer, org.nrf_arts.unifiedpos.checkscannerevents.ErrorLocus>();
        eventErrorLocus.put(jpos.CheckScanner.JPOS_EL_INPUT, org.nrf_arts.unifiedpos.checkscannerevents.ErrorLocus.INPUT);
        eventErrorLocus.put(jpos.CheckScanner.JPOS_EL_INPUT_DATA, org.nrf_arts.unifiedpos.checkscannerevents.ErrorLocus.INPUT_DATA);
        eventErrorLocus.put(jpos.CheckScanner.JPOS_EL_OUTPUT, org.nrf_arts.unifiedpos.checkscannerevents.ErrorLocus.OUTPUT);

        eventErrorResponse = new HashMap<Integer, org.nrf_arts.unifiedpos.checkscannerevents.ErrorResponse>();
        eventErrorResponse.put(jpos.CheckScanner.JPOS_ER_CLEAR, org.nrf_arts.unifiedpos.checkscannerevents.ErrorResponse.CLEAR);
        eventErrorResponse.put(jpos.CheckScanner.JPOS_ER_CONTINUEINPUT, org.nrf_arts.unifiedpos.checkscannerevents.ErrorResponse.CONTINUE_INPUT);
        eventErrorResponse.put(jpos.CheckScanner.JPOS_ER_RETRY, org.nrf_arts.unifiedpos.checkscannerevents.ErrorResponse.RETRY);
    }

    private String deviceName;
    private UposVersion deviceControlVersion;
    private org.nrf_arts.unifiedpos.checkscannerevents.CheckScannerEvent deviceEvent;
    private jpos.CheckScanner device = new jpos.CheckScanner();
    private DatatypeFactory datatypeFactory;

    public CheckScannerService(String logicalDeviceName) {
        deviceName = logicalDeviceName;
        deviceControlVersion = new UposVersion();
        deviceControlVersion.setMajor(1);
        deviceControlVersion.setMinor(13);
        deviceControlVersion.setBuild(1);
        try {
            datatypeFactory = DatatypeFactory.newInstance();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    //
    // CheckScanner Member
    //

    public void beginInsertion(Integer timeout) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.beginInsertion(timeout);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void beginRemoval(Integer timeout) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.beginRemoval(timeout);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void checkHealth(HealthCheckLevel level) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.checkHealth(jposConst.get(level));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void claim(Integer timeout) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.claim(timeout);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void clearImage(CheckImageClear by) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.clearImage(jposConst.get(by));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void clearInput() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.clearInput();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void clearInputProperties() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.clearInputProperties();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void close(String string) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            if (deviceEvent != null)
            {
                device.removeDataListener(this);
                device.removeDirectIOListener(this);
                device.removeErrorListener(this);
                device.removeStatusUpdateListener(this);
                deviceEvent = null;
            }
            device.close();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public CompareFirmwareResult compareFirmwareVersion(String firmwareFileName) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            int[] param = new int[1];
            device.compareFirmwareVersion(firmwareFileName, param);
            return compareFirmwareResult.get(param[0]);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void defineCropArea(Integer cropAreaID, Integer x, Integer y, Integer cx, Integer cy) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.defineCropArea(cropAreaID, x, y, cx, cy);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public DirectIOData directIO(Integer command, Integer data, Object obj) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            DirectIOData res = new DirectIOData();
            int[] param = new int[] { data };
            device.directIO(command, param, obj);
            res.setData(param[0]);
            res.setObj(obj);
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void endInsertion() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.endInsertion();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void endRemoval() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.endRemoval();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getAutoDisable() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getAutoDisable();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapAutoContrast() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapAutoContrast();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapAutoGenerateFileID() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapAutoGenerateFileID();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapAutoGenerateImageTagData() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapAutoGenerateImageTagData();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapAutoSize() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapAutoSize();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getCapColor() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapColor();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapCompareFirmwareVersion() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapCompareFirmwareVersion();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapConcurrentMICR() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapConcurrentMICR();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapContrast() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapContrast();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapDefineCropArea() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapDefineCropArea();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getCapImageFormat() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapImageFormat();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapImageTagData() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapImageTagData();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapMICRDevice() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapMICRDevice();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public PowerReporting getCapPowerReporting() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return powerReporting.get(device.getCapPowerReporting());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapStatisticsReporting() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapStatisticsReporting();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapStoreImageFiles() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapStoreImageFiles();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapUpdateFirmware() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapUpdateFirmware();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapUpdateStatistics() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapUpdateStatistics();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapValidationDevice() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapValidationDevice();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getCheckHealthText() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCheckHealthText();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getClaimed() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getClaimed();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getColor() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getColor();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getConcurrentMICR() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getConcurrentMICR();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getContrast() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getContrast();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getCropAreaCount() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCropAreaCount();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getDataCount() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getDataCount();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getDataEventEnabled() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getDataEventEnabled();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getDeviceControlDescription() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        return device.getDeviceControlDescription();
    }

    public UposVersion getDeviceControlVersion() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        UposVersion res = new UposVersion();
        int version = device.getDeviceControlVersion();
        res.setMajor(version / 1000000 % 1000);
        res.setMinor(version / 1000 % 1000);
        res.setBuild(version % 1000);
        return res;
    }

    public Boolean getDeviceEnabled() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getDeviceEnabled();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getDeviceServiceDescription() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getDeviceServiceDescription();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public UposVersion getDeviceServiceVersion() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            UposVersion res = new UposVersion();
            int version = device.getDeviceServiceVersion();
            res.setMajor(version / 1000000 % 1000);
            res.setMinor(version / 1000 % 1000);
            res.setBuild(version % 1000);
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getDocumentHeight() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getDocumentHeight();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getDocumentWidth() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getDocumentWidth();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getFileID() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getFileID();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getFileIndex() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getFileIndex();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getFreezeEvents() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getFreezeEvents();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public byte[] getImageData() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getImageData();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getImageFormat() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getImageFormat();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public ImageMemoryStatus getImageMemoryStatus() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return imageMemoryStatus.get(device.getImageMemoryStatus());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getImageTagData() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getImageTagData();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public MapMode getMapMode() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return mapMode.get(device.getMapMode());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getMaxCropAreas() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getMaxCropAreas();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getPhysicalDeviceDescription() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getPhysicalDeviceDescription();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getPhysicalDeviceName() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getPhysicalDeviceName();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public PowerNotification getPowerNotify() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return powerNotification.get(device.getPowerNotify());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public PowerState getPowerState() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return powerState.get(device.getPowerState());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getQuality() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getQuality();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public QualityList getQualityList() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            QualityList res = new QualityList();
            List<Integer> list = res.getQuality();
            for (String s : device.getQualityList().split(",")) {
                list.add(Integer.parseInt(s));
            }
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getRemainingImagesEstimate() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getRemainingImagesEstimate();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public ControlState getState() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        return controlState.get(device.getState());
    }

    public void open(String endpointAddress) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.open(deviceName);
            if (endpointAddress != null)
            {
                try {
                    Service service = Service.create(
                            new URL(endpointAddress + "?wsdl"),
                            new QName("http://www.nrf-arts.org/UnifiedPOS/CheckScannerEvents/", "CheckScannerEventService"));
                    deviceEvent = service.getPort(org.nrf_arts.unifiedpos.checkscannerevents.CheckScannerEvent.class);
                    device.addDataListener(this);
                    device.addDirectIOListener(this);
                    device.addErrorListener(this);
                    device.addStatusUpdateListener(this);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void release() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.release();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void resetStatistics(StatisticList statisticsBuffer) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            String param = null;
            List<Statistic> list = statisticsBuffer.getStatistic();
            switch (list.size()) {
                case 0:
                    param = "";
                    break;
                case 1:
                    String name = list.get(0).getName();
                    if (name.equals(StatisticCategories.ALL)) {
                        param = "";
                    }
                    else if (name.equals(StatisticCategories.MANUFACTURER)) {
                        param = "M_";
                    }
                    else if (name.equals(StatisticCategories.UPOS)) {
                        param = "U_";
                    }
                    else {
                        param = name;
                    }
                    break;
                default:
                    StringBuffer buffer = new StringBuffer();
                    for (Statistic statistic : statisticsBuffer.getStatistic()) {
                        buffer.append(",").append(statistic.getName());
                    }
                    param = buffer.substring(1);
                    break;
            }
            device.resetStatistics(param);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void retrieveImage(Integer cropAreaID) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.retrieveImage(cropAreaID);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void retrieveMemory(CheckImageLocate by) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.retrieveMemory(jposConst.get(by));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String retrieveStatistics(StatisticList statisticsBuffer) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            String[] param = new String[1];
            List<Statistic> list = statisticsBuffer.getStatistic();
            switch (list.size()) {
                case 0:
                    param[0] = "";
                    break;
                case 1:
                    String name = list.get(0).getName();
                    if (name.equals(StatisticCategories.ALL)) {
                        param[0] = "";
                    }
                    else if (name.equals(StatisticCategories.MANUFACTURER)) {
                        param[0] = "M_";
                    }
                    else if (name.equals(StatisticCategories.UPOS)) {
                        param[0] = "U_";
                    }
                    else {
                        param[0] = name;
                    }
                    break;
                default:
                    StringBuffer buffer = new StringBuffer();
                    for (Statistic statistic : statisticsBuffer.getStatistic()) {
                        buffer.append(",").append(statistic.getName());
                    }
                    param[0] = buffer.substring(1);
                    break;
            }
            device.retrieveStatistics(param);
            return param[0];
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setAutoDisable(Boolean autoDisable) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setAutoDisable(autoDisable);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setColor(Integer color) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setColor(color);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setConcurrentMICR(Boolean concurrentMICR) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setConcurrentMICR(concurrentMICR);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setContrast(Integer contrast) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setContrast(contrast);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setDataEventEnabled(Boolean dataEventEnabled) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setDataEventEnabled(dataEventEnabled);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setDeviceEnabled(Boolean deviceEnabled) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setDeviceEnabled(deviceEnabled);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setDocumentHeight(Integer documentHeight) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setDocumentHeight(documentHeight);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setDocumentWidth(Integer documentWidth) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setDocumentWidth(documentWidth);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setFileID(String fileID) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setFileID(fileID);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setFileIndex(Integer fileIndex) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setFileIndex(fileIndex);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setFreezeEvents(Boolean freezeEvents) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setFreezeEvents(freezeEvents);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setImageFormat(Integer imageFormat) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setImageFormat(imageFormat);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setImageTagData(String imageTagData) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setImageTagData(deviceName);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setMapMode(MapMode mapMode) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setMapMode(jposConst.get(mapMode));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setPowerNotify(PowerNotification powerNotify) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setPowerNotify(jposConst.get(powerNotify));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setQuality(Integer quality) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setQuality(quality);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void storeImage(Integer cropAreaID) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.storeImage(cropAreaID);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void updateFirmware(String firmwareFileName) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.updateFirmware(firmwareFileName);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void updateStatistics(StatisticList statisticsBuffer) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            String param = null;
            List<Statistic> list = statisticsBuffer.getStatistic();
            switch (list.size()) {
                case 0:
                    param = "";
                    break;
                case 1:
                    Statistic s = list.get(0);
                    String name = s.getName();
                    String value = s.getValue();
                    if (name.equals(StatisticCategories.ALL)) {
                        param = "=" + value;
                    }
                    else if (name.equals(StatisticCategories.MANUFACTURER)) {
                        param = "M_=" + value;
                    }
                    else if (name.equals(StatisticCategories.UPOS)) {
                        param = "U_=" + value;
                    }
                    else {
                        param = name + "=" + value;
                    }
                    break;
                default:
                    StringBuffer buffer = new StringBuffer();
                    for (Statistic statistic : statisticsBuffer.getStatistic()) {
                        buffer.append(",").append(statistic.getName()).append("=").append(statistic.getValue());
                    }
                    param = buffer.substring(1);
                    break;
            }
            device.updateStatistics(param);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    //
    // CheckScannerEvent Member
    //

    public void dataOccurred(DataEvent de) {
        //throw new UnsupportedOperationException("Not supported yet.");
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(new Date(de.getWhen()));
        deviceEvent.dataEvent(
                de.getSource().toString(),
                (int)de.getSequenceNumber(),
                datatypeFactory.newXMLGregorianCalendar(cal),
                de.getStatus());
    }

    public void directIOOccurred(DirectIOEvent dioe) {
        //throw new UnsupportedOperationException("Not supported yet.");
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(new Date(dioe.getWhen()));
        org.nrf_arts.unifiedpos.checkscannerevents.DirectIOData value = deviceEvent.directIOEvent(
                dioe.getSource().toString(),
                (int)dioe.getSequenceNumber(),
                datatypeFactory.newXMLGregorianCalendar(cal),
                dioe.getEventNumber(),
                dioe.getData(),
                dioe.getObject());
        dioe.setData(value.getData());
        dioe.setObject(value.getObj());
    }

    public void errorOccurred(ErrorEvent ee) {
        //throw new UnsupportedOperationException("Not supported yet.");
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(new Date(ee.getWhen()));
        org.nrf_arts.unifiedpos.checkscannerevents.ErrorResponse value = deviceEvent.errorEvent(
                ee.getSource().toString(),
                (int)ee.getSequenceNumber(),
                datatypeFactory.newXMLGregorianCalendar(cal),
                eventErrorCode.get(ee.getErrorCode()),
                ee.getErrorCodeExtended(),
                eventErrorLocus.get(ee.getErrorLocus()),
                eventErrorResponse.get(ee.getErrorResponse()));
        ee.setErrorResponse(jposEventConst.get(value));
    }

    public void statusUpdateOccurred(StatusUpdateEvent sue) {
        //throw new UnsupportedOperationException("Not supported yet.");
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(new Date(sue.getWhen()));
        deviceEvent.statusUpdateEvent(
                sue.getSource().toString(),
                (int)sue.getSequenceNumber(),
                datatypeFactory.newXMLGregorianCalendar(cal),
                sue.getStatus());
    }

}
