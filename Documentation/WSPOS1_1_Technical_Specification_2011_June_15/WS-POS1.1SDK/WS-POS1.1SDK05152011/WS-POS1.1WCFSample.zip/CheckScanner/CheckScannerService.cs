﻿using UnifiedPOS.CheckScanner;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace Wspos
{
    [ServiceBehavior(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/", InstanceContextMode = InstanceContextMode.Single)]
    public class CheckScannerService : CheckScanner, IDisposable
    {
        #region CheckScanner Enumration Converter

        private static Dictionary<Enum, Enum> Convert = new Dictionary<Enum, Enum>()
            {
                { Microsoft.PointOfService.PowerReporting.Advanced, PowerReporting.Advanced },
                { Microsoft.PointOfService.PowerReporting.None, PowerReporting.None },
                { Microsoft.PointOfService.PowerReporting.Standard, PowerReporting.Standard },
                { PowerReporting.Advanced, Microsoft.PointOfService.PowerReporting.Advanced },
                { PowerReporting.None, Microsoft.PointOfService.PowerReporting.None },
                { PowerReporting.Standard, Microsoft.PointOfService.PowerReporting.Standard },

                { Microsoft.PointOfService.PowerNotification.Disabled, PowerNotification.Disabled },
                { Microsoft.PointOfService.PowerNotification.Enabled, PowerNotification.Enabled },
                { PowerNotification.Disabled, Microsoft.PointOfService.PowerNotification.Disabled },
                { PowerNotification.Enabled, Microsoft.PointOfService.PowerNotification.Enabled },

                { Microsoft.PointOfService.PowerState.Off, PowerState.Off },
                { Microsoft.PointOfService.PowerState.Offline, PowerState.Offline },
                { Microsoft.PointOfService.PowerState.OffOffline, PowerState.OffOffline },
                { Microsoft.PointOfService.PowerState.Online, PowerState.Online },
                { Microsoft.PointOfService.PowerState.Unknown, PowerState.Unknown },
                { PowerState.Off, Microsoft.PointOfService.PowerState.Off },
                { PowerState.Offline, Microsoft.PointOfService.PowerState.Offline },
                { PowerState.OffOffline, Microsoft.PointOfService.PowerState.OffOffline },
                { PowerState.Online, Microsoft.PointOfService.PowerState.Online },
                { PowerState.Unknown, Microsoft.PointOfService.PowerState.Unknown },

                { Microsoft.PointOfService.ControlState.Busy, ControlState.Busy },
                { Microsoft.PointOfService.ControlState.Closed, ControlState.Closed },
                { Microsoft.PointOfService.ControlState.Error, ControlState.Error },
                { Microsoft.PointOfService.ControlState.Idle, ControlState.Idle },
                { ControlState.Busy, Microsoft.PointOfService.ControlState.Busy },
                { ControlState.Closed, Microsoft.PointOfService.ControlState.Closed },
                { ControlState.Error, Microsoft.PointOfService.ControlState.Error },
                { ControlState.Idle, Microsoft.PointOfService.ControlState.Idle },

                { Microsoft.PointOfService.HealthCheckLevel.External, HealthCheckLevel.External },
                { Microsoft.PointOfService.HealthCheckLevel.Interactive, HealthCheckLevel.Interactive },
                { Microsoft.PointOfService.HealthCheckLevel.Internal, HealthCheckLevel.Internal },
                { HealthCheckLevel.External, Microsoft.PointOfService.HealthCheckLevel.External },
                { HealthCheckLevel.Interactive, Microsoft.PointOfService.HealthCheckLevel.Interactive },
                { HealthCheckLevel.Internal, Microsoft.PointOfService.HealthCheckLevel.Internal },

                { Microsoft.PointOfService.CompareFirmwareResult.Different, CompareFirmwareResult.Different },
                { Microsoft.PointOfService.CompareFirmwareResult.Newer, CompareFirmwareResult.Newer },
                { Microsoft.PointOfService.CompareFirmwareResult.Older, CompareFirmwareResult.Older },
                { Microsoft.PointOfService.CompareFirmwareResult.Same, CompareFirmwareResult.Same },
                { Microsoft.PointOfService.CompareFirmwareResult.Unknown, CompareFirmwareResult.Unknown },
                { CompareFirmwareResult.Different, Microsoft.PointOfService.CompareFirmwareResult.Different },
                { CompareFirmwareResult.Newer, Microsoft.PointOfService.CompareFirmwareResult.Newer },
                { CompareFirmwareResult.Older, Microsoft.PointOfService.CompareFirmwareResult.Older },
                { CompareFirmwareResult.Same, Microsoft.PointOfService.CompareFirmwareResult.Same },
                { CompareFirmwareResult.Unknown, Microsoft.PointOfService.CompareFirmwareResult.Unknown },

                { Microsoft.PointOfService.ErrorCode.Busy, UnifiedPOS.CheckScanner.ErrorCode.Busy },
                { Microsoft.PointOfService.ErrorCode.Claimed, UnifiedPOS.CheckScanner.ErrorCode.Claimed },
                { Microsoft.PointOfService.ErrorCode.Closed, UnifiedPOS.CheckScanner.ErrorCode.Closed },
                { Microsoft.PointOfService.ErrorCode.Deprecated, UnifiedPOS.CheckScanner.ErrorCode.Deprecated },
                { Microsoft.PointOfService.ErrorCode.Disabled, UnifiedPOS.CheckScanner.ErrorCode.Disabled },
                { Microsoft.PointOfService.ErrorCode.Exists, UnifiedPOS.CheckScanner.ErrorCode.Exists },
                { Microsoft.PointOfService.ErrorCode.Extended, UnifiedPOS.CheckScanner.ErrorCode.Extended },
                { Microsoft.PointOfService.ErrorCode.Failure, UnifiedPOS.CheckScanner.ErrorCode.Failure },
                { Microsoft.PointOfService.ErrorCode.Illegal, UnifiedPOS.CheckScanner.ErrorCode.Illegal },
                { Microsoft.PointOfService.ErrorCode.NoExist, UnifiedPOS.CheckScanner.ErrorCode.NoExist },
                { Microsoft.PointOfService.ErrorCode.NoHardware, UnifiedPOS.CheckScanner.ErrorCode.NoHardware },
                { Microsoft.PointOfService.ErrorCode.NoService, UnifiedPOS.CheckScanner.ErrorCode.NoService },
                { Microsoft.PointOfService.ErrorCode.NotClaimed, UnifiedPOS.CheckScanner.ErrorCode.NotClaimed },
                { Microsoft.PointOfService.ErrorCode.Offline, UnifiedPOS.CheckScanner.ErrorCode.Offline },
                { Microsoft.PointOfService.ErrorCode.Success, UnifiedPOS.CheckScanner.ErrorCode.Success },
                { Microsoft.PointOfService.ErrorCode.Timeout, UnifiedPOS.CheckScanner.ErrorCode.Timeout },
                { UnifiedPOS.CheckScanner.ErrorCode.Busy, Microsoft.PointOfService.ErrorCode.Busy },
                { UnifiedPOS.CheckScanner.ErrorCode.Claimed, Microsoft.PointOfService.ErrorCode.Claimed },
                { UnifiedPOS.CheckScanner.ErrorCode.Closed, Microsoft.PointOfService.ErrorCode.Closed },
                { UnifiedPOS.CheckScanner.ErrorCode.Deprecated, Microsoft.PointOfService.ErrorCode.Deprecated },
                { UnifiedPOS.CheckScanner.ErrorCode.Disabled, Microsoft.PointOfService.ErrorCode.Disabled },
                { UnifiedPOS.CheckScanner.ErrorCode.Exists, Microsoft.PointOfService.ErrorCode.Exists },
                { UnifiedPOS.CheckScanner.ErrorCode.Extended, Microsoft.PointOfService.ErrorCode.Extended },
                { UnifiedPOS.CheckScanner.ErrorCode.Failure, Microsoft.PointOfService.ErrorCode.Failure },
                { UnifiedPOS.CheckScanner.ErrorCode.Illegal, Microsoft.PointOfService.ErrorCode.Illegal },
                { UnifiedPOS.CheckScanner.ErrorCode.NoExist, Microsoft.PointOfService.ErrorCode.NoExist },
                { UnifiedPOS.CheckScanner.ErrorCode.NoHardware, Microsoft.PointOfService.ErrorCode.NoHardware },
                { UnifiedPOS.CheckScanner.ErrorCode.NoService, Microsoft.PointOfService.ErrorCode.NoService },
                { UnifiedPOS.CheckScanner.ErrorCode.NotClaimed, Microsoft.PointOfService.ErrorCode.NotClaimed },
                { UnifiedPOS.CheckScanner.ErrorCode.Offline, Microsoft.PointOfService.ErrorCode.Offline },
                { UnifiedPOS.CheckScanner.ErrorCode.Success, Microsoft.PointOfService.ErrorCode.Success },
                { UnifiedPOS.CheckScanner.ErrorCode.Timeout, Microsoft.PointOfService.ErrorCode.Timeout },

                { Microsoft.PointOfService.CheckImageClear.All, UnifiedPOS.CheckScanner.CheckImageClear.All },
                { Microsoft.PointOfService.CheckImageClear.FileId, UnifiedPOS.CheckScanner.CheckImageClear.FileId },
                { Microsoft.PointOfService.CheckImageClear.FileIndex, UnifiedPOS.CheckScanner.CheckImageClear.FileIndex },
                { Microsoft.PointOfService.CheckImageClear.ImageTagData, UnifiedPOS.CheckScanner.CheckImageClear.ImageTagData },
                { UnifiedPOS.CheckScanner.CheckImageClear.All, Microsoft.PointOfService.CheckImageClear.All },
                { UnifiedPOS.CheckScanner.CheckImageClear.FileId, Microsoft.PointOfService.CheckImageClear.FileId },
                { UnifiedPOS.CheckScanner.CheckImageClear.FileIndex, Microsoft.PointOfService.CheckImageClear.FileIndex },
                { UnifiedPOS.CheckScanner.CheckImageClear.ImageTagData, Microsoft.PointOfService.CheckImageClear.ImageTagData },

                { Microsoft.PointOfService.CheckImageLocate.FileId, UnifiedPOS.CheckScanner.CheckImageLocate.FileId },
                { Microsoft.PointOfService.CheckImageLocate.FileIndex, UnifiedPOS.CheckScanner.CheckImageLocate.FileIndex },
                { Microsoft.PointOfService.CheckImageLocate.ImageTagData, UnifiedPOS.CheckScanner.CheckImageLocate.ImageTagData },
                { UnifiedPOS.CheckScanner.CheckImageLocate.FileId, Microsoft.PointOfService.CheckImageLocate.FileId },
                { UnifiedPOS.CheckScanner.CheckImageLocate.FileIndex, Microsoft.PointOfService.CheckImageLocate.FileIndex },
                { UnifiedPOS.CheckScanner.CheckImageLocate.ImageTagData, Microsoft.PointOfService.CheckImageLocate.ImageTagData },

                { Microsoft.PointOfService.ImageMemoryStatus.Empty, UnifiedPOS.CheckScanner.ImageMemoryStatus.Empty },
                { Microsoft.PointOfService.ImageMemoryStatus.Full, UnifiedPOS.CheckScanner.ImageMemoryStatus.Full },
                { Microsoft.PointOfService.ImageMemoryStatus.OK, UnifiedPOS.CheckScanner.ImageMemoryStatus.OK },
                { UnifiedPOS.CheckScanner.ImageMemoryStatus.Empty, Microsoft.PointOfService.ImageMemoryStatus.Empty },
                { UnifiedPOS.CheckScanner.ImageMemoryStatus.Full, Microsoft.PointOfService.ImageMemoryStatus.Full },
                { UnifiedPOS.CheckScanner.ImageMemoryStatus.OK, Microsoft.PointOfService.ImageMemoryStatus.OK },

                { Microsoft.PointOfService.MapMode.Dots, UnifiedPOS.CheckScanner.MapMode.Dots },
                { Microsoft.PointOfService.MapMode.English, UnifiedPOS.CheckScanner.MapMode.English },
                { Microsoft.PointOfService.MapMode.Metric, UnifiedPOS.CheckScanner.MapMode.Metric },
                { Microsoft.PointOfService.MapMode.Twips, UnifiedPOS.CheckScanner.MapMode.Twips },
                { UnifiedPOS.CheckScanner.MapMode.Dots, Microsoft.PointOfService.MapMode.Dots },
                { UnifiedPOS.CheckScanner.MapMode.English, Microsoft.PointOfService.MapMode.English },
                { UnifiedPOS.CheckScanner.MapMode.Metric, Microsoft.PointOfService.MapMode.Metric },
                { UnifiedPOS.CheckScanner.MapMode.Twips, Microsoft.PointOfService.MapMode.Twips },
            };

        private static Dictionary<Enum, Enum> EventConvert = new Dictionary<Enum, Enum>()
            {
                { Microsoft.PointOfService.ErrorCode.Busy, UnifiedPOS.CheckScannerEvents.ErrorCode.Busy },
                { Microsoft.PointOfService.ErrorCode.Claimed, UnifiedPOS.CheckScannerEvents.ErrorCode.Claimed },
                { Microsoft.PointOfService.ErrorCode.Closed, UnifiedPOS.CheckScannerEvents.ErrorCode.Closed },
                { Microsoft.PointOfService.ErrorCode.Deprecated, UnifiedPOS.CheckScannerEvents.ErrorCode.Deprecated },
                { Microsoft.PointOfService.ErrorCode.Disabled, UnifiedPOS.CheckScannerEvents.ErrorCode.Disabled },
                { Microsoft.PointOfService.ErrorCode.Exists, UnifiedPOS.CheckScannerEvents.ErrorCode.Exists },
                { Microsoft.PointOfService.ErrorCode.Extended, UnifiedPOS.CheckScannerEvents.ErrorCode.Extended },
                { Microsoft.PointOfService.ErrorCode.Failure, UnifiedPOS.CheckScannerEvents.ErrorCode.Failure },
                { Microsoft.PointOfService.ErrorCode.Illegal, UnifiedPOS.CheckScannerEvents.ErrorCode.Illegal },
                { Microsoft.PointOfService.ErrorCode.NoExist, UnifiedPOS.CheckScannerEvents.ErrorCode.NoExist },
                { Microsoft.PointOfService.ErrorCode.NoHardware, UnifiedPOS.CheckScannerEvents.ErrorCode.NoHardware },
                { Microsoft.PointOfService.ErrorCode.NoService, UnifiedPOS.CheckScannerEvents.ErrorCode.NoService },
                { Microsoft.PointOfService.ErrorCode.NotClaimed, UnifiedPOS.CheckScannerEvents.ErrorCode.NotClaimed },
                { Microsoft.PointOfService.ErrorCode.Offline, UnifiedPOS.CheckScannerEvents.ErrorCode.Offline },
                { Microsoft.PointOfService.ErrorCode.Success, UnifiedPOS.CheckScannerEvents.ErrorCode.Success },
                { Microsoft.PointOfService.ErrorCode.Timeout, UnifiedPOS.CheckScannerEvents.ErrorCode.Timeout },
                { UnifiedPOS.CheckScannerEvents.ErrorCode.Busy, Microsoft.PointOfService.ErrorCode.Busy },
                { UnifiedPOS.CheckScannerEvents.ErrorCode.Claimed, Microsoft.PointOfService.ErrorCode.Claimed },
                { UnifiedPOS.CheckScannerEvents.ErrorCode.Closed, Microsoft.PointOfService.ErrorCode.Closed },
                { UnifiedPOS.CheckScannerEvents.ErrorCode.Deprecated, Microsoft.PointOfService.ErrorCode.Deprecated },
                { UnifiedPOS.CheckScannerEvents.ErrorCode.Disabled, Microsoft.PointOfService.ErrorCode.Disabled },
                { UnifiedPOS.CheckScannerEvents.ErrorCode.Exists, Microsoft.PointOfService.ErrorCode.Exists },
                { UnifiedPOS.CheckScannerEvents.ErrorCode.Extended, Microsoft.PointOfService.ErrorCode.Extended },
                { UnifiedPOS.CheckScannerEvents.ErrorCode.Failure, Microsoft.PointOfService.ErrorCode.Failure },
                { UnifiedPOS.CheckScannerEvents.ErrorCode.Illegal, Microsoft.PointOfService.ErrorCode.Illegal },
                { UnifiedPOS.CheckScannerEvents.ErrorCode.NoExist, Microsoft.PointOfService.ErrorCode.NoExist },
                { UnifiedPOS.CheckScannerEvents.ErrorCode.NoHardware, Microsoft.PointOfService.ErrorCode.NoHardware },
                { UnifiedPOS.CheckScannerEvents.ErrorCode.NoService, Microsoft.PointOfService.ErrorCode.NoService },
                { UnifiedPOS.CheckScannerEvents.ErrorCode.NotClaimed, Microsoft.PointOfService.ErrorCode.NotClaimed },
                { UnifiedPOS.CheckScannerEvents.ErrorCode.Offline, Microsoft.PointOfService.ErrorCode.Offline },
                { UnifiedPOS.CheckScannerEvents.ErrorCode.Success, Microsoft.PointOfService.ErrorCode.Success },
                { UnifiedPOS.CheckScannerEvents.ErrorCode.Timeout, Microsoft.PointOfService.ErrorCode.Timeout },

                { Microsoft.PointOfService.ErrorLocus.Input, UnifiedPOS.CheckScannerEvents.ErrorLocus.Input },
                { Microsoft.PointOfService.ErrorLocus.InputData, UnifiedPOS.CheckScannerEvents.ErrorLocus.InputData },
                { Microsoft.PointOfService.ErrorLocus.Output, UnifiedPOS.CheckScannerEvents.ErrorLocus.Output },
                { UnifiedPOS.CheckScannerEvents.ErrorLocus.Input, Microsoft.PointOfService.ErrorLocus.Input },
                { UnifiedPOS.CheckScannerEvents.ErrorLocus.InputData, Microsoft.PointOfService.ErrorLocus.InputData },
                { UnifiedPOS.CheckScannerEvents.ErrorLocus.Output, Microsoft.PointOfService.ErrorLocus.Output },

                { Microsoft.PointOfService.ErrorResponse.Clear, UnifiedPOS.CheckScannerEvents.ErrorResponse.Clear },
                { Microsoft.PointOfService.ErrorResponse.ContinueInput, UnifiedPOS.CheckScannerEvents.ErrorResponse.ContinueInput },
                { Microsoft.PointOfService.ErrorResponse.Retry, UnifiedPOS.CheckScannerEvents.ErrorResponse.Retry },
                { UnifiedPOS.CheckScannerEvents.ErrorResponse.Clear, Microsoft.PointOfService.ErrorResponse.Clear },
                { UnifiedPOS.CheckScannerEvents.ErrorResponse.ContinueInput, Microsoft.PointOfService.ErrorResponse.ContinueInput },
                { UnifiedPOS.CheckScannerEvents.ErrorResponse.Retry, Microsoft.PointOfService.ErrorResponse.Retry },
            };

        #endregion

        private string deviceControlDescription = "";
        private UposVersion deviceControlVersion = new UposVersion() { Major = 1, Minor = 13, Build = 1 };
        private UnifiedPOS.CheckScannerEvents.CheckScannerEvent deviceEvent;
        private Microsoft.PointOfService.CheckScanner device;

        #region Constructor

        public CheckScannerService()
        {
            try
            {
                Microsoft.PointOfService.PosExplorer posExplorer = new Microsoft.PointOfService.PosExplorer();
                Microsoft.PointOfService.DeviceCollection deviceCollection = posExplorer.GetDevices("CheckScanner");
                if (deviceCollection.Count > 0)
                {
                    device = (Microsoft.PointOfService.CheckScanner)posExplorer.CreateInstance(deviceCollection[0]);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        #endregion

        #region CheckScanner Member

        public bool GetAutoDisable()
        {
            //throw new NotImplementedException();
            return device.AutoDisable;
        }

        public void SetAutoDisable(bool AutoDisable)
        {
            //throw new NotImplementedException();
            device.AutoDisable = AutoDisable;
        }

        public bool GetCapCompareFirmwareVersion()
        {
            //throw new NotImplementedException();
            return device.CapCompareFirmwareVersion;
        }

        public PowerReporting GetCapPowerReporting()
        {
            //throw new NotImplementedException();
            return (PowerReporting)Convert[device.CapPowerReporting];
        }

        public bool GetCapStatisticsReporting()
        {
            //throw new NotImplementedException();
            return device.CapStatisticsReporting;
        }

        public bool GetCapUpdateFirmware()
        {
            //throw new NotImplementedException();
            return device.CapUpdateFirmware;
        }

        public bool GetCapUpdateStatistics()
        {
            //throw new NotImplementedException();
            return device.CapUpdateStatistics;
        }

        public string GetCheckHealthText()
        {
            //throw new NotImplementedException();
            return device.CheckHealthText;
        }

        public bool GetClaimed()
        {
            //throw new NotImplementedException();
            return device.Claimed;
        }

        public int GetDataCount()
        {
            //throw new NotImplementedException();
            return device.DataCount;
        }

        public bool GetDataEventEnabled()
        {
            //throw new NotImplementedException();
            return device.DataEventEnabled;
        }

        public void SetDataEventEnabled(bool DataEventEnabled)
        {
            //throw new NotImplementedException();
            device.DataEventEnabled = DataEventEnabled;
        }

        public bool GetDeviceEnabled()
        {
            //throw new NotImplementedException();
            return device.DeviceEnabled;
        }

        public void SetDeviceEnabled(bool DeviceEnabled)
        {
            //throw new NotImplementedException();
            device.DeviceEnabled = DeviceEnabled;
        }

        public bool GetFreezeEvents()
        {
            //throw new NotImplementedException();
            return device.FreezeEvents;
        }

        public void SetFreezeEvents(bool FreezeEvents)
        {
            //throw new NotImplementedException();
            device.FreezeEvents = FreezeEvents;
        }

        public PowerNotification GetPowerNotify()
        {
            //throw new NotImplementedException();
            return (PowerNotification)Convert[device.PowerNotify];
        }

        public void SetPowerNotify(PowerNotification PowerNotify)
        {
            //throw new NotImplementedException();
            device.PowerNotify = (Microsoft.PointOfService.PowerNotification)Convert[PowerNotify];
        }

        public PowerState GetPowerState()
        {
            //throw new NotImplementedException();
            return (PowerState)Convert[device.PowerState];
        }

        public ControlState GetState()
        {
            //throw new NotImplementedException();
            return (ControlState)Convert[device.State];
        }

        public string GetDeviceControlDescription()
        {
            //throw new NotImplementedException();
            return deviceControlDescription;
        }

        public UposVersion GetDeviceControlVersion()
        {
            //throw new NotImplementedException();
            return deviceControlVersion;
        }

        public string GetDeviceServiceDescription()
        {
            //throw new NotImplementedException();
            return device.ServiceObjectDescription;
        }

        public UposVersion GetDeviceServiceVersion()
        {
            //throw new NotImplementedException();
            Version value = device.ServiceObjectVersion;
            return new UposVersion() { Build = value.Build, Major = value.Major, Minor = value.Minor };
        }

        public string GetPhysicalDeviceDescription()
        {
            //throw new NotImplementedException();
            return device.DeviceDescription;
        }

        public string GetPhysicalDeviceName()
        {
            //throw new NotImplementedException();
            return device.DeviceName;
        }

        public bool GetCapAutoContrast()
        {
            //throw new NotImplementedException();
            return device.CapAutoContrast;
        }

        public bool GetCapAutoGenerateFileID()
        {
            //throw new NotImplementedException();
            return device.CapAutoGenerateFileId;
        }

        public bool GetCapAutoGenerateImageTagData()
        {
            //throw new NotImplementedException();
            return device.CapAutoGenerateImageTagData;
        }

        public bool GetCapAutoSize()
        {
            //throw new NotImplementedException();
            return device.CapAutoSize;
        }

        public int GetCapColor()
        {
            //throw new NotImplementedException();
            return (int)device.CapColor;
        }

        public bool GetCapConcurrentMICR()
        {
            //throw new NotImplementedException();
            return device.CapConcurrentMicr;
        }

        public bool GetCapContrast()
        {
            //throw new NotImplementedException();
            return device.CapContrast;
        }

        public bool GetCapDefineCropArea()
        {
            //throw new NotImplementedException();
            return device.CapDefineCropArea;
        }

        public int GetCapImageFormat()
        {
            //throw new NotImplementedException();
            return (int)device.CapImageFormat;
        }

        public bool GetCapImageTagData()
        {
            //throw new NotImplementedException();
            return device.CapImageTagData;
        }

        public bool GetCapMICRDevice()
        {
            //throw new NotImplementedException();
            return device.CapMicrDevice;
        }

        public bool GetCapStoreImageFiles()
        {
            //throw new NotImplementedException();
            return device.CapStoreImageFiles;
        }

        public bool GetCapValidationDevice()
        {
            //throw new NotImplementedException();
            return device.CapValidationDevice;
        }

        public int GetColor()
        {
            //throw new NotImplementedException();
            return (int)device.Color;
        }

        public void SetColor(int Color)
        {
            //throw new NotImplementedException();
            device.Color = (Microsoft.PointOfService.CheckColors)Color;
        }

        public bool GetConcurrentMICR()
        {
            //throw new NotImplementedException();
            return device.ConcurrentMicr;
        }

        public void SetConcurrentMICR(bool ConcurrentMICR)
        {
            //throw new NotImplementedException();
            device.ConcurrentMicr = ConcurrentMICR;
        }

        public int GetContrast()
        {
            //throw new NotImplementedException();
            return device.Contrast;
        }

        public void SetContrast(int Contrast)
        {
            //throw new NotImplementedException();
            device.Contrast = Contrast;
        }

        public int GetCropAreaCount()
        {
            //throw new NotImplementedException();
            return device.CropAreaCount;
        }

        public int GetDocumentHeight()
        {
            //throw new NotImplementedException();
            return device.DocumentHeight;
        }

        public void SetDocumentHeight(int DocumentHeight)
        {
            //throw new NotImplementedException();
            device.DocumentHeight = DocumentHeight;
        }

        public int GetDocumentWidth()
        {
            //throw new NotImplementedException();
            return device.DocumentWidth;
        }

        public void SetDocumentWidth(int DocumentWidth)
        {
            //throw new NotImplementedException();
            device.DocumentWidth = DocumentWidth;
        }

        public string GetFileID()
        {
            //throw new NotImplementedException();
            return device.FileId;
        }

        public void SetFileID(string FileID)
        {
            //throw new NotImplementedException();
            device.FileId = FileID;
        }

        public int GetFileIndex()
        {
            //throw new NotImplementedException();
            return device.FileIndex;
        }

        public void SetFileIndex(int FileIndex)
        {
            //throw new NotImplementedException();
            device.FileIndex = FileIndex;
        }

        public byte[] GetImageData()
        {
            //throw new NotImplementedException();
            System.IO.MemoryStream res = new System.IO.MemoryStream();
            device.ImageData.Save(res, device.ImageData.RawFormat);
            return res.ToArray();
        }

        public int GetImageFormat()
        {
            //throw new NotImplementedException();
            return (int)device.ImageFormat;
        }

        public void SetImageFormat(int ImageFormat)
        {
            //throw new NotImplementedException();
            device.ImageFormat = (Microsoft.PointOfService.CheckImageFormats)ImageFormat;
        }

        public ImageMemoryStatus GetImageMemoryStatus()
        {
            //throw new NotImplementedException();
            return (ImageMemoryStatus)Convert[device.ImageMemoryStatus];
        }

        public string GetImageTagData()
        {
            //throw new NotImplementedException();
            return device.ImageTagData;
        }

        public void SetImageTagData(string ImageTagData)
        {
            //throw new NotImplementedException();
            device.ImageTagData = ImageTagData;
        }

        public MapMode GetMapMode()
        {
            //throw new NotImplementedException();
            return (MapMode)Convert[device.MapMode];
        }

        public void SetMapMode(MapMode MapMode)
        {
            //throw new NotImplementedException();
            device.MapMode = (Microsoft.PointOfService.MapMode)Convert[MapMode];
        }

        public int GetMaxCropAreas()
        {
            //throw new NotImplementedException();
            return device.MaxCropAreas;
        }

        public int GetQuality()
        {
            //throw new NotImplementedException();
            return device.Quality;
        }

        public void SetQuality(int Quality)
        {
            //throw new NotImplementedException();
            device.Quality = Quality;
        }

        public QualityList GetQualityList()
        {
            //throw new NotImplementedException();
            QualityList res = new QualityList();
            res.AddRange(device.QualityList);
            return res;
        }

        public int GetRemainingImagesEstimate()
        {
            //throw new NotImplementedException();
            return device.RemainingImagesEstimate;
        }

        public void Open(string EndpointAddress)
        {
            //throw new NotImplementedException();
            device.Open();
            if (EndpointAddress != null)
            {
                ChannelFactory<UnifiedPOS.CheckScannerEvents.CheckScannerEvent> factory =
                    new ChannelFactory<UnifiedPOS.CheckScannerEvents.CheckScannerEvent>("CheckScannerEventPort", new EndpointAddress(EndpointAddress));
                deviceEvent = factory.CreateChannel();

                device.DataEvent += new Microsoft.PointOfService.DataEventHandler(device_DataEvent);
                device.DirectIOEvent += new Microsoft.PointOfService.DirectIOEventHandler(device_DirectIOEvent);
                device.ErrorEvent += new Microsoft.PointOfService.DeviceErrorEventHandler(device_ErrorEvent);
                device.StatusUpdateEvent += new Microsoft.PointOfService.StatusUpdateEventHandler(device_StatusUpdateEvent);
            }
        }

        public void Close(string EndpointAddress)
        {
            //throw new NotImplementedException();
            device.Close();
            if (deviceEvent != null)
            {
                device.DataEvent -= device_DataEvent;
                device.DirectIOEvent -= device_DirectIOEvent;
                device.ErrorEvent -= device_ErrorEvent;
                device.StatusUpdateEvent -= device_StatusUpdateEvent;

                ((IClientChannel)deviceEvent).Close();
                deviceEvent = null;
            }
        }

        public void Claim(int Timeout)
        {
            //throw new NotImplementedException();
            device.Claim(Timeout);
        }

        public void Release()
        {
            //throw new NotImplementedException();
            device.Release();
        }

        public void CheckHealth(HealthCheckLevel Level)
        {
            //throw new NotImplementedException();
            device.CheckHealth((Microsoft.PointOfService.HealthCheckLevel)Convert[Level]);
        }

        public void ClearInput()
        {
            //throw new NotImplementedException();
            device.ClearInput();
        }

        public void ClearInputProperties()
        {
            //throw new NotImplementedException();
            device.ClearInputProperties();
        }

        public DirectIOData DirectIO(int Command, int Data, object Obj)
        {
            //throw new NotImplementedException();
            Microsoft.PointOfService.DirectIOData value = device.DirectIO(Command, Data, Obj);
            return new DirectIOData() { Data = value.Data, Obj = value.Object };
        }

        public CompareFirmwareResult CompareFirmwareVersion(string FirmwareFileName)
        {
            //throw new NotImplementedException();
            return (CompareFirmwareResult)Convert[device.CompareFirmwareVersion(FirmwareFileName)];
        }

        public void ResetStatistics(StatisticList StatisticsBuffer)
        {
            //throw new NotImplementedException();
            var value = from el in StatisticsBuffer select el.Name;
            switch (value.Count())
            {
                case 0:
                    device.ResetStatistics();
                    break;
                case 1:
                    string name = value.First();
                    switch (name)
                    {
                        case StatisticCategories.All:
                            device.ResetStatistics(Microsoft.PointOfService.StatisticCategories.All);
                            break;
                        case StatisticCategories.Manufacturer:
                            device.ResetStatistics(Microsoft.PointOfService.StatisticCategories.Manufacturer);
                            break;
                        case StatisticCategories.Upos:
                            device.ResetStatistics(Microsoft.PointOfService.StatisticCategories.Upos);
                            break;
                        default:
                            device.ResetStatistic(name);
                            break;
                    }
                    break;
                default:
                    device.ResetStatistics(value.ToArray());
                    break;
            }
        }

        public string RetrieveStatistics(StatisticList StatisticsBuffer)
        {
            //throw new NotImplementedException();
            string res = null;
            var value = from el in StatisticsBuffer select el.Name;
            switch (value.Count())
            {
                case 0:
                    res = device.RetrieveStatistics();
                    break;
                case 1:
                    string name = value.First();
                    switch (name)
                    {
                        case StatisticCategories.All:
                            res = device.RetrieveStatistics(Microsoft.PointOfService.StatisticCategories.All);
                            break;
                        case StatisticCategories.Manufacturer:
                            res = device.RetrieveStatistics(Microsoft.PointOfService.StatisticCategories.Manufacturer);
                            break;
                        case StatisticCategories.Upos:
                            res = device.RetrieveStatistics(Microsoft.PointOfService.StatisticCategories.Upos);
                            break;
                        default:
                            res = device.RetrieveStatistic(name);
                            break;
                    }
                    break;
                default:
                    res = device.RetrieveStatistics(value.ToArray());
                    break;
            }
            return res;
        }

        public void UpdateFirmware(string FirmwareFileName)
        {
            //throw new NotImplementedException();
            device.UpdateFirmware(FirmwareFileName);
        }

        public void UpdateStatistics(StatisticList StatisticsBuffer)
        {
            //throw new NotImplementedException();
            var value = from el in StatisticsBuffer select new Microsoft.PointOfService.Statistic(el.Name, el.Value);
            switch (value.Count())
            {
                case 0:
                    device.UpdateStatistics(value.ToArray());
                    break;
                case 1:
                    Microsoft.PointOfService.Statistic statistic = value.First();
                    switch (statistic.Name)
                    {
                        case StatisticCategories.All:
                            device.UpdateStatistics(Microsoft.PointOfService.StatisticCategories.All, statistic.Value);
                            break;
                        case StatisticCategories.Manufacturer:
                            device.UpdateStatistics(Microsoft.PointOfService.StatisticCategories.Manufacturer, statistic.Value);
                            break;
                        case StatisticCategories.Upos:
                            device.UpdateStatistics(Microsoft.PointOfService.StatisticCategories.Upos, statistic.Value);
                            break;
                        default:
                            device.UpdateStatistic(statistic.Name, statistic.Value);
                            break;
                    }
                    break;
                default:
                    device.UpdateStatistics(value.ToArray());
                    break;
            }
        }

        public void BeginInsertion(int Timeout)
        {
            //throw new NotImplementedException();
            device.BeginInsertion(Timeout);
        }

        public void BeginRemoval(int Timeout)
        {
            //throw new NotImplementedException();
            device.BeginRemoval(Timeout);
        }

        public void ClearImage(CheckImageClear By)
        {
            //throw new NotImplementedException();
            device.ClearImage((Microsoft.PointOfService.CheckImageClear)Convert[By]);
        }

        public void DefineCropArea(int CropAreaID, int X, int Y, int CX, int CY)
        {
            //throw new NotImplementedException();
            device.DefineCropArea(CropAreaID, X, Y, CX, CY);
        }

        public void EndInsertion()
        {
            //throw new NotImplementedException();
            device.EndInsertion();
        }

        public void EndRemoval()
        {
            //throw new NotImplementedException();
            device.EndRemoval();
        }

        public void RetrieveImage(int CropAreaID)
        {
            //throw new NotImplementedException();
            device.RetrieveImage(CropAreaID);
        }

        public void RetrieveMemory(CheckImageLocate By)
        {
            //throw new NotImplementedException();
            device.RetrieveMemory((Microsoft.PointOfService.CheckImageLocate)Convert[By]);
        }

        public void StoreImage(int CropAreaID)
        {
            //throw new NotImplementedException();
            device.StoreImage(CropAreaID);
        }

        #endregion

        #region CheckScannerEvent Member

        private void device_DataEvent(object sender, Microsoft.PointOfService.DataEventArgs e)
        {
            //throw new NotImplementedException();
            if (deviceEvent != null)
            {
                deviceEvent.DataEvent(sender.ToString(), e.EventId, e.TimeStamp, e.Status);
            }
        }

        private void device_DirectIOEvent(object sender, Microsoft.PointOfService.DirectIOEventArgs e)
        {
            //throw new NotImplementedException();
            if (deviceEvent != null)
            {
                UnifiedPOS.CheckScannerEvents.DirectIOData value = deviceEvent.DirectIOEvent(sender.ToString(), e.EventId, e.TimeStamp, e.EventNumber, e.Data, e.Object);
                e.Data = value.Data;
                e.Object = value.Obj;
            }
        }

        private void device_ErrorEvent(object sender, Microsoft.PointOfService.DeviceErrorEventArgs e)
        {
            //throw new NotImplementedException();
            if (deviceEvent != null)
            {
                UnifiedPOS.CheckScannerEvents.ErrorResponse value = deviceEvent.ErrorEvent(sender.ToString(), e.EventId, e.TimeStamp, (UnifiedPOS.CheckScannerEvents.ErrorCode)EventConvert[e.ErrorCode], e.ErrorCodeExtended, (UnifiedPOS.CheckScannerEvents.ErrorLocus)EventConvert[e.ErrorLocus], (UnifiedPOS.CheckScannerEvents.ErrorResponse)EventConvert[e.ErrorResponse]);
                e.ErrorResponse = (Microsoft.PointOfService.ErrorResponse)EventConvert[value];
            }
        }

        private void device_StatusUpdateEvent(object sender, Microsoft.PointOfService.StatusUpdateEventArgs e)
        {
            //throw new NotImplementedException();
            if (deviceEvent != null)
            {
                deviceEvent.StatusUpdateEvent(sender.ToString(), e.EventId, e.TimeStamp, e.Status);
            }
        }

        #endregion

        #region IDisposable Member

        public void Dispose()
        {
            //throw new NotImplementedException();
            if (device != null)
            {
                try
                {
                    device.Close();
                }
                catch
                {
                }
                finally
                {
                    device = null;
                }
            }
            if (deviceEvent != null)
            {
                try
                {
                    ((IClientChannel)deviceEvent).Close();
                }
                catch
                {
                }
                finally
                {
                    deviceEvent = null;
                }
            }
        }

        #endregion
    
    }
}
