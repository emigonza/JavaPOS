
package org.nrf_arts.unifiedpos.belt;

public class StatisticCategories {

    public static final String ALL = "";
    public static final String MANUFACTURER = "M_";
    public static final String UPOS = "U_";

}
