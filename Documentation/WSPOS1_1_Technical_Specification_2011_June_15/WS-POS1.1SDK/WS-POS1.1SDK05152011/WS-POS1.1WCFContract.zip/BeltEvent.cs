﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace UnifiedPOS.BeltEvents
{
    [ServiceContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BeltEvents/")]
    public interface BeltEvent
    {

        //
        // Events
        //

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BeltEvents/DataEvent", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BeltEvents/DataEventResponse")]
        // void DataEvent(string Source, int EventID, DateTime TimeStamp, int Status);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BeltEvents/DirectIOEvent", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BeltEvents/DirectIOEventResponse")]
        DirectIOData DirectIOEvent(string Source, int EventID, DateTime TimeStamp, int EventNumber, int Data, object Obj);

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BeltEvents/ErrorEvent", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BeltEvents/ErrorEventResponse")]
        // ErrorResponse ErrorEvent(string Source, int EventID, DateTime TimeStamp, ErrorCode ErrorCode, int ErrorCodeExtended, ErrorLocus ErrorLocus, ErrorResponse ErrorResponse);

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BeltEvents/OutputCompleteEvent", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BeltEvents/OutputCompleteEventResponse")]
        // void OutputCompleteEvent(string Source, int EventID, DateTime TimeStamp, int OutputID);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BeltEvents/StatusUpdateEvent", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BeltEvents/StatusUpdateEventResponse")]
        void StatusUpdateEvent(string Source, int EventID, DateTime TimeStamp, int Status);
    }

    //
    // Common Data Types
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BeltEvents/")]
    public class DirectIOData
    {
        [DataMember]
        public int Data { get; set; }
        [DataMember]
        public object Obj { get; set; }
    }

    //
    // Common Enumerations
    //

    /*
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BeltEvents/")]
    public enum ErrorCode
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Claimed,
        [EnumMember]
        Closed,
        [EnumMember]
        Deprecated,
        [EnumMember]
        Disabled,
        [EnumMember]
        Exists,
        [EnumMember]
        Extended,
        [EnumMember]
        Failure,
        [EnumMember]
        Illegal,
        [EnumMember]
        NoExist,
        [EnumMember]
        NoHardware,
        [EnumMember]
        NoService,
        [EnumMember]
        NotClaimed,
        [EnumMember]
        Offline,
        [EnumMember]
        Success,
        [EnumMember]
        Timeout,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BeltEvents/")]
    public enum ErrorLocus
    {
        [EnumMember]
        Input,
        [EnumMember]
        InputData,
        [EnumMember]
        Output,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BeltEvents/")]
    public enum ErrorResponse
    {
        [EnumMember]
        Clear,
        [EnumMember]
        ContinueInput,
        [EnumMember]
        Retry,
    }
    */

    //
    // Specific Data Types
    //

    //
    // Specific Enumerations
    //

    //
    // Constants
    //

    /*
    public class Constants
    {
        public const int StatusAutoStop = 11;
        public const int StatusEmergencyStop = 12;
        public const int StatusLightBarrierBackwardInterrupted = 17;
        public const int StatusLightBarrierBackwardOk = 18;
        public const int StatusLightBarrierForwardInterrupted = 19;
        public const int StatusLightBarrierForwardOk = 20;
        public const int StatusMotorFuseDefect = 16;
        public const int StatusMotorOverheating = 15;
        public const int StatusPowerOff = 2002;
        public const int StatusPowerOffline = 2003;
        public const int StatusPowerOffOffline = 2004;
        public const int StatusPowerOnline = 2001;
        public const int StatusSafetyStop = 13;
        public const int StatusSecurityFlapBackwardClosed = 22;
        public const int StatusSecurityFlapBackwardOpened = 21;
        public const int StatusSecurityFlapForwardClosed = 24;
        public const int StatusSecurityFlapForwardOpened = 23;
        public const int StatusTimeoutStop = 14;
        public const int StatusUpdateFirmwareComplete = 2200;
        public const int StatusUpdateFirmwareCompleteDeviceNotRestored = 2205;
        public const int StatusUpdateFirmwareFailedDeviceNeedsFirmware = 2203;
        public const int StatusUpdateFirmwareFailedDeviceOk = 2201;
        public const int StatusUpdateFirmwareFailedDeviceUnknown = 2204;
        public const int StatusUpdateFirmwareFailedDeviceUnrecoverable = 2202;
        public const int StatusUpdateFirmwareProgress = 2100;
    }
    */

    public class Status
    {
        public const int AutoStop = 11;
        public const int EmergencyStop = 12;
        public const int LightBarrierBackwardInterrupted = 17;
        public const int LightBarrierBackwardOk = 18;
        public const int LightBarrierForwardInterrupted = 19;
        public const int LightBarrierForwardOk = 20;
        public const int MotorFuseDefect = 16;
        public const int MotorOverheating = 15;
        public const int PowerOff = 2002;
        public const int PowerOffline = 2003;
        public const int PowerOffOffline = 2004;
        public const int PowerOnline = 2001;
        public const int SafetyStop = 13;
        public const int SecurityFlapBackwardClosed = 22;
        public const int SecurityFlapBackwardOpened = 21;
        public const int SecurityFlapForwardClosed = 24;
        public const int SecurityFlapForwardOpened = 23;
        public const int TimeoutStop = 14;
        public const int UpdateFirmwareComplete = 2200;
        public const int UpdateFirmwareCompleteDeviceNotRestored = 2205;
        public const int UpdateFirmwareFailedDeviceNeedsFirmware = 2203;
        public const int UpdateFirmwareFailedDeviceOk = 2201;
        public const int UpdateFirmwareFailedDeviceUnknown = 2204;
        public const int UpdateFirmwareFailedDeviceUnrecoverable = 2202;
        public const int UpdateFirmwareProgress = 2100;
    }
}
