
package org.nrf_arts.unifiedpos.billacceptor;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for CashCounts complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CashCounts">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Counts" type="{http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/}CashCountList" minOccurs="0"/>
 *         &lt;element name="Discrepancy" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CashCounts", propOrder = {
    "counts",
    "discrepancy"
})
public class CashCounts {

    @XmlElement(name = "Counts", nillable = true)
    protected CashCountList counts;
    @XmlElement(name = "Discrepancy")
    protected Boolean discrepancy;

    /**
     * Gets the value of the counts property.
     * 
     * @return
     *     possible object is
     *     {@link CashCountList }
     *     
     */
    public CashCountList getCounts() {
        return counts;
    }

    /**
     * Sets the value of the counts property.
     * 
     * @param value
     *     allowed object is
     *     {@link CashCountList }
     *     
     */
    public void setCounts(CashCountList value) {
        this.counts = value;
    }

    /**
     * Gets the value of the discrepancy property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isDiscrepancy() {
        return discrepancy;
    }

    /**
     * Sets the value of the discrepancy property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setDiscrepancy(Boolean value) {
        this.discrepancy = value;
    }

}
