﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace UnifiedPOS.MSR
{
    [ServiceContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/MSR/")]
    public interface MSR
    {

        //
        // Common Properties
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetAutoDisableResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        bool GetAutoDisable();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/SetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/SetAutoDisableResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        void SetAutoDisable(bool AutoDisable);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetCapCompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetCapCompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        bool GetCapCompareFirmwareVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetCapPowerReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetCapPowerReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        PowerReporting GetCapPowerReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetCapStatisticsReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetCapStatisticsReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        bool GetCapStatisticsReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetCapUpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetCapUpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        bool GetCapUpdateFirmware();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetCapUpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetCapUpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        bool GetCapUpdateStatistics();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetCheckHealthText", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetCheckHealthTextResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        string GetCheckHealthText();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetClaimed", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetClaimedResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        bool GetClaimed();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetDataCount", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetDataCountResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        int GetDataCount();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetDataEventEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        bool GetDataEventEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/SetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/SetDataEventEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        void SetDataEventEnabled(bool DataEventEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        bool GetDeviceEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/SetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/SetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        void SetDeviceEnabled(bool DeviceEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        bool GetFreezeEvents();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/SetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/SetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        void SetFreezeEvents(bool FreezeEvents);

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetOutputID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetOutputIDResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        // int GetOutputID();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        PowerNotification GetPowerNotify();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/SetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/SetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        void SetPowerNotify(PowerNotification PowerNotify);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetPowerState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetPowerStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        PowerState GetPowerState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        ControlState GetState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetDeviceControlDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetDeviceControlDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        string GetDeviceControlDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetDeviceControlVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetDeviceControlVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        UposVersion GetDeviceControlVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetDeviceServiceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetDeviceServiceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        string GetDeviceServiceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetDeviceServiceVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetDeviceServiceVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        UposVersion GetDeviceServiceVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetPhysicalDeviceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetPhysicalDeviceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        string GetPhysicalDeviceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetPhysicalDeviceName", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetPhysicalDeviceNameResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        string GetPhysicalDeviceName();

        //
        // Specific Properties
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetCapCardAuthentication", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetCapCardAuthenticationResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        string GetCapCardAuthentication();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetCapDataEncryption", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetCapDataEncryptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        int GetCapDataEncryption();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetCapDeviceAuthentication", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetCapDeviceAuthenticationResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        DeviceAuthenticationLevel GetCapDeviceAuthentication();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetCapISO", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetCapISOResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        bool GetCapISO();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetCapJISOne", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetCapJISOneResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        bool GetCapJISOne();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetCapJISTwo", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetCapJISTwoResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        bool GetCapJISTwo();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetCapTrackDataMasking", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetCapTrackDataMaskingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        bool GetCapTrackDataMasking();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetCapTransmitSentinels", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetCapTransmitSentinelsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        bool GetCapTransmitSentinels();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetCapWritableTracks", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetCapWritableTracksResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        MSRTracks GetCapWritableTracks();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetAccountNumber", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetAccountNumberResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        string GetAccountNumber();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetAdditionalSecurityInformation", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetAdditionalSecurityInformationResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        byte[] GetAdditionalSecurityInformation();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetCardAuthenticationData", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetCardAuthenticationDataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        byte[] GetCardAuthenticationData();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetCardAuthenticationDataLength", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetCardAuthenticationDataLengthResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        int GetCardAuthenticationDataLength();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetCardPropertyList", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetCardPropertyListResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        CardPropertyList GetCardPropertyList();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetCardType", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetCardTypeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        string GetCardType();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetCardTypeList", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetCardTypeListResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        CardTypeList GetCardTypeList();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetDataEncryptionAlgorithm", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetDataEncryptionAlgorithmResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        int GetDataEncryptionAlgorithm();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/SetDataEncryptionAlgorithm", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/SetDataEncryptionAlgorithmResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        void SetDataEncryptionAlgorithm(int DataEncryptionAlgorithm);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetDecodeData", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetDecodeDataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        bool GetDecodeData();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/SetDecodeData", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/SetDecodeDataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        void SetDecodeData(bool DecodeData);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetDeviceAuthenticated", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetDeviceAuthenticatedResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        bool GetDeviceAuthenticated();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetDeviceAuthenticationProtocol", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetDeviceAuthenticationProtocolResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        DeviceAuthenticationProtocol GetDeviceAuthenticationProtocol();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetEncodingMaxLength", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetEncodingMaxLengthResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        int GetEncodingMaxLength();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetErrorReportingType", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetErrorReportingTypeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        MSRErrorReporting GetErrorReportingType();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/SetErrorReportingType", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/SetErrorReportingTypeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        void SetErrorReportingType(MSRErrorReporting ErrorReportingType);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetExpirationDate", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetExpirationDateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        string GetExpirationDate();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetFirstName", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetFirstNameResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        string GetFirstName();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetMiddleInitial", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetMiddleInitialResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        string GetMiddleInitial();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetParseDecodeData", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetParseDecodeDataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        bool GetParseDecodeData();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/SetParseDecodeData", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/SetParseDecodeDataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        void SetParseDecodeData(bool ParseDecodeData);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetServiceCode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetServiceCodeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        string GetServiceCode();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetSuffix", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetSuffixResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        string GetSuffix();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetSurname", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetSurnameResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        string GetSurname();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetTitle", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetTitleResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        string GetTitle();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetTrack1Data", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetTrack1DataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        byte[] GetTrack1Data();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetTrack1DiscretionaryData", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetTrack1DiscretionaryDataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        byte[] GetTrack1DiscretionaryData();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetTrack1EncryptedData", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetTrack1EncryptedDataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        byte[] GetTrack1EncryptedData();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetTrack1EncryptedDataLength", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetTrack1EncryptedDataLengthResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        int GetTrack1EncryptedDataLength();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetTrack2Data", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetTrack2DataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        byte[] GetTrack2Data();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetTrack2DiscretionaryData", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetTrack2DiscretionaryDataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        byte[] GetTrack2DiscretionaryData();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetTrack2EncryptedData", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetTrack2EncryptedDataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        byte[] GetTrack2EncryptedData();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetTrack2EncryptedDataLength", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetTrack2EncryptedDataLengthResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        int GetTrack2EncryptedDataLength();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetTrack3Data", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetTrack3DataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        byte[] GetTrack3Data();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetTrack3EncryptedData", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetTrack3EncryptedDataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        byte[] GetTrack3EncryptedData();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetTrack3EncryptedDataLength", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetTrack3EncryptedDataLengthResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        int GetTrack3EncryptedDataLength();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetTrack4Data", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetTrack4DataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        byte[] GetTrack4Data();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetTrack4EncryptedData", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetTrack4EncryptedDataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        byte[] GetTrack4EncryptedData();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetTrack4EncryptedDataLength", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetTrack4EncryptedDataLengthResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        int GetTrack4EncryptedDataLength();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetTracksToRead", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetTracksToReadResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        MSRTracks GetTracksToRead();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/SetTracksToRead", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/SetTracksToReadResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        void SetTracksToRead(MSRTracks TracksToRead);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetTracksToWrite", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetTracksToWriteResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        MSRTracks GetTracksToWrite();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/SetTracksToWrite", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/SetTracksToWriteResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        void SetTracksToWrite(MSRTracks TracksToWrite);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetTransmitSentinels", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetTransmitSentinelsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        bool GetTransmitSentinels();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/SetTransmitSentinels", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/SetTransmitSentinelsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        void SetTransmitSentinels(bool TransmitSentinels);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetWriteCardType", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/GetWriteCardTypeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        string GetWriteCardType();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/SetWriteCardType", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/SetWriteCardTypeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        void SetWriteCardType(string WriteCardType);

        //
        // Common Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/Open", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/OpenResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        void Open(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/Close", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/CloseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        void Close(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/Claim", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/ClaimResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        void Claim(int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/Release", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/ReleaseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        void Release();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/CheckHealth", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/CheckHealthResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        void CheckHealth(HealthCheckLevel Level);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/ClearInput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/ClearInputResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        void ClearInput();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/ClearInputProperties", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/ClearInputPropertiesResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        void ClearInputProperties();

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/ClearOutput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/ClearOutputResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        // void ClearOutput();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/DirectIO", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/DirectIOResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        DirectIOData DirectIO(int Command, int Data, object Obj);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/CompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/CompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        CompareFirmwareResult CompareFirmwareVersion(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/ResetStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/ResetStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        void ResetStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/RetrieveStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/RetrieveStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        string RetrieveStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/UpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        void UpdateFirmware(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/UpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        void UpdateStatistics(StatisticList StatisticsBuffer);

        //
        // Specific Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/AuthenticateDevice", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/AuthenticateDeviceResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        void AuthenticateDevice(byte[] Response);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/DeauthenticateDevice", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/DeauthenticateDeviceResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        void DeauthenticateDevice(byte[] Response);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/RetrieveCardProperty", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/RetrieveCardPropertyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        string RetrieveCardProperty(string Name);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/RetrieveDeviceAuthenticationData", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/RetrieveDeviceAuthenticationDataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        byte[] RetrieveDeviceAuthenticationData();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UpdateKey", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/UpdateKeyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        void UpdateKey(string Key, string KeyName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/WriteTracks", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MSR/WriteTracksResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MSR/UposException", Name = "UposException")]
        void WriteTracks(byte[] Track1Data, byte[] Track2Data, byte[] Track3Data, byte[] Track4Data, int Timeout);
    }

    //
    // Common Data Types
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/MSR/")]
    public class DirectIOData
    {
        [DataMember]
        public int Data { get; set; }
        [DataMember]
        public object Obj { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/MSR/")]
    public class UposException
    {
        [DataMember]
        public ErrorCode ErrorCode { get; set; }
        [DataMember]
        public int ErrorCodeExtended { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/MSR/")]
    public class UposVersion
    {
        [DataMember]
        public int Major { get; set; }
        [DataMember]
        public int Minor { get; set; }
        [DataMember]
        public int Build { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/MSR/")]
    public class Statistic
    {
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public string Value { get; set; }
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/MSR/", ItemName = "Statistic")]
    public class StatisticList : List<Statistic>
    {
    }

    //
    // Common Enumerations
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/MSR/")]
    public enum CompareFirmwareResult
    {
        [EnumMember]
        Different,
        [EnumMember]
        Newer,
        [EnumMember]
        Older,
        [EnumMember]
        Same,
        [EnumMember]
        Unknown,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/MSR/")]
    public enum ControlState
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Closed,
        [EnumMember]
        Error,
        [EnumMember]
        Idle,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/MSR/")]
    public enum ErrorCode
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Claimed,
        [EnumMember]
        Closed,
        [EnumMember]
        Deprecated,
        [EnumMember]
        Disabled,
        [EnumMember]
        Exists,
        [EnumMember]
        Extended,
        [EnumMember]
        Failure,
        [EnumMember]
        Illegal,
        [EnumMember]
        NoExist,
        [EnumMember]
        NoHardware,
        [EnumMember]
        NoService,
        [EnumMember]
        NotClaimed,
        [EnumMember]
        Offline,
        [EnumMember]
        Success,
        [EnumMember]
        Timeout,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/MSR/")]
    public enum HealthCheckLevel
    {
        [EnumMember]
        External,
        [EnumMember]
        Interactive,
        [EnumMember]
        Internal,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/MSR/")]
    public enum PowerNotification
    {
        [EnumMember]
        Disabled,
        [EnumMember]
        Enabled,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/MSR/")]
    public enum PowerReporting
    {
        [EnumMember]
        Advanced,
        [EnumMember]
        None,
        [EnumMember]
        Standard,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/MSR/")]
    public enum PowerState
    {
        [EnumMember]
        Off,
        [EnumMember]
        Offline,
        [EnumMember]
        OffOffline,
        [EnumMember]
        Online,
        [EnumMember]
        Unknown,
    }

    /*
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/MSR/")]
    public enum StatisticCategories
    {
        [EnumMember]
        All,
        [EnumMember]
        Manufacturer,
        [EnumMember]
        Upos,
    }
    */
    public class StatisticCategories
    {
        public const string All = "";
        public const string Manufacturer = "M_";
        public const string Upos = "U_";
    }

    //
    // Specific Data Types
    //

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/MSR/", ItemName = "CardProperty")]
    public class CardPropertyList : List<string>
    {
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/MSR/", ItemName = "CardType")]
    public class CardTypeList : List<string>
    {
    }

    //
    // Specific Enumerations
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/MSR/")]
    public enum DeviceAuthenticationLevel
    {
        [EnumMember]
        NotSupported,
        [EnumMember]
        Optional,
        [EnumMember]
        Required,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/MSR/")]
    public enum DeviceAuthenticationProtocol
    {
        [EnumMember]
        ChallengeResponse,
        [EnumMember]
        None,
    }

    /*
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/MSR/")]
    public enum EncryptionAlgorithm
    {
        [EnumMember]
        None,
        [EnumMember]
        TripleDeaDukpt,
    }
    */
    public class EncryptionAlgorithm
    {
        public const int None = 1;
        public const int TripleDeaDukpt = 2;
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/MSR/")]
    public enum MSRErrorReporting
    {
        [EnumMember]
        Card,
        [EnumMember]
        Track,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/MSR/")]
    public enum MSRTracks
    {
        [EnumMember]
        None,
        [EnumMember]
        Track1,
        [EnumMember]
        Track2,
        [EnumMember]
        Track3,
        [EnumMember]
        Track4,
        [EnumMember]
        Tracks12,
        [EnumMember]
        Tracks123,
        [EnumMember]
        Tracks1234,
        [EnumMember]
        Tracks124,
        [EnumMember]
        Tracks13,
        [EnumMember]
        Tracks134,
        [EnumMember]
        Tracks14,
        [EnumMember]
        Tracks23,
        [EnumMember]
        Tracks234,
        [EnumMember]
        Tracks24,
        [EnumMember]
        Tracks34,
    }

    //
    // Constants
    //

    /*
    public class Constants
    {
        public const string CardTypeAamva = "AAMVA";
        public const string CardTypeBank = "BANK";
        public const int ExtendedErrorDeviceAuthenticationFailed = 205;
        public const int ExtendedErrorDeviceDeauthenticationFailed = 206;
        public const int ExtendedErrorEnd = 202;
        public const int ExtendedErrorFailure = 111;
        public const int ExtendedErrorFirmwareBadFile = 281;
        public const int ExtendedErrorLrc = 204;
        public const int ExtendedErrorParity = 203;
        public const int ExtendedErrorStart = 201;
        public const int ExtendedErrorStatistics = 280;
        public const int ExtendedErrorStatisticsDependency = 282;
        public const int ExtendedErrorSuccess = 0;
        public const string StatisticChallengeRequestCount = "ChallengeRequestCount";
        public const string StatisticCommunicationErrorCount = "CommunicationErrorCount";
        public const string StatisticDeviceCategory = "DeviceCategory";
        public const string StatisticFailedCardAuthenticationDataCount = "FailedCardAuthenticationDataCount";
        public const string StatisticFailedDeviceAuthenticationCount = "FailedDeviceAuthenticationCount";
        public const string StatisticFailedReadCount = "FailedReadCount";
        public const string StatisticFailedWriteCount = "FailedWriteCount";
        public const string StatisticFirmwareRevision = "FirmwareRevision";
        public const string StatisticGoodCardAuthenticationDataCount = "GoodCardAuthenticationDataCount";
        public const string StatisticGoodDeviceAuthenticationCount = "GoodDeviceAuthenticationCount";
        public const string StatisticGoodReadCount = "GoodReadCount";
        public const string StatisticGoodWriteCount = "GoodWriteCount";
        public const string StatisticHoursPoweredCount = "HoursPoweredCount";
        public const string StatisticInstallationDate = "InstallationDate";
        public const string StatisticInterface = "Interface";
        public const string StatisticManufactureDate = "ManufactureDate";
        public const string StatisticManufacturerName = "ManufacturerName";
        public const string StatisticMechanicalRevision = "MechanicalRevision";
        public const string StatisticMissingStartSentinelTrack1Count = "MissingStartSentinelTrack1Count";
        public const string StatisticMissingStartSentinelTrack2Count = "MissingStartSentinelTrack2Count";
        public const string StatisticMissingStartSentinelTrack3Count = "MissingStartSentinelTrack3Count";
        public const string StatisticMissingStartSentinelTrack4Count = "MissingStartSentinelTrack4Count";
        public const string StatisticModelName = "ModelName";
        public const string StatisticParityLrcErrorTrack1Count = "ParityLrcErrorTrack1Count";
        public const string StatisticParityLrcErrorTrack2Count = "ParityLrcErrorTrack2Count";
        public const string StatisticParityLrcErrorTrack3Count = "ParityLrcErrorTrack3Count";
        public const string StatisticParityLrcErrorTrack4Count = "ParityLrcErrorTrack4Count";
        public const string StatisticSerialNumber = "SerialNumber";
        public const string StatisticUnifiedPOSVersion = "UnifiedPOSVersion";
        public const string StatisticUnreadableCardCount = "UnreadableCardCount";
        public const int WaitForever = -1;
    }
    */

    public class AamvaCardProperties
    {
        public const string Address = "Address";
        public const string BirthDate = "BirthDate";
        public const string City = "City";
        public const string Class = "Class";
        public const string Endorsements = "Endorsements";
        public const string ExpirationDate = "ExpirationDate";
        public const string EyeColor = "EyeColor";
        public const string FirstName = "FirstName";
        public const string Gender = "Gender";
        public const string HairColor = "HairColor";
        public const string Height = "Height";
        public const string LicenseNumber = "LicenseNumber";
        public const string PostalCode = "PostalCode";
        public const string Restrictions = "Restrictions";
        public const string State = "State";
        public const string Suffix = "Suffix";
        public const string Surname = "Surname";
        public const string Weight = "Weight";
    }

    public class BankCardProperties
    {
        public const string AccountNumber = "AccountNumber";
        public const string ExpirationDate = "ExpirationDate";
        public const string FirstName = "FirstName";
        public const string MiddleInitial = "MiddleInitial";
        public const string ServiceCode = "ServiceCode";
        public const string Suffix = "Suffix";
        public const string Surname = "Surname";
        public const string Title = "Title";
    }

    public class CardType
    {
        public const string Aamva = "AAMVA";
        public const string Bank = "BANK";
    }

    public class ExtendedError
    {
        public const int DeviceAuthenticationFailed = 205;
        public const int DeviceDeauthenticationFailed = 206;
        public const int End = 202;
        public const int Failure = 111;
        public const int FirmwareBadFile = 281;
        public const int Lrc = 204;
        public const int Parity = 203;
        public const int Start = 201;
        public const int Statistics = 280;
        public const int StatisticsDependency = 282;
        public const int Success = 0;
    }

    public class StatisticProperties
    {
        public const string ChallengeRequestCount = "ChallengeRequestCount";
        public const string CommunicationErrorCount = "CommunicationErrorCount";
        public const string DeviceCategory = "DeviceCategory";
        public const string FailedCardAuthenticationDataCount = "FailedCardAuthenticationDataCount";
        public const string FailedDeviceAuthenticationCount = "FailedDeviceAuthenticationCount";
        public const string FailedReadCount = "FailedReadCount";
        public const string FailedWriteCount = "FailedWriteCount";
        public const string FirmwareRevision = "FirmwareRevision";
        public const string GoodCardAuthenticationDataCount = "GoodCardAuthenticationDataCount";
        public const string GoodDeviceAuthenticationCount = "GoodDeviceAuthenticationCount";
        public const string GoodReadCount = "GoodReadCount";
        public const string GoodWriteCount = "GoodWriteCount";
        public const string HoursPoweredCount = "HoursPoweredCount";
        public const string InstallationDate = "InstallationDate";
        public const string Interface = "Interface";
        public const string ManufactureDate = "ManufactureDate";
        public const string ManufacturerName = "ManufacturerName";
        public const string MechanicalRevision = "MechanicalRevision";
        public const string MissingStartSentinelTrack1Count = "MissingStartSentinelTrack1Count";
        public const string MissingStartSentinelTrack2Count = "MissingStartSentinelTrack2Count";
        public const string MissingStartSentinelTrack3Count = "MissingStartSentinelTrack3Count";
        public const string MissingStartSentinelTrack4Count = "MissingStartSentinelTrack4Count";
        public const string ModelName = "ModelName";
        public const string ParityLrcErrorTrack1Count = "ParityLrcErrorTrack1Count";
        public const string ParityLrcErrorTrack2Count = "ParityLrcErrorTrack2Count";
        public const string ParityLrcErrorTrack3Count = "ParityLrcErrorTrack3Count";
        public const string ParityLrcErrorTrack4Count = "ParityLrcErrorTrack4Count";
        public const string SerialNumber = "SerialNumber";
        public const string UnifiedPOSVersion = "UnifiedPOSVersion";
        public const string UnreadableCardCount = "UnreadableCardCount";
    }

    public class Wait
    {
        public const int Forever = -1;
    }
}
