﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace UnifiedPOS.Scale
{
    [ServiceContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Scale/")]
    public interface Scale
    {

        //
        // Common Properties
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetAutoDisableResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        bool GetAutoDisable();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/SetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/SetAutoDisableResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        void SetAutoDisable(bool AutoDisable);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetCapCompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetCapCompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        bool GetCapCompareFirmwareVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetCapPowerReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetCapPowerReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        PowerReporting GetCapPowerReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetCapStatisticsReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetCapStatisticsReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        bool GetCapStatisticsReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetCapUpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetCapUpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        bool GetCapUpdateFirmware();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetCapUpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetCapUpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        bool GetCapUpdateStatistics();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetCheckHealthText", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetCheckHealthTextResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        string GetCheckHealthText();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetClaimed", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetClaimedResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        bool GetClaimed();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetDataCount", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetDataCountResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        int GetDataCount();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetDataEventEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        bool GetDataEventEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/SetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/SetDataEventEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        void SetDataEventEnabled(bool DataEventEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        bool GetDeviceEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/SetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/SetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        void SetDeviceEnabled(bool DeviceEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        bool GetFreezeEvents();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/SetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/SetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        void SetFreezeEvents(bool FreezeEvents);

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetOutputID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetOutputIDResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        // int GetOutputID();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        PowerNotification GetPowerNotify();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/SetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/SetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        void SetPowerNotify(PowerNotification PowerNotify);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetPowerState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetPowerStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        PowerState GetPowerState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        ControlState GetState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetDeviceControlDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetDeviceControlDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        string GetDeviceControlDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetDeviceControlVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetDeviceControlVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        UposVersion GetDeviceControlVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetDeviceServiceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetDeviceServiceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        string GetDeviceServiceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetDeviceServiceVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetDeviceServiceVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        UposVersion GetDeviceServiceVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetPhysicalDeviceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetPhysicalDeviceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        string GetPhysicalDeviceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetPhysicalDeviceName", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetPhysicalDeviceNameResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        string GetPhysicalDeviceName();

        //
        // Specific Properties
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetAsyncMode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetAsyncModeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        bool GetAsyncMode();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/SetAsyncMode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/SetAsyncModeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        void SetAsyncMode(bool AsyncMode);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetCapDisplay", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetCapDisplayResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        bool GetCapDisplay();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetCapDisplayText", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetCapDisplayTextResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        bool GetCapDisplayText();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetCapPriceCalculating", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetCapPriceCalculatingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        bool GetCapPriceCalculating();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetCapStatusUpdate", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetCapStatusUpdateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        bool GetCapStatusUpdate();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetCapTareWeight", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetCapTareWeightResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        bool GetCapTareWeight();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetCapZeroScale", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetCapZeroScaleResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        bool GetCapZeroScale();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetMaxDisplayTextChars", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetMaxDisplayTextCharsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        int GetMaxDisplayTextChars();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetMaximumWeight", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetMaximumWeightResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        decimal GetMaximumWeight();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetSalesPrice", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetSalesPriceResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        decimal GetSalesPrice();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetScaleLiveWeight", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetScaleLiveWeightResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        decimal GetScaleLiveWeight();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetStatusNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetStatusNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        StatusNotify GetStatusNotify();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/SetStatusNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/SetStatusNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        void SetStatusNotify(StatusNotify StatusNotify);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetTareWeight", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetTareWeightResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        decimal GetTareWeight();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/SetTareWeight", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/SetTareWeightResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        void SetTareWeight(decimal TareWeight);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetUnitPrice", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetUnitPriceResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        decimal GetUnitPrice();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/SetUnitPrice", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/SetUnitPriceResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        void SetUnitPrice(decimal UnitPrice);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetWeightUnit", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetWeightUnitResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        WeightUnit GetWeightUnit();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetZeroValid", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/GetZeroValidResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        bool GetZeroValid();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/SetZeroValid", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/SetZeroValidResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        void SetZeroValid(bool ZeroValid);

        //
        // Common Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/Open", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/OpenResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        void Open(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/Close", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/CloseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        void Close(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/Claim", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/ClaimResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        void Claim(int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/Release", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/ReleaseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        void Release();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/CheckHealth", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/CheckHealthResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        void CheckHealth(HealthCheckLevel Level);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/ClearInput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/ClearInputResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        void ClearInput();

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/ClearInputProperties", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/ClearInputPropertiesResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        // void ClearInputProperties();

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/ClearOutput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/ClearOutputResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        // void ClearOutput();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/DirectIO", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/DirectIOResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        DirectIOData DirectIO(int Command, int Data, object Obj);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/CompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/CompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        CompareFirmwareResult CompareFirmwareVersion(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/ResetStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/ResetStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        void ResetStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/RetrieveStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/RetrieveStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        string RetrieveStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/UpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        void UpdateFirmware(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/UpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        void UpdateStatistics(StatisticList StatisticsBuffer);

        //
        // Specific Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/DisplayText", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/DisplayTextResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        void DisplayText(string Data);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/ReadWeight", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/ReadWeightResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        decimal ReadWeight(int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/ZeroScale", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scale/ZeroScaleResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scale/UposException", Name = "UposException")]
        void ZeroScale();

    }

    //
    // Common Data Types
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Scale/")]
    public class DirectIOData
    {
        [DataMember]
        public int Data { get; set; }
        [DataMember]
        public object Obj { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Scale/")]
    public class UposException
    {
        [DataMember]
        public ErrorCode ErrorCode { get; set; }
        [DataMember]
        public int ErrorCodeExtended { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Scale/")]
    public class UposVersion
    {
        [DataMember]
        public int Major { get; set; }
        [DataMember]
        public int Minor { get; set; }
        [DataMember]
        public int Build { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Scale/")]
    public class Statistic
    {
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public string Value { get; set; }
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Scale/", ItemName = "Statistic")]
    public class StatisticList : List<Statistic>
    {
    }

    //
    // Common Enumerations
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Scale/")]
    public enum CompareFirmwareResult
    {
        [EnumMember]
        Different,
        [EnumMember]
        Newer,
        [EnumMember]
        Older,
        [EnumMember]
        Same,
        [EnumMember]
        Unknown,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Scale/")]
    public enum ControlState
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Closed,
        [EnumMember]
        Error,
        [EnumMember]
        Idle,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Scale/")]
    public enum ErrorCode
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Claimed,
        [EnumMember]
        Closed,
        [EnumMember]
        Deprecated,
        [EnumMember]
        Disabled,
        [EnumMember]
        Exists,
        [EnumMember]
        Extended,
        [EnumMember]
        Failure,
        [EnumMember]
        Illegal,
        [EnumMember]
        NoExist,
        [EnumMember]
        NoHardware,
        [EnumMember]
        NoService,
        [EnumMember]
        NotClaimed,
        [EnumMember]
        Offline,
        [EnumMember]
        Success,
        [EnumMember]
        Timeout,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Scale/")]
    public enum HealthCheckLevel
    {
        [EnumMember]
        External,
        [EnumMember]
        Interactive,
        [EnumMember]
        Internal,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Scale/")]
    public enum PowerNotification
    {
        [EnumMember]
        Disabled,
        [EnumMember]
        Enabled,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Scale/")]
    public enum PowerReporting
    {
        [EnumMember]
        Advanced,
        [EnumMember]
        None,
        [EnumMember]
        Standard,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Scale/")]
    public enum PowerState
    {
        [EnumMember]
        Off,
        [EnumMember]
        Offline,
        [EnumMember]
        OffOffline,
        [EnumMember]
        Online,
        [EnumMember]
        Unknown,
    }

    // [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Scale/")]
    // public enum StatisticCategories
    // {
    //     [EnumMember]
    //     All,
    //     [EnumMember]
    //     Manufacturer,
    //     [EnumMember]
    //     Upos,
    // }

    public class StatisticCategories
    {
        public const string All = "";
        public const string Manufacturer = "M_";
        public const string Upos = "U_";
    }

    //
    // Specific Data Types
    //

    //
    // Specific Enumerations
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Scale/")]
    public enum StatusNotify
    {
        [EnumMember]
        Disabled,
        [EnumMember]
        Enabled,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Scale/")]
    public enum WeightUnit
    {
        [EnumMember]
        Gram,
        [EnumMember]
        Kilogram,
        [EnumMember]
        Ounce,
        [EnumMember]
        Pound,
    }

    //
    // Constants
    //

    public class ExtendedError
    {
        public const int FirmwareBadFile = 281;
        public const int OverWeight = 201;
        public const int SameWeight = 203;
        public const int Statistics = 280;
        public const int StatisticsDependency = 282;
        public const int UnderZero = 202;
    }

    public class StatisticProperties
    {
        public const string CommunicationErrorCount = "CommunicationErrorCount";
        public const string DeviceCategory = "DeviceCategory";
        public const string FirmwareRevision = "FirmwareRevision";
        public const string GoodWeightReadCount = "GoodWeightReadCount";
        public const string HoursPoweredCount = "HoursPoweredCount";
        public const string InstallationDate = "InstallationDate";
        public const string Interface = "Interface";
        public const string ManufactureDate = "ManufactureDate";
        public const string ManufacturerName = "ManufacturerName";
        public const string MechanicalRevision = "MechanicalRevision";
        public const string ModelName = "ModelName";
        public const string SerialNumber = "SerialNumber";
        public const string UnifiedPOSVersion = "UnifiedPOSVersion";
    }

    public class Wait
    {
        public const int Forever = -1;
    }
}
