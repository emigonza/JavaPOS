/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package wspos;

import java.math.BigDecimal;
import java.net.URL;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import javax.xml.datatype.XMLGregorianCalendar;
import jpos.events.DataEvent;
import jpos.events.DirectIOEvent;
import jpos.events.ErrorEvent;
import jpos.events.OutputCompleteEvent;
import jpos.events.StatusUpdateEvent;
import org.nrf_arts.unifiedpos.electronicvaluerw.*;
import javax.jws.WebService;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.namespace.QName;
import javax.xml.ws.Service;

/**
 *
 * @author hideon
 */
@WebService(serviceName = "ElectronicValueRWService", endpointInterface = "org.nrf_arts.unifiedpos.electronicvaluerw.ElectronicValueRW", targetNamespace = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/")
public class ElectronicValueRWService implements ElectronicValueRW, jpos.events.DataListener, jpos.events.DirectIOListener, jpos.events.ErrorListener, jpos.events.OutputCompleteListener, jpos.events.StatusUpdateListener {

    //
    // ElectronicValueRW Enumration Converter
    //

    private static HashMap<Enum, Integer> jposConst;
    private static HashMap<Integer, PowerReporting> powerReporting;
    private static HashMap<Integer, PowerNotification> powerNotification;
    private static HashMap<Integer, PowerState> powerState;
    private static HashMap<Integer, ControlState> controlState;
    private static HashMap<Integer, HealthCheckLevel> healthCheckLevel;
    private static HashMap<Integer, CompareFirmwareResult> compareFirmwareResult;
    private static HashMap<Integer, ErrorCode> errorCode;
    private static HashMap<Integer, DetectionState> detectionState;
    private static HashMap<Integer, LogState> logState;
    private static HashMap<Integer, TransactionLogType> transactionLogType;
    private static HashMap<Integer, BeginDetectionType> beginDetectionType;
    private static HashMap<Integer, TransactionControl> transactionControl;

    private static HashMap<Enum, Integer> jposEventConst;
    private static HashMap<Integer, org.nrf_arts.unifiedpos.electronicvaluerwevents.ErrorCode> eventErrorCode;
    private static HashMap<Integer, org.nrf_arts.unifiedpos.electronicvaluerwevents.ErrorLocus> eventErrorLocus;
    private static HashMap<Integer, org.nrf_arts.unifiedpos.electronicvaluerwevents.ErrorResponse> eventErrorResponse;

    static {
        jposConst = new HashMap<Enum, Integer>();
        jposConst.put(PowerReporting.ADVANCED, jpos.ElectronicValueRW.JPOS_PR_ADVANCED);
        jposConst.put(PowerReporting.NONE, jpos.ElectronicValueRW.JPOS_PR_NONE);
        jposConst.put(PowerReporting.STANDARD, jpos.ElectronicValueRW.JPOS_PR_STANDARD);
        jposConst.put(PowerNotification.DISABLED, jpos.ElectronicValueRW.JPOS_PN_DISABLED);
        jposConst.put(PowerNotification.ENABLED, jpos.ElectronicValueRW.JPOS_PN_ENABLED);
        jposConst.put(PowerState.OFF, jpos.ElectronicValueRW.JPOS_PS_OFF);
        jposConst.put(PowerState.OFFLINE, jpos.ElectronicValueRW.JPOS_PS_OFFLINE);
        jposConst.put(PowerState.OFF_OFFLINE, jpos.ElectronicValueRW.JPOS_PS_OFF_OFFLINE);
        jposConst.put(PowerState.ONLINE, jpos.ElectronicValueRW.JPOS_PS_ONLINE);
        jposConst.put(PowerState.UNKNOWN, jpos.ElectronicValueRW.JPOS_PS_UNKNOWN);
        jposConst.put(ControlState.BUSY, jpos.ElectronicValueRW.JPOS_S_BUSY);
        jposConst.put(ControlState.CLOSED, jpos.ElectronicValueRW.JPOS_S_CLOSED);
        jposConst.put(ControlState.ERROR, jpos.ElectronicValueRW.JPOS_S_ERROR);
        jposConst.put(ControlState.IDLE, jpos.ElectronicValueRW.JPOS_S_IDLE);
        jposConst.put(HealthCheckLevel.EXTERNAL, jpos.ElectronicValueRW.JPOS_CH_EXTERNAL);
        jposConst.put(HealthCheckLevel.INTERACTIVE, jpos.ElectronicValueRW.JPOS_CH_INTERACTIVE);
        jposConst.put(HealthCheckLevel.INTERNAL, jpos.ElectronicValueRW.JPOS_CH_INTERNAL);
        jposConst.put(CompareFirmwareResult.DIFFERENT, jpos.ElectronicValueRW.JPOS_CFV_FIRMWARE_DIFFERENT);
        jposConst.put(CompareFirmwareResult.NEWER, jpos.ElectronicValueRW.JPOS_CFV_FIRMWARE_NEWER);
        jposConst.put(CompareFirmwareResult.OLDER, jpos.ElectronicValueRW.JPOS_CFV_FIRMWARE_OLDER);
        jposConst.put(CompareFirmwareResult.SAME, jpos.ElectronicValueRW.JPOS_CFV_FIRMWARE_SAME);
        jposConst.put(CompareFirmwareResult.UNKNOWN, jpos.ElectronicValueRW.JPOS_CFV_FIRMWARE_UNKNOWN);
        jposConst.put(ErrorCode.BUSY, jpos.ElectronicValueRW.JPOS_E_BUSY);
        jposConst.put(ErrorCode.CLAIMED, jpos.ElectronicValueRW.JPOS_E_CLAIMED);
        jposConst.put(ErrorCode.CLOSED, jpos.ElectronicValueRW.JPOS_E_CLOSED);
        jposConst.put(ErrorCode.DEPRECATED, jpos.ElectronicValueRW.JPOS_E_DEPRECATED);
        jposConst.put(ErrorCode.DISABLED, jpos.ElectronicValueRW.JPOS_E_DISABLED);
        jposConst.put(ErrorCode.EXISTS, jpos.ElectronicValueRW.JPOS_E_EXISTS);
        jposConst.put(ErrorCode.EXTENDED, jpos.ElectronicValueRW.JPOS_E_EXTENDED);
        jposConst.put(ErrorCode.FAILURE, jpos.ElectronicValueRW.JPOS_E_FAILURE);
        jposConst.put(ErrorCode.ILLEGAL, jpos.ElectronicValueRW.JPOS_E_ILLEGAL);
        jposConst.put(ErrorCode.NO_EXIST, jpos.ElectronicValueRW.JPOS_E_NOEXIST);
        jposConst.put(ErrorCode.NO_HARDWARE, jpos.ElectronicValueRW.JPOS_E_NOHARDWARE);
        jposConst.put(ErrorCode.NO_SERVICE, jpos.ElectronicValueRW.JPOS_E_NOSERVICE);
        jposConst.put(ErrorCode.NOT_CLAIMED, jpos.ElectronicValueRW.JPOS_E_NOTCLAIMED);
        jposConst.put(ErrorCode.OFFLINE, jpos.ElectronicValueRW.JPOS_E_OFFLINE);
        jposConst.put(ErrorCode.SUCCESS, 0);
        jposConst.put(ErrorCode.TIMEOUT, jpos.ElectronicValueRW.JPOS_E_TIMEOUT);
        jposConst.put(DetectionState.CAPTURED, jpos.ElectronicValueRWConst.EVRW_DS_CAPTURED);
        jposConst.put(DetectionState.DETECTED, jpos.ElectronicValueRWConst.EVRW_DS_DETECTED);
        jposConst.put(DetectionState.ENTERED, jpos.ElectronicValueRWConst.EVRW_DS_ENTERED);
        jposConst.put(DetectionState.NO_CARD, jpos.ElectronicValueRWConst.EVRW_DS_NOCARD);
        jposConst.put(LogState.FULL, jpos.ElectronicValueRWConst.EVRW_LS_FULL);
        jposConst.put(LogState.NEAR_FULL, jpos.ElectronicValueRWConst.EVRW_LS_NEARFULL);
        jposConst.put(LogState.OK, jpos.ElectronicValueRWConst.EVRW_LS_OK);
        jposConst.put(TransactionLogType.REPORTING, jpos.ElectronicValueRWConst.EVRW_AL_REPORTING);
        jposConst.put(TransactionLogType.SETTLEMENT, jpos.ElectronicValueRWConst.EVRW_AL_SETTLEMENT);
        jposConst.put(BeginDetectionType.ANY, jpos.ElectronicValueRWConst.EVRW_BD_ANY);
        jposConst.put(BeginDetectionType.SPECIFIC, jpos.ElectronicValueRWConst.EVRW_BD_SPECIFIC);
        jposConst.put(TransactionControl.NORMAL, jpos.ElectronicValueRWConst.EVRW_TA_NORMAL);
        jposConst.put(TransactionControl.TRANSACTION, jpos.ElectronicValueRWConst.EVRW_TA_TRANSACTION);

        powerReporting = new HashMap<Integer, PowerReporting>();
        powerReporting.put(jpos.ElectronicValueRW.JPOS_PR_ADVANCED, PowerReporting.ADVANCED);
        powerReporting.put(jpos.ElectronicValueRW.JPOS_PR_NONE, PowerReporting.NONE);
        powerReporting.put(jpos.ElectronicValueRW.JPOS_PR_STANDARD, PowerReporting.STANDARD);

        powerNotification = new HashMap<Integer, PowerNotification>();
        powerNotification.put(jpos.ElectronicValueRW.JPOS_PN_DISABLED, PowerNotification.DISABLED);
        powerNotification.put(jpos.ElectronicValueRW.JPOS_PN_ENABLED, PowerNotification.ENABLED);

        powerState = new HashMap<Integer, PowerState>();
        powerState.put(jpos.ElectronicValueRW.JPOS_PS_OFF, PowerState.OFF);
        powerState.put(jpos.ElectronicValueRW.JPOS_PS_OFFLINE, PowerState.OFFLINE);
        powerState.put(jpos.ElectronicValueRW.JPOS_PS_OFF_OFFLINE, PowerState.OFF_OFFLINE);
        powerState.put(jpos.ElectronicValueRW.JPOS_PS_ONLINE, PowerState.ONLINE);
        powerState.put(jpos.ElectronicValueRW.JPOS_PS_UNKNOWN, PowerState.UNKNOWN);

        controlState = new HashMap<Integer, ControlState>();
        controlState.put(jpos.ElectronicValueRW.JPOS_S_BUSY, ControlState.BUSY);
        controlState.put(jpos.ElectronicValueRW.JPOS_S_CLOSED, ControlState.CLOSED);
        controlState.put(jpos.ElectronicValueRW.JPOS_S_ERROR, ControlState.ERROR);
        controlState.put(jpos.ElectronicValueRW.JPOS_S_IDLE, ControlState.IDLE);

        healthCheckLevel = new HashMap<Integer, HealthCheckLevel>();
        healthCheckLevel.put(jpos.ElectronicValueRW.JPOS_CH_EXTERNAL, HealthCheckLevel.EXTERNAL);
        healthCheckLevel.put(jpos.ElectronicValueRW.JPOS_CH_INTERACTIVE, HealthCheckLevel.INTERACTIVE);
        healthCheckLevel.put(jpos.ElectronicValueRW.JPOS_CH_INTERNAL, HealthCheckLevel.INTERNAL);

        compareFirmwareResult = new HashMap<Integer, CompareFirmwareResult>();
        compareFirmwareResult.put(jpos.ElectronicValueRW.JPOS_CFV_FIRMWARE_DIFFERENT, CompareFirmwareResult.DIFFERENT);
        compareFirmwareResult.put(jpos.ElectronicValueRW.JPOS_CFV_FIRMWARE_NEWER, CompareFirmwareResult.NEWER);
        compareFirmwareResult.put(jpos.ElectronicValueRW.JPOS_CFV_FIRMWARE_OLDER, CompareFirmwareResult.OLDER);
        compareFirmwareResult.put(jpos.ElectronicValueRW.JPOS_CFV_FIRMWARE_SAME, CompareFirmwareResult.SAME);
        compareFirmwareResult.put(jpos.ElectronicValueRW.JPOS_CFV_FIRMWARE_UNKNOWN, CompareFirmwareResult.UNKNOWN);

        errorCode = new HashMap<Integer, ErrorCode>();
        errorCode.put(jpos.ElectronicValueRW.JPOS_E_BUSY, ErrorCode.BUSY);
        errorCode.put(jpos.ElectronicValueRW.JPOS_E_CLAIMED, ErrorCode.CLAIMED);
        errorCode.put(jpos.ElectronicValueRW.JPOS_E_CLOSED, ErrorCode.CLOSED);
        errorCode.put(jpos.ElectronicValueRW.JPOS_E_DEPRECATED, ErrorCode.DEPRECATED);
        errorCode.put(jpos.ElectronicValueRW.JPOS_E_DISABLED, ErrorCode.DISABLED);
        errorCode.put(jpos.ElectronicValueRW.JPOS_E_EXISTS, ErrorCode.EXISTS);
        errorCode.put(jpos.ElectronicValueRW.JPOS_E_EXTENDED, ErrorCode.EXTENDED);
        errorCode.put(jpos.ElectronicValueRW.JPOS_E_FAILURE, ErrorCode.FAILURE);
        errorCode.put(jpos.ElectronicValueRW.JPOS_E_ILLEGAL, ErrorCode.ILLEGAL);
        errorCode.put(jpos.ElectronicValueRW.JPOS_E_NOEXIST, ErrorCode.NO_EXIST);
        errorCode.put(jpos.ElectronicValueRW.JPOS_E_NOHARDWARE, ErrorCode.NO_HARDWARE);
        errorCode.put(jpos.ElectronicValueRW.JPOS_E_NOSERVICE, ErrorCode.NO_SERVICE);
        errorCode.put(jpos.ElectronicValueRW.JPOS_E_NOTCLAIMED, ErrorCode.NOT_CLAIMED);
        errorCode.put(jpos.ElectronicValueRW.JPOS_E_OFFLINE, ErrorCode.OFFLINE);
        errorCode.put(0, ErrorCode.SUCCESS);
        errorCode.put(jpos.ElectronicValueRW.JPOS_E_TIMEOUT, ErrorCode.TIMEOUT);

        detectionState = new HashMap<Integer, DetectionState>();
        detectionState.put(jpos.ElectronicValueRWConst.EVRW_DS_CAPTURED, DetectionState.CAPTURED);
        detectionState.put(jpos.ElectronicValueRWConst.EVRW_DS_DETECTED, DetectionState.DETECTED);
        detectionState.put(jpos.ElectronicValueRWConst.EVRW_DS_ENTERED, DetectionState.ENTERED);
        detectionState.put(jpos.ElectronicValueRWConst.EVRW_DS_NOCARD, DetectionState.NO_CARD);

        logState = new HashMap<Integer, LogState>();
        logState.put(jpos.ElectronicValueRWConst.EVRW_LS_FULL, LogState.FULL);
        logState.put(jpos.ElectronicValueRWConst.EVRW_LS_NEARFULL, LogState.NEAR_FULL);
        logState.put(jpos.ElectronicValueRWConst.EVRW_LS_OK, LogState.OK);

        transactionLogType = new HashMap<Integer, TransactionLogType>();
        transactionLogType.put(jpos.ElectronicValueRWConst.EVRW_AL_REPORTING, TransactionLogType.REPORTING);
        transactionLogType.put(jpos.ElectronicValueRWConst.EVRW_AL_SETTLEMENT, TransactionLogType.SETTLEMENT);

        beginDetectionType = new HashMap<Integer, BeginDetectionType>();
        beginDetectionType.put(jpos.ElectronicValueRWConst.EVRW_BD_ANY, BeginDetectionType.ANY);
        beginDetectionType.put(jpos.ElectronicValueRWConst.EVRW_BD_SPECIFIC, BeginDetectionType.SPECIFIC);

        transactionControl = new HashMap<Integer, TransactionControl>();
        transactionControl.put(jpos.ElectronicValueRWConst.EVRW_TA_NORMAL, TransactionControl.NORMAL);
        transactionControl.put(jpos.ElectronicValueRWConst.EVRW_TA_TRANSACTION, TransactionControl.TRANSACTION);

        jposEventConst = new HashMap<Enum, Integer>();
        jposEventConst.put(org.nrf_arts.unifiedpos.electronicvaluerwevents.ErrorCode.BUSY, jpos.ElectronicValueRW.JPOS_E_BUSY);
        jposEventConst.put(org.nrf_arts.unifiedpos.electronicvaluerwevents.ErrorCode.CLAIMED, jpos.ElectronicValueRW.JPOS_E_CLAIMED);
        jposEventConst.put(org.nrf_arts.unifiedpos.electronicvaluerwevents.ErrorCode.CLOSED, jpos.ElectronicValueRW.JPOS_E_CLOSED);
        jposEventConst.put(org.nrf_arts.unifiedpos.electronicvaluerwevents.ErrorCode.DEPRECATED, jpos.ElectronicValueRW.JPOS_E_DEPRECATED);
        jposEventConst.put(org.nrf_arts.unifiedpos.electronicvaluerwevents.ErrorCode.DISABLED, jpos.ElectronicValueRW.JPOS_E_DISABLED);
        jposEventConst.put(org.nrf_arts.unifiedpos.electronicvaluerwevents.ErrorCode.EXISTS, jpos.ElectronicValueRW.JPOS_E_EXISTS);
        jposEventConst.put(org.nrf_arts.unifiedpos.electronicvaluerwevents.ErrorCode.EXTENDED, jpos.ElectronicValueRW.JPOS_E_EXTENDED);
        jposEventConst.put(org.nrf_arts.unifiedpos.electronicvaluerwevents.ErrorCode.FAILURE, jpos.ElectronicValueRW.JPOS_E_FAILURE);
        jposEventConst.put(org.nrf_arts.unifiedpos.electronicvaluerwevents.ErrorCode.ILLEGAL, jpos.ElectronicValueRW.JPOS_E_ILLEGAL);
        jposEventConst.put(org.nrf_arts.unifiedpos.electronicvaluerwevents.ErrorCode.NO_EXIST, jpos.ElectronicValueRW.JPOS_E_NOEXIST);
        jposEventConst.put(org.nrf_arts.unifiedpos.electronicvaluerwevents.ErrorCode.NO_HARDWARE, jpos.ElectronicValueRW.JPOS_E_NOHARDWARE);
        jposEventConst.put(org.nrf_arts.unifiedpos.electronicvaluerwevents.ErrorCode.NO_SERVICE, jpos.ElectronicValueRW.JPOS_E_NOSERVICE);
        jposEventConst.put(org.nrf_arts.unifiedpos.electronicvaluerwevents.ErrorCode.NOT_CLAIMED, jpos.ElectronicValueRW.JPOS_E_NOTCLAIMED);
        jposEventConst.put(org.nrf_arts.unifiedpos.electronicvaluerwevents.ErrorCode.OFFLINE, jpos.ElectronicValueRW.JPOS_E_OFFLINE);
        jposEventConst.put(org.nrf_arts.unifiedpos.electronicvaluerwevents.ErrorCode.SUCCESS, 0);
        jposEventConst.put(org.nrf_arts.unifiedpos.electronicvaluerwevents.ErrorCode.TIMEOUT, jpos.ElectronicValueRW.JPOS_E_TIMEOUT);
        jposEventConst.put(org.nrf_arts.unifiedpos.electronicvaluerwevents.ErrorLocus.INPUT, jpos.ElectronicValueRW.JPOS_EL_INPUT);
        jposEventConst.put(org.nrf_arts.unifiedpos.electronicvaluerwevents.ErrorLocus.INPUT_DATA, jpos.ElectronicValueRW.JPOS_EL_INPUT_DATA);
        jposEventConst.put(org.nrf_arts.unifiedpos.electronicvaluerwevents.ErrorLocus.OUTPUT, jpos.ElectronicValueRW.JPOS_EL_OUTPUT);
        jposEventConst.put(org.nrf_arts.unifiedpos.electronicvaluerwevents.ErrorResponse.CLEAR, jpos.ElectronicValueRW.JPOS_ER_CLEAR);
        jposEventConst.put(org.nrf_arts.unifiedpos.electronicvaluerwevents.ErrorResponse.CONTINUE_INPUT, jpos.ElectronicValueRW.JPOS_ER_CONTINUEINPUT);
        jposEventConst.put(org.nrf_arts.unifiedpos.electronicvaluerwevents.ErrorResponse.RETRY, jpos.ElectronicValueRW.JPOS_ER_RETRY);

        eventErrorCode = new HashMap<Integer, org.nrf_arts.unifiedpos.electronicvaluerwevents.ErrorCode>();
        eventErrorCode.put(jpos.ElectronicValueRW.JPOS_E_BUSY, org.nrf_arts.unifiedpos.electronicvaluerwevents.ErrorCode.BUSY);
        eventErrorCode.put(jpos.ElectronicValueRW.JPOS_E_CLAIMED, org.nrf_arts.unifiedpos.electronicvaluerwevents.ErrorCode.CLAIMED);
        eventErrorCode.put(jpos.ElectronicValueRW.JPOS_E_CLOSED, org.nrf_arts.unifiedpos.electronicvaluerwevents.ErrorCode.CLOSED);
        eventErrorCode.put(jpos.ElectronicValueRW.JPOS_E_DEPRECATED, org.nrf_arts.unifiedpos.electronicvaluerwevents.ErrorCode.DEPRECATED);
        eventErrorCode.put(jpos.ElectronicValueRW.JPOS_E_DISABLED, org.nrf_arts.unifiedpos.electronicvaluerwevents.ErrorCode.DISABLED);
        eventErrorCode.put(jpos.ElectronicValueRW.JPOS_E_EXISTS, org.nrf_arts.unifiedpos.electronicvaluerwevents.ErrorCode.EXISTS);
        eventErrorCode.put(jpos.ElectronicValueRW.JPOS_E_EXTENDED, org.nrf_arts.unifiedpos.electronicvaluerwevents.ErrorCode.EXTENDED);
        eventErrorCode.put(jpos.ElectronicValueRW.JPOS_E_FAILURE, org.nrf_arts.unifiedpos.electronicvaluerwevents.ErrorCode.FAILURE);
        eventErrorCode.put(jpos.ElectronicValueRW.JPOS_E_ILLEGAL, org.nrf_arts.unifiedpos.electronicvaluerwevents.ErrorCode.ILLEGAL);
        eventErrorCode.put(jpos.ElectronicValueRW.JPOS_E_NOEXIST, org.nrf_arts.unifiedpos.electronicvaluerwevents.ErrorCode.NO_EXIST);
        eventErrorCode.put(jpos.ElectronicValueRW.JPOS_E_NOHARDWARE, org.nrf_arts.unifiedpos.electronicvaluerwevents.ErrorCode.NO_HARDWARE);
        eventErrorCode.put(jpos.ElectronicValueRW.JPOS_E_NOSERVICE, org.nrf_arts.unifiedpos.electronicvaluerwevents.ErrorCode.NO_SERVICE);
        eventErrorCode.put(jpos.ElectronicValueRW.JPOS_E_NOTCLAIMED, org.nrf_arts.unifiedpos.electronicvaluerwevents.ErrorCode.NOT_CLAIMED);
        eventErrorCode.put(jpos.ElectronicValueRW.JPOS_E_OFFLINE, org.nrf_arts.unifiedpos.electronicvaluerwevents.ErrorCode.OFFLINE);
        eventErrorCode.put(0, org.nrf_arts.unifiedpos.electronicvaluerwevents.ErrorCode.SUCCESS);
        eventErrorCode.put(jpos.ElectronicValueRW.JPOS_E_TIMEOUT, org.nrf_arts.unifiedpos.electronicvaluerwevents.ErrorCode.TIMEOUT);

        eventErrorLocus = new HashMap<Integer, org.nrf_arts.unifiedpos.electronicvaluerwevents.ErrorLocus>();
        eventErrorLocus.put(jpos.ElectronicValueRW.JPOS_EL_INPUT, org.nrf_arts.unifiedpos.electronicvaluerwevents.ErrorLocus.INPUT);
        eventErrorLocus.put(jpos.ElectronicValueRW.JPOS_EL_INPUT_DATA, org.nrf_arts.unifiedpos.electronicvaluerwevents.ErrorLocus.INPUT_DATA);
        eventErrorLocus.put(jpos.ElectronicValueRW.JPOS_EL_OUTPUT, org.nrf_arts.unifiedpos.electronicvaluerwevents.ErrorLocus.OUTPUT);

        eventErrorResponse = new HashMap<Integer, org.nrf_arts.unifiedpos.electronicvaluerwevents.ErrorResponse>();
        eventErrorResponse.put(jpos.ElectronicValueRW.JPOS_ER_CLEAR, org.nrf_arts.unifiedpos.electronicvaluerwevents.ErrorResponse.CLEAR);
        eventErrorResponse.put(jpos.ElectronicValueRW.JPOS_ER_CONTINUEINPUT, org.nrf_arts.unifiedpos.electronicvaluerwevents.ErrorResponse.CONTINUE_INPUT);
        eventErrorResponse.put(jpos.ElectronicValueRW.JPOS_ER_RETRY, org.nrf_arts.unifiedpos.electronicvaluerwevents.ErrorResponse.RETRY);
    }

    private String deviceName;
    private UposVersion deviceControlVersion;
    private org.nrf_arts.unifiedpos.electronicvaluerwevents.ElectronicValueRWEvent deviceEvent;
    private jpos.ElectronicValueRW device = new jpos.ElectronicValueRW();
    private DatatypeFactory datatypeFactory;

    public ElectronicValueRWService(String logicalDeviceName) {
        deviceName = logicalDeviceName;
        deviceControlVersion = new UposVersion();
        deviceControlVersion.setMajor(1);
        deviceControlVersion.setMinor(13);
        deviceControlVersion.setBuild(1);
        try {
            datatypeFactory = DatatypeFactory.newInstance();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    //
    // ElectronicValueRW Member
    //

    public void accessLog(Integer sequenceNumber, TransactionLogType type, Integer timeout) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.accessLog(sequenceNumber, jposConst.get(type), timeout);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public EVRWResult activateService(Integer data, Object obj) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            EVRWResult res = new EVRWResult();
            int[] param = new int[] { data };
            Object[] object = new Object[] { obj };
            device.activateService(param, object);
            res.setData(param[0]);
            res.setObj(object[0]);
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void addValue(Integer sequenceNumber, Integer timeout) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.addValue(sequenceNumber, timeout);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void beginDetection(BeginDetectionType type, Integer timeout) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.beginDetection(jposConst.get(type), timeout);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void beginRemoval(Integer timeout) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.beginRemoval(timeout);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void cancelValue(Integer sequenceNumber, Integer timeout) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.cancelValue(sequenceNumber, timeout);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void captureCard() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.captureCard();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void checkHealth(HealthCheckLevel level) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.checkHealth(jposConst.get(level));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void claim(Integer timeout) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.claim(timeout);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void clearInput() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.clearInput();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void clearInputProperties() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.clearInputProperties();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void clearOutput() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.clearOutput();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void close(String endpointAddress) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            if (deviceEvent != null)
            {
                device.removeDataListener(this);
                device.removeDirectIOListener(this);
                device.removeErrorListener(this);
                device.removeOutputCompleteListener(this);
                device.removeStatusUpdateListener(this);
                deviceEvent = null;
            }
            device.close();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public CompareFirmwareResult compareFirmwareVersion(String firmwareFileName) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            int[] param = new int[1];
            device.compareFirmwareVersion(firmwareFileName, param);
            return compareFirmwareResult.get(param[0]);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public DirectIOData directIO(Integer command, Integer data, Object obj) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            DirectIOData res = new DirectIOData();
            int[] param = new int[] { data };
            device.directIO(command, param, obj);
            res.setData(param[0]);
            res.setObj(obj);
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void endDetection() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.endDetection();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void endRemoval() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.endRemoval();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void enumerateCardServices() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.enumerateCardServices();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getAccountNumber() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getAccountNumber();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getAdditionalSecurityInformation() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getAdditionalSecurityInformation();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public BigDecimal getAmount() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return BigDecimal.valueOf(device.getAmount()).scaleByPowerOfTen(-4);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getApprovalCode() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getApprovalCode();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getAsyncMode() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getAsyncMode();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getAutoDisable() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getAutoDisable();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public BigDecimal getBalance() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return BigDecimal.valueOf(device.getBalance()).scaleByPowerOfTen(-4);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public BigDecimal getBalanceOfPoint() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return BigDecimal.valueOf(device.getBalanceOfPoint()).scaleByPowerOfTen(-4);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapActivateService() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapActivateService();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapAddValue() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapAddValue();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapCancelValue() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapCancelValue();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getCapCardSensor() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapCardSensor();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapCompareFirmwareVersion() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapCompareFirmwareVersion();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getCapDetectionControl() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapDetectionControl();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapElectronicMoney() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapElectronicMoney();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapEnumerateCardServices() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapEnumerateCardServices();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapIndirectTransactionLog() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapIndirectTransactionLog();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapLockTerminal() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapLockTerminal();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapLogStatus() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapLogStatus();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapMediumID() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapMediumID();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapPoint() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapPoint();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public PowerReporting getCapPowerReporting() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return powerReporting.get(device.getCapPowerReporting());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapStatisticsReporting() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapStatisticsReporting();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapSubtractValue() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapSubtractValue();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapTransaction() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapTransaction();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapTransactionLog() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapTransactionLog();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapUnlockTerminal() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapUnlockTerminal();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapUpdateFirmware() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapUpdateFirmware();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapUpdateKey() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapUpdateKey();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapUpdateStatistics() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapUpdateStatistics();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapVoucher() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapVoucher();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapWriteValue() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapWriteValue();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public CardServiceList getCardServiceList() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            CardServiceList res = new CardServiceList();
            List<String> list = res.getCardService();
            for (String s : device.getCardServiceList().split(",")) {
                list.add(s);
            }
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getCheckHealthText() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCheckHealthText();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getClaimed() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getClaimed();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getCurrentService() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCurrentService();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getDataCount() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getDataCount();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getDataEventEnabled() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getDataEventEnabled();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getDetectionControl() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getDetectionControl();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public DetectionState getDetectionStatus() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return detectionState.get(device.getDetectionStatus());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getDeviceControlDescription() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        return device.getDeviceControlDescription();
    }

    public UposVersion getDeviceControlVersion() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        UposVersion res = new UposVersion();
        int version = device.getDeviceControlVersion();
        res.setMajor(version / 1000000 % 1000);
        res.setMinor(version / 1000 % 1000);
        res.setBuild(version % 1000);
        return res;
    }

    public Boolean getDeviceEnabled() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getDeviceEnabled();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getDeviceServiceDescription() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getDeviceServiceDescription();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public UposVersion getDeviceServiceVersion() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            UposVersion res = new UposVersion();
            int version = device.getDeviceServiceVersion();
            res.setMajor(version / 1000000 % 1000);
            res.setMinor(version / 1000 % 1000);
            res.setBuild(version % 1000);
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public XMLGregorianCalendar getExpirationDate() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            String s = device.getExpirationDate();
            int year = Integer.valueOf(s.substring(0, 4));
            int month = Integer.valueOf(s.substring(4, 6)) - 1;
            int day = Integer.valueOf(s.substring(6, 8));
            return datatypeFactory.newXMLGregorianCalendar(new GregorianCalendar(year, month, day));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getFreezeEvents() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getFreezeEvents();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public XMLGregorianCalendar getLastUsedDate() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            String s = device.getLastUsedDate();
            int year = Integer.valueOf(s.substring(0, 4));
            int month = Integer.valueOf(s.substring(4, 6)) - 1;
            int day = Integer.valueOf(s.substring(6, 8));
            int hour = Integer.valueOf(s.substring(8, 10));
            int minute = Integer.valueOf(s.substring(10, 12));
            int second = Integer.valueOf(s.substring(12, 14));
            return datatypeFactory.newXMLGregorianCalendar(new GregorianCalendar(year, month, day, hour, minute, second));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
        catch (Exception e) {
            throw new FaultException(e.getMessage(), null, e);
        }
    }

    public LogState getLogStatus() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return logState.get(device.getLogStatus());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getMediumID() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getMediumID();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getOutputID() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getOutputID();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getPhysicalDeviceDescription() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getPhysicalDeviceDescription();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getPhysicalDeviceName() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getPhysicalDeviceName();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public BigDecimal getPoint() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return BigDecimal.valueOf(device.getPoint()).scaleByPowerOfTen(-4);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public PowerNotification getPowerNotify() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return powerNotification.get(device.getPowerNotify());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public PowerState getPowerState() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return powerState.get(device.getPowerState());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public ReaderWriterServiceList getReaderWriterServiceList() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            ReaderWriterServiceList res = new ReaderWriterServiceList();
            List<String> list = res.getReaderWriterService();
            for (String s : device.getReaderWriterServiceList().split(",")) {
                list.add(s);
            }
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getSequenceNumber() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getSequenceNumber();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public BigDecimal getSettledAmount() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return BigDecimal.valueOf(device.getSettledAmount()).scaleByPowerOfTen(-4);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public BigDecimal getSettledPoint() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return BigDecimal.valueOf(device.getSettledPoint()).scaleByPowerOfTen(-4);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public ControlState getState() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        return controlState.get(device.getState());
    }

    public String getTransactionLog() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getTransactionLog();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public VoucherID getVoucherID() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            VoucherID res = new VoucherID();
            String[] s = device.getVoucherID().split(":");
            if (s.length > 1) {
                res.setTicketID(s[0]);
                res.setCount(Integer.valueOf(s[1]));
            }
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public VoucherIDList getVoucherIDList() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            VoucherIDList res = new VoucherIDList();
            List<VoucherID> list = res.getVoucherID();
            for (String voucher : device.getVoucherIDList().split(",")) {
                String[] s = voucher.split(":");
                if (s.length > 1) {
                    VoucherID v = new VoucherID();
                    v.setTicketID(s[0]);
                    v.setCount(Integer.valueOf(s[1]));
                    list.add(v);
                }
            }
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void lockTerminal() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.lockTerminal();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void open(String endpointAddress) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.open(deviceName);
            if (endpointAddress != null)
            {
                try {
                    Service service = Service.create(
                            new URL(endpointAddress + "?wsdl"),
                            new QName("http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRWEvents/", "ElectronicValueRWEventService"));
                    deviceEvent = service.getPort(org.nrf_arts.unifiedpos.electronicvaluerwevents.ElectronicValueRWEvent.class);
                    device.addDataListener(this);
                    device.addDirectIOListener(this);
                    device.addErrorListener(this);
                    device.addOutputCompleteListener(this);
                    device.addStatusUpdateListener(this);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void readValue(Integer sequenceNumber, Integer timeout) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.readValue(sequenceNumber, timeout);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void release() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.release();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void resetStatistics(StatisticList statisticsBuffer) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            String param = null;
            List<Statistic> list = statisticsBuffer.getStatistic();
            switch (list.size()) {
                case 0:
                    param = "";
                    break;
                case 1:
                    String name = list.get(0).getName();
                    if (name.equals(StatisticCategories.ALL)) {
                        param = "";
                    }
                    else if (name.equals(StatisticCategories.MANUFACTURER)) {
                        param = "M_";
                    }
                    else if (name.equals(StatisticCategories.UPOS)) {
                        param = "U_";
                    }
                    else {
                        param = name;
                    }
                    break;
                default:
                    StringBuffer buffer = new StringBuffer();
                    for (Statistic statistic : statisticsBuffer.getStatistic()) {
                        buffer.append(",").append(statistic.getName());
                    }
                    param = buffer.substring(1);
                    break;
            }
            device.resetStatistics(param);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String retrieveStatistics(StatisticList statisticsBuffer) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            String[] param = new String[1];
            List<Statistic> list = statisticsBuffer.getStatistic();
            switch (list.size()) {
                case 0:
                    param[0] = "";
                    break;
                case 1:
                    String name = list.get(0).getName();
                    if (name.equals(StatisticCategories.ALL)) {
                        param[0] = "";
                    }
                    else if (name.equals(StatisticCategories.MANUFACTURER)) {
                        param[0] = "M_";
                    }
                    else if (name.equals(StatisticCategories.UPOS)) {
                        param[0] = "U_";
                    }
                    else {
                        param[0] = name;
                    }
                    break;
                default:
                    StringBuffer buffer = new StringBuffer();
                    for (Statistic statistic : statisticsBuffer.getStatistic()) {
                        buffer.append(",").append(statistic.getName());
                    }
                    param[0] = buffer.substring(1);
                    break;
            }
            device.retrieveStatistics(param);
            return param[0];
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setAdditionalSecurityInformation(String additionalSecurityInformation) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setAdditionalSecurityInformation(additionalSecurityInformation);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setAmount(BigDecimal amount) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setAmount(amount.scaleByPowerOfTen(4).longValue());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setApprovalCode(String approvalCode) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setApprovalCode(approvalCode);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setAsyncMode(Boolean asyncMode) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setAsyncMode(asyncMode);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setAutoDisable(Boolean autoDisable) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setAutoDisable(autoDisable);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setCurrentService(String currentService) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setCurrentService(currentService);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setDataEventEnabled(Boolean dataEventEnabled) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setDataEventEnabled(dataEventEnabled);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setDetectionControl(Boolean detectionControl) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setDetectionControl(detectionControl);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setDeviceEnabled(Boolean deviceEnabled) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setDeviceEnabled(deviceEnabled);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setFreezeEvents(Boolean freezeEvents) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setFreezeEvents(freezeEvents);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setMediumID(String mediumID) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setMediumID(mediumID);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setPoint(BigDecimal point) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setPoint(point.scaleByPowerOfTen(4).longValue());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setPowerNotify(PowerNotification powerNotify) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setPowerNotify(jposConst.get(powerNotify));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setVoucherID(VoucherID voucherID) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setVoucherID(voucherID.getTicketID() + ":" + voucherID.getCount());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setVoucherIDList(VoucherIDList voucherIDList) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            StringBuffer buffer = new StringBuffer();
            for (VoucherID voucherID : voucherIDList.getVoucherID()) {
                buffer.append(",").append(voucherID.getTicketID()).append(":").append(voucherID.getCount());
            }
            device.setVoucherIDList(buffer.substring(1));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void subtractValue(Integer sequenceNumber, Integer timeout) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.subtractValue(sequenceNumber, timeout);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void transactionAccess(TransactionControl control) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.transactionAccess(jposConst.get(control));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void unlockTerminal() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.unlockTerminal();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void updateFirmware(String firmwareFileName) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.updateFirmware(firmwareFileName);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public EVRWResult updateKey(Integer data, Object obj) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            EVRWResult res = new EVRWResult();
            int[] param = new int[] { data };
            Object[] object = new Object[] { obj };
            device.updateKey(param, object);
            res.setData(param[0]);
            res.setObj(object[0]);
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void updateStatistics(StatisticList statisticsBuffer) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            String param = null;
            List<Statistic> list = statisticsBuffer.getStatistic();
            switch (list.size()) {
                case 0:
                    param = "";
                    break;
                case 1:
                    Statistic s = list.get(0);
                    String name = s.getName();
                    String value = s.getValue();
                    if (name.equals(StatisticCategories.ALL)) {
                        param = "=" + value;
                    }
                    else if (name.equals(StatisticCategories.MANUFACTURER)) {
                        param = "M_=" + value;
                    }
                    else if (name.equals(StatisticCategories.UPOS)) {
                        param = "U_=" + value;
                    }
                    else {
                        param = name + "=" + value;
                    }
                    break;
                default:
                    StringBuffer buffer = new StringBuffer();
                    for (Statistic statistic : statisticsBuffer.getStatistic()) {
                        buffer.append(",").append(statistic.getName()).append("=").append(statistic.getValue());
                    }
                    param = buffer.substring(1);
                    break;
            }
            device.updateStatistics(param);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void writeValue(Integer sequenceNumber, Integer timeout) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.writeValue(sequenceNumber, timeout);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    //
    // ElectronicValueRWEvent Member
    //

    public void dataOccurred(DataEvent de) {
        //throw new UnsupportedOperationException("Not supported yet.");
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(new Date(de.getWhen()));
        deviceEvent.dataEvent(
                de.getSource().toString(),
                (int)de.getSequenceNumber(),
                datatypeFactory.newXMLGregorianCalendar(cal),
                de.getStatus());
    }

    public void directIOOccurred(DirectIOEvent dioe) {
        //throw new UnsupportedOperationException("Not supported yet.");
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(new Date(dioe.getWhen()));
        org.nrf_arts.unifiedpos.electronicvaluerwevents.DirectIOData value = deviceEvent.directIOEvent(
                dioe.getSource().toString(),
                (int)dioe.getSequenceNumber(),
                datatypeFactory.newXMLGregorianCalendar(cal),
                dioe.getEventNumber(),
                dioe.getData(),
                dioe.getObject());
        dioe.setData(value.getData());
        dioe.setObject(value.getObj());
    }

    public void errorOccurred(ErrorEvent ee) {
        //throw new UnsupportedOperationException("Not supported yet.");
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(new Date(ee.getWhen()));
        org.nrf_arts.unifiedpos.electronicvaluerwevents.ErrorResponse value = deviceEvent.errorEvent(
                ee.getSource().toString(),
                (int)ee.getSequenceNumber(),
                datatypeFactory.newXMLGregorianCalendar(cal),
                eventErrorCode.get(ee.getErrorCode()),
                ee.getErrorCodeExtended(),
                eventErrorLocus.get(ee.getErrorLocus()),
                eventErrorResponse.get(ee.getErrorResponse()));
        ee.setErrorResponse(jposEventConst.get(value));
    }

    public void outputCompleteOccurred(OutputCompleteEvent oce) {
        //throw new UnsupportedOperationException("Not supported yet.");
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(new Date(oce.getWhen()));
        deviceEvent.statusUpdateEvent(
                oce.getSource().toString(),
                (int)oce.getSequenceNumber(),
                datatypeFactory.newXMLGregorianCalendar(cal),
                oce.getOutputID());
    }

    public void statusUpdateOccurred(StatusUpdateEvent sue) {
        //throw new UnsupportedOperationException("Not supported yet.");
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(new Date(sue.getWhen()));
        deviceEvent.statusUpdateEvent(
                sue.getSource().toString(),
                (int)sue.getSequenceNumber(),
                datatypeFactory.newXMLGregorianCalendar(cal),
                sue.getStatus());
    }

}
