/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.nrf_arts.unifiedpos.biometrics;

/**
 *
 * @author Administrator
 */
public class BIRDataTypes {
    public static final int ENCRYPTED = 8;
    public static final int INTERMEDIATE = 2;
    public static final int PROCESSED = 4;
    public static final int RAW = 1;
    public static final int SIGNED = 16;
}
