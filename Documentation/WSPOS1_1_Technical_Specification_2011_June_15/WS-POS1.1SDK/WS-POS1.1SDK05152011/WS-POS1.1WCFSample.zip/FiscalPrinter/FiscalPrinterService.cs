﻿using UnifiedPOS.FiscalPrinter;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Text.RegularExpressions;

namespace Wspos
{
    [ServiceBehavior(Namespace = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/", InstanceContextMode = InstanceContextMode.Single)]
    public class FiscalPrinterService : FiscalPrinter
    {
        #region FiscalPrinter Enumration Converter

        private static Dictionary<Enum, Enum> Convert = new Dictionary<Enum, Enum>()
            {
                { Microsoft.PointOfService.PowerReporting.Advanced, PowerReporting.Advanced },
                { Microsoft.PointOfService.PowerReporting.None, PowerReporting.None },
                { Microsoft.PointOfService.PowerReporting.Standard, PowerReporting.Standard },
                { PowerReporting.Advanced, Microsoft.PointOfService.PowerReporting.Advanced },
                { PowerReporting.None, Microsoft.PointOfService.PowerReporting.None },
                { PowerReporting.Standard, Microsoft.PointOfService.PowerReporting.Standard },

                { Microsoft.PointOfService.PowerNotification.Disabled, PowerNotification.Disabled },
                { Microsoft.PointOfService.PowerNotification.Enabled, PowerNotification.Enabled },
                { PowerNotification.Disabled, Microsoft.PointOfService.PowerNotification.Disabled },
                { PowerNotification.Enabled, Microsoft.PointOfService.PowerNotification.Enabled },

                { Microsoft.PointOfService.PowerState.Off, PowerState.Off },
                { Microsoft.PointOfService.PowerState.Offline, PowerState.Offline },
                { Microsoft.PointOfService.PowerState.OffOffline, PowerState.OffOffline },
                { Microsoft.PointOfService.PowerState.Online, PowerState.Online },
                { Microsoft.PointOfService.PowerState.Unknown, PowerState.Unknown },
                { PowerState.Off, Microsoft.PointOfService.PowerState.Off },
                { PowerState.Offline, Microsoft.PointOfService.PowerState.Offline },
                { PowerState.OffOffline, Microsoft.PointOfService.PowerState.OffOffline },
                { PowerState.Online, Microsoft.PointOfService.PowerState.Online },
                { PowerState.Unknown, Microsoft.PointOfService.PowerState.Unknown },

                { Microsoft.PointOfService.ControlState.Busy, ControlState.Busy },
                { Microsoft.PointOfService.ControlState.Closed, ControlState.Closed },
                { Microsoft.PointOfService.ControlState.Error, ControlState.Error },
                { Microsoft.PointOfService.ControlState.Idle, ControlState.Idle },
                { ControlState.Busy, Microsoft.PointOfService.ControlState.Busy },
                { ControlState.Closed, Microsoft.PointOfService.ControlState.Closed },
                { ControlState.Error, Microsoft.PointOfService.ControlState.Error },
                { ControlState.Idle, Microsoft.PointOfService.ControlState.Idle },

                { Microsoft.PointOfService.HealthCheckLevel.External, HealthCheckLevel.External },
                { Microsoft.PointOfService.HealthCheckLevel.Interactive, HealthCheckLevel.Interactive },
                { Microsoft.PointOfService.HealthCheckLevel.Internal, HealthCheckLevel.Internal },
                { HealthCheckLevel.External, Microsoft.PointOfService.HealthCheckLevel.External },
                { HealthCheckLevel.Interactive, Microsoft.PointOfService.HealthCheckLevel.Interactive },
                { HealthCheckLevel.Internal, Microsoft.PointOfService.HealthCheckLevel.Internal },

                { Microsoft.PointOfService.CompareFirmwareResult.Different, CompareFirmwareResult.Different },
                { Microsoft.PointOfService.CompareFirmwareResult.Newer, CompareFirmwareResult.Newer },
                { Microsoft.PointOfService.CompareFirmwareResult.Older, CompareFirmwareResult.Older },
                { Microsoft.PointOfService.CompareFirmwareResult.Same, CompareFirmwareResult.Same },
                { Microsoft.PointOfService.CompareFirmwareResult.Unknown, CompareFirmwareResult.Unknown },
                { CompareFirmwareResult.Different, Microsoft.PointOfService.CompareFirmwareResult.Different },
                { CompareFirmwareResult.Newer, Microsoft.PointOfService.CompareFirmwareResult.Newer },
                { CompareFirmwareResult.Older, Microsoft.PointOfService.CompareFirmwareResult.Older },
                { CompareFirmwareResult.Same, Microsoft.PointOfService.CompareFirmwareResult.Same },
                { CompareFirmwareResult.Unknown, Microsoft.PointOfService.CompareFirmwareResult.Unknown },

                { Microsoft.PointOfService.ErrorCode.Busy, UnifiedPOS.FiscalPrinter.ErrorCode.Busy },
                { Microsoft.PointOfService.ErrorCode.Claimed, UnifiedPOS.FiscalPrinter.ErrorCode.Claimed },
                { Microsoft.PointOfService.ErrorCode.Closed, UnifiedPOS.FiscalPrinter.ErrorCode.Closed },
                { Microsoft.PointOfService.ErrorCode.Deprecated, UnifiedPOS.FiscalPrinter.ErrorCode.Deprecated },
                { Microsoft.PointOfService.ErrorCode.Disabled, UnifiedPOS.FiscalPrinter.ErrorCode.Disabled },
                { Microsoft.PointOfService.ErrorCode.Exists, UnifiedPOS.FiscalPrinter.ErrorCode.Exists },
                { Microsoft.PointOfService.ErrorCode.Extended, UnifiedPOS.FiscalPrinter.ErrorCode.Extended },
                { Microsoft.PointOfService.ErrorCode.Failure, UnifiedPOS.FiscalPrinter.ErrorCode.Failure },
                { Microsoft.PointOfService.ErrorCode.Illegal, UnifiedPOS.FiscalPrinter.ErrorCode.Illegal },
                { Microsoft.PointOfService.ErrorCode.NoExist, UnifiedPOS.FiscalPrinter.ErrorCode.NoExist },
                { Microsoft.PointOfService.ErrorCode.NoHardware, UnifiedPOS.FiscalPrinter.ErrorCode.NoHardware },
                { Microsoft.PointOfService.ErrorCode.NoService, UnifiedPOS.FiscalPrinter.ErrorCode.NoService },
                { Microsoft.PointOfService.ErrorCode.NotClaimed, UnifiedPOS.FiscalPrinter.ErrorCode.NotClaimed },
                { Microsoft.PointOfService.ErrorCode.Offline, UnifiedPOS.FiscalPrinter.ErrorCode.Offline },
                { Microsoft.PointOfService.ErrorCode.Success, UnifiedPOS.FiscalPrinter.ErrorCode.Success },
                { Microsoft.PointOfService.ErrorCode.Timeout, UnifiedPOS.FiscalPrinter.ErrorCode.Timeout },
                { UnifiedPOS.FiscalPrinter.ErrorCode.Busy, Microsoft.PointOfService.ErrorCode.Busy },
                { UnifiedPOS.FiscalPrinter.ErrorCode.Claimed, Microsoft.PointOfService.ErrorCode.Claimed },
                { UnifiedPOS.FiscalPrinter.ErrorCode.Closed, Microsoft.PointOfService.ErrorCode.Closed },
                { UnifiedPOS.FiscalPrinter.ErrorCode.Deprecated, Microsoft.PointOfService.ErrorCode.Deprecated },
                { UnifiedPOS.FiscalPrinter.ErrorCode.Disabled, Microsoft.PointOfService.ErrorCode.Disabled },
                { UnifiedPOS.FiscalPrinter.ErrorCode.Exists, Microsoft.PointOfService.ErrorCode.Exists },
                { UnifiedPOS.FiscalPrinter.ErrorCode.Extended, Microsoft.PointOfService.ErrorCode.Extended },
                { UnifiedPOS.FiscalPrinter.ErrorCode.Failure, Microsoft.PointOfService.ErrorCode.Failure },
                { UnifiedPOS.FiscalPrinter.ErrorCode.Illegal, Microsoft.PointOfService.ErrorCode.Illegal },
                { UnifiedPOS.FiscalPrinter.ErrorCode.NoExist, Microsoft.PointOfService.ErrorCode.NoExist },
                { UnifiedPOS.FiscalPrinter.ErrorCode.NoHardware, Microsoft.PointOfService.ErrorCode.NoHardware },
                { UnifiedPOS.FiscalPrinter.ErrorCode.NoService, Microsoft.PointOfService.ErrorCode.NoService },
                { UnifiedPOS.FiscalPrinter.ErrorCode.NotClaimed, Microsoft.PointOfService.ErrorCode.NotClaimed },
                { UnifiedPOS.FiscalPrinter.ErrorCode.Offline, Microsoft.PointOfService.ErrorCode.Offline },
                { UnifiedPOS.FiscalPrinter.ErrorCode.Success, Microsoft.PointOfService.ErrorCode.Success },
                { UnifiedPOS.FiscalPrinter.ErrorCode.Timeout, Microsoft.PointOfService.ErrorCode.Timeout },

                { Microsoft.PointOfService.FiscalCurrency.BrazilianCruceiro, UnifiedPOS.FiscalPrinter.FiscalCurrency.BrazilianCruceiro },
                { Microsoft.PointOfService.FiscalCurrency.BulgarianLev, UnifiedPOS.FiscalPrinter.FiscalCurrency.BulgarianLev },
                { Microsoft.PointOfService.FiscalCurrency.CzechianKoruna, UnifiedPOS.FiscalPrinter.FiscalCurrency.CzechianKoruna },
                { Microsoft.PointOfService.FiscalCurrency.Euro, UnifiedPOS.FiscalPrinter.FiscalCurrency.Euro },
                { Microsoft.PointOfService.FiscalCurrency.GreekDrachma, UnifiedPOS.FiscalPrinter.FiscalCurrency.GreekDrachma },
                { Microsoft.PointOfService.FiscalCurrency.HungarianForint, UnifiedPOS.FiscalPrinter.FiscalCurrency.HungarianForint },
                { Microsoft.PointOfService.FiscalCurrency.ItalianLira, UnifiedPOS.FiscalPrinter.FiscalCurrency.ItalianLira },
                { Microsoft.PointOfService.FiscalCurrency.Other, UnifiedPOS.FiscalPrinter.FiscalCurrency.Other },
                { Microsoft.PointOfService.FiscalCurrency.PolishZloty, UnifiedPOS.FiscalPrinter.FiscalCurrency.PolishZloty },
                { Microsoft.PointOfService.FiscalCurrency.RomanianLeu, UnifiedPOS.FiscalPrinter.FiscalCurrency.RomanianLeu },
                { Microsoft.PointOfService.FiscalCurrency.RussianRouble, UnifiedPOS.FiscalPrinter.FiscalCurrency.RussianRouble },
                { Microsoft.PointOfService.FiscalCurrency.SwedishKrona, UnifiedPOS.FiscalPrinter.FiscalCurrency.SwedishKrona },
                { Microsoft.PointOfService.FiscalCurrency.TurkishLira, UnifiedPOS.FiscalPrinter.FiscalCurrency.TurkishLira },
                { Microsoft.PointOfService.FiscalCurrency.UkrainianHryvnia, UnifiedPOS.FiscalPrinter.FiscalCurrency.UkrainianHryvnia },
                { UnifiedPOS.FiscalPrinter.FiscalCurrency.BrazilianCruceiro, Microsoft.PointOfService.FiscalCurrency.BrazilianCruceiro },
                { UnifiedPOS.FiscalPrinter.FiscalCurrency.BulgarianLev, Microsoft.PointOfService.FiscalCurrency.BulgarianLev },
                { UnifiedPOS.FiscalPrinter.FiscalCurrency.CzechianKoruna, Microsoft.PointOfService.FiscalCurrency.CzechianKoruna },
                { UnifiedPOS.FiscalPrinter.FiscalCurrency.Euro, Microsoft.PointOfService.FiscalCurrency.Euro },
                { UnifiedPOS.FiscalPrinter.FiscalCurrency.GreekDrachma, Microsoft.PointOfService.FiscalCurrency.GreekDrachma },
                { UnifiedPOS.FiscalPrinter.FiscalCurrency.HungarianForint, Microsoft.PointOfService.FiscalCurrency.HungarianForint },
                { UnifiedPOS.FiscalPrinter.FiscalCurrency.ItalianLira, Microsoft.PointOfService.FiscalCurrency.ItalianLira },
                { UnifiedPOS.FiscalPrinter.FiscalCurrency.Other, Microsoft.PointOfService.FiscalCurrency.Other },
                { UnifiedPOS.FiscalPrinter.FiscalCurrency.PolishZloty, Microsoft.PointOfService.FiscalCurrency.PolishZloty },
                { UnifiedPOS.FiscalPrinter.FiscalCurrency.RomanianLeu, Microsoft.PointOfService.FiscalCurrency.RomanianLeu },
                { UnifiedPOS.FiscalPrinter.FiscalCurrency.RussianRouble, Microsoft.PointOfService.FiscalCurrency.RussianRouble },
                { UnifiedPOS.FiscalPrinter.FiscalCurrency.SwedishKrona, Microsoft.PointOfService.FiscalCurrency.SwedishKrona },
                { UnifiedPOS.FiscalPrinter.FiscalCurrency.TurkishLira, Microsoft.PointOfService.FiscalCurrency.TurkishLira },
                { UnifiedPOS.FiscalPrinter.FiscalCurrency.UkrainianHryvnia, Microsoft.PointOfService.FiscalCurrency.UkrainianHryvnia },

                { Microsoft.PointOfService.FiscalContractorId.First, UnifiedPOS.FiscalPrinter.FiscalContractorID.First },
                { Microsoft.PointOfService.FiscalContractorId.Second, UnifiedPOS.FiscalPrinter.FiscalContractorID.Second },
                { Microsoft.PointOfService.FiscalContractorId.Single, UnifiedPOS.FiscalPrinter.FiscalContractorID.Single },
                { UnifiedPOS.FiscalPrinter.FiscalContractorID.First, Microsoft.PointOfService.FiscalContractorId.First },
                { UnifiedPOS.FiscalPrinter.FiscalContractorID.Second, Microsoft.PointOfService.FiscalContractorId.Second },
                { UnifiedPOS.FiscalPrinter.FiscalContractorID.Single, Microsoft.PointOfService.FiscalContractorId.Single },

                { Microsoft.PointOfService.FiscalDateType.Configuration, UnifiedPOS.FiscalPrinter.FiscalDateType.Configuration },
                { Microsoft.PointOfService.FiscalDateType.EndOfDay, UnifiedPOS.FiscalPrinter.FiscalDateType.EndOfDay },
                { Microsoft.PointOfService.FiscalDateType.RealTimeClock, UnifiedPOS.FiscalPrinter.FiscalDateType.RealTimeClock },
                { Microsoft.PointOfService.FiscalDateType.Reset, UnifiedPOS.FiscalPrinter.FiscalDateType.Reset },
                { Microsoft.PointOfService.FiscalDateType.Start, UnifiedPOS.FiscalPrinter.FiscalDateType.Start },
                { Microsoft.PointOfService.FiscalDateType.VatChange, UnifiedPOS.FiscalPrinter.FiscalDateType.VatChange },
                { UnifiedPOS.FiscalPrinter.FiscalDateType.Configuration, Microsoft.PointOfService.FiscalDateType.Configuration },
                { UnifiedPOS.FiscalPrinter.FiscalDateType.EndOfDay, Microsoft.PointOfService.FiscalDateType.EndOfDay },
                { UnifiedPOS.FiscalPrinter.FiscalDateType.RealTimeClock, Microsoft.PointOfService.FiscalDateType.RealTimeClock },
                { UnifiedPOS.FiscalPrinter.FiscalDateType.Reset, Microsoft.PointOfService.FiscalDateType.Reset },
                { UnifiedPOS.FiscalPrinter.FiscalDateType.Start, Microsoft.PointOfService.FiscalDateType.Start },
                { UnifiedPOS.FiscalPrinter.FiscalDateType.VatChange, Microsoft.PointOfService.FiscalDateType.VatChange },

                { Microsoft.PointOfService.FiscalErrorLevel.Blocked, UnifiedPOS.FiscalPrinter.FiscalErrorLevel.Blocked },
                { Microsoft.PointOfService.FiscalErrorLevel.Fatal, UnifiedPOS.FiscalPrinter.FiscalErrorLevel.Fatal },
                { Microsoft.PointOfService.FiscalErrorLevel.None, UnifiedPOS.FiscalPrinter.FiscalErrorLevel.None },
                { Microsoft.PointOfService.FiscalErrorLevel.Recoverable, UnifiedPOS.FiscalPrinter.FiscalErrorLevel.Recoverable },
                { UnifiedPOS.FiscalPrinter.FiscalErrorLevel.Blocked, Microsoft.PointOfService.FiscalErrorLevel.Blocked },
                { UnifiedPOS.FiscalPrinter.FiscalErrorLevel.Fatal, Microsoft.PointOfService.FiscalErrorLevel.Fatal },
                { UnifiedPOS.FiscalPrinter.FiscalErrorLevel.None, Microsoft.PointOfService.FiscalErrorLevel.None },
                { UnifiedPOS.FiscalPrinter.FiscalErrorLevel.Recoverable, Microsoft.PointOfService.FiscalErrorLevel.Recoverable },

                { Microsoft.PointOfService.FiscalPrinterState.FiscalDocument, UnifiedPOS.FiscalPrinter.FiscalPrinterState.FiscalDocument },
                { Microsoft.PointOfService.FiscalPrinterState.FiscalReceipt, UnifiedPOS.FiscalPrinter.FiscalPrinterState.FiscalReceipt },
                { Microsoft.PointOfService.FiscalPrinterState.FiscalReceiptEnding, UnifiedPOS.FiscalPrinter.FiscalPrinterState.FiscalReceiptEnding },
                { Microsoft.PointOfService.FiscalPrinterState.FiscalReceiptTotal, UnifiedPOS.FiscalPrinter.FiscalPrinterState.FiscalReceiptTotal },
                { Microsoft.PointOfService.FiscalPrinterState.FixedOutput, UnifiedPOS.FiscalPrinter.FiscalPrinterState.FixedOutput },
                { Microsoft.PointOfService.FiscalPrinterState.ItemList, UnifiedPOS.FiscalPrinter.FiscalPrinterState.ItemList },
                { Microsoft.PointOfService.FiscalPrinterState.Locked, UnifiedPOS.FiscalPrinter.FiscalPrinterState.Locked },
                { Microsoft.PointOfService.FiscalPrinterState.Monitor, UnifiedPOS.FiscalPrinter.FiscalPrinterState.Monitor },
                { Microsoft.PointOfService.FiscalPrinterState.NonFiscal, UnifiedPOS.FiscalPrinter.FiscalPrinterState.NonFiscal },
                { Microsoft.PointOfService.FiscalPrinterState.Report, UnifiedPOS.FiscalPrinter.FiscalPrinterState.Report },

                { Microsoft.PointOfService.FiscalPrinterStations.Journal, UnifiedPOS.FiscalPrinter.FiscalPrinterStations.Journal },
                { Microsoft.PointOfService.FiscalPrinterStations.JournalReceipt, UnifiedPOS.FiscalPrinter.FiscalPrinterStations.JournalReceipt },
                { Microsoft.PointOfService.FiscalPrinterStations.JournalSlip, UnifiedPOS.FiscalPrinter.FiscalPrinterStations.JournalSlip },
                { Microsoft.PointOfService.FiscalPrinterStations.Receipt, UnifiedPOS.FiscalPrinter.FiscalPrinterStations.Receipt },
                { Microsoft.PointOfService.FiscalPrinterStations.ReceiptSlip, UnifiedPOS.FiscalPrinter.FiscalPrinterStations.ReceiptSlip },
                { Microsoft.PointOfService.FiscalPrinterStations.Slip, UnifiedPOS.FiscalPrinter.FiscalPrinterStations.Slip },
                { UnifiedPOS.FiscalPrinter.FiscalPrinterStations.Journal, Microsoft.PointOfService.FiscalPrinterStations.Journal },
                { UnifiedPOS.FiscalPrinter.FiscalPrinterStations.JournalReceipt, Microsoft.PointOfService.FiscalPrinterStations.JournalReceipt },
                { UnifiedPOS.FiscalPrinter.FiscalPrinterStations.JournalSlip, Microsoft.PointOfService.FiscalPrinterStations.JournalSlip },
                { UnifiedPOS.FiscalPrinter.FiscalPrinterStations.Receipt, Microsoft.PointOfService.FiscalPrinterStations.Receipt },
                { UnifiedPOS.FiscalPrinter.FiscalPrinterStations.ReceiptSlip, Microsoft.PointOfService.FiscalPrinterStations.ReceiptSlip },
                { UnifiedPOS.FiscalPrinter.FiscalPrinterStations.Slip, Microsoft.PointOfService.FiscalPrinterStations.Slip },

                { Microsoft.PointOfService.FiscalReceiptStation.Receipt, UnifiedPOS.FiscalPrinter.FiscalReceiptStation.Receipt },
                { Microsoft.PointOfService.FiscalReceiptStation.Slip, UnifiedPOS.FiscalPrinter.FiscalReceiptStation.Slip },
                { UnifiedPOS.FiscalPrinter.FiscalReceiptStation.Receipt, Microsoft.PointOfService.FiscalReceiptStation.Receipt },
                { UnifiedPOS.FiscalPrinter.FiscalReceiptStation.Slip, Microsoft.PointOfService.FiscalReceiptStation.Slip },

                { Microsoft.PointOfService.FiscalReceiptType.CashIn, UnifiedPOS.FiscalPrinter.FiscalReceiptType.CashIn },
                { Microsoft.PointOfService.FiscalReceiptType.CashOut, UnifiedPOS.FiscalPrinter.FiscalReceiptType.CashOut },
                { Microsoft.PointOfService.FiscalReceiptType.Generic, UnifiedPOS.FiscalPrinter.FiscalReceiptType.Generic },
                { Microsoft.PointOfService.FiscalReceiptType.Refund, UnifiedPOS.FiscalPrinter.FiscalReceiptType.Refund },
                { Microsoft.PointOfService.FiscalReceiptType.Sales, UnifiedPOS.FiscalPrinter.FiscalReceiptType.Sales },
                { Microsoft.PointOfService.FiscalReceiptType.Service, UnifiedPOS.FiscalPrinter.FiscalReceiptType.Service },
                { Microsoft.PointOfService.FiscalReceiptType.SimpleInvoice, UnifiedPOS.FiscalPrinter.FiscalReceiptType.SimpleInvoice },
                { UnifiedPOS.FiscalPrinter.FiscalReceiptType.CashIn, Microsoft.PointOfService.FiscalReceiptType.CashIn },
                { UnifiedPOS.FiscalPrinter.FiscalReceiptType.CashOut, Microsoft.PointOfService.FiscalReceiptType.CashOut },
                { UnifiedPOS.FiscalPrinter.FiscalReceiptType.Generic, Microsoft.PointOfService.FiscalReceiptType.Generic },
                { UnifiedPOS.FiscalPrinter.FiscalReceiptType.Refund, Microsoft.PointOfService.FiscalReceiptType.Refund },
                { UnifiedPOS.FiscalPrinter.FiscalReceiptType.Sales, Microsoft.PointOfService.FiscalReceiptType.Sales },
                { UnifiedPOS.FiscalPrinter.FiscalReceiptType.Service, Microsoft.PointOfService.FiscalReceiptType.Service },
                { UnifiedPOS.FiscalPrinter.FiscalReceiptType.SimpleInvoice, Microsoft.PointOfService.FiscalReceiptType.SimpleInvoice },

                { Microsoft.PointOfService.FiscalMessageType.Advance, UnifiedPOS.FiscalPrinter.FiscalMessageType.Advance },
                { Microsoft.PointOfService.FiscalMessageType.AdvancePaid, UnifiedPOS.FiscalPrinter.FiscalMessageType.AdvancePaid },
                { Microsoft.PointOfService.FiscalMessageType.AmountToBePaid, UnifiedPOS.FiscalPrinter.FiscalMessageType.AmountToBePaid },
                { Microsoft.PointOfService.FiscalMessageType.AmountToBePaidBack, UnifiedPOS.FiscalPrinter.FiscalMessageType.AmountToBePaidBack },
                { Microsoft.PointOfService.FiscalMessageType.Card, UnifiedPOS.FiscalPrinter.FiscalMessageType.Card },
                { Microsoft.PointOfService.FiscalMessageType.CardNumber, UnifiedPOS.FiscalPrinter.FiscalMessageType.CardNumber },
                { Microsoft.PointOfService.FiscalMessageType.CardType, UnifiedPOS.FiscalPrinter.FiscalMessageType.CardType },
                { Microsoft.PointOfService.FiscalMessageType.Cash, UnifiedPOS.FiscalPrinter.FiscalMessageType.Cash },
                { Microsoft.PointOfService.FiscalMessageType.Cashier, UnifiedPOS.FiscalPrinter.FiscalMessageType.Cashier },
                { Microsoft.PointOfService.FiscalMessageType.CashRegisterNumber, UnifiedPOS.FiscalPrinter.FiscalMessageType.CashRegisterNumber },
                { Microsoft.PointOfService.FiscalMessageType.Change, UnifiedPOS.FiscalPrinter.FiscalMessageType.Change },
                { Microsoft.PointOfService.FiscalMessageType.Cheque, UnifiedPOS.FiscalPrinter.FiscalMessageType.Cheque },
                { Microsoft.PointOfService.FiscalMessageType.ClientNumber, UnifiedPOS.FiscalPrinter.FiscalMessageType.ClientNumber },
                { Microsoft.PointOfService.FiscalMessageType.ClientSignature, UnifiedPOS.FiscalPrinter.FiscalMessageType.ClientSignature },
                { Microsoft.PointOfService.FiscalMessageType.CounterState, UnifiedPOS.FiscalPrinter.FiscalMessageType.CounterState },
                { Microsoft.PointOfService.FiscalMessageType.CreditCard, UnifiedPOS.FiscalPrinter.FiscalMessageType.CreditCard },
                { Microsoft.PointOfService.FiscalMessageType.Currency, UnifiedPOS.FiscalPrinter.FiscalMessageType.Currency },
                { Microsoft.PointOfService.FiscalMessageType.CurrencyValue, UnifiedPOS.FiscalPrinter.FiscalMessageType.CurrencyValue },
                { Microsoft.PointOfService.FiscalMessageType.Deposit, UnifiedPOS.FiscalPrinter.FiscalMessageType.Deposit },
                { Microsoft.PointOfService.FiscalMessageType.DepositReturned, UnifiedPOS.FiscalPrinter.FiscalMessageType.DepositReturned },
                { Microsoft.PointOfService.FiscalMessageType.DotLine, UnifiedPOS.FiscalPrinter.FiscalMessageType.DotLine },
                { Microsoft.PointOfService.FiscalMessageType.DriverNumber, UnifiedPOS.FiscalPrinter.FiscalMessageType.DriverNumber },
                { Microsoft.PointOfService.FiscalMessageType.EmptyLine, UnifiedPOS.FiscalPrinter.FiscalMessageType.EmptyLine },
                { Microsoft.PointOfService.FiscalMessageType.FreeText, UnifiedPOS.FiscalPrinter.FiscalMessageType.FreeText },
                { Microsoft.PointOfService.FiscalMessageType.FreeTextWithDayLimit, UnifiedPOS.FiscalPrinter.FiscalMessageType.FreeTextWithDayLimit },
                { Microsoft.PointOfService.FiscalMessageType.GivenDiscount, UnifiedPOS.FiscalPrinter.FiscalMessageType.GivenDiscount },
                { Microsoft.PointOfService.FiscalMessageType.LocalCredit, UnifiedPOS.FiscalPrinter.FiscalMessageType.LocalCredit },
                { Microsoft.PointOfService.FiscalMessageType.MileageKilometers, UnifiedPOS.FiscalPrinter.FiscalMessageType.MileageKilometers },
                { Microsoft.PointOfService.FiscalMessageType.Note, UnifiedPOS.FiscalPrinter.FiscalMessageType.Note },
                { Microsoft.PointOfService.FiscalMessageType.Paid, UnifiedPOS.FiscalPrinter.FiscalMessageType.Paid },
                { Microsoft.PointOfService.FiscalMessageType.PayIn, UnifiedPOS.FiscalPrinter.FiscalMessageType.PayIn },
                { Microsoft.PointOfService.FiscalMessageType.PointGranted, UnifiedPOS.FiscalPrinter.FiscalMessageType.PointGranted },
                { Microsoft.PointOfService.FiscalMessageType.PointsBonus, UnifiedPOS.FiscalPrinter.FiscalMessageType.PointsBonus },
                { Microsoft.PointOfService.FiscalMessageType.PointsReceipt, UnifiedPOS.FiscalPrinter.FiscalMessageType.PointsReceipt },
                { Microsoft.PointOfService.FiscalMessageType.PointsTotal, UnifiedPOS.FiscalPrinter.FiscalMessageType.PointsTotal },
                { Microsoft.PointOfService.FiscalMessageType.Profited, UnifiedPOS.FiscalPrinter.FiscalMessageType.Profited },
                { Microsoft.PointOfService.FiscalMessageType.Rate, UnifiedPOS.FiscalPrinter.FiscalMessageType.Rate },
                { Microsoft.PointOfService.FiscalMessageType.RegisterNumber, UnifiedPOS.FiscalPrinter.FiscalMessageType.RegisterNumber },
                { Microsoft.PointOfService.FiscalMessageType.ShiftNumber, UnifiedPOS.FiscalPrinter.FiscalMessageType.ShiftNumber },
                { Microsoft.PointOfService.FiscalMessageType.StateOfAnAccount, UnifiedPOS.FiscalPrinter.FiscalMessageType.StateOfAnAccount },
                { Microsoft.PointOfService.FiscalMessageType.Subscription, UnifiedPOS.FiscalPrinter.FiscalMessageType.Subscription },
                { Microsoft.PointOfService.FiscalMessageType.Table, UnifiedPOS.FiscalPrinter.FiscalMessageType.Table },
                { Microsoft.PointOfService.FiscalMessageType.ThankYouForLoyalty, UnifiedPOS.FiscalPrinter.FiscalMessageType.ThankYouForLoyalty },
                { Microsoft.PointOfService.FiscalMessageType.TransactionNumber, UnifiedPOS.FiscalPrinter.FiscalMessageType.TransactionNumber },
                { Microsoft.PointOfService.FiscalMessageType.ValidTo, UnifiedPOS.FiscalPrinter.FiscalMessageType.ValidTo },
                { Microsoft.PointOfService.FiscalMessageType.Voucher, UnifiedPOS.FiscalPrinter.FiscalMessageType.Voucher },
                { Microsoft.PointOfService.FiscalMessageType.VoucherPaid, UnifiedPOS.FiscalPrinter.FiscalMessageType.VoucherPaid },
                { Microsoft.PointOfService.FiscalMessageType.VoucherValue, UnifiedPOS.FiscalPrinter.FiscalMessageType.VoucherValue },
                { Microsoft.PointOfService.FiscalMessageType.WithDiscount, UnifiedPOS.FiscalPrinter.FiscalMessageType.WithDiscount },
                { Microsoft.PointOfService.FiscalMessageType.WithoutUplift, UnifiedPOS.FiscalPrinter.FiscalMessageType.WithoutUplift },
                { UnifiedPOS.FiscalPrinter.FiscalMessageType.Advance, Microsoft.PointOfService.FiscalMessageType.Advance },
                { UnifiedPOS.FiscalPrinter.FiscalMessageType.AdvancePaid, Microsoft.PointOfService.FiscalMessageType.AdvancePaid },
                { UnifiedPOS.FiscalPrinter.FiscalMessageType.AmountToBePaid, Microsoft.PointOfService.FiscalMessageType.AmountToBePaid },
                { UnifiedPOS.FiscalPrinter.FiscalMessageType.AmountToBePaidBack, Microsoft.PointOfService.FiscalMessageType.AmountToBePaidBack },
                { UnifiedPOS.FiscalPrinter.FiscalMessageType.Card, Microsoft.PointOfService.FiscalMessageType.Card },
                { UnifiedPOS.FiscalPrinter.FiscalMessageType.CardNumber, Microsoft.PointOfService.FiscalMessageType.CardNumber },
                { UnifiedPOS.FiscalPrinter.FiscalMessageType.CardType, Microsoft.PointOfService.FiscalMessageType.CardType },
                { UnifiedPOS.FiscalPrinter.FiscalMessageType.Cash, Microsoft.PointOfService.FiscalMessageType.Cash },
                { UnifiedPOS.FiscalPrinter.FiscalMessageType.Cashier, Microsoft.PointOfService.FiscalMessageType.Cashier },
                { UnifiedPOS.FiscalPrinter.FiscalMessageType.CashRegisterNumber, Microsoft.PointOfService.FiscalMessageType.CashRegisterNumber },
                { UnifiedPOS.FiscalPrinter.FiscalMessageType.Change, Microsoft.PointOfService.FiscalMessageType.Change },
                { UnifiedPOS.FiscalPrinter.FiscalMessageType.Cheque, Microsoft.PointOfService.FiscalMessageType.Cheque },
                { UnifiedPOS.FiscalPrinter.FiscalMessageType.ClientNumber, Microsoft.PointOfService.FiscalMessageType.ClientNumber },
                { UnifiedPOS.FiscalPrinter.FiscalMessageType.ClientSignature, Microsoft.PointOfService.FiscalMessageType.ClientSignature },
                { UnifiedPOS.FiscalPrinter.FiscalMessageType.CounterState, Microsoft.PointOfService.FiscalMessageType.CounterState },
                { UnifiedPOS.FiscalPrinter.FiscalMessageType.CreditCard, Microsoft.PointOfService.FiscalMessageType.CreditCard },
                { UnifiedPOS.FiscalPrinter.FiscalMessageType.Currency, Microsoft.PointOfService.FiscalMessageType.Currency },
                { UnifiedPOS.FiscalPrinter.FiscalMessageType.CurrencyValue, Microsoft.PointOfService.FiscalMessageType.CurrencyValue },
                { UnifiedPOS.FiscalPrinter.FiscalMessageType.Deposit, Microsoft.PointOfService.FiscalMessageType.Deposit },
                { UnifiedPOS.FiscalPrinter.FiscalMessageType.DepositReturned, Microsoft.PointOfService.FiscalMessageType.DepositReturned },
                { UnifiedPOS.FiscalPrinter.FiscalMessageType.DotLine, Microsoft.PointOfService.FiscalMessageType.DotLine },
                { UnifiedPOS.FiscalPrinter.FiscalMessageType.DriverNumber, Microsoft.PointOfService.FiscalMessageType.DriverNumber },
                { UnifiedPOS.FiscalPrinter.FiscalMessageType.EmptyLine, Microsoft.PointOfService.FiscalMessageType.EmptyLine },
                { UnifiedPOS.FiscalPrinter.FiscalMessageType.FreeText, Microsoft.PointOfService.FiscalMessageType.FreeText },
                { UnifiedPOS.FiscalPrinter.FiscalMessageType.FreeTextWithDayLimit, Microsoft.PointOfService.FiscalMessageType.FreeTextWithDayLimit },
                { UnifiedPOS.FiscalPrinter.FiscalMessageType.GivenDiscount, Microsoft.PointOfService.FiscalMessageType.GivenDiscount },
                { UnifiedPOS.FiscalPrinter.FiscalMessageType.LocalCredit, Microsoft.PointOfService.FiscalMessageType.LocalCredit },
                { UnifiedPOS.FiscalPrinter.FiscalMessageType.MileageKilometers, Microsoft.PointOfService.FiscalMessageType.MileageKilometers },
                { UnifiedPOS.FiscalPrinter.FiscalMessageType.Note, Microsoft.PointOfService.FiscalMessageType.Note },
                { UnifiedPOS.FiscalPrinter.FiscalMessageType.Paid, Microsoft.PointOfService.FiscalMessageType.Paid },
                { UnifiedPOS.FiscalPrinter.FiscalMessageType.PayIn, Microsoft.PointOfService.FiscalMessageType.PayIn },
                { UnifiedPOS.FiscalPrinter.FiscalMessageType.PointGranted, Microsoft.PointOfService.FiscalMessageType.PointGranted },
                { UnifiedPOS.FiscalPrinter.FiscalMessageType.PointsBonus, Microsoft.PointOfService.FiscalMessageType.PointsBonus },
                { UnifiedPOS.FiscalPrinter.FiscalMessageType.PointsReceipt, Microsoft.PointOfService.FiscalMessageType.PointsReceipt },
                { UnifiedPOS.FiscalPrinter.FiscalMessageType.PointsTotal, Microsoft.PointOfService.FiscalMessageType.PointsTotal },
                { UnifiedPOS.FiscalPrinter.FiscalMessageType.Profited, Microsoft.PointOfService.FiscalMessageType.Profited },
                { UnifiedPOS.FiscalPrinter.FiscalMessageType.Rate, Microsoft.PointOfService.FiscalMessageType.Rate },
                { UnifiedPOS.FiscalPrinter.FiscalMessageType.RegisterNumber, Microsoft.PointOfService.FiscalMessageType.RegisterNumber },
                { UnifiedPOS.FiscalPrinter.FiscalMessageType.ShiftNumber, Microsoft.PointOfService.FiscalMessageType.ShiftNumber },
                { UnifiedPOS.FiscalPrinter.FiscalMessageType.StateOfAnAccount, Microsoft.PointOfService.FiscalMessageType.StateOfAnAccount },
                { UnifiedPOS.FiscalPrinter.FiscalMessageType.Subscription, Microsoft.PointOfService.FiscalMessageType.Subscription },
                { UnifiedPOS.FiscalPrinter.FiscalMessageType.Table, Microsoft.PointOfService.FiscalMessageType.Table },
                { UnifiedPOS.FiscalPrinter.FiscalMessageType.ThankYouForLoyalty, Microsoft.PointOfService.FiscalMessageType.ThankYouForLoyalty },
                { UnifiedPOS.FiscalPrinter.FiscalMessageType.TransactionNumber, Microsoft.PointOfService.FiscalMessageType.TransactionNumber },
                { UnifiedPOS.FiscalPrinter.FiscalMessageType.ValidTo, Microsoft.PointOfService.FiscalMessageType.ValidTo },
                { UnifiedPOS.FiscalPrinter.FiscalMessageType.Voucher, Microsoft.PointOfService.FiscalMessageType.Voucher },
                { UnifiedPOS.FiscalPrinter.FiscalMessageType.VoucherPaid, Microsoft.PointOfService.FiscalMessageType.VoucherPaid },
                { UnifiedPOS.FiscalPrinter.FiscalMessageType.VoucherValue, Microsoft.PointOfService.FiscalMessageType.VoucherValue },
                { UnifiedPOS.FiscalPrinter.FiscalMessageType.WithDiscount, Microsoft.PointOfService.FiscalMessageType.WithDiscount },
                { UnifiedPOS.FiscalPrinter.FiscalMessageType.WithoutUplift, Microsoft.PointOfService.FiscalMessageType.WithoutUplift },

                { Microsoft.PointOfService.FiscalSlipSelection.FullLength, UnifiedPOS.FiscalPrinter.FiscalSlipSelection.FullLength },
                { Microsoft.PointOfService.FiscalSlipSelection.Validation, UnifiedPOS.FiscalPrinter.FiscalSlipSelection.Validation },
                { UnifiedPOS.FiscalPrinter.FiscalSlipSelection.FullLength, Microsoft.PointOfService.FiscalSlipSelection.FullLength },
                { UnifiedPOS.FiscalPrinter.FiscalSlipSelection.Validation, Microsoft.PointOfService.FiscalSlipSelection.Validation },

                { Microsoft.PointOfService.FiscalTotalizerType.Day, UnifiedPOS.FiscalPrinter.FiscalTotalizerType.Day },
                { Microsoft.PointOfService.FiscalTotalizerType.Document, UnifiedPOS.FiscalPrinter.FiscalTotalizerType.Document },
                { Microsoft.PointOfService.FiscalTotalizerType.Grand, UnifiedPOS.FiscalPrinter.FiscalTotalizerType.Grand },
                { Microsoft.PointOfService.FiscalTotalizerType.Receipt, UnifiedPOS.FiscalPrinter.FiscalTotalizerType.Receipt },
                { UnifiedPOS.FiscalPrinter.FiscalTotalizerType.Day, Microsoft.PointOfService.FiscalTotalizerType.Day },
                { UnifiedPOS.FiscalPrinter.FiscalTotalizerType.Document, Microsoft.PointOfService.FiscalTotalizerType.Document },
                { UnifiedPOS.FiscalPrinter.FiscalTotalizerType.Grand, Microsoft.PointOfService.FiscalTotalizerType.Grand },
                { UnifiedPOS.FiscalPrinter.FiscalTotalizerType.Receipt, Microsoft.PointOfService.FiscalTotalizerType.Receipt },

                { Microsoft.PointOfService.FiscalAdjustment.AmountDiscount, UnifiedPOS.FiscalPrinter.FiscalAdjustment.AmountDiscount },
                { Microsoft.PointOfService.FiscalAdjustment.AmountSurcharge, UnifiedPOS.FiscalPrinter.FiscalAdjustment.AmountSurcharge },
                { Microsoft.PointOfService.FiscalAdjustment.CouponAmountDiscount, UnifiedPOS.FiscalPrinter.FiscalAdjustment.CouponAmountDiscount },
                { Microsoft.PointOfService.FiscalAdjustment.CouponPercentageDiscount, UnifiedPOS.FiscalPrinter.FiscalAdjustment.CouponPercentageDiscount },
                { Microsoft.PointOfService.FiscalAdjustment.PercentageDiscount, UnifiedPOS.FiscalPrinter.FiscalAdjustment.PercentageDiscount },
                { Microsoft.PointOfService.FiscalAdjustment.PercentageSurcharge, UnifiedPOS.FiscalPrinter.FiscalAdjustment.PercentageSurcharge },
                { UnifiedPOS.FiscalPrinter.FiscalAdjustment.AmountDiscount, Microsoft.PointOfService.FiscalAdjustment.AmountDiscount },
                { UnifiedPOS.FiscalPrinter.FiscalAdjustment.AmountSurcharge, Microsoft.PointOfService.FiscalAdjustment.AmountSurcharge },
                { UnifiedPOS.FiscalPrinter.FiscalAdjustment.CouponAmountDiscount, Microsoft.PointOfService.FiscalAdjustment.CouponAmountDiscount },
                { UnifiedPOS.FiscalPrinter.FiscalAdjustment.CouponPercentageDiscount, Microsoft.PointOfService.FiscalAdjustment.CouponPercentageDiscount },
                { UnifiedPOS.FiscalPrinter.FiscalAdjustment.PercentageDiscount, Microsoft.PointOfService.FiscalAdjustment.PercentageDiscount },
                { UnifiedPOS.FiscalPrinter.FiscalAdjustment.PercentageSurcharge, Microsoft.PointOfService.FiscalAdjustment.PercentageSurcharge },

                { Microsoft.PointOfService.FiscalAdjustmentType.Discount, UnifiedPOS.FiscalPrinter.FiscalAdjustmentType.Discount },
                { Microsoft.PointOfService.FiscalAdjustmentType.Surcharge, UnifiedPOS.FiscalPrinter.FiscalAdjustmentType.Surcharge },
                { UnifiedPOS.FiscalPrinter.FiscalAdjustmentType.Discount, Microsoft.PointOfService.FiscalAdjustmentType.Discount },
                { UnifiedPOS.FiscalPrinter.FiscalAdjustmentType.Surcharge, Microsoft.PointOfService.FiscalAdjustmentType.Surcharge },

                { Microsoft.PointOfService.ReportType.Date, UnifiedPOS.FiscalPrinter.ReportType.Date },
                { Microsoft.PointOfService.ReportType.EndOfDayOrdinal, UnifiedPOS.FiscalPrinter.ReportType.EndOfDayOrdinal },
                { Microsoft.PointOfService.ReportType.Ordinal, UnifiedPOS.FiscalPrinter.ReportType.Ordinal },
                { UnifiedPOS.FiscalPrinter.ReportType.Date, Microsoft.PointOfService.ReportType.Date },
                { UnifiedPOS.FiscalPrinter.ReportType.EndOfDayOrdinal, Microsoft.PointOfService.ReportType.EndOfDayOrdinal },
                { UnifiedPOS.FiscalPrinter.ReportType.Ordinal, Microsoft.PointOfService.ReportType.Ordinal },

                { Microsoft.PointOfService.FiscalData.CurrentTotal, UnifiedPOS.FiscalPrinter.FiscalData.CurrentTotal },
                { Microsoft.PointOfService.FiscalData.DailyTotal, UnifiedPOS.FiscalPrinter.FiscalData.DailyTotal },
                { Microsoft.PointOfService.FiscalData.DescriptionLength, UnifiedPOS.FiscalPrinter.FiscalData.DescriptionLength },
                { Microsoft.PointOfService.FiscalData.Firmware, UnifiedPOS.FiscalPrinter.FiscalData.Firmware },
                { Microsoft.PointOfService.FiscalData.FiscalDocument, UnifiedPOS.FiscalPrinter.FiscalData.FiscalDocument },
                { Microsoft.PointOfService.FiscalData.FiscalDocumentVoid, UnifiedPOS.FiscalPrinter.FiscalData.FiscalDocumentVoid },
                { Microsoft.PointOfService.FiscalData.FiscalReceipt, UnifiedPOS.FiscalPrinter.FiscalData.FiscalReceipt },
                { Microsoft.PointOfService.FiscalData.FiscalReceiptVoid, UnifiedPOS.FiscalPrinter.FiscalData.FiscalReceiptVoid },
                { Microsoft.PointOfService.FiscalData.GrandTotal, UnifiedPOS.FiscalPrinter.FiscalData.GrandTotal },
                { Microsoft.PointOfService.FiscalData.LineCount, UnifiedPOS.FiscalPrinter.FiscalData.LineCount },
                { Microsoft.PointOfService.FiscalData.NonFiscalDocument, UnifiedPOS.FiscalPrinter.FiscalData.NonFiscalDocument },
                { Microsoft.PointOfService.FiscalData.NonFiscalDocumentVoid, UnifiedPOS.FiscalPrinter.FiscalData.NonFiscalDocumentVoid },
                { Microsoft.PointOfService.FiscalData.NonFiscalReceipt, UnifiedPOS.FiscalPrinter.FiscalData.NonFiscalReceipt },
                { Microsoft.PointOfService.FiscalData.NotPaid, UnifiedPOS.FiscalPrinter.FiscalData.NotPaid },
                { Microsoft.PointOfService.FiscalData.NumberOfConfigurationBlocks, UnifiedPOS.FiscalPrinter.FiscalData.NumberOfConfigurationBlocks },
                { Microsoft.PointOfService.FiscalData.NumberOfCurrencyBlocks, UnifiedPOS.FiscalPrinter.FiscalData.NumberOfCurrencyBlocks },
                { Microsoft.PointOfService.FiscalData.NumberOfHeaderBlocks, UnifiedPOS.FiscalPrinter.FiscalData.NumberOfHeaderBlocks },
                { Microsoft.PointOfService.FiscalData.NumberOfResetBlocks, UnifiedPOS.FiscalPrinter.FiscalData.NumberOfResetBlocks },
                { Microsoft.PointOfService.FiscalData.NumberOfVatBlocks, UnifiedPOS.FiscalPrinter.FiscalData.NumberOfVatBlocks },
                { Microsoft.PointOfService.FiscalData.NumberOfVoidedReceipts, UnifiedPOS.FiscalPrinter.FiscalData.NumberOfVoidedReceipts },
                { Microsoft.PointOfService.FiscalData.PrinterId, UnifiedPOS.FiscalPrinter.FiscalData.PrinterId },
                { Microsoft.PointOfService.FiscalData.ReceiptNumber, UnifiedPOS.FiscalPrinter.FiscalData.ReceiptNumber },
                { Microsoft.PointOfService.FiscalData.Refund, UnifiedPOS.FiscalPrinter.FiscalData.Refund },
                { Microsoft.PointOfService.FiscalData.RefundVoid, UnifiedPOS.FiscalPrinter.FiscalData.RefundVoid },
                { Microsoft.PointOfService.FiscalData.Restart, UnifiedPOS.FiscalPrinter.FiscalData.Restart },
                { Microsoft.PointOfService.FiscalData.SimplifiedInvoice, UnifiedPOS.FiscalPrinter.FiscalData.SimplifiedInvoice },
                { Microsoft.PointOfService.FiscalData.Tender, UnifiedPOS.FiscalPrinter.FiscalData.Tender },
                { Microsoft.PointOfService.FiscalData.ZReport, UnifiedPOS.FiscalPrinter.FiscalData.ZReport },
                { UnifiedPOS.FiscalPrinter.FiscalData.CurrentTotal, Microsoft.PointOfService.FiscalData.CurrentTotal },
                { UnifiedPOS.FiscalPrinter.FiscalData.DailyTotal, Microsoft.PointOfService.FiscalData.DailyTotal },
                { UnifiedPOS.FiscalPrinter.FiscalData.DescriptionLength, Microsoft.PointOfService.FiscalData.DescriptionLength },
                { UnifiedPOS.FiscalPrinter.FiscalData.Firmware, Microsoft.PointOfService.FiscalData.Firmware },
                { UnifiedPOS.FiscalPrinter.FiscalData.FiscalDocument, Microsoft.PointOfService.FiscalData.FiscalDocument },
                { UnifiedPOS.FiscalPrinter.FiscalData.FiscalDocumentVoid, Microsoft.PointOfService.FiscalData.FiscalDocumentVoid },
                { UnifiedPOS.FiscalPrinter.FiscalData.FiscalReceipt, Microsoft.PointOfService.FiscalData.FiscalReceipt },
                { UnifiedPOS.FiscalPrinter.FiscalData.FiscalReceiptVoid, Microsoft.PointOfService.FiscalData.FiscalReceiptVoid },
                { UnifiedPOS.FiscalPrinter.FiscalData.GrandTotal, Microsoft.PointOfService.FiscalData.GrandTotal },
                { UnifiedPOS.FiscalPrinter.FiscalData.LineCount, Microsoft.PointOfService.FiscalData.LineCount },
                { UnifiedPOS.FiscalPrinter.FiscalData.NonFiscalDocument, Microsoft.PointOfService.FiscalData.NonFiscalDocument },
                { UnifiedPOS.FiscalPrinter.FiscalData.NonFiscalDocumentVoid, Microsoft.PointOfService.FiscalData.NonFiscalDocumentVoid },
                { UnifiedPOS.FiscalPrinter.FiscalData.NonFiscalReceipt, Microsoft.PointOfService.FiscalData.NonFiscalReceipt },
                { UnifiedPOS.FiscalPrinter.FiscalData.NotPaid, Microsoft.PointOfService.FiscalData.NotPaid },
                { UnifiedPOS.FiscalPrinter.FiscalData.NumberOfConfigurationBlocks, Microsoft.PointOfService.FiscalData.NumberOfConfigurationBlocks },
                { UnifiedPOS.FiscalPrinter.FiscalData.NumberOfCurrencyBlocks, Microsoft.PointOfService.FiscalData.NumberOfCurrencyBlocks },
                { UnifiedPOS.FiscalPrinter.FiscalData.NumberOfHeaderBlocks, Microsoft.PointOfService.FiscalData.NumberOfHeaderBlocks },
                { UnifiedPOS.FiscalPrinter.FiscalData.NumberOfResetBlocks, Microsoft.PointOfService.FiscalData.NumberOfResetBlocks },
                { UnifiedPOS.FiscalPrinter.FiscalData.NumberOfVatBlocks, Microsoft.PointOfService.FiscalData.NumberOfVatBlocks },
                { UnifiedPOS.FiscalPrinter.FiscalData.NumberOfVoidedReceipts, Microsoft.PointOfService.FiscalData.NumberOfVoidedReceipts },
                { UnifiedPOS.FiscalPrinter.FiscalData.PrinterId, Microsoft.PointOfService.FiscalData.PrinterId },
                { UnifiedPOS.FiscalPrinter.FiscalData.ReceiptNumber, Microsoft.PointOfService.FiscalData.ReceiptNumber },
                { UnifiedPOS.FiscalPrinter.FiscalData.Refund, Microsoft.PointOfService.FiscalData.Refund },
                { UnifiedPOS.FiscalPrinter.FiscalData.RefundVoid, Microsoft.PointOfService.FiscalData.RefundVoid },
                { UnifiedPOS.FiscalPrinter.FiscalData.Restart, Microsoft.PointOfService.FiscalData.Restart },
                { UnifiedPOS.FiscalPrinter.FiscalData.SimplifiedInvoice, Microsoft.PointOfService.FiscalData.SimplifiedInvoice },
                { UnifiedPOS.FiscalPrinter.FiscalData.Tender, Microsoft.PointOfService.FiscalData.Tender },
                { UnifiedPOS.FiscalPrinter.FiscalData.ZReport, Microsoft.PointOfService.FiscalData.ZReport },

                { Microsoft.PointOfService.FiscalTotalizer.Discount, UnifiedPOS.FiscalPrinter.FiscalTotalizer.Discount },
                { Microsoft.PointOfService.FiscalTotalizer.DiscountVoid, UnifiedPOS.FiscalPrinter.FiscalTotalizer.DiscountVoid },
                { Microsoft.PointOfService.FiscalTotalizer.Gross, UnifiedPOS.FiscalPrinter.FiscalTotalizer.Gross },
                { Microsoft.PointOfService.FiscalTotalizer.Item, UnifiedPOS.FiscalPrinter.FiscalTotalizer.Item },
                { Microsoft.PointOfService.FiscalTotalizer.ItemVoid, UnifiedPOS.FiscalPrinter.FiscalTotalizer.ItemVoid },
                { Microsoft.PointOfService.FiscalTotalizer.Net, UnifiedPOS.FiscalPrinter.FiscalTotalizer.Net },
                { Microsoft.PointOfService.FiscalTotalizer.NotPaid, UnifiedPOS.FiscalPrinter.FiscalTotalizer.NotPaid },
                { Microsoft.PointOfService.FiscalTotalizer.Refund, UnifiedPOS.FiscalPrinter.FiscalTotalizer.Refund },
                { Microsoft.PointOfService.FiscalTotalizer.RefundVoid, UnifiedPOS.FiscalPrinter.FiscalTotalizer.RefundVoid },
                { Microsoft.PointOfService.FiscalTotalizer.SubtotalDiscount, UnifiedPOS.FiscalPrinter.FiscalTotalizer.SubtotalDiscount },
                { Microsoft.PointOfService.FiscalTotalizer.SubtotalDiscountVoid, UnifiedPOS.FiscalPrinter.FiscalTotalizer.SubtotalDiscountVoid },
                { Microsoft.PointOfService.FiscalTotalizer.SubtotalSurcharges, UnifiedPOS.FiscalPrinter.FiscalTotalizer.SubtotalSurcharges },
                { Microsoft.PointOfService.FiscalTotalizer.SubtotalSurchargesVoid, UnifiedPOS.FiscalPrinter.FiscalTotalizer.SubtotalSurchargesVoid },
                { Microsoft.PointOfService.FiscalTotalizer.Surcharge, UnifiedPOS.FiscalPrinter.FiscalTotalizer.Surcharge },
                { Microsoft.PointOfService.FiscalTotalizer.SurchargeVoid, UnifiedPOS.FiscalPrinter.FiscalTotalizer.SurchargeVoid },
                { Microsoft.PointOfService.FiscalTotalizer.Vat, UnifiedPOS.FiscalPrinter.FiscalTotalizer.Vat },
                { Microsoft.PointOfService.FiscalTotalizer.VatCategory, UnifiedPOS.FiscalPrinter.FiscalTotalizer.VatCategory },
                { UnifiedPOS.FiscalPrinter.FiscalTotalizer.Discount, Microsoft.PointOfService.FiscalTotalizer.Discount },
                { UnifiedPOS.FiscalPrinter.FiscalTotalizer.DiscountVoid, Microsoft.PointOfService.FiscalTotalizer.DiscountVoid },
                { UnifiedPOS.FiscalPrinter.FiscalTotalizer.Gross, Microsoft.PointOfService.FiscalTotalizer.Gross },
                { UnifiedPOS.FiscalPrinter.FiscalTotalizer.Item, Microsoft.PointOfService.FiscalTotalizer.Item },
                { UnifiedPOS.FiscalPrinter.FiscalTotalizer.ItemVoid, Microsoft.PointOfService.FiscalTotalizer.ItemVoid },
                { UnifiedPOS.FiscalPrinter.FiscalTotalizer.Net, Microsoft.PointOfService.FiscalTotalizer.Net },
                { UnifiedPOS.FiscalPrinter.FiscalTotalizer.NotPaid, Microsoft.PointOfService.FiscalTotalizer.NotPaid },
                { UnifiedPOS.FiscalPrinter.FiscalTotalizer.Refund, Microsoft.PointOfService.FiscalTotalizer.Refund },
                { UnifiedPOS.FiscalPrinter.FiscalTotalizer.RefundVoid, Microsoft.PointOfService.FiscalTotalizer.RefundVoid },
                { UnifiedPOS.FiscalPrinter.FiscalTotalizer.SubtotalDiscount, Microsoft.PointOfService.FiscalTotalizer.SubtotalDiscount },
                { UnifiedPOS.FiscalPrinter.FiscalTotalizer.SubtotalDiscountVoid, Microsoft.PointOfService.FiscalTotalizer.SubtotalDiscountVoid },
                { UnifiedPOS.FiscalPrinter.FiscalTotalizer.SubtotalSurcharges, Microsoft.PointOfService.FiscalTotalizer.SubtotalSurcharges },
                { UnifiedPOS.FiscalPrinter.FiscalTotalizer.SubtotalSurchargesVoid, Microsoft.PointOfService.FiscalTotalizer.SubtotalSurchargesVoid },
                { UnifiedPOS.FiscalPrinter.FiscalTotalizer.Surcharge, Microsoft.PointOfService.FiscalTotalizer.Surcharge },
                { UnifiedPOS.FiscalPrinter.FiscalTotalizer.SurchargeVoid, Microsoft.PointOfService.FiscalTotalizer.SurchargeVoid },
                { UnifiedPOS.FiscalPrinter.FiscalTotalizer.Vat, Microsoft.PointOfService.FiscalTotalizer.Vat },
                { UnifiedPOS.FiscalPrinter.FiscalTotalizer.VatCategory, Microsoft.PointOfService.FiscalTotalizer.VatCategory },
            };

        private static Dictionary<Enum, Enum> EventConvert = new Dictionary<Enum, Enum>()
            {
                { Microsoft.PointOfService.ErrorCode.Busy, UnifiedPOS.FiscalPrinterEvents.ErrorCode.Busy },
                { Microsoft.PointOfService.ErrorCode.Claimed, UnifiedPOS.FiscalPrinterEvents.ErrorCode.Claimed },
                { Microsoft.PointOfService.ErrorCode.Closed, UnifiedPOS.FiscalPrinterEvents.ErrorCode.Closed },
                { Microsoft.PointOfService.ErrorCode.Deprecated, UnifiedPOS.FiscalPrinterEvents.ErrorCode.Deprecated },
                { Microsoft.PointOfService.ErrorCode.Disabled, UnifiedPOS.FiscalPrinterEvents.ErrorCode.Disabled },
                { Microsoft.PointOfService.ErrorCode.Exists, UnifiedPOS.FiscalPrinterEvents.ErrorCode.Exists },
                { Microsoft.PointOfService.ErrorCode.Extended, UnifiedPOS.FiscalPrinterEvents.ErrorCode.Extended },
                { Microsoft.PointOfService.ErrorCode.Failure, UnifiedPOS.FiscalPrinterEvents.ErrorCode.Failure },
                { Microsoft.PointOfService.ErrorCode.Illegal, UnifiedPOS.FiscalPrinterEvents.ErrorCode.Illegal },
                { Microsoft.PointOfService.ErrorCode.NoExist, UnifiedPOS.FiscalPrinterEvents.ErrorCode.NoExist },
                { Microsoft.PointOfService.ErrorCode.NoHardware, UnifiedPOS.FiscalPrinterEvents.ErrorCode.NoHardware },
                { Microsoft.PointOfService.ErrorCode.NoService, UnifiedPOS.FiscalPrinterEvents.ErrorCode.NoService },
                { Microsoft.PointOfService.ErrorCode.NotClaimed, UnifiedPOS.FiscalPrinterEvents.ErrorCode.NotClaimed },
                { Microsoft.PointOfService.ErrorCode.Offline, UnifiedPOS.FiscalPrinterEvents.ErrorCode.Offline },
                { Microsoft.PointOfService.ErrorCode.Success, UnifiedPOS.FiscalPrinterEvents.ErrorCode.Success },
                { Microsoft.PointOfService.ErrorCode.Timeout, UnifiedPOS.FiscalPrinterEvents.ErrorCode.Timeout },
                { UnifiedPOS.FiscalPrinterEvents.ErrorCode.Busy, Microsoft.PointOfService.ErrorCode.Busy },
                { UnifiedPOS.FiscalPrinterEvents.ErrorCode.Claimed, Microsoft.PointOfService.ErrorCode.Claimed },
                { UnifiedPOS.FiscalPrinterEvents.ErrorCode.Closed, Microsoft.PointOfService.ErrorCode.Closed },
                { UnifiedPOS.FiscalPrinterEvents.ErrorCode.Deprecated, Microsoft.PointOfService.ErrorCode.Deprecated },
                { UnifiedPOS.FiscalPrinterEvents.ErrorCode.Disabled, Microsoft.PointOfService.ErrorCode.Disabled },
                { UnifiedPOS.FiscalPrinterEvents.ErrorCode.Exists, Microsoft.PointOfService.ErrorCode.Exists },
                { UnifiedPOS.FiscalPrinterEvents.ErrorCode.Extended, Microsoft.PointOfService.ErrorCode.Extended },
                { UnifiedPOS.FiscalPrinterEvents.ErrorCode.Failure, Microsoft.PointOfService.ErrorCode.Failure },
                { UnifiedPOS.FiscalPrinterEvents.ErrorCode.Illegal, Microsoft.PointOfService.ErrorCode.Illegal },
                { UnifiedPOS.FiscalPrinterEvents.ErrorCode.NoExist, Microsoft.PointOfService.ErrorCode.NoExist },
                { UnifiedPOS.FiscalPrinterEvents.ErrorCode.NoHardware, Microsoft.PointOfService.ErrorCode.NoHardware },
                { UnifiedPOS.FiscalPrinterEvents.ErrorCode.NoService, Microsoft.PointOfService.ErrorCode.NoService },
                { UnifiedPOS.FiscalPrinterEvents.ErrorCode.NotClaimed, Microsoft.PointOfService.ErrorCode.NotClaimed },
                { UnifiedPOS.FiscalPrinterEvents.ErrorCode.Offline, Microsoft.PointOfService.ErrorCode.Offline },
                { UnifiedPOS.FiscalPrinterEvents.ErrorCode.Success, Microsoft.PointOfService.ErrorCode.Success },
                { UnifiedPOS.FiscalPrinterEvents.ErrorCode.Timeout, Microsoft.PointOfService.ErrorCode.Timeout },

                { Microsoft.PointOfService.ErrorLocus.Input, UnifiedPOS.FiscalPrinterEvents.ErrorLocus.Input },
                { Microsoft.PointOfService.ErrorLocus.InputData, UnifiedPOS.FiscalPrinterEvents.ErrorLocus.InputData },
                { Microsoft.PointOfService.ErrorLocus.Output, UnifiedPOS.FiscalPrinterEvents.ErrorLocus.Output },
                { UnifiedPOS.FiscalPrinterEvents.ErrorLocus.Input, Microsoft.PointOfService.ErrorLocus.Input },
                { UnifiedPOS.FiscalPrinterEvents.ErrorLocus.InputData, Microsoft.PointOfService.ErrorLocus.InputData },
                { UnifiedPOS.FiscalPrinterEvents.ErrorLocus.Output, Microsoft.PointOfService.ErrorLocus.Output },

                { Microsoft.PointOfService.ErrorResponse.Clear, UnifiedPOS.FiscalPrinterEvents.ErrorResponse.Clear },
                { Microsoft.PointOfService.ErrorResponse.ContinueInput, UnifiedPOS.FiscalPrinterEvents.ErrorResponse.ContinueInput },
                { Microsoft.PointOfService.ErrorResponse.Retry, UnifiedPOS.FiscalPrinterEvents.ErrorResponse.Retry },
                { UnifiedPOS.FiscalPrinterEvents.ErrorResponse.Clear, Microsoft.PointOfService.ErrorResponse.Clear },
                { UnifiedPOS.FiscalPrinterEvents.ErrorResponse.ContinueInput, Microsoft.PointOfService.ErrorResponse.ContinueInput },
                { UnifiedPOS.FiscalPrinterEvents.ErrorResponse.Retry, Microsoft.PointOfService.ErrorResponse.Retry },
            };

        #endregion

        private string deviceControlDescription = "";
        private UposVersion deviceControlVersion = new UposVersion() { Major = 1, Minor = 13, Build = 1 };
        private UnifiedPOS.FiscalPrinterEvents.FiscalPrinterEvent deviceEvent;
        private Microsoft.PointOfService.FiscalPrinter device;
        private Regex pattern = new Regex("\\\\u([0-9a-fA-F]{4})|(\\\\\\\\)|(\\\\n)|(\\\\r)|(\\\\t)|(\\\\f)|(\\\\b)", RegexOptions.Compiled);

        private string ProcessEscapeSequence(string data)
        {
            Match m = pattern.Match(data);
            StringBuilder s = new StringBuilder();
            int start = 0;
            while (m.Success)
            {
                s.Append(data.Substring(start, m.Index - start));
                if (m.Groups[1].Length > 0)
                {
                    s.Append(System.Convert.ToChar(System.Convert.ToInt32(m.Groups[1].Value, 16)));
                }
                else if (m.Groups[2].Length > 0)
                {
                    s.Append("\\");
                }
                else if (m.Groups[3].Length > 0)
                {
                    s.Append("\n");
                }
                else if (m.Groups[4].Length > 0)
                {
                    s.Append("\r");
                }
                else if (m.Groups[5].Length > 0)
                {
                    s.Append("\t");
                }
                else if (m.Groups[6].Length > 0)
                {
                    s.Append("\f");
                }
                else if (m.Groups[7].Length > 0)
                {
                    s.Append("\b");
                }
                start = m.Index + m.Length;
                m = m.NextMatch();
            }
            s.Append(data.Substring(start));
            return s.ToString();
        }

        #region Constructor

        public FiscalPrinterService()
        {
            try
            {
                Microsoft.PointOfService.PosExplorer posExplorer = new Microsoft.PointOfService.PosExplorer();
                Microsoft.PointOfService.DeviceCollection deviceCollection = posExplorer.GetDevices("FiscalPrinter");
                if (deviceCollection.Count > 0)
                {
                    device = (Microsoft.PointOfService.FiscalPrinter)posExplorer.CreateInstance(deviceCollection[0]);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        #endregion

        #region FiscalPrinter Member

        public bool GetCapCompareFirmwareVersion()
        {
            //throw new NotImplementedException();
            return device.CapCompareFirmwareVersion;
        }

        public PowerReporting GetCapPowerReporting()
        {
            //throw new NotImplementedException();
            return (PowerReporting)Convert[device.CapPowerReporting];
        }

        public bool GetCapStatisticsReporting()
        {
            //throw new NotImplementedException();
            return device.CapStatisticsReporting;
        }

        public bool GetCapUpdateFirmware()
        {
            //throw new NotImplementedException();
            return device.CapUpdateFirmware;
        }

        public bool GetCapUpdateStatistics()
        {
            //throw new NotImplementedException();
            return device.CapUpdateStatistics;
        }

        public string GetCheckHealthText()
        {
            //throw new NotImplementedException();
            return device.CheckHealthText;
        }

        public bool GetClaimed()
        {
            //throw new NotImplementedException();
            return device.Claimed;
        }

        public bool GetDeviceEnabled()
        {
            //throw new NotImplementedException();
            return device.DeviceEnabled;
        }

        public void SetDeviceEnabled(bool DeviceEnabled)
        {
            //throw new NotImplementedException();
            device.DeviceEnabled = DeviceEnabled;
        }

        public bool GetFreezeEvents()
        {
            //throw new NotImplementedException();
            return device.FreezeEvents;
        }

        public void SetFreezeEvents(bool FreezeEvents)
        {
            //throw new NotImplementedException();
            device.FreezeEvents = FreezeEvents;
        }

        public int GetOutputID()
        {
            //throw new NotImplementedException();
            return device.OutputId;
        }

        public PowerNotification GetPowerNotify()
        {
            //throw new NotImplementedException();
            return (PowerNotification)Convert[device.PowerNotify];
        }

        public void SetPowerNotify(PowerNotification PowerNotify)
        {
            //throw new NotImplementedException();
            device.PowerNotify = (Microsoft.PointOfService.PowerNotification)Convert[PowerNotify];
        }

        public PowerState GetPowerState()
        {
            //throw new NotImplementedException();
            return (PowerState)Convert[device.PowerState];
        }

        public ControlState GetState()
        {
            //throw new NotImplementedException();
            return (ControlState)Convert[device.State];
        }

        public string GetDeviceControlDescription()
        {
            //throw new NotImplementedException();
            return deviceControlDescription;
        }

        public UposVersion GetDeviceControlVersion()
        {
            //throw new NotImplementedException();
            return deviceControlVersion;
        }

        public string GetDeviceServiceDescription()
        {
            //throw new NotImplementedException();
            return device.ServiceObjectDescription;
        }

        public UposVersion GetDeviceServiceVersion()
        {
            //throw new NotImplementedException();
            Version value = device.ServiceObjectVersion;
            return new UposVersion() { Build = value.Build, Major = value.Major, Minor = value.Minor };
        }

        public string GetPhysicalDeviceDescription()
        {
            //throw new NotImplementedException();
            return device.DeviceDescription;
        }

        public string GetPhysicalDeviceName()
        {
            //throw new NotImplementedException();
            return device.DeviceName;
        }

        public bool GetCapAdditionalHeader()
        {
            //throw new NotImplementedException();
            return device.CapAdditionalHeader;
        }

        public bool GetCapAdditionalLines()
        {
            //throw new NotImplementedException();
            return device.CapAdditionalLines;
        }

        public bool GetCapAdditionalTrailer()
        {
            //throw new NotImplementedException();
            return device.CapAdditionalTrailer;
        }

        public bool GetCapAmountAdjustment()
        {
            //throw new NotImplementedException();
            return device.CapAmountAdjustment;
        }

        public bool GetCapChangeDue()
        {
            //throw new NotImplementedException();
            return device.CapChangeDue;
        }

        public bool GetCapCheckTotal()
        {
            //throw new NotImplementedException();
            return device.CapCheckTotal;
        }

        public bool GetCapCoverSensor()
        {
            //throw new NotImplementedException();
            return device.CapCoverSensor;
        }

        public bool GetCapDoubleWidth()
        {
            //throw new NotImplementedException();
            return device.CapDoubleWidth;
        }

        public bool GetCapDuplicateReceipt()
        {
            //throw new NotImplementedException();
            return device.CapDuplicateReceipt;
        }

        public bool GetCapEmptyReceiptIsVoidable()
        {
            //throw new NotImplementedException();
            return device.CapEmptyReceiptIsVoidable;
        }

        public bool GetCapFiscalReceiptStation()
        {
            //throw new NotImplementedException();
            return device.CapFiscalReceiptStation;
        }

        public bool GetCapFiscalReceiptType()
        {
            //throw new NotImplementedException();
            return device.CapFiscalReceiptType;
        }

        public bool GetCapFixedOutput()
        {
            //throw new NotImplementedException();
            return device.CapFixedOutput;
        }

        public bool GetCapHasVatTable()
        {
            //throw new NotImplementedException();
            return device.CapHasVatTable;
        }

        public bool GetCapIndependentHeader()
        {
            //throw new NotImplementedException();
            return device.CapIndependentHeader;
        }

        public bool GetCapItemList()
        {
            //throw new NotImplementedException();
            return device.CapItemList;
        }

        public bool GetCapJrnEmptySensor()
        {
            //throw new NotImplementedException();
            return device.CapJrnEmptySensor;
        }

        public bool GetCapJrnNearEndSensor()
        {
            //throw new NotImplementedException();
            return device.CapJrnNearEndSensor;
        }

        public bool GetCapJrnPresent()
        {
            //throw new NotImplementedException();
            return device.CapJrnPresent;
        }

        public bool GetCapMultiContractor()
        {
            //throw new NotImplementedException();
            return device.CapMultiContractor;
        }

        public bool GetCapNonFiscalMode()
        {
            //throw new NotImplementedException();
            return device.CapNonFiscalMode;
        }

        public bool GetCapOnlyVoidLastItem()
        {
            //throw new NotImplementedException();
            return device.CapOnlyVoidLastItem;
        }

        public bool GetCapOrderAdjustmentFirst()
        {
            //throw new NotImplementedException();
            return device.CapOrderAdjustmentFirst;
        }

        public bool GetCapPackageAdjustment()
        {
            //throw new NotImplementedException();
            return device.CapPackageAdjustment;
        }

        public bool GetCapPercentAdjustment()
        {
            //throw new NotImplementedException();
            return device.CapPercentAdjustment;
        }

        public bool GetCapPositiveAdjustment()
        {
            //throw new NotImplementedException();
            return device.CapPositiveAdjustment;
        }

        public bool GetCapPositiveSubtotalAdjustment()
        {
            //throw new NotImplementedException();
            return device.CapPositiveSubtotalAdjustment;
        }

        public bool GetCapPostPreLine()
        {
            //throw new NotImplementedException();
            return device.CapPostPreLine;
        }

        public bool GetCapPowerLossReport()
        {
            //throw new NotImplementedException();
            return device.CapPowerLossReport;
        }

        public bool GetCapPredefinedPaymentLines()
        {
            //throw new NotImplementedException();
            return device.CapPredefinedPaymentLines;
        }

        public bool GetCapReceiptNotPaid()
        {
            //throw new NotImplementedException();
            return device.CapReceiptNotPaid;
        }

        public bool GetCapRecEmptySensor()
        {
            //throw new NotImplementedException();
            return device.CapRecEmptySensor;
        }

        public bool GetCapRecNearEndSensor()
        {
            //throw new NotImplementedException();
            return device.CapRecNearEndSensor;
        }

        public bool GetCapRecPresent()
        {
            //throw new NotImplementedException();
            return device.CapRecPresent;
        }

        public bool GetCapRemainingFiscalMemory()
        {
            //throw new NotImplementedException();
            return device.CapRemainingFiscalMemory;
        }

        public bool GetCapReservedWord()
        {
            //throw new NotImplementedException();
            return device.CapReservedWord;
        }

        public bool GetCapSetCurrency()
        {
            //throw new NotImplementedException();
            return device.CapSetCurrency;
        }

        public bool GetCapSetHeader()
        {
            //throw new NotImplementedException();
            return device.CapSetHeader;
        }

        public bool GetCapSetPOSID()
        {
            //throw new NotImplementedException();
            return device.CapSetPosId;
        }

        public bool GetCapSetStoreFiscalID()
        {
            //throw new NotImplementedException();
            return device.CapSetStoreFiscalId;
        }

        public bool GetCapSetTrailer()
        {
            //throw new NotImplementedException();
            return device.CapSetTrailer;
        }

        public bool GetCapSetVatTable()
        {
            //throw new NotImplementedException();
            return device.CapSetVatTable;
        }

        public bool GetCapSlpEmptySensor()
        {
            //throw new NotImplementedException();
            return device.CapSlpEmptySensor;
        }

        public bool GetCapSlpFiscalDocument()
        {
            //throw new NotImplementedException();
            return device.CapSlpFiscalDocument;
        }

        public bool GetCapSlpFullSlip()
        {
            //throw new NotImplementedException();
            return device.CapSlpFullSlip;
        }

        public bool GetCapSlpNearEndSensor()
        {
            //throw new NotImplementedException();
            return device.CapSlpNearEndSensor;
        }

        public bool GetCapSlpPresent()
        {
            //throw new NotImplementedException();
            return device.CapSlpPresent;
        }

        public bool GetCapSlpValidation()
        {
            //throw new NotImplementedException();
            return device.CapSlpValidation;
        }

        public bool GetCapSubAmountAdjustment()
        {
            //throw new NotImplementedException();
            return device.CapSubAmountAdjustment;
        }

        public bool GetCapSubPercentAdjustment()
        {
            //throw new NotImplementedException();
            return device.CapSubPercentAdjustment;
        }

        public bool GetCapSubtotal()
        {
            //throw new NotImplementedException();
            return device.CapSubtotal;
        }

        public bool GetCapTotalizerType()
        {
            //throw new NotImplementedException();
            return device.CapTotalizerType;
        }

        public bool GetCapTrainingMode()
        {
            //throw new NotImplementedException();
            return device.CapTrainingMode;
        }

        public bool GetCapValidateJournal()
        {
            //throw new NotImplementedException();
            return device.CapValidateJournal;
        }

        public bool GetCapXReport()
        {
            //throw new NotImplementedException();
            return device.CapXReport;
        }

        public FiscalCurrency GetActualCurrency()
        {
            //throw new NotImplementedException();
            return (FiscalCurrency)Convert[device.ActualCurrency];
        }

        public string GetAdditionalHeader()
        {
            //throw new NotImplementedException();
            return device.AdditionalHeader;
        }

        public void SetAdditionalHeader(string AdditionalHeader)
        {
            //throw new NotImplementedException();
            device.AdditionalHeader = AdditionalHeader;
        }

        public string GetAdditionalTrailer()
        {
            //throw new NotImplementedException();
            return device.AdditionalTrailer;
        }

        public void SetAdditionalTrailer(string AdditionalTrailer)
        {
            //throw new NotImplementedException();
            device.AdditionalTrailer = AdditionalTrailer;
        }

        public int GetAmountDecimalPlaces()
        {
            //throw new NotImplementedException();
            return device.AmountDecimalPlaces;
        }

        public bool GetAsyncMode()
        {
            //throw new NotImplementedException();
            return device.AsyncMode;
        }

        public void SetAsyncMode(bool AsyncMode)
        {
            //throw new NotImplementedException();
            device.AsyncMode = AsyncMode;
        }

        public string GetChangeDue()
        {
            //throw new NotImplementedException();
            return device.ChangeDue;
        }

        public void SetChangeDue(string ChangeDue)
        {
            //throw new NotImplementedException();
            device.ChangeDue = ChangeDue;
        }

        public bool GetCheckTotal()
        {
            //throw new NotImplementedException();
            return device.CheckTotal;
        }

        public void SetCheckTotal(bool CheckTotal)
        {
            //throw new NotImplementedException();
            device.CheckTotal = CheckTotal;
        }

        public FiscalContractorID GetContractorID()
        {
            //throw new NotImplementedException();
            return (FiscalContractorID)Convert[device.ContractorId];
        }

        public void SetContractorID(FiscalContractorID ContractorID)
        {
            //throw new NotImplementedException();
            device.ContractorId = (Microsoft.PointOfService.FiscalContractorId)Convert[ContractorID];
        }

        public int GetCountryCode()
        {
            //throw new NotImplementedException();
            return (int)device.CountryCode;
        }

        public bool GetCoverOpen()
        {
            //throw new NotImplementedException();
            return device.CoverOpen;
        }

        public FiscalDateType GetDateType()
        {
            //throw new NotImplementedException();
            return (FiscalDateType)Convert[device.DateType];
        }

        public void SetDateType(FiscalDateType DateType)
        {
            //throw new NotImplementedException();
            device.DateType = (Microsoft.PointOfService.FiscalDateType)Convert[DateType];
        }

        public bool GetDayOpened()
        {
            //throw new NotImplementedException();
            return device.DayOpened;
        }

        public int GetDescriptionLength()
        {
            //throw new NotImplementedException();
            return device.DescriptionLength;
        }

        public bool GetDuplicateReceipt()
        {
            //throw new NotImplementedException();
            return device.DuplicateReceipt;
        }

        public void SetDuplicateReceipt(bool DuplicateReceipt)
        {
            //throw new NotImplementedException();
            device.DuplicateReceipt = DuplicateReceipt;
        }

        public FiscalErrorLevel GetErrorLevel()
        {
            //throw new NotImplementedException();
            return (FiscalErrorLevel)Convert[device.ErrorLevel];
        }

        public int GetErrorOutID()
        {
            //throw new NotImplementedException();
            return device.ErrorOutId;
        }

        public FiscalPrinterState GetErrorState()
        {
            //throw new NotImplementedException();
            return (FiscalPrinterState)Convert[device.ErrorState];
        }

        public FiscalPrinterStations GetErrorStation()
        {
            //throw new NotImplementedException();
            return (FiscalPrinterStations)Convert[device.ErrorStation];
        }

        public string GetErrorString()
        {
            //throw new NotImplementedException();
            return device.ErrorString;
        }

        public FiscalReceiptStation GetFiscalReceiptStation()
        {
            //throw new NotImplementedException();
            return (FiscalReceiptStation)Convert[device.FiscalReceiptStation];
        }

        public void SetFiscalReceiptStation(FiscalReceiptStation FiscalReceiptStation)
        {
            //throw new NotImplementedException();
            device.FiscalReceiptStation = (Microsoft.PointOfService.FiscalReceiptStation)Convert[FiscalReceiptStation];
        }

        public FiscalReceiptType GetFiscalReceiptType()
        {
            //throw new NotImplementedException();
            return (FiscalReceiptType)Convert[device.FiscalReceiptType];
        }

        public void SetFiscalReceiptType(FiscalReceiptType FiscalReceiptType)
        {
            //throw new NotImplementedException();
            device.FiscalReceiptType = (Microsoft.PointOfService.FiscalReceiptType)Convert[FiscalReceiptType];
        }

        public bool GetFlagWhenIdle()
        {
            //throw new NotImplementedException();
            return device.FlagWhenIdle;
        }

        public void SetFlagWhenIdle(bool FlagWhenIdle)
        {
            //throw new NotImplementedException();
            device.FlagWhenIdle = FlagWhenIdle;
        }

        public bool GetJrnEmpty()
        {
            //throw new NotImplementedException();
            return device.JrnEmpty;
        }

        public bool GetJrnNearEnd()
        {
            //throw new NotImplementedException();
            return device.JrnNearEnd;
        }

        public int GetMessageLength()
        {
            //throw new NotImplementedException();
            return device.MessageLength;
        }

        public FiscalMessageType GetMessageType()
        {
            //throw new NotImplementedException();
            return (FiscalMessageType)Convert[device.MessageType];
        }

        public void SetMessageType(FiscalMessageType MessageType)
        {
            //throw new NotImplementedException();
            device.MessageType = (Microsoft.PointOfService.FiscalMessageType)Convert[MessageType];
        }

        public int GetNumHeaderLines()
        {
            //throw new NotImplementedException();
            return device.NumHeaderLines;
        }

        public int GetNumTrailerLines()
        {
            //throw new NotImplementedException();
            return device.NumTrailerLines;
        }

        public int GetNumVatRates()
        {
            //throw new NotImplementedException();
            return device.NumVatRates;
        }

        public string GetPostLine()
        {
            //throw new NotImplementedException();
            return device.PostLine;
        }

        public void SetPostLine(string PostLine)
        {
            //throw new NotImplementedException();
            device.PostLine = PostLine;
        }

        public PaymentLinesList GetPredefinedPaymentLines()
        {
            //throw new NotImplementedException();
            PaymentLinesList res = new PaymentLinesList();
            res.AddRange(device.PredefinedPaymentLines);
            return res;
        }

        public string GetPreLine()
        {
            //throw new NotImplementedException();
            return device.PreLine;
        }

        public void SetPreLine(string PreLine)
        {
            //throw new NotImplementedException();
            device.PreLine = PreLine;
        }

        public FiscalPrinterState GetPrinterState()
        {
            //throw new NotImplementedException();
            return (FiscalPrinterState)Convert[device.PrinterState];
        }

        public int GetQuantityDecimalPlaces()
        {
            //throw new NotImplementedException();
            return device.QuantityDecimalPlaces;
        }

        public int GetQuantityLength()
        {
            //throw new NotImplementedException();
            return device.QuantityLength;
        }

        public bool GetRecEmpty()
        {
            //throw new NotImplementedException();
            return device.RecEmpty;
        }

        public bool GetRecNearEnd()
        {
            //throw new NotImplementedException();
            return device.RecNearEnd;
        }

        public int GetRemainingFiscalMemory()
        {
            //throw new NotImplementedException();
            return device.RemainingFiscalMemory;
        }

        public string GetReservedWord()
        {
            //throw new NotImplementedException();
            return device.ReservedWord;
        }

        public bool GetSlpEmpty()
        {
            //throw new NotImplementedException();
            return device.SlpEmpty;
        }

        public bool GetSlpNearEnd()
        {
            //throw new NotImplementedException();
            return device.SlpNearEnd;
        }

        public FiscalSlipSelection GetSlipSelection()
        {
            //throw new NotImplementedException();
            return (FiscalSlipSelection)Convert[device.SlipSelection];
        }

        public void SetSlipSelection(FiscalSlipSelection SlipSelection)
        {
            //throw new NotImplementedException();
            device.SlipSelection = (Microsoft.PointOfService.FiscalSlipSelection)Convert[SlipSelection];
        }

        public FiscalTotalizerType GetTotalizerType()
        {
            //throw new NotImplementedException();
            return (FiscalTotalizerType)Convert[device.TotalizerType];
        }

        public void SetTotalizerType(FiscalTotalizerType TotalizerType)
        {
            //throw new NotImplementedException();
            device.TotalizerType = (Microsoft.PointOfService.FiscalTotalizerType)Convert[TotalizerType];
        }

        public bool GetTrainingModeActive()
        {
            //throw new NotImplementedException();
            return device.TrainingModeActive;
        }

        public void Open(string EndpointAddress)
        {
            //throw new NotImplementedException();
            device.Open();
            if (EndpointAddress != null)
            {
                ChannelFactory<UnifiedPOS.FiscalPrinterEvents.FiscalPrinterEvent> factory =
                    new ChannelFactory<UnifiedPOS.FiscalPrinterEvents.FiscalPrinterEvent>("FiscalPrinterEventPort", new EndpointAddress(EndpointAddress));
                deviceEvent = factory.CreateChannel();

                device.DirectIOEvent += new Microsoft.PointOfService.DirectIOEventHandler(device_DirectIOEvent);
                device.ErrorEvent += new Microsoft.PointOfService.DeviceErrorEventHandler(device_ErrorEvent);
                device.OutputCompleteEvent += new Microsoft.PointOfService.OutputCompleteEventHandler(device_OutputCompleteEvent);
                device.StatusUpdateEvent += new Microsoft.PointOfService.StatusUpdateEventHandler(device_StatusUpdateEvent);
            }
        }

        public void Close(string EndpointAddress)
        {
            //throw new NotImplementedException();
            device.Close();
            if (deviceEvent != null)
            {
                device.DirectIOEvent -= device_DirectIOEvent;
                device.ErrorEvent -= device_ErrorEvent;
                device.OutputCompleteEvent -= device_OutputCompleteEvent;
                device.StatusUpdateEvent -= device_StatusUpdateEvent;

                ((IClientChannel)deviceEvent).Close();
                deviceEvent = null;
            }
        }

        public void Claim(int Timeout)
        {
            //throw new NotImplementedException();
            device.Claim(Timeout);
        }

        public void Release()
        {
            //throw new NotImplementedException();
            device.Release();
        }

        public void CheckHealth(HealthCheckLevel Level)
        {
            //throw new NotImplementedException();
            device.CheckHealth((Microsoft.PointOfService.HealthCheckLevel)Convert[Level]);
        }

        public void ClearOutput()
        {
            //throw new NotImplementedException();
            device.ClearOutput();
        }

        public DirectIOData DirectIO(int Command, int Data, object Obj)
        {
            //throw new NotImplementedException();
            Microsoft.PointOfService.DirectIOData value = device.DirectIO(Command, Data, Obj);
            return new DirectIOData() { Data = value.Data, Obj = value.Object };
        }

        public CompareFirmwareResult CompareFirmwareVersion(string FirmwareFileName)
        {
            //throw new NotImplementedException();
            return (CompareFirmwareResult)Convert[device.CompareFirmwareVersion(FirmwareFileName)];
        }

        public void ResetStatistics(StatisticList StatisticsBuffer)
        {
            //throw new NotImplementedException();
            var value = from el in StatisticsBuffer select el.Name;
            switch (value.Count())
            {
                case 0:
                    device.ResetStatistics();
                    break;
                case 1:
                    string name = value.First();
                    switch (name)
                    {
                        case StatisticCategories.All:
                            device.ResetStatistics(Microsoft.PointOfService.StatisticCategories.All);
                            break;
                        case StatisticCategories.Manufacturer:
                            device.ResetStatistics(Microsoft.PointOfService.StatisticCategories.Manufacturer);
                            break;
                        case StatisticCategories.Upos:
                            device.ResetStatistics(Microsoft.PointOfService.StatisticCategories.Upos);
                            break;
                        default:
                            device.ResetStatistic(name);
                            break;
                    }
                    break;
                default:
                    device.ResetStatistics(value.ToArray());
                    break;
            }
        }

        public string RetrieveStatistics(StatisticList StatisticsBuffer)
        {
            //throw new NotImplementedException();
            string res = null;
            var value = from el in StatisticsBuffer select el.Name;
            switch (value.Count())
            {
                case 0:
                    res = device.RetrieveStatistics();
                    break;
                case 1:
                    string name = value.First();
                    switch (name)
                    {
                        case StatisticCategories.All:
                            res = device.RetrieveStatistics(Microsoft.PointOfService.StatisticCategories.All);
                            break;
                        case StatisticCategories.Manufacturer:
                            res = device.RetrieveStatistics(Microsoft.PointOfService.StatisticCategories.Manufacturer);
                            break;
                        case StatisticCategories.Upos:
                            res = device.RetrieveStatistics(Microsoft.PointOfService.StatisticCategories.Upos);
                            break;
                        default:
                            res = device.RetrieveStatistic(name);
                            break;
                    }
                    break;
                default:
                    res = device.RetrieveStatistics(value.ToArray());
                    break;
            }
            return res;
        }

        public void UpdateFirmware(string FirmwareFileName)
        {
            //throw new NotImplementedException();
            device.UpdateFirmware(FirmwareFileName);
        }

        public void UpdateStatistics(StatisticList StatisticsBuffer)
        {
            //throw new NotImplementedException();
            var value = from el in StatisticsBuffer select new Microsoft.PointOfService.Statistic(el.Name, el.Value);
            switch (value.Count())
            {
                case 0:
                    device.UpdateStatistics(value.ToArray());
                    break;
                case 1:
                    Microsoft.PointOfService.Statistic statistic = value.First();
                    switch (statistic.Name)
                    {
                        case StatisticCategories.All:
                            device.UpdateStatistics(Microsoft.PointOfService.StatisticCategories.All, statistic.Value);
                            break;
                        case StatisticCategories.Manufacturer:
                            device.UpdateStatistics(Microsoft.PointOfService.StatisticCategories.Manufacturer, statistic.Value);
                            break;
                        case StatisticCategories.Upos:
                            device.UpdateStatistics(Microsoft.PointOfService.StatisticCategories.Upos, statistic.Value);
                            break;
                        default:
                            device.UpdateStatistic(statistic.Name, statistic.Value);
                            break;
                    }
                    break;
                default:
                    device.UpdateStatistics(value.ToArray());
                    break;
            }
        }

        public void SetCurrency(FiscalCurrency NewCurrency)
        {
            //throw new NotImplementedException();
            device.SetCurrency((Microsoft.PointOfService.FiscalCurrency)Convert[NewCurrency]);
        }

        public void SetDate(DateTime Date)
        {
            //throw new NotImplementedException();
            device.SetDate(Date);
        }

        public void SetHeaderLine(int LineNumber, string Text, bool DoubleWidth)
        {
            //throw new NotImplementedException();
            device.SetHeaderLine(LineNumber, Text, DoubleWidth);
        }

        public void SetPOSID(string POSID, string CashierID)
        {
            //throw new NotImplementedException();
            device.SetPosId(POSID, CashierID);
        }

        public void SetStoreFiscalID(string ID)
        {
            //throw new NotImplementedException();
            device.SetStoreFiscalId(ID);
        }

        public void SetTrailerLine(int LineNumber, string Text, bool DoubleWidth)
        {
            //throw new NotImplementedException();
            device.SetTrailerLine(LineNumber, Text, DoubleWidth);
        }

        public void SetVatTable()
        {
            //throw new NotImplementedException();
            device.SetVatTable();
        }

        public void SetVatValue(int VatID, string VatValue)
        {
            //throw new NotImplementedException();
            device.SetVatValue(VatID, VatValue);
        }

        public void BeginFiscalReceipt(bool PrintHeader)
        {
            //throw new NotImplementedException();
            device.BeginFiscalReceipt(PrintHeader);
        }

        public void EndFiscalReceipt(bool PrintHeader)
        {
            //throw new NotImplementedException();
            device.EndFiscalReceipt(PrintHeader);
        }

        public void PrintDuplicateReceipt()
        {
            //throw new NotImplementedException();
            device.PrintDuplicateReceipt();
        }

        public void PrintRecCash(decimal Amount)
        {
            //throw new NotImplementedException();
            device.PrintRecCash(Amount);
        }

        public void PrintRecItem(string Description, decimal Price, int Quantity, int VatInfo, decimal UnitPrice, string UnitName)
        {
            //throw new NotImplementedException();
            device.PrintRecItem(Description, Price, Quantity, VatInfo, UnitPrice, UnitName);
        }

        public void PrintRecItemVoid(string Description, decimal Price, int Quantity, int VatInfo, decimal UnitPrice, string UnitName)
        {
            //throw new NotImplementedException();
            device.PrintRecItemVoid(Description, Price, Quantity, VatInfo, UnitPrice, UnitName);
        }

        public void PrintRecItemAdjustment(FiscalAdjustment AdjustmentType, string Description, decimal Amount, int VatInfo)
        {
            //throw new NotImplementedException();
            device.PrintRecItemAdjustment((Microsoft.PointOfService.FiscalAdjustment)Convert[AdjustmentType], Description, Amount, VatInfo);
        }

        public void PrintRecItemAdjustmentVoid(FiscalAdjustment AdjustmentType, string Description, decimal Amount, int VatInfo)
        {
            //throw new NotImplementedException();
            device.PrintRecItemAdjustmentVoid((Microsoft.PointOfService.FiscalAdjustment)Convert[AdjustmentType], Description, Amount, VatInfo);
        }

        public void PrintRecItemFuel(string Description, decimal Price, int Quantity, int VatInfo, decimal UnitPrice, string UnitName, decimal SpecialTax, string SpecialTaxName)
        {
            //throw new NotImplementedException();
            device.PrintRecItemFuel(Description, Price, Quantity, VatInfo, UnitPrice, UnitName, SpecialTax, SpecialTaxName);
        }

        public void PrintRecItemFuelVoid(string Description, decimal Price, int VatInfo, decimal SpecialTax)
        {
            //throw new NotImplementedException();
            device.PrintRecItemFuelVoid(Description, Price, VatInfo, SpecialTax);
        }

        public void PrintRecItemRefund(string Description, decimal Amount, int Quantity, int VatInfo, decimal UnitAmount, string UnitName)
        {
            //throw new NotImplementedException();
            device.PrintRecItemRefund(Description, Amount, Quantity, VatInfo, UnitAmount, UnitName);
        }

        public void PrintRecItemRefundVoid(string Description, decimal Amount, int Quantity, int VatInfo, decimal UnitAmount, string UnitName)
        {
            //throw new NotImplementedException();
            device.PrintRecItemRefundVoid(Description, Amount, Quantity, VatInfo, UnitAmount, UnitName);
        }

        public void PrintRecMessage(string Message)
        {
            //throw new NotImplementedException();
            device.PrintRecMessage(Message);
        }

        public void PrintRecNotPaid(string Description, decimal Amount)
        {
            //throw new NotImplementedException();
            device.PrintRecNotPaid(Description, Amount);
        }

        public void PrintRecPackageAdjustment(FiscalAdjustmentType AdjustmentType, string Description, VatInfoList VatAdjustments)
        {
            //throw new NotImplementedException();
            device.PrintRecPackageAdjustment((Microsoft.PointOfService.FiscalAdjustmentType)Convert[AdjustmentType], Description, from el in VatAdjustments select new Microsoft.PointOfService.VatInfo(el.ID, el.Amount));
        }

        public void PrintRecPackageAdjustVoid(FiscalAdjustmentType AdjustmentType, VatInfoList VatAdjustments)
        {
            //throw new NotImplementedException();
            device.PrintRecPackageAdjustVoid((Microsoft.PointOfService.FiscalAdjustmentType)Convert[AdjustmentType], from el in VatAdjustments select new Microsoft.PointOfService.VatInfo(el.ID, el.Amount));
        }

        public void PrintRecRefund(string Description, decimal Amount, int VatInfo)
        {
            //throw new NotImplementedException();
            device.PrintRecRefund(Description, Amount, VatInfo);
        }

        public void PrintRecRefundVoid(string Description, decimal Amount, int VatInfo)
        {
            //throw new NotImplementedException();
            device.PrintRecRefundVoid(Description, Amount, VatInfo);
        }

        public void PrintRecSubtotal(decimal Amount)
        {
            //throw new NotImplementedException();
            device.PrintRecSubtotal(Amount);
        }

        public void PrintRecSubtotalAdjustment(FiscalAdjustment AdjustmentType, string Description, decimal Amount)
        {
            //throw new NotImplementedException();
            device.PrintRecSubtotalAdjustment((Microsoft.PointOfService.FiscalAdjustment)Convert[AdjustmentType], Description, Amount);
        }

        public void PrintRecSubtotalAdjustVoid(FiscalAdjustment AdjustmentType, decimal Amount)
        {
            //throw new NotImplementedException();
            device.PrintRecSubtotalAdjustVoid((Microsoft.PointOfService.FiscalAdjustment)Convert[AdjustmentType], Amount);
        }

        public void PrintRecTaxID(string TaxID)
        {
            //throw new NotImplementedException();
            device.PrintRecTaxId(TaxID);
        }

        public void PrintRecTotal(decimal Total, decimal Payment, string Description)
        {
            //throw new NotImplementedException();
            device.PrintRecTotal(Total, Payment, Description);
        }

        public void PrintRecVoid(string Description)
        {
            //throw new NotImplementedException();
            device.PrintRecVoid(Description);
        }

        public void BeginFiscalDocument(int DocumentAmount)
        {
            //throw new NotImplementedException();
            device.BeginFiscalDocument(DocumentAmount);
        }

        public void EndFiscalDocument()
        {
            //throw new NotImplementedException();
            device.EndFiscalDocument();
        }

        public void PrintFiscalDocumentLine(string DocumentLine)
        {
            //throw new NotImplementedException();
            device.PrintFiscalDocumentLine(DocumentLine);
        }

        public void BeginItemList(int VatID)
        {
            //throw new NotImplementedException();
            device.BeginItemList(VatID);
        }

        public void EndItemList()
        {
            //throw new NotImplementedException();
            device.EndItemList();
        }

        public void VerifyItem(string ItemName, int VatID)
        {
            //throw new NotImplementedException();
            device.VerifyItem(ItemName, VatID);
        }

        public void PrintPeriodicTotalsReport(DateTime Date1, DateTime Date2)
        {
            //throw new NotImplementedException();
            device.PrintPeriodicTotalsReport(Date1, Date2);
        }

        public void PrintPowerLossReport()
        {
            //throw new NotImplementedException();
            device.PrintPowerLossReport();
        }

        public void PrintReport(ReportType ReportType, string StartNum, string EndNum)
        {
            //throw new NotImplementedException();
            device.PrintReport((Microsoft.PointOfService.ReportType)Convert[ReportType], StartNum, EndNum);
        }

        public void PrintXReport()
        {
            //throw new NotImplementedException();
            device.PrintXReport();
        }

        public void PrintZReport()
        {
            //throw new NotImplementedException();
            device.PrintZReport();
        }

        public void BeginInsertion(int Timeout)
        {
            //throw new NotImplementedException();
            device.BeginInsertion(Timeout);
        }

        public void BeginRemoval(int Timeout)
        {
            //throw new NotImplementedException();
            device.BeginRemoval(Timeout);
        }

        public void EndInsertion()
        {
            //throw new NotImplementedException();
            device.EndInsertion();
        }

        public void EndRemoval()
        {
            //throw new NotImplementedException();
            device.EndRemoval();
        }

        public void BeginFixedOutput(FiscalReceiptStation Station, int DocumentType)
        {
            //throw new NotImplementedException();
            device.BeginFixedOutput((Microsoft.PointOfService.FiscalReceiptStation)Convert[Station], DocumentType);
        }

        public void BeginNonFiscal()
        {
            //throw new NotImplementedException();
            device.BeginNonFiscal();
        }

        public void BeginTraining()
        {
            //throw new NotImplementedException();
            device.BeginTraining();
        }

        public void EndFixedOutput()
        {
            //throw new NotImplementedException();
            device.EndFixedOutput();
        }

        public void EndNonFiscal()
        {
            //throw new NotImplementedException();
            device.EndNonFiscal();
        }

        public void EndTraining()
        {
            //throw new NotImplementedException();
            device.EndTraining();
        }

        public void PrintFixedOutput(int DocumentType, int LineNumber, string Data)
        {
            //throw new NotImplementedException();
            device.PrintFixedOutput(DocumentType, LineNumber, Data);
        }

        public void PrintNormal(FiscalPrinterStations Station, string Data)
        {
            //throw new NotImplementedException();
            device.PrintNormal((Microsoft.PointOfService.FiscalPrinterStations)Convert[Station], ProcessEscapeSequence(Data));
        }

        public FiscalDataItem GetData(FiscalData DataItem, int OptArgs)
        {
            //throw new NotImplementedException();
            Microsoft.PointOfService.FiscalDataItem value = device.GetData((Microsoft.PointOfService.FiscalData)DataItem, OptArgs);
            return new FiscalDataItem() { Data = value.Data, ItemOption = value.ItemOption };
        }

        public DateTime GetDate()
        {
            //throw new NotImplementedException();
            return device.GetDate();
        }

        public string GetTotalizer(int VatID, FiscalTotalizer OptArgs)
        {
            //throw new NotImplementedException();
            return device.GetTotalizer(VatID, (Microsoft.PointOfService.FiscalTotalizer)Convert[OptArgs]);
        }

        public int GetVatEntry(int VatID, int OptArgs)
        {
            //throw new NotImplementedException();
            return device.GetVatEntry(VatID, OptArgs);
        }

        public void ClearError()
        {
            //throw new NotImplementedException();
            device.ClearError();
        }

        public void ResetPrinter()
        {
            //throw new NotImplementedException();
            device.ResetPrinter();
        }

        #endregion

        #region FiscalPrinterEvent Member

        private void device_DirectIOEvent(object sender, Microsoft.PointOfService.DirectIOEventArgs e)
        {
            //throw new NotImplementedException();
            if (deviceEvent != null)
            {
                UnifiedPOS.FiscalPrinterEvents.DirectIOData value = deviceEvent.DirectIOEvent(sender.ToString(), e.EventId, e.TimeStamp, e.EventNumber, e.Data, e.Object);
                e.Data = value.Data;
                e.Object = value.Obj;
            }
        }

        private void device_ErrorEvent(object sender, Microsoft.PointOfService.DeviceErrorEventArgs e)
        {
            //throw new NotImplementedException();
            if (deviceEvent != null)
            {
                UnifiedPOS.FiscalPrinterEvents.ErrorResponse value = deviceEvent.ErrorEvent(sender.ToString(), e.EventId, e.TimeStamp, (UnifiedPOS.FiscalPrinterEvents.ErrorCode)EventConvert[e.ErrorCode], e.ErrorCodeExtended, (UnifiedPOS.FiscalPrinterEvents.ErrorLocus)EventConvert[e.ErrorLocus], (UnifiedPOS.FiscalPrinterEvents.ErrorResponse)EventConvert[e.ErrorResponse]);
                e.ErrorResponse = (Microsoft.PointOfService.ErrorResponse)EventConvert[value];
            }
        }

        private void device_OutputCompleteEvent(object sender, Microsoft.PointOfService.OutputCompleteEventArgs e)
        {
            //throw new NotImplementedException();
            if (deviceEvent != null)
            {
                deviceEvent.OutputCompleteEvent(sender.ToString(), e.EventId, e.TimeStamp, e.OutputId);
            }
        }

        private void device_StatusUpdateEvent(object sender, Microsoft.PointOfService.StatusUpdateEventArgs e)
        {
            //throw new NotImplementedException();
            if (deviceEvent != null)
            {
                deviceEvent.StatusUpdateEvent(sender.ToString(), e.EventId, e.TimeStamp, e.Status);
            }
        }

        #endregion

        #region IDisposable Member

        public void Dispose()
        {
            //throw new NotImplementedException();
            if (device != null)
            {
                try
                {
                    device.Close();
                }
                catch
                {
                }
                finally
                {
                    device = null;
                }
            }
            if (deviceEvent != null)
            {
                try
                {
                    ((IClientChannel)deviceEvent).Close();
                }
                catch
                {
                }
                finally
                {
                    deviceEvent = null;
                }
            }
        }

        #endregion

    }
}
