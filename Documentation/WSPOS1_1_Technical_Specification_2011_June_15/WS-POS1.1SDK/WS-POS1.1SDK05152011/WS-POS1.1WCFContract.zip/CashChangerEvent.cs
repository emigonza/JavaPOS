﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace UnifiedPOS.CashChangerEvents
{
    [ServiceContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CashChangerEvents/")]
    public interface CashChangerEvent
    {

        //
        // Events
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChangerEvents/DataEvent", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChangerEvents/DataEventResponse")]
        void DataEvent(string Source, int EventID, DateTime TimeStamp, int Status);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChangerEvents/DirectIOEvent", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChangerEvents/DirectIOEventResponse")]
        DirectIOData DirectIOEvent(string Source, int EventID, DateTime TimeStamp, int EventNumber, int Data, object Obj);

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChangerEvents/ErrorEvent", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChangerEvents/ErrorEventResponse")]
        // ErrorResponse ErrorEvent(string Source, int EventID, DateTime TimeStamp, ErrorCode ErrorCode, int ErrorCodeExtended, ErrorLocus ErrorLocus, ErrorResponse ErrorResponse);

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChangerEvents/OutputCompleteEvent", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChangerEvents/OutputCompleteEventResponse")]
        // void OutputCompleteEvent(string Source, int EventID, DateTime TimeStamp, int OutputID);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChangerEvents/StatusUpdateEvent", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChangerEvents/StatusUpdateEventResponse")]
        void StatusUpdateEvent(string Source, int EventID, DateTime TimeStamp, int Status);
    }

    //
    // Common Data Types
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CashChangerEvents/")]
    public class DirectIOData
    {
        [DataMember]
        public int Data { get; set; }
        [DataMember]
        public object Obj { get; set; }
    }

    //
    // Common Enumerations
    //

    /*
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CashChangerEvents/")]
    public enum ErrorCode
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Claimed,
        [EnumMember]
        Closed,
        [EnumMember]
        Deprecated,
        [EnumMember]
        Disabled,
        [EnumMember]
        Exists,
        [EnumMember]
        Extended,
        [EnumMember]
        Failure,
        [EnumMember]
        Illegal,
        [EnumMember]
        NoExist,
        [EnumMember]
        NoHardware,
        [EnumMember]
        NoService,
        [EnumMember]
        NotClaimed,
        [EnumMember]
        Offline,
        [EnumMember]
        Success,
        [EnumMember]
        Timeout,
    }
    */

    /*
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CashChangerEvents/")]
    public enum ErrorLocus
    {
        [EnumMember]
        Input,
        [EnumMember]
        InputData,
        [EnumMember]
        Output,
    }
    */

    /*
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CashChangerEvents/")]
    public enum ErrorResponse
    {
        [EnumMember]
        Clear,
        [EnumMember]
        ContinueInput,
        [EnumMember]
        Retry,
    }
    */

    //
    // Specific Data Types
    //

    //
    // Specific Enumerations
    //

    //
    // Constants
    //

    /*
    public class Constants
    {

        public const int StatusAsync = 91;
        public const int StatusEmpty = 11;
        public const int StatusEmptyOK = 13;
        public const int StatusFull = 21;
        public const int StatusFullOK = 23;
        public const int StatusJam = 31;
        public const int StatusJamOK = 32;
        public const int StatusNearEmpty = 12;
        public const int StatusNearFull = 22;
        public const int StatusOK = 0;
        public const int StatusPowerOff = 2002;
        public const int StatusPowerOffline = 2003;
        public const int StatusPowerOffOffline = 2004;
        public const int StatusPowerOnline = 2001;
        public const int StatusUpdateFirmwareComplete = 2200;
        public const int StatusUpdateFirmwareCompleteDeviceNotRestored = 2205;
        public const int StatusUpdateFirmwareFailedDeviceNeedsFirmware = 2203;
        public const int StatusUpdateFirmwareFailedDeviceOk = 2201;
        public const int StatusUpdateFirmwareFailedDeviceUnknown = 2204;
        public const int StatusUpdateFirmwareFailedDeviceUnrecoverable = 2202;
        public const int StatusUpdateFirmwareProgress = 2100;
    }
    */

    public class Status
    {
        public const int Async = 91;
        public const int Empty = 11;
        public const int EmptyOK = 13;
        public const int Full = 21;
        public const int FullOK = 23;
        public const int Jam = 31;
        public const int JamOK = 32;
        public const int NearEmpty = 12;
        public const int NearFull = 22;
        public const int OK = 0;
        public const int PowerOff = 2002;
        public const int PowerOffline = 2003;
        public const int PowerOffOffline = 2004;
        public const int PowerOnline = 2001;
        public const int UpdateFirmwareComplete = 2200;
        public const int UpdateFirmwareCompleteDeviceNotRestored = 2205;
        public const int UpdateFirmwareFailedDeviceNeedsFirmware = 2203;
        public const int UpdateFirmwareFailedDeviceOk = 2201;
        public const int UpdateFirmwareFailedDeviceUnknown = 2204;
        public const int UpdateFirmwareFailedDeviceUnrecoverable = 2202;
        public const int UpdateFirmwareProgress = 2100;
    }
}
