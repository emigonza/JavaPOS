
package org.nrf_arts.unifiedpos.billdispenser;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="GetDeviceControlVersionResult" type="{http://www.nrf-arts.org/UnifiedPOS/BillDispenser/}UposVersion" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "getDeviceControlVersionResult"
})
@XmlRootElement(name = "GetDeviceControlVersionResponse")
public class GetDeviceControlVersionResponse {

    @XmlElement(name = "GetDeviceControlVersionResult", nillable = true)
    protected UposVersion getDeviceControlVersionResult;

    /**
     * Gets the value of the getDeviceControlVersionResult property.
     * 
     * @return
     *     possible object is
     *     {@link UposVersion }
     *     
     */
    public UposVersion getGetDeviceControlVersionResult() {
        return getDeviceControlVersionResult;
    }

    /**
     * Sets the value of the getDeviceControlVersionResult property.
     * 
     * @param value
     *     allowed object is
     *     {@link UposVersion }
     *     
     */
    public void setGetDeviceControlVersionResult(UposVersion value) {
        this.getDeviceControlVersionResult = value;
    }

}
