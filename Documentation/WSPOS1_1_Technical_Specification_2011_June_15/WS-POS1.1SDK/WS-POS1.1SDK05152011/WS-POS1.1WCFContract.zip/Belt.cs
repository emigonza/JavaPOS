﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace UnifiedPOS.Belt
{
    [ServiceContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Belt/")]
    public interface Belt
    {

        //
        // Common Properties
        //

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetAutoDisableResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        // int GetAutoDisable();

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/SetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/SetAutoDisableResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        // void SetAutoDisable(int AutoDisable);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetCapCompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetCapCompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        bool GetCapCompareFirmwareVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetCapPowerReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetCapPowerReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        PowerReporting GetCapPowerReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetCapStatisticsReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetCapStatisticsReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        bool GetCapStatisticsReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetCapUpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetCapUpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        bool GetCapUpdateFirmware();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetCapUpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetCapUpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        bool GetCapUpdateStatistics();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetCheckHealthText", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetCheckHealthTextResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        string GetCheckHealthText();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetClaimed", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetClaimedResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        bool GetClaimed();

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetDataCount", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetDataCountResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        // int GetDataCount();

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetDataEventEnabledResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        // bool GetDataEventEnabled();

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/SetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/SetDataEventEnabledResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        // void SetDataEventEnabled(bool DataEventEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        bool GetDeviceEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/SetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/SetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        void SetDeviceEnabled(bool DeviceEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        bool GetFreezeEvents();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/SetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/SetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        void SetFreezeEvents(bool FreezeEvents);

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetOutputID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetOutputIDResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        // int GetOutputID();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        PowerNotification GetPowerNotify();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/SetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/SetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        void SetPowerNotify(PowerNotification PowerNotify);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetPowerState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetPowerStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        PowerState GetPowerState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        ControlState GetState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetDeviceControlDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetDeviceControlDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        string GetDeviceControlDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetDeviceControlVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetDeviceControlVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        UposVersion GetDeviceControlVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetDeviceServiceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetDeviceServiceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        string GetDeviceServiceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetDeviceServiceVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetDeviceServiceVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        UposVersion GetDeviceServiceVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetPhysicalDeviceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetPhysicalDeviceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        string GetPhysicalDeviceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetPhysicalDeviceName", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetPhysicalDeviceNameResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        string GetPhysicalDeviceName();

        //
        // Specific Properties
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetCapAutoStopBackward", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetCapAutoStopBackwardResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        bool GetCapAutoStopBackward();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetCapAutoStopBackwardItemCount", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetCapAutoStopBackwardItemCountResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        bool GetCapAutoStopBackwardItemCount();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetCapAutoStopForward", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetCapAutoStopForwardResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        bool GetCapAutoStopForward();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetCapAutoStopForwardItemCount", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetCapAutoStopForwardItemCountResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        bool GetCapAutoStopForwardItemCount();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetCapLightBarrierBackward", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetCapLightBarrierBackwardResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        bool GetCapLightBarrierBackward();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetCapLightBarrierForward", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetCapLightBarrierForwardResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        bool GetCapLightBarrierForward();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetCapMoveBackward", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetCapMoveBackwardResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        bool GetCapMoveBackward();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetCapSecurityFlapBackward", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetCapSecurityFlapBackwardResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        bool GetCapSecurityFlapBackward();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetCapSecurityFlapForward", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetCapSecurityFlapForwardResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        bool GetCapSecurityFlapForward();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetCapSpeedStepsBackward", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetCapSpeedStepsBackwardResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        int GetCapSpeedStepsBackward();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetCapSpeedStepsForward", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetCapSpeedStepsForwardResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        int GetCapSpeedStepsForward();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetAutoStopBackward", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetAutoStopBackwardResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        bool GetAutoStopBackward();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/SetAutoStopBackward", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/SetAutoStopBackwardResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        void SetAutoStopBackward(bool AutoStopBackward);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetAutoStopBackwardDelayTime", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetAutoStopBackwardDelayTimeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        int GetAutoStopBackwardDelayTime();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetAutoStopBackwardItemCount", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetAutoStopBackwardItemCountResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        void SetAutoStopBackwardDelayTime(int AutoStopBackwardDelayTime);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetCapStatus", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetCapStatusResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        int GetAutoStopBackwardItemCount();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetAutoStopForward", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetAutoStopForwardResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        bool GetAutoStopForward();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/SetAutoStopForward", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/SetAutoStopForwardResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        void SetAutoStopForward(bool AutoStopForward);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetAutoStopForwardDelayTime", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetAutoStopForwardDelayTimeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        int GetAutoStopForwardDelayTime();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/SetAutoStopForwardDelayTime", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/SetAutoStopForwardDelayTimeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        void SetAutoStopForwardDelayTime(int AutoStopForwardDelayTime);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetAutoStopForwardItemCount", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetAutoStopForwardItemCountResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        int GetAutoStopForwardItemCount();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetLightBarrierBackwardInterrupted", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetLightBarrierBackwardInterruptedResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        bool GetLightBarrierBackwardInterrupted();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetLightBarrierForwardInterrupted", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetLightBarrierForwardInterruptedResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        bool GetLightBarrierForwardInterrupted();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetMotionStatus", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetMotionStatusResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        BeltMotionStatus GetMotionStatus();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetSecurityFlapBackwardOpened", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetSecurityFlapBackwardOpenedResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        bool GetSecurityFlapBackwardOpened();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetSecurityFlapForwardOpened", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/GetSecurityFlapForwardOpenedResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        bool GetSecurityFlapForwardOpened();

        //
        // Common Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/Open", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/OpenResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        void Open(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/Close", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/CloseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        void Close(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/Claim", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/ClaimResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        void Claim(int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/Release", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/ReleaseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        void Release();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/CheckHealth", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/CheckHealthResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        void CheckHealth(HealthCheckLevel Level);

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/ClearInput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/ClearInputResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        // void ClearInput();

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/ClearInputProperties", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/ClearInputPropertiesResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        // void ClearInputProperties();

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/ClearOutput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/ClearOutputResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        // void ClearOutput();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/DirectIO", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/DirectIOResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        DirectIOData DirectIO(int Command, int Data, object Obj);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/CompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/CompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        CompareFirmwareResult CompareFirmwareVersion(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/ResetStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/ResetStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        void ResetStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/RetrieveStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/RetrieveStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        string RetrieveStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/UpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        void UpdateFirmware(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/UpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        void UpdateStatistics(StatisticList StatisticsBuffer);

        //
        // Specific Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/AdjustItemCount", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/AdjustItemCountResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        void AdjustItemCount(BeltDirection Direction, int Count);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/MoveBackward", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/MoveBackwardResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        void MoveBackward(int Speed);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/MoveForward", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/MoveForwardResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        void MoveForward(int Speed);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/ResetBelt", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/ResetBeltResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        void ResetBelt();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/ResetItemCount", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/ResetItemCountResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        void ResetItemCount(BeltDirection Direction);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/StopBelt", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Belt/StopBeltResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        void StopBelt();
    }

    //
    // Common Data Types
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Belt/")]
    public class DirectIOData
    {
        [DataMember]
        public int Data { get; set; }
        [DataMember]
        public object Obj { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Belt/")]
    public class UposException
    {
        [DataMember]
        public ErrorCode ErrorCode { get; set; }
        [DataMember]
        public int ErrorCodeExtended { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Belt/")]
    public class UposVersion
    {
        [DataMember]
        public int Major { get; set; }
        [DataMember]
        public int Minor { get; set; }
        [DataMember]
        public int Build { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Belt/")]
    public class Statistic
    {
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public string Value { get; set; }
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Belt/", ItemName = "Statistic")]
    public class StatisticList : List<Statistic>
    {
    }

    //
    // Common Enumerations
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Belt/")]
    public enum CompareFirmwareResult
    {
        [EnumMember]
        Different,
        [EnumMember]
        Newer,
        [EnumMember]
        Older,
        [EnumMember]
        Same,
        [EnumMember]
        Unknown,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Belt/")]
    public enum ControlState
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Closed,
        [EnumMember]
        Error,
        [EnumMember]
        Idle,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Belt/")]
    public enum ErrorCode
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Claimed,
        [EnumMember]
        Closed,
        [EnumMember]
        Deprecated,
        [EnumMember]
        Disabled,
        [EnumMember]
        Exists,
        [EnumMember]
        Extended,
        [EnumMember]
        Failure,
        [EnumMember]
        Illegal,
        [EnumMember]
        NoExist,
        [EnumMember]
        NoHardware,
        [EnumMember]
        NoService,
        [EnumMember]
        NotClaimed,
        [EnumMember]
        Offline,
        [EnumMember]
        Success,
        [EnumMember]
        Timeout,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Belt/")]
    public enum HealthCheckLevel
    {
        [EnumMember]
        External,
        [EnumMember]
        Interactive,
        [EnumMember]
        Internal,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Belt/")]
    public enum PowerNotification
    {
        [EnumMember]
        Disabled,
        [EnumMember]
        Enabled,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Belt/")]
    public enum PowerReporting
    {
        [EnumMember]
        Advanced,
        [EnumMember]
        None,
        [EnumMember]
        Standard,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Belt/")]
    public enum PowerState
    {
        [EnumMember]
        Off,
        [EnumMember]
        Offline,
        [EnumMember]
        OffOffline,
        [EnumMember]
        Online,
        [EnumMember]
        Unknown,
    }

    /*
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Belt/")]
    public enum StatisticCategories
    {
        [EnumMember]
        All,
        [EnumMember]
        Manufacturer,
        [EnumMember]
        Upos,
    }
    */
    public class StatisticCategories
    {
        public const string All = "";
        public const string Manufacturer = "M_";
        public const string Upos = "U_";
    }

    //
    // Specific Data Types
    //

    //
    // Specific Enumerations
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Belt/")]
    public enum BeltDirection
    {
        [EnumMember]
        Backward,
        [EnumMember]
        Forward,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Belt/")]
    public enum BeltMotionStatus
    {
        [EnumMember]
        Backward,
        [EnumMember]
        Emergency,
        [EnumMember]
        Forward,
        [EnumMember]
        MotorFault,
        [EnumMember]
        Stopped,
    }

    //
    // Constants
    //

    /*
    public class Constants
    {
        public const int ExtendedErrorFirmwareBadFile = 281;
        public const int ExtendedErrorStatistics = 280;
        public const int ExtendedErrorStatisticsDependency = 282;
        public const string StatisticCommunicationErrorCount = "CommunicationErrorCount";
        public const string StatisticDeviceCategory = "DeviceCategory";
        public const string StatisticFirmwareRevision = "FirmwareRevision";
        public const string StatisticHoursPoweredCount = "HoursPoweredCount";
        public const string StatisticInstallationDate = "InstallationDate";
        public const string StatisticInterface = "Interface";
        public const string StatisticManufactureDate = "ManufactureDate";
        public const string StatisticManufacturerName = "ManufacturerName";
        public const string StatisticMechanicalRevision = "MechanicalRevision";
        public const string StatisticModelName = "ModelName";
        public const string StatisticSerialNumber = "SerialNumber";
        public const string StatisticUnifiedPOSVersion = "UnifiedPOSVersion";
        public const int WaitForever = -1;
    }
    */

    public class ExtendedError
    {
        public const int FirmwareBadFile = 281;
        public const int Statistics = 280;
        public const int StatisticsDependency = 282;
    }

    public class StatisticProperties
    {
        public const string CommunicationErrorCount = "CommunicationErrorCount";
        public const string DeviceCategory = "DeviceCategory";
        public const string FirmwareRevision = "FirmwareRevision";
        public const string HoursPoweredCount = "HoursPoweredCount";
        public const string InstallationDate = "InstallationDate";
        public const string Interface = "Interface";
        public const string ManufactureDate = "ManufactureDate";
        public const string ManufacturerName = "ManufacturerName";
        public const string MechanicalRevision = "MechanicalRevision";
        public const string ModelName = "ModelName";
        public const string SerialNumber = "SerialNumber";
        public const string UnifiedPOSVersion = "UnifiedPOSVersion";
    }

    public class Wait
    {
        public const int Forever = -1;
    }
}
