﻿using UnifiedPOS.POSPrinterEvents;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace Wspos
{
    [ServiceBehavior(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPrinterEvents/", InstanceContextMode = InstanceContextMode.Single)]
    public class POSPrinterEventService : POSPrinterEvent
    {
        private static Dictionary<int, string> Convert = new Dictionary<int, string>()
            {
                { Status.CoverOK, "CoverOK" },
                { Status.CoverOpen, "CoverOpen" },
                { Status.Idle, "Idle" },
                { Status.JournalCartridgeEmpty, "JournalCartridgeEmpty" },
                { Status.JournalCartridgeNearEmpty, "JournalCartridgeNearEmpty" },
                { Status.JournalCartridgeOK, "JournalCartridgeOK" },
                { Status.JournalCoverOK, "JournalCoverOK" },
                { Status.JournalCoverOpen, "JournalCoverOpen" },
                { Status.JournalEmpty, "JournalEmpty" },
                { Status.JournalHeadCleaning, "JournalHeadCleaning" },
                { Status.JournalNearEmpty, "JournalNearEmpty" },
                { Status.JournalPaperOK, "JournalPaperOK" },
                { Status.PowerOff, "PowerOff" },
                { Status.PowerOffline, "PowerOffline" },
                { Status.PowerOffOffline, "PowerOffOffline" },
                { Status.PowerOnline, "PowerOnline" },
                { Status.ReceiptCartridgeEmpty, "ReceiptCartridgeEmpty" },
                { Status.ReceiptCartridgeNearEmpty, "ReceiptCartridgeNearEmpty" },
                { Status.ReceiptCartridgeOK, "ReceiptCartridgeOK" },
                { Status.ReceiptCoverOK, "ReceiptCoverOK" },
                { Status.ReceiptCoverOpen, "ReceiptCoverOpen" },
                { Status.ReceiptEmpty, "ReceiptEmpty" },
                { Status.ReceiptHeadCleaning, "ReceiptHeadCleaning" },
                { Status.ReceiptNearEmpty, "ReceiptNearEmpty" },
                { Status.ReceiptPaperOK, "ReceiptPaperOK" },
                { Status.SlipCartridgeEmpty, "SlipCartridgeEmpty" },
                { Status.SlipCartridgeNearEmpty, "SlipCartridgeNearEmpty" },
                { Status.SlipCartridgeOK, "SlipCartridgeOK" },
                { Status.SlipCoverOK, "SlipCoverOK" },
                { Status.SlipCoverOpen, "SlipCoverOpen" },
                { Status.SlipEmpty, "SlipEmpty" },
                { Status.SlipHeadCleaning, "SlipHeadCleaning" },
                { Status.SlipNearEmpty, "SlipNearEmpty" },
                { Status.SlipPaperOK, "SlipPaperOK" },
                { Status.UpdateFirmwareComplete, "UpdateFirmwareComplete" },
                { Status.UpdateFirmwareCompleteDeviceNotRestored, "UpdateFirmwareCompleteDeviceNotRestored" },
                { Status.UpdateFirmwareFailedDeviceNeedsFirmware, "UpdateFirmwareFailedDeviceNeedsFirmware" },
                { Status.UpdateFirmwareFailedDeviceOk, "UpdateFirmwareFailedDeviceOk" },
                { Status.UpdateFirmwareFailedDeviceUnknown, "UpdateFirmwareFailedDeviceUnknown" },
                { Status.UpdateFirmwareFailedDeviceUnrecoverable, "UpdateFirmwareFailedDeviceUnrecoverable" },
                { Status.UpdateFirmwareProgress, "UpdateFirmwareProgress" },
            };

        #region POSPrinterEvent Member

        public DirectIOData DirectIOEvent(string Source, int EventID, DateTime TimeStamp, int EventNumber, int Data, object Obj)
        {
            //throw new NotImplementedException();
            Console.WriteLine("{0}, {1}, DirectIOEvent, {2}, {3}, {4}", EventID, TimeStamp, EventNumber, Data, Obj);
            return new DirectIOData() { Data = Data, Obj = Obj };
        }

        public ErrorResponse ErrorEvent(string Source, int EventID, DateTime TimeStamp, ErrorCode ErrorCode, int ErrorCodeExtended, ErrorLocus ErrorLocus, ErrorResponse ErrorResponse)
        {
            //throw new NotImplementedException();
            Console.WriteLine("{0}, {1}, ErrorEvent, {2}, {3}, {4}, {5}", EventID, TimeStamp, ErrorCode, ErrorCodeExtended, ErrorLocus, ErrorResponse);
            return ErrorResponse.Clear;
        }

        public void OutputCompleteEvent(string Source, int EventID, DateTime TimeStamp, int OutputID)
        {
            //throw new NotImplementedException();
            Console.WriteLine("{0}, {1}, OutputCompleteEvent, {2}", EventID, TimeStamp, OutputID);
        }

        public void StatusUpdateEvent(string Source, int EventID, DateTime TimeStamp, int Status)
        {
            //throw new NotImplementedException();
            int p = UnifiedPOS.POSPrinterEvents.Status.UpdateFirmwareProgress;
            Console.WriteLine("{0}, {1}, StatusUpdateEvent, {2}", EventID, TimeStamp, (Status > p && Status < p + 100) ? Convert[p] + " + " + (Status - p) : Convert[Status]);
        }

        #endregion

    }
}