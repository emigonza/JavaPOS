﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace UnifiedPOS.POSPrinterEvents
{
    [ServiceContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPrinterEvents/")]
    public interface POSPrinterEvent
    {

        //
        // Events
        //

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinterEvents/DataEvent", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinterEvents/DataEventResponse")]
        // void DataEvent(string Source, int EventID, DateTime TimeStamp, int Status);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinterEvents/DirectIOEvent", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinterEvents/DirectIOEventResponse")]
        DirectIOData DirectIOEvent(string Source, int EventID, DateTime TimeStamp, int EventNumber, int Data, object Obj);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinterEvents/ErrorEvent", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinterEvents/ErrorEventResponse")]
        ErrorResponse ErrorEvent(string Source, int EventID, DateTime TimeStamp, ErrorCode ErrorCode, int ErrorCodeExtended, ErrorLocus ErrorLocus, ErrorResponse ErrorResponse);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinterEvents/OutputCompleteEvent", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinterEvents/OutputCompleteEventResponse")]
        void OutputCompleteEvent(string Source, int EventID, DateTime TimeStamp, int OutputID);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPrinterEvents/StatusUpdateEvent", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPrinterEvents/StatusUpdateEventResponse")]
        void StatusUpdateEvent(string Source, int EventID, DateTime TimeStamp, int Status);
    }

    //
    // Common Data Types
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPrinterEvents/")]
    public class DirectIOData
    {
        [DataMember]
        public int Data { get; set; }
        [DataMember]
        public object Obj { get; set; }
    }

    //
    // Common Enumerations
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPrinterEvents/")]
    public enum ErrorCode
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Claimed,
        [EnumMember]
        Closed,
        [EnumMember]
        Deprecated,
        [EnumMember]
        Disabled,
        [EnumMember]
        Exists,
        [EnumMember]
        Extended,
        [EnumMember]
        Failure,
        [EnumMember]
        Illegal,
        [EnumMember]
        NoExist,
        [EnumMember]
        NoHardware,
        [EnumMember]
        NoService,
        [EnumMember]
        NotClaimed,
        [EnumMember]
        Offline,
        [EnumMember]
        Success,
        [EnumMember]
        Timeout,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPrinterEvents/")]
    public enum ErrorLocus
    {
        [EnumMember]
        Input,
        [EnumMember]
        InputData,
        [EnumMember]
        Output,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPrinterEvents/")]
    public enum ErrorResponse
    {
        [EnumMember]
        Clear,
        [EnumMember]
        ContinueInput,
        [EnumMember]
        Retry,
    }

    //
    // Specific Data Types
    //

    //
    // Specific Enumerations
    //

    //
    // Constants
    //

    /*
    public class Constants
    {
        public const int ExtendedErrorBadFormat = 207;
        public const int ExtendedErrorCoverOpen = 201;
        public const int ExtendedErrorFirmwareBadFile = 281;
        public const int ExtendedErrorJournalCartridgeEmpty = 209;
        public const int ExtendedErrorJournalCartridgeRemoved = 208;
        public const int ExtendedErrorJournalEmpty = 202;
        public const int ExtendedErrorJournalHeadCleaning = 210;
        public const int ExtendedErrorReceiptCartridgeEmpty = 212;
        public const int ExtendedErrorReceiptCartridgeRemoved = 211;
        public const int ExtendedErrorReceiptEmpty = 203;
        public const int ExtendedErrorReceiptHeadCleaning = 213;
        public const int ExtendedErrorSlipCartridgeEmpty = 215;
        public const int ExtendedErrorSlipCartridgeRemoved = 214;
        public const int ExtendedErrorSlipEmpty = 204;
        public const int ExtendedErrorSlipForm = 205;
        public const int ExtendedErrorSlipHeadCleaning = 216;
        public const int ExtendedErrorStatistics = 280;
        public const int ExtendedErrorStatisticsDependency = 282;
        public const int ExtendedErrorTooBig = 206;
        public const int StatusCoverOK = 12;
        public const int StatusCoverOpen = 11;
        public const int StatusIdle = 1001;
        public const int StatusJournalCartridgeEmpty = 41;
        public const int StatusJournalCartridgeNearEmpty = 42;
        public const int StatusJournalCartridgeOK = 44;
        public const int StatusJournalCoverOK = 61;
        public const int StatusJournalCoverOpen = 60;
        public const int StatusJournalEmpty = 21;
        public const int StatusJournalHeadCleaning = 43;
        public const int StatusJournalNearEmpty = 22;
        public const int StatusJournalPaperOK = 23;
        public const int StatusPowerOff = 2002;
        public const int StatusPowerOffline = 2003;
        public const int StatusPowerOffOffline = 2004;
        public const int StatusPowerOnline = 2001;
        public const int StatusReceiptCartridgeEmpty = 45;
        public const int StatusReceiptCartridgeNearEmpty = 46;
        public const int StatusReceiptCartridgeOK = 48;
        public const int StatusReceiptCoverOK = 63;
        public const int StatusReceiptCoverOpen = 62;
        public const int StatusReceiptEmpty = 24;
        public const int StatusReceiptHeadCleaning = 47;
        public const int StatusReceiptNearEmpty = 25;
        public const int StatusReceiptPaperOK = 26;
        public const int StatusSlipCartridgeEmpty = 49;
        public const int StatusSlipCartridgeNearEmpty = 50;
        public const int StatusSlipCartridgeOK = 52;
        public const int StatusSlipCoverOK = 65;
        public const int StatusSlipCoverOpen = 64;
        public const int StatusSlipEmpty = 27;
        public const int StatusSlipHeadCleaning = 51;
        public const int StatusSlipNearEmpty = 28;
        public const int StatusSlipPaperOK = 29;
        public const int StatusUpdateFirmwareComplete = 2200;
        public const int StatusUpdateFirmwareCompleteDeviceNotRestored = 2205;
        public const int StatusUpdateFirmwareFailedDeviceNeedsFirmware = 2203;
        public const int StatusUpdateFirmwareFailedDeviceOk = 2201;
        public const int StatusUpdateFirmwareFailedDeviceUnknown = 2204;
        public const int StatusUpdateFirmwareFailedDeviceUnrecoverable = 2202;
        public const int StatusUpdateFirmwareProgress = 2100;
    }
    */

    public class ExtendedError
    {
        public const int BadFormat = 207;
        public const int CoverOpen = 201;
        public const int FirmwareBadFile = 281;
        public const int JournalCartridgeEmpty = 209;
        public const int JournalCartridgeRemoved = 208;
        public const int JournalEmpty = 202;
        public const int JournalHeadCleaning = 210;
        public const int ReceiptCartridgeEmpty = 212;
        public const int ReceiptCartridgeRemoved = 211;
        public const int ReceiptEmpty = 203;
        public const int ReceiptHeadCleaning = 213;
        public const int SlipCartridgeEmpty = 215;
        public const int SlipCartridgeRemoved = 214;
        public const int SlipEmpty = 204;
        public const int SlipForm = 205;
        public const int SlipHeadCleaning = 216;
        public const int Statistics = 280;
        public const int StatisticsDependency = 282;
        public const int TooBig = 206;
    }

    public class Status
    {
        public const int CoverOK = 12;
        public const int CoverOpen = 11;
        public const int Idle = 1001;
        public const int JournalCartridgeEmpty = 41;
        public const int JournalCartridgeNearEmpty = 42;
        public const int JournalCartridgeOK = 44;
        public const int JournalCoverOK = 61;
        public const int JournalCoverOpen = 60;
        public const int JournalEmpty = 21;
        public const int JournalHeadCleaning = 43;
        public const int JournalNearEmpty = 22;
        public const int JournalPaperOK = 23;
        public const int PowerOff = 2002;
        public const int PowerOffline = 2003;
        public const int PowerOffOffline = 2004;
        public const int PowerOnline = 2001;
        public const int ReceiptCartridgeEmpty = 45;
        public const int ReceiptCartridgeNearEmpty = 46;
        public const int ReceiptCartridgeOK = 48;
        public const int ReceiptCoverOK = 63;
        public const int ReceiptCoverOpen = 62;
        public const int ReceiptEmpty = 24;
        public const int ReceiptHeadCleaning = 47;
        public const int ReceiptNearEmpty = 25;
        public const int ReceiptPaperOK = 26;
        public const int SlipCartridgeEmpty = 49;
        public const int SlipCartridgeNearEmpty = 50;
        public const int SlipCartridgeOK = 52;
        public const int SlipCoverOK = 65;
        public const int SlipCoverOpen = 64;
        public const int SlipEmpty = 27;
        public const int SlipHeadCleaning = 51;
        public const int SlipNearEmpty = 28;
        public const int SlipPaperOK = 29;
        public const int UpdateFirmwareComplete = 2200;
        public const int UpdateFirmwareCompleteDeviceNotRestored = 2205;
        public const int UpdateFirmwareFailedDeviceNeedsFirmware = 2203;
        public const int UpdateFirmwareFailedDeviceOk = 2201;
        public const int UpdateFirmwareFailedDeviceUnknown = 2204;
        public const int UpdateFirmwareFailedDeviceUnrecoverable = 2202;
        public const int UpdateFirmwareProgress = 2100;
    }
}
