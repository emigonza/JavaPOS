
package org.nrf_arts.unifiedpos.biometrics;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for BiometricsInformationRecordList complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BiometricsInformationRecordList">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="BiometricsInformationRecord" type="{http://www.nrf-arts.org/UnifiedPOS/Biometrics/}BiometricsInformationRecord" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BiometricsInformationRecordList", propOrder = {
    "biometricsInformationRecord"
})
public class BiometricsInformationRecordList {

    @XmlElement(name = "BiometricsInformationRecord", nillable = true)
    protected List<BiometricsInformationRecord> biometricsInformationRecord;

    /**
     * Gets the value of the biometricsInformationRecord property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the biometricsInformationRecord property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getBiometricsInformationRecord().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link BiometricsInformationRecord }
     * 
     * 
     */
    public List<BiometricsInformationRecord> getBiometricsInformationRecord() {
        if (biometricsInformationRecord == null) {
            biometricsInformationRecord = new ArrayList<BiometricsInformationRecord>();
        }
        return this.biometricsInformationRecord;
    }

}
