/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package wspos;

import java.net.URL;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import jpos.events.DataEvent;
import jpos.events.DirectIOEvent;
import jpos.events.ErrorEvent;
import jpos.events.StatusUpdateEvent;
import org.nrf_arts.unifiedpos.msr.*;
import javax.jws.WebService;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.namespace.QName;
import javax.xml.ws.Service;

/**
 *
 * @author hideon
 */
@WebService(serviceName = "MSRService", endpointInterface = "org.nrf_arts.unifiedpos.msr.MSR", targetNamespace = "http://www.nrf-arts.org/UnifiedPOS/MSR/")
public class MSRService implements MSR, jpos.events.DataListener, jpos.events.DirectIOListener, jpos.events.ErrorListener, jpos.events.StatusUpdateListener {

    //
    // MSR Enumration Converter
    //

    private static HashMap<Enum, Integer> jposConst;
    private static HashMap<Integer, PowerReporting> powerReporting;
    private static HashMap<Integer, PowerNotification> powerNotification;
    private static HashMap<Integer, PowerState> powerState;
    private static HashMap<Integer, ControlState> controlState;
    private static HashMap<Integer, HealthCheckLevel> healthCheckLevel;
    private static HashMap<Integer, CompareFirmwareResult> compareFirmwareResult;
    private static HashMap<Integer, ErrorCode> errorCode;
    private static HashMap<Integer, DeviceAuthenticationLevel> deviceAuthenticationLevel;
    private static HashMap<Integer, MSRTracks> msrTracks;
    private static HashMap<Integer, DeviceAuthenticationProtocol> deviceAuthenticationProtocol;
    private static HashMap<Integer, MSRErrorReporting> msrErrorReporting;

    private static HashMap<Enum, Integer> jposEventConst;
    private static HashMap<Integer, org.nrf_arts.unifiedpos.msrevents.ErrorCode> eventErrorCode;
    private static HashMap<Integer, org.nrf_arts.unifiedpos.msrevents.ErrorLocus> eventErrorLocus;
    private static HashMap<Integer, org.nrf_arts.unifiedpos.msrevents.ErrorResponse> eventErrorResponse;

    static {
        jposConst = new HashMap<Enum, Integer>();
        jposConst.put(PowerReporting.ADVANCED, jpos.MSR.JPOS_PR_ADVANCED);
        jposConst.put(PowerReporting.NONE, jpos.MSR.JPOS_PR_NONE);
        jposConst.put(PowerReporting.STANDARD, jpos.MSR.JPOS_PR_STANDARD);
        jposConst.put(PowerNotification.DISABLED, jpos.MSR.JPOS_PN_DISABLED);
        jposConst.put(PowerNotification.ENABLED, jpos.MSR.JPOS_PN_ENABLED);
        jposConst.put(PowerState.OFF, jpos.MSR.JPOS_PS_OFF);
        jposConst.put(PowerState.OFFLINE, jpos.MSR.JPOS_PS_OFFLINE);
        jposConst.put(PowerState.OFF_OFFLINE, jpos.MSR.JPOS_PS_OFF_OFFLINE);
        jposConst.put(PowerState.ONLINE, jpos.MSR.JPOS_PS_ONLINE);
        jposConst.put(PowerState.UNKNOWN, jpos.MSR.JPOS_PS_UNKNOWN);
        jposConst.put(ControlState.BUSY, jpos.MSR.JPOS_S_BUSY);
        jposConst.put(ControlState.CLOSED, jpos.MSR.JPOS_S_CLOSED);
        jposConst.put(ControlState.ERROR, jpos.MSR.JPOS_S_ERROR);
        jposConst.put(ControlState.IDLE, jpos.MSR.JPOS_S_IDLE);
        jposConst.put(HealthCheckLevel.EXTERNAL, jpos.MSR.JPOS_CH_EXTERNAL);
        jposConst.put(HealthCheckLevel.INTERACTIVE, jpos.MSR.JPOS_CH_INTERACTIVE);
        jposConst.put(HealthCheckLevel.INTERNAL, jpos.MSR.JPOS_CH_INTERNAL);
        jposConst.put(CompareFirmwareResult.DIFFERENT, jpos.MSR.JPOS_CFV_FIRMWARE_DIFFERENT);
        jposConst.put(CompareFirmwareResult.NEWER, jpos.MSR.JPOS_CFV_FIRMWARE_NEWER);
        jposConst.put(CompareFirmwareResult.OLDER, jpos.MSR.JPOS_CFV_FIRMWARE_OLDER);
        jposConst.put(CompareFirmwareResult.SAME, jpos.MSR.JPOS_CFV_FIRMWARE_SAME);
        jposConst.put(CompareFirmwareResult.UNKNOWN, jpos.MSR.JPOS_CFV_FIRMWARE_UNKNOWN);
        jposConst.put(ErrorCode.BUSY, jpos.MSR.JPOS_E_BUSY);
        jposConst.put(ErrorCode.CLAIMED, jpos.MSR.JPOS_E_CLAIMED);
        jposConst.put(ErrorCode.CLOSED, jpos.MSR.JPOS_E_CLOSED);
        jposConst.put(ErrorCode.DEPRECATED, jpos.MSR.JPOS_E_DEPRECATED);
        jposConst.put(ErrorCode.DISABLED, jpos.MSR.JPOS_E_DISABLED);
        jposConst.put(ErrorCode.EXISTS, jpos.MSR.JPOS_E_EXISTS);
        jposConst.put(ErrorCode.EXTENDED, jpos.MSR.JPOS_E_EXTENDED);
        jposConst.put(ErrorCode.FAILURE, jpos.MSR.JPOS_E_FAILURE);
        jposConst.put(ErrorCode.ILLEGAL, jpos.MSR.JPOS_E_ILLEGAL);
        jposConst.put(ErrorCode.NO_EXIST, jpos.MSR.JPOS_E_NOEXIST);
        jposConst.put(ErrorCode.NO_HARDWARE, jpos.MSR.JPOS_E_NOHARDWARE);
        jposConst.put(ErrorCode.NO_SERVICE, jpos.MSR.JPOS_E_NOSERVICE);
        jposConst.put(ErrorCode.NOT_CLAIMED, jpos.MSR.JPOS_E_NOTCLAIMED);
        jposConst.put(ErrorCode.OFFLINE, jpos.MSR.JPOS_E_OFFLINE);
        jposConst.put(ErrorCode.SUCCESS, 0);
        jposConst.put(ErrorCode.TIMEOUT, jpos.MSR.JPOS_E_TIMEOUT);
        jposConst.put(DeviceAuthenticationLevel.NOT_SUPPORTED, jpos.MSRConst.MSR_DA_NOT_SUPPORTED);
        jposConst.put(DeviceAuthenticationLevel.OPTIONAL, jpos.MSRConst.MSR_DA_OPTIONAL);
        jposConst.put(DeviceAuthenticationLevel.REQUIRED, jpos.MSRConst.MSR_DA_REQUIRED);
        jposConst.put(MSRTracks.NONE, jpos.MSRConst.MSR_TR_NONE);
        jposConst.put(MSRTracks.TRACK_1, jpos.MSRConst.MSR_TR_1);
        jposConst.put(MSRTracks.TRACK_2, jpos.MSRConst.MSR_TR_2);
        jposConst.put(MSRTracks.TRACK_3, jpos.MSRConst.MSR_TR_3);
        jposConst.put(MSRTracks.TRACK_4, jpos.MSRConst.MSR_TR_4);
        jposConst.put(MSRTracks.TRACKS_12, jpos.MSRConst.MSR_TR_1_2);
        jposConst.put(MSRTracks.TRACKS_123, jpos.MSRConst.MSR_TR_1_2_3);
        jposConst.put(MSRTracks.TRACKS_1234, jpos.MSRConst.MSR_TR_1_2_3_4);
        jposConst.put(MSRTracks.TRACKS_124, jpos.MSRConst.MSR_TR_1_2_4);
        jposConst.put(MSRTracks.TRACKS_13, jpos.MSRConst.MSR_TR_1_3);
        jposConst.put(MSRTracks.TRACKS_134, jpos.MSRConst.MSR_TR_1_3_4);
        jposConst.put(MSRTracks.TRACKS_14, jpos.MSRConst.MSR_TR_1_4);
        jposConst.put(MSRTracks.TRACKS_23, jpos.MSRConst.MSR_TR_2_3);
        jposConst.put(MSRTracks.TRACKS_234, jpos.MSRConst.MSR_TR_2_3_4);
        jposConst.put(MSRTracks.TRACKS_24, jpos.MSRConst.MSR_TR_2_4);
        jposConst.put(MSRTracks.TRACKS_34, jpos.MSRConst.MSR_TR_3_4);
        jposConst.put(DeviceAuthenticationProtocol.CHALLENGE_RESPONSE, jpos.MSRConst.MSR_AP_CHALLENGERESPONSE);
        jposConst.put(DeviceAuthenticationProtocol.NONE, jpos.MSRConst.MSR_AP_NONE);
        jposConst.put(MSRErrorReporting.CARD, jpos.MSRConst.MSR_ERT_CARD);
        jposConst.put(MSRErrorReporting.TRACK, jpos.MSRConst.MSR_ERT_TRACK);

        powerReporting = new HashMap<Integer, PowerReporting>();
        powerReporting.put(jpos.MSR.JPOS_PR_ADVANCED, PowerReporting.ADVANCED);
        powerReporting.put(jpos.MSR.JPOS_PR_NONE, PowerReporting.NONE);
        powerReporting.put(jpos.MSR.JPOS_PR_STANDARD, PowerReporting.STANDARD);

        powerNotification = new HashMap<Integer, PowerNotification>();
        powerNotification.put(jpos.MSR.JPOS_PN_DISABLED, PowerNotification.DISABLED);
        powerNotification.put(jpos.MSR.JPOS_PN_ENABLED, PowerNotification.ENABLED);

        powerState = new HashMap<Integer, PowerState>();
        powerState.put(jpos.MSR.JPOS_PS_OFF, PowerState.OFF);
        powerState.put(jpos.MSR.JPOS_PS_OFFLINE, PowerState.OFFLINE);
        powerState.put(jpos.MSR.JPOS_PS_OFF_OFFLINE, PowerState.OFF_OFFLINE);
        powerState.put(jpos.MSR.JPOS_PS_ONLINE, PowerState.ONLINE);
        powerState.put(jpos.MSR.JPOS_PS_UNKNOWN, PowerState.UNKNOWN);

        controlState = new HashMap<Integer, ControlState>();
        controlState.put(jpos.MSR.JPOS_S_BUSY, ControlState.BUSY);
        controlState.put(jpos.MSR.JPOS_S_CLOSED, ControlState.CLOSED);
        controlState.put(jpos.MSR.JPOS_S_ERROR, ControlState.ERROR);
        controlState.put(jpos.MSR.JPOS_S_IDLE, ControlState.IDLE);

        healthCheckLevel = new HashMap<Integer, HealthCheckLevel>();
        healthCheckLevel.put(jpos.MSR.JPOS_CH_EXTERNAL, HealthCheckLevel.EXTERNAL);
        healthCheckLevel.put(jpos.MSR.JPOS_CH_INTERACTIVE, HealthCheckLevel.INTERACTIVE);
        healthCheckLevel.put(jpos.MSR.JPOS_CH_INTERNAL, HealthCheckLevel.INTERNAL);

        compareFirmwareResult = new HashMap<Integer, CompareFirmwareResult>();
        compareFirmwareResult.put(jpos.MSR.JPOS_CFV_FIRMWARE_DIFFERENT, CompareFirmwareResult.DIFFERENT);
        compareFirmwareResult.put(jpos.MSR.JPOS_CFV_FIRMWARE_NEWER, CompareFirmwareResult.NEWER);
        compareFirmwareResult.put(jpos.MSR.JPOS_CFV_FIRMWARE_OLDER, CompareFirmwareResult.OLDER);
        compareFirmwareResult.put(jpos.MSR.JPOS_CFV_FIRMWARE_SAME, CompareFirmwareResult.SAME);
        compareFirmwareResult.put(jpos.MSR.JPOS_CFV_FIRMWARE_UNKNOWN, CompareFirmwareResult.UNKNOWN);

        errorCode = new HashMap<Integer, ErrorCode>();
        errorCode.put(jpos.MSR.JPOS_E_BUSY, ErrorCode.BUSY);
        errorCode.put(jpos.MSR.JPOS_E_CLAIMED, ErrorCode.CLAIMED);
        errorCode.put(jpos.MSR.JPOS_E_CLOSED, ErrorCode.CLOSED);
        errorCode.put(jpos.MSR.JPOS_E_DEPRECATED, ErrorCode.DEPRECATED);
        errorCode.put(jpos.MSR.JPOS_E_DISABLED, ErrorCode.DISABLED);
        errorCode.put(jpos.MSR.JPOS_E_EXISTS, ErrorCode.EXISTS);
        errorCode.put(jpos.MSR.JPOS_E_EXTENDED, ErrorCode.EXTENDED);
        errorCode.put(jpos.MSR.JPOS_E_FAILURE, ErrorCode.FAILURE);
        errorCode.put(jpos.MSR.JPOS_E_ILLEGAL, ErrorCode.ILLEGAL);
        errorCode.put(jpos.MSR.JPOS_E_NOEXIST, ErrorCode.NO_EXIST);
        errorCode.put(jpos.MSR.JPOS_E_NOHARDWARE, ErrorCode.NO_HARDWARE);
        errorCode.put(jpos.MSR.JPOS_E_NOSERVICE, ErrorCode.NO_SERVICE);
        errorCode.put(jpos.MSR.JPOS_E_NOTCLAIMED, ErrorCode.NOT_CLAIMED);
        errorCode.put(jpos.MSR.JPOS_E_OFFLINE, ErrorCode.OFFLINE);
        errorCode.put(0, ErrorCode.SUCCESS);
        errorCode.put(jpos.MSR.JPOS_E_TIMEOUT, ErrorCode.TIMEOUT);

        deviceAuthenticationLevel = new HashMap<Integer, DeviceAuthenticationLevel>();
        deviceAuthenticationLevel.put(jpos.MSRConst.MSR_DA_NOT_SUPPORTED, DeviceAuthenticationLevel.NOT_SUPPORTED);
        deviceAuthenticationLevel.put(jpos.MSRConst.MSR_DA_OPTIONAL, DeviceAuthenticationLevel.OPTIONAL);
        deviceAuthenticationLevel.put(jpos.MSRConst.MSR_DA_REQUIRED, DeviceAuthenticationLevel.REQUIRED);

        msrTracks = new HashMap<Integer, MSRTracks>();
        msrTracks.put(jpos.MSRConst.MSR_TR_NONE, MSRTracks.NONE);
        msrTracks.put(jpos.MSRConst.MSR_TR_1, MSRTracks.TRACK_1);
        msrTracks.put(jpos.MSRConst.MSR_TR_2, MSRTracks.TRACK_2);
        msrTracks.put(jpos.MSRConst.MSR_TR_3, MSRTracks.TRACK_3);
        msrTracks.put(jpos.MSRConst.MSR_TR_4, MSRTracks.TRACK_4);
        msrTracks.put(jpos.MSRConst.MSR_TR_1_2, MSRTracks.TRACKS_12);
        msrTracks.put(jpos.MSRConst.MSR_TR_1_2_3, MSRTracks.TRACKS_123);
        msrTracks.put(jpos.MSRConst.MSR_TR_1_2_3_4, MSRTracks.TRACKS_1234);
        msrTracks.put(jpos.MSRConst.MSR_TR_1_2_4, MSRTracks.TRACKS_124);
        msrTracks.put(jpos.MSRConst.MSR_TR_1_3, MSRTracks.TRACKS_13);
        msrTracks.put(jpos.MSRConst.MSR_TR_1_3_4, MSRTracks.TRACKS_134);
        msrTracks.put(jpos.MSRConst.MSR_TR_1_4, MSRTracks.TRACKS_14);
        msrTracks.put(jpos.MSRConst.MSR_TR_2_3, MSRTracks.TRACKS_23);
        msrTracks.put(jpos.MSRConst.MSR_TR_2_3_4, MSRTracks.TRACKS_234);
        msrTracks.put(jpos.MSRConst.MSR_TR_2_4, MSRTracks.TRACKS_24);
        msrTracks.put(jpos.MSRConst.MSR_TR_3_4, MSRTracks.TRACKS_34);

        deviceAuthenticationProtocol = new HashMap<Integer, DeviceAuthenticationProtocol>();
        deviceAuthenticationProtocol.put(jpos.MSRConst.MSR_AP_CHALLENGERESPONSE, DeviceAuthenticationProtocol.CHALLENGE_RESPONSE);
        deviceAuthenticationProtocol.put(jpos.MSRConst.MSR_AP_NONE, DeviceAuthenticationProtocol.NONE);

        msrErrorReporting = new HashMap<Integer, MSRErrorReporting>();
        msrErrorReporting.put(jpos.MSRConst.MSR_ERT_CARD, MSRErrorReporting.CARD);
        msrErrorReporting.put(jpos.MSRConst.MSR_ERT_TRACK, MSRErrorReporting.TRACK);

        jposEventConst = new HashMap<Enum, Integer>();
        jposEventConst.put(org.nrf_arts.unifiedpos.msrevents.ErrorCode.BUSY, jpos.MSR.JPOS_E_BUSY);
        jposEventConst.put(org.nrf_arts.unifiedpos.msrevents.ErrorCode.CLAIMED, jpos.MSR.JPOS_E_CLAIMED);
        jposEventConst.put(org.nrf_arts.unifiedpos.msrevents.ErrorCode.CLOSED, jpos.MSR.JPOS_E_CLOSED);
        jposEventConst.put(org.nrf_arts.unifiedpos.msrevents.ErrorCode.DEPRECATED, jpos.MSR.JPOS_E_DEPRECATED);
        jposEventConst.put(org.nrf_arts.unifiedpos.msrevents.ErrorCode.DISABLED, jpos.MSR.JPOS_E_DISABLED);
        jposEventConst.put(org.nrf_arts.unifiedpos.msrevents.ErrorCode.EXISTS, jpos.MSR.JPOS_E_EXISTS);
        jposEventConst.put(org.nrf_arts.unifiedpos.msrevents.ErrorCode.EXTENDED, jpos.MSR.JPOS_E_EXTENDED);
        jposEventConst.put(org.nrf_arts.unifiedpos.msrevents.ErrorCode.FAILURE, jpos.MSR.JPOS_E_FAILURE);
        jposEventConst.put(org.nrf_arts.unifiedpos.msrevents.ErrorCode.ILLEGAL, jpos.MSR.JPOS_E_ILLEGAL);
        jposEventConst.put(org.nrf_arts.unifiedpos.msrevents.ErrorCode.NO_EXIST, jpos.MSR.JPOS_E_NOEXIST);
        jposEventConst.put(org.nrf_arts.unifiedpos.msrevents.ErrorCode.NO_HARDWARE, jpos.MSR.JPOS_E_NOHARDWARE);
        jposEventConst.put(org.nrf_arts.unifiedpos.msrevents.ErrorCode.NO_SERVICE, jpos.MSR.JPOS_E_NOSERVICE);
        jposEventConst.put(org.nrf_arts.unifiedpos.msrevents.ErrorCode.NOT_CLAIMED, jpos.MSR.JPOS_E_NOTCLAIMED);
        jposEventConst.put(org.nrf_arts.unifiedpos.msrevents.ErrorCode.OFFLINE, jpos.MSR.JPOS_E_OFFLINE);
        jposEventConst.put(org.nrf_arts.unifiedpos.msrevents.ErrorCode.SUCCESS, 0);
        jposEventConst.put(org.nrf_arts.unifiedpos.msrevents.ErrorCode.TIMEOUT, jpos.MSR.JPOS_E_TIMEOUT);
        jposEventConst.put(org.nrf_arts.unifiedpos.msrevents.ErrorLocus.INPUT, jpos.MSR.JPOS_EL_INPUT);
        jposEventConst.put(org.nrf_arts.unifiedpos.msrevents.ErrorLocus.INPUT_DATA, jpos.MSR.JPOS_EL_INPUT_DATA);
        jposEventConst.put(org.nrf_arts.unifiedpos.msrevents.ErrorLocus.OUTPUT, jpos.MSR.JPOS_EL_OUTPUT);
        jposEventConst.put(org.nrf_arts.unifiedpos.msrevents.ErrorResponse.CLEAR, jpos.MSR.JPOS_ER_CLEAR);
        jposEventConst.put(org.nrf_arts.unifiedpos.msrevents.ErrorResponse.CONTINUE_INPUT, jpos.MSR.JPOS_ER_CONTINUEINPUT);
        jposEventConst.put(org.nrf_arts.unifiedpos.msrevents.ErrorResponse.RETRY, jpos.MSR.JPOS_ER_RETRY);

        eventErrorCode = new HashMap<Integer, org.nrf_arts.unifiedpos.msrevents.ErrorCode>();
        eventErrorCode.put(jpos.MSR.JPOS_E_BUSY, org.nrf_arts.unifiedpos.msrevents.ErrorCode.BUSY);
        eventErrorCode.put(jpos.MSR.JPOS_E_CLAIMED, org.nrf_arts.unifiedpos.msrevents.ErrorCode.CLAIMED);
        eventErrorCode.put(jpos.MSR.JPOS_E_CLOSED, org.nrf_arts.unifiedpos.msrevents.ErrorCode.CLOSED);
        eventErrorCode.put(jpos.MSR.JPOS_E_DEPRECATED, org.nrf_arts.unifiedpos.msrevents.ErrorCode.DEPRECATED);
        eventErrorCode.put(jpos.MSR.JPOS_E_DISABLED, org.nrf_arts.unifiedpos.msrevents.ErrorCode.DISABLED);
        eventErrorCode.put(jpos.MSR.JPOS_E_EXISTS, org.nrf_arts.unifiedpos.msrevents.ErrorCode.EXISTS);
        eventErrorCode.put(jpos.MSR.JPOS_E_EXTENDED, org.nrf_arts.unifiedpos.msrevents.ErrorCode.EXTENDED);
        eventErrorCode.put(jpos.MSR.JPOS_E_FAILURE, org.nrf_arts.unifiedpos.msrevents.ErrorCode.FAILURE);
        eventErrorCode.put(jpos.MSR.JPOS_E_ILLEGAL, org.nrf_arts.unifiedpos.msrevents.ErrorCode.ILLEGAL);
        eventErrorCode.put(jpos.MSR.JPOS_E_NOEXIST, org.nrf_arts.unifiedpos.msrevents.ErrorCode.NO_EXIST);
        eventErrorCode.put(jpos.MSR.JPOS_E_NOHARDWARE, org.nrf_arts.unifiedpos.msrevents.ErrorCode.NO_HARDWARE);
        eventErrorCode.put(jpos.MSR.JPOS_E_NOSERVICE, org.nrf_arts.unifiedpos.msrevents.ErrorCode.NO_SERVICE);
        eventErrorCode.put(jpos.MSR.JPOS_E_NOTCLAIMED, org.nrf_arts.unifiedpos.msrevents.ErrorCode.NOT_CLAIMED);
        eventErrorCode.put(jpos.MSR.JPOS_E_OFFLINE, org.nrf_arts.unifiedpos.msrevents.ErrorCode.OFFLINE);
        eventErrorCode.put(0, org.nrf_arts.unifiedpos.msrevents.ErrorCode.SUCCESS);
        eventErrorCode.put(jpos.MSR.JPOS_E_TIMEOUT, org.nrf_arts.unifiedpos.msrevents.ErrorCode.TIMEOUT);

        eventErrorLocus = new HashMap<Integer, org.nrf_arts.unifiedpos.msrevents.ErrorLocus>();
        eventErrorLocus.put(jpos.MSR.JPOS_EL_INPUT, org.nrf_arts.unifiedpos.msrevents.ErrorLocus.INPUT);
        eventErrorLocus.put(jpos.MSR.JPOS_EL_INPUT_DATA, org.nrf_arts.unifiedpos.msrevents.ErrorLocus.INPUT_DATA);
        eventErrorLocus.put(jpos.MSR.JPOS_EL_OUTPUT, org.nrf_arts.unifiedpos.msrevents.ErrorLocus.OUTPUT);

        eventErrorResponse = new HashMap<Integer, org.nrf_arts.unifiedpos.msrevents.ErrorResponse>();
        eventErrorResponse.put(jpos.MSR.JPOS_ER_CLEAR, org.nrf_arts.unifiedpos.msrevents.ErrorResponse.CLEAR);
        eventErrorResponse.put(jpos.MSR.JPOS_ER_CONTINUEINPUT, org.nrf_arts.unifiedpos.msrevents.ErrorResponse.CONTINUE_INPUT);
        eventErrorResponse.put(jpos.MSR.JPOS_ER_RETRY, org.nrf_arts.unifiedpos.msrevents.ErrorResponse.RETRY);
    }

    private String deviceName;
    private UposVersion deviceControlVersion;
    private org.nrf_arts.unifiedpos.msrevents.MSREvent deviceEvent;
    private jpos.MSR device = new jpos.MSR();
    private DatatypeFactory datatypeFactory;

    public MSRService(String logicalDeviceName) {
        deviceName = logicalDeviceName;
        deviceControlVersion = new UposVersion();
        deviceControlVersion.setMajor(1);
        deviceControlVersion.setMinor(13);
        deviceControlVersion.setBuild(1);
        try {
            datatypeFactory = DatatypeFactory.newInstance();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    //
    // MSR Member
    //

    public void authenticateDevice(byte[] response) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.authenticateDevice(response);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void checkHealth(HealthCheckLevel level) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.checkHealth(jposConst.get(level));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void claim(Integer timeout) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.claim(timeout);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void clearInput() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.clearInput();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void clearInputProperties() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.clearInputProperties();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void close(String endpointAddress) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            if (deviceEvent != null)
            {
                device.removeDataListener(this);
                device.removeDirectIOListener(this);
                device.removeErrorListener(this);
                device.removeStatusUpdateListener(this);
                deviceEvent = null;
            }
            device.close();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public CompareFirmwareResult compareFirmwareVersion(String firmwareFileName) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            int[] param = new int[1];
            device.compareFirmwareVersion(firmwareFileName, param);
            return compareFirmwareResult.get(param[0]);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void deauthenticateDevice(byte[] response) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.deauthenticateDevice(response);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public DirectIOData directIO(Integer command, Integer data, Object obj) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            DirectIOData res = new DirectIOData();
            int[] param = new int[] { data };
            device.directIO(command, param, obj);
            res.setData(param[0]);
            res.setObj(obj);
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getAccountNumber() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getAccountNumber();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public byte[] getAdditionalSecurityInformation() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getAdditionalSecurityInformation();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getAutoDisable() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getAutoDisable();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getCapCardAuthentication() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapCardAuthentication();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapCompareFirmwareVersion() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapCompareFirmwareVersion();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getCapDataEncryption() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapDataEncryption();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public DeviceAuthenticationLevel getCapDeviceAuthentication() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return deviceAuthenticationLevel.get(device.getCapDeviceAuthentication());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapISO() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapISO();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapJISOne() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapJISOne();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapJISTwo() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapJISTwo();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public PowerReporting getCapPowerReporting() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return powerReporting.get(device.getCapPowerReporting());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapStatisticsReporting() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapStatisticsReporting();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapTrackDataMasking() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapTrackDataMasking();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapTransmitSentinels() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapTransmitSentinels();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapUpdateFirmware() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapUpdateFirmware();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapUpdateStatistics() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapUpdateStatistics();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public MSRTracks getCapWritableTracks() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return msrTracks.get(device.getCapWritableTracks());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public byte[] getCardAuthenticationData() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCardAuthenticationData();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getCardAuthenticationDataLength() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCardAuthenticationDataLength();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public CardPropertyList getCardPropertyList() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            CardPropertyList res = new CardPropertyList();
            List<String> list = res.getCardProperty();
            for (String s : device.getCardPropertyList().split(",")) {
                list.add(s);
            }
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getCardType() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCardType();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public CardTypeList getCardTypeList() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            CardTypeList res = new CardTypeList();
            List<String> list = res.getCardType();
            for (String s : device.getCardTypeList().split(",")) {
                list.add(s);
            }
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getCheckHealthText() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCheckHealthText();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getClaimed() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getClaimed();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getDataCount() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getDataCount();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getDataEncryptionAlgorithm() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getDataEncryptionAlgorithm();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getDataEventEnabled() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getDataEventEnabled();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getDecodeData() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getDecodeData();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getDeviceAuthenticated() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getDeviceAuthenticated();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public DeviceAuthenticationProtocol getDeviceAuthenticationProtocol() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return deviceAuthenticationProtocol.get(device.getDeviceAuthenticationProtocol());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getDeviceControlDescription() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        return device.getDeviceControlDescription();
    }

    public UposVersion getDeviceControlVersion() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        UposVersion res = new UposVersion();
        int version = device.getDeviceControlVersion();
        res.setMajor(version / 1000000 % 1000);
        res.setMinor(version / 1000 % 1000);
        res.setBuild(version % 1000);
        return res;
    }

    public Boolean getDeviceEnabled() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getDeviceEnabled();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getDeviceServiceDescription() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getDeviceServiceDescription();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public UposVersion getDeviceServiceVersion() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            UposVersion res = new UposVersion();
            int version = device.getDeviceServiceVersion();
            res.setMajor(version / 1000000 % 1000);
            res.setMinor(version / 1000 % 1000);
            res.setBuild(version % 1000);
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getEncodingMaxLength() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getEncodingMaxLength();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public MSRErrorReporting getErrorReportingType() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return msrErrorReporting.get(device.getErrorReportingType());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getExpirationDate() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getExpirationDate();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getFirstName() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getFirstName();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getFreezeEvents() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getFreezeEvents();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getMiddleInitial() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getMiddleInitial();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getParseDecodeData() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getParseDecodeData();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getPhysicalDeviceDescription() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getPhysicalDeviceDescription();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getPhysicalDeviceName() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getPhysicalDeviceName();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public PowerNotification getPowerNotify() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return powerNotification.get(device.getPowerNotify());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public PowerState getPowerState() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return powerState.get(device.getPowerState());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getServiceCode() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getServiceCode();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public ControlState getState() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        return controlState.get(device.getState());
    }

    public String getSuffix() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getSuffix();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getSurname() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getSurname();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getTitle() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getTitle();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public byte[] getTrack1Data() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getTrack1Data();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public byte[] getTrack1DiscretionaryData() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getTrack1DiscretionaryData();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public byte[] getTrack1EncryptedData() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getTrack1EncryptedData();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getTrack1EncryptedDataLength() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getTrack1EncryptedDataLength();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public byte[] getTrack2Data() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getTrack2Data();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public byte[] getTrack2DiscretionaryData() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getTrack2DiscretionaryData();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public byte[] getTrack2EncryptedData() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getTrack2EncryptedData();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getTrack2EncryptedDataLength() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getTrack2EncryptedDataLength();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public byte[] getTrack3Data() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getTrack3Data();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public byte[] getTrack3EncryptedData() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getTrack3EncryptedData();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getTrack3EncryptedDataLength() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getTrack3EncryptedDataLength();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public byte[] getTrack4Data() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getTrack4Data();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public byte[] getTrack4EncryptedData() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getTrack4EncryptedData();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getTrack4EncryptedDataLength() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getTrack4EncryptedDataLength();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public MSRTracks getTracksToRead() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return msrTracks.get(device.getTracksToRead());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public MSRTracks getTracksToWrite() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return msrTracks.get(device.getTracksToWrite());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getTransmitSentinels() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getTransmitSentinels();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getWriteCardType() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getWriteCardType();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void open(String endpointAddress) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.open(deviceName);
            if (endpointAddress != null)
            {
                try {
                    Service service = Service.create(
                            new URL(endpointAddress + "?wsdl"),
                            new QName("http://www.nrf-arts.org/UnifiedPOS/MSREvents/", "MSREventService"));
                    deviceEvent = service.getPort(org.nrf_arts.unifiedpos.msrevents.MSREvent.class);
                    device.addDataListener(this);
                    device.addDirectIOListener(this);
                    device.addErrorListener(this);
                    device.addStatusUpdateListener(this);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void release() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.release();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void resetStatistics(StatisticList statisticsBuffer) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            String param = null;
            List<Statistic> list = statisticsBuffer.getStatistic();
            switch (list.size()) {
                case 0:
                    param = "";
                    break;
                case 1:
                    String name = list.get(0).getName();
                    if (name.equals(StatisticCategories.ALL)) {
                        param = "";
                    }
                    else if (name.equals(StatisticCategories.MANUFACTURER)) {
                        param = "M_";
                    }
                    else if (name.equals(StatisticCategories.UPOS)) {
                        param = "U_";
                    }
                    else {
                        param = name;
                    }
                    break;
                default:
                    StringBuffer buffer = new StringBuffer();
                    for (Statistic statistic : statisticsBuffer.getStatistic()) {
                        buffer.append(",").append(statistic.getName());
                    }
                    param = buffer.substring(1);
                    break;
            }
            device.resetStatistics(param);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String retrieveCardProperty(String name) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            String[] param = new String[1];
            device.retrieveCardProperty(name, param);
            return param[0];
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public byte[] retrieveDeviceAuthenticationData() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            byte[] res = null;
            device.retrieveDeviceAuthenticationData(res);
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String retrieveStatistics(StatisticList statisticsBuffer) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            String[] param = new String[1];
            List<Statistic> list = statisticsBuffer.getStatistic();
            switch (list.size()) {
                case 0:
                    param[0] = "";
                    break;
                case 1:
                    String name = list.get(0).getName();
                    if (name.equals(StatisticCategories.ALL)) {
                        param[0] = "";
                    }
                    else if (name.equals(StatisticCategories.MANUFACTURER)) {
                        param[0] = "M_";
                    }
                    else if (name.equals(StatisticCategories.UPOS)) {
                        param[0] = "U_";
                    }
                    else {
                        param[0] = name;
                    }
                    break;
                default:
                    StringBuffer buffer = new StringBuffer();
                    for (Statistic statistic : statisticsBuffer.getStatistic()) {
                        buffer.append(",").append(statistic.getName());
                    }
                    param[0] = buffer.substring(1);
                    break;
            }
            device.retrieveStatistics(param);
            return param[0];
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setAutoDisable(Boolean autoDisable) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setAutoDisable(autoDisable);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setDataEncryptionAlgorithm(Integer dataEncryptionAlgorithm) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setDataEncryptionAlgorithm(dataEncryptionAlgorithm);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setDataEventEnabled(Boolean dataEventEnabled) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setDataEventEnabled(dataEventEnabled);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setDecodeData(Boolean decodeData) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setDecodeData(decodeData);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setDeviceEnabled(Boolean deviceEnabled) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setDeviceEnabled(deviceEnabled);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setErrorReportingType(MSRErrorReporting errorReportingType) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setErrorReportingType(jposConst.get(errorReportingType));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setFreezeEvents(Boolean freezeEvents) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setFreezeEvents(freezeEvents);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setParseDecodeData(Boolean parseDecodeData) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setParseDecodeData(parseDecodeData);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setPowerNotify(PowerNotification powerNotify) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setPowerNotify(jposConst.get(powerNotify));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setTracksToRead(MSRTracks tracksToRead) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setTracksToRead(jposConst.get(tracksToRead));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setTracksToWrite(MSRTracks tracksToWrite) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setTracksToWrite(jposConst.get(tracksToWrite));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setTransmitSentinels(Boolean transmitSentinels) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setTransmitSentinels(transmitSentinels);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setWriteCardType(String writeCardType) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setWriteCardType(writeCardType);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void updateFirmware(String firmwareFileName) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.updateFirmware(firmwareFileName);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void updateKey(String key, String keyName) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.updateKey(key, keyName);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void updateStatistics(StatisticList statisticsBuffer) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            String param = null;
            List<Statistic> list = statisticsBuffer.getStatistic();
            switch (list.size()) {
                case 0:
                    param = "";
                    break;
                case 1:
                    Statistic s = list.get(0);
                    String name = s.getName();
                    String value = s.getValue();
                    if (name.equals(StatisticCategories.ALL)) {
                        param = "=" + value;
                    }
                    else if (name.equals(StatisticCategories.MANUFACTURER)) {
                        param = "M_=" + value;
                    }
                    else if (name.equals(StatisticCategories.UPOS)) {
                        param = "U_=" + value;
                    }
                    else {
                        param = name + "=" + value;
                    }
                    break;
                default:
                    StringBuffer buffer = new StringBuffer();
                    for (Statistic statistic : statisticsBuffer.getStatistic()) {
                        buffer.append(",").append(statistic.getName()).append("=").append(statistic.getValue());
                    }
                    param = buffer.substring(1);
                    break;
            }
            device.updateStatistics(param);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void writeTracks(byte[] track1Data, byte[] track2Data, byte[] track3Data, byte[] track4Data, Integer timeout) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.writeTracks(new byte[][] { track1Data, track2Data, track3Data, track4Data }, timeout);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    //
    // MSREvent Member
    //

    public void dataOccurred(DataEvent de) {
        //throw new UnsupportedOperationException("Not supported yet.");
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(new Date(de.getWhen()));
        deviceEvent.dataEvent(
                de.getSource().toString(),
                (int)de.getSequenceNumber(),
                datatypeFactory.newXMLGregorianCalendar(cal),
                de.getStatus());
    }

    public void directIOOccurred(DirectIOEvent dioe) {
        //throw new UnsupportedOperationException("Not supported yet.");
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(new Date(dioe.getWhen()));
        org.nrf_arts.unifiedpos.msrevents.DirectIOData value = deviceEvent.directIOEvent(
                dioe.getSource().toString(),
                (int)dioe.getSequenceNumber(),
                datatypeFactory.newXMLGregorianCalendar(cal),
                dioe.getEventNumber(),
                dioe.getData(),
                dioe.getObject());
        dioe.setData(value.getData());
        dioe.setObject(value.getObj());
    }

    public void errorOccurred(ErrorEvent ee) {
        //throw new UnsupportedOperationException("Not supported yet.");
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(new Date(ee.getWhen()));
        org.nrf_arts.unifiedpos.msrevents.ErrorResponse value = deviceEvent.errorEvent(
                ee.getSource().toString(),
                (int)ee.getSequenceNumber(),
                datatypeFactory.newXMLGregorianCalendar(cal),
                eventErrorCode.get(ee.getErrorCode()),
                ee.getErrorCodeExtended(),
                eventErrorLocus.get(ee.getErrorLocus()),
                eventErrorResponse.get(ee.getErrorResponse()));
        ee.setErrorResponse(jposEventConst.get(value));
    }

    public void statusUpdateOccurred(StatusUpdateEvent sue) {
        //throw new UnsupportedOperationException("Not supported yet.");
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(new Date(sue.getWhen()));
        deviceEvent.statusUpdateEvent(
                sue.getSource().toString(),
                (int)sue.getSequenceNumber(),
                datatypeFactory.newXMLGregorianCalendar(cal),
                sue.getStatus());
    }

}
