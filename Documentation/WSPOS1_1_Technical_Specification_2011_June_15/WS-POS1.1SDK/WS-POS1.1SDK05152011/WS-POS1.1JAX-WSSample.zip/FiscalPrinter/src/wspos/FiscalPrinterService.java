/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package wspos;

import java.math.BigDecimal;
import java.net.URL;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.xml.datatype.XMLGregorianCalendar;
import jpos.events.DirectIOEvent;
import jpos.events.ErrorEvent;
import jpos.events.OutputCompleteEvent;
import jpos.events.StatusUpdateEvent;
import org.nrf_arts.unifiedpos.fiscalprinter.*;
import javax.jws.WebService;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.namespace.QName;
import javax.xml.ws.Service;

/**
 *
 * @author hideon
 */
@WebService(serviceName = "FiscalPrinterService", endpointInterface = "org.nrf_arts.unifiedpos.fiscalprinter.FiscalPrinter", targetNamespace = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/")
public class FiscalPrinterService implements FiscalPrinter, jpos.events.DirectIOListener, jpos.events.ErrorListener, jpos.events.OutputCompleteListener, jpos.events.StatusUpdateListener {

    //
    // FiscalPrinter Enumration Converter
    //

    private static HashMap<Enum, Integer> jposConst;
    private static HashMap<Integer, PowerReporting> powerReporting;
    private static HashMap<Integer, PowerNotification> powerNotification;
    private static HashMap<Integer, PowerState> powerState;
    private static HashMap<Integer, ControlState> controlState;
    private static HashMap<Integer, HealthCheckLevel> healthCheckLevel;
    private static HashMap<Integer, CompareFirmwareResult> compareFirmwareResult;
    private static HashMap<Integer, ErrorCode> errorCode;
    private static HashMap<Integer, FiscalCurrency> fiscalCurrency;
    private static HashMap<Integer, FiscalContractorID> fiscalContractorID;
    private static HashMap<Integer, FiscalDateType> fiscalDateType;
    private static HashMap<Integer, FiscalErrorLevel> fiscalErrorLevel;
    private static HashMap<Integer, FiscalPrinterState> fiscalPrinterState;
    private static HashMap<Integer, FiscalPrinterStations> fiscalPrinterStations;
    private static HashMap<Integer, FiscalReceiptStation> fiscalReceiptStation;
    private static HashMap<Integer, FiscalReceiptType> fiscalReceiptType;
    private static HashMap<Integer, FiscalMessageType> fiscalMessageType;
    private static HashMap<Integer, FiscalSlipSelection> fiscalSlipSelection;
    private static HashMap<Integer, FiscalTotalizerType> fiscalTotalizerType;
    private static HashMap<Integer, FiscalAdjustment> fiscalAdjustment;
    private static HashMap<Integer, FiscalAdjustmentType> fiscalAdjustmentType;
    private static HashMap<Integer, ReportType> reportType;
    private static HashMap<Integer, FiscalData> fiscalData;
    private static HashMap<Integer, FiscalTotalizer> fiscalTotalizer;

    private static HashMap<Enum, Integer> jposEventConst;
    private static HashMap<Integer, org.nrf_arts.unifiedpos.fiscalprinterevents.ErrorCode> eventErrorCode;
    private static HashMap<Integer, org.nrf_arts.unifiedpos.fiscalprinterevents.ErrorLocus> eventErrorLocus;
    private static HashMap<Integer, org.nrf_arts.unifiedpos.fiscalprinterevents.ErrorResponse> eventErrorResponse;

    static {
        jposConst = new HashMap<Enum, Integer>();
        jposConst.put(PowerReporting.ADVANCED, jpos.FiscalPrinter.JPOS_PR_ADVANCED);
        jposConst.put(PowerReporting.NONE, jpos.FiscalPrinter.JPOS_PR_NONE);
        jposConst.put(PowerReporting.STANDARD, jpos.FiscalPrinter.JPOS_PR_STANDARD);
        jposConst.put(PowerNotification.DISABLED, jpos.FiscalPrinter.JPOS_PN_DISABLED);
        jposConst.put(PowerNotification.ENABLED, jpos.FiscalPrinter.JPOS_PN_ENABLED);
        jposConst.put(PowerState.OFF, jpos.FiscalPrinter.JPOS_PS_OFF);
        jposConst.put(PowerState.OFFLINE, jpos.FiscalPrinter.JPOS_PS_OFFLINE);
        jposConst.put(PowerState.OFF_OFFLINE, jpos.FiscalPrinter.JPOS_PS_OFF_OFFLINE);
        jposConst.put(PowerState.ONLINE, jpos.FiscalPrinter.JPOS_PS_ONLINE);
        jposConst.put(PowerState.UNKNOWN, jpos.FiscalPrinter.JPOS_PS_UNKNOWN);
        jposConst.put(ControlState.BUSY, jpos.FiscalPrinter.JPOS_S_BUSY);
        jposConst.put(ControlState.CLOSED, jpos.FiscalPrinter.JPOS_S_CLOSED);
        jposConst.put(ControlState.ERROR, jpos.FiscalPrinter.JPOS_S_ERROR);
        jposConst.put(ControlState.IDLE, jpos.FiscalPrinter.JPOS_S_IDLE);
        jposConst.put(HealthCheckLevel.EXTERNAL, jpos.FiscalPrinter.JPOS_CH_EXTERNAL);
        jposConst.put(HealthCheckLevel.INTERACTIVE, jpos.FiscalPrinter.JPOS_CH_INTERACTIVE);
        jposConst.put(HealthCheckLevel.INTERNAL, jpos.FiscalPrinter.JPOS_CH_INTERNAL);
        jposConst.put(CompareFirmwareResult.DIFFERENT, jpos.FiscalPrinter.JPOS_CFV_FIRMWARE_DIFFERENT);
        jposConst.put(CompareFirmwareResult.NEWER, jpos.FiscalPrinter.JPOS_CFV_FIRMWARE_NEWER);
        jposConst.put(CompareFirmwareResult.OLDER, jpos.FiscalPrinter.JPOS_CFV_FIRMWARE_OLDER);
        jposConst.put(CompareFirmwareResult.SAME, jpos.FiscalPrinter.JPOS_CFV_FIRMWARE_SAME);
        jposConst.put(CompareFirmwareResult.UNKNOWN, jpos.FiscalPrinter.JPOS_CFV_FIRMWARE_UNKNOWN);
        jposConst.put(ErrorCode.BUSY, jpos.FiscalPrinter.JPOS_E_BUSY);
        jposConst.put(ErrorCode.CLAIMED, jpos.FiscalPrinter.JPOS_E_CLAIMED);
        jposConst.put(ErrorCode.CLOSED, jpos.FiscalPrinter.JPOS_E_CLOSED);
        jposConst.put(ErrorCode.DEPRECATED, jpos.FiscalPrinter.JPOS_E_DEPRECATED);
        jposConst.put(ErrorCode.DISABLED, jpos.FiscalPrinter.JPOS_E_DISABLED);
        jposConst.put(ErrorCode.EXISTS, jpos.FiscalPrinter.JPOS_E_EXISTS);
        jposConst.put(ErrorCode.EXTENDED, jpos.FiscalPrinter.JPOS_E_EXTENDED);
        jposConst.put(ErrorCode.FAILURE, jpos.FiscalPrinter.JPOS_E_FAILURE);
        jposConst.put(ErrorCode.ILLEGAL, jpos.FiscalPrinter.JPOS_E_ILLEGAL);
        jposConst.put(ErrorCode.NO_EXIST, jpos.FiscalPrinter.JPOS_E_NOEXIST);
        jposConst.put(ErrorCode.NO_HARDWARE, jpos.FiscalPrinter.JPOS_E_NOHARDWARE);
        jposConst.put(ErrorCode.NO_SERVICE, jpos.FiscalPrinter.JPOS_E_NOSERVICE);
        jposConst.put(ErrorCode.NOT_CLAIMED, jpos.FiscalPrinter.JPOS_E_NOTCLAIMED);
        jposConst.put(ErrorCode.OFFLINE, jpos.FiscalPrinter.JPOS_E_OFFLINE);
        jposConst.put(ErrorCode.SUCCESS, 0);
        jposConst.put(ErrorCode.TIMEOUT, jpos.FiscalPrinter.JPOS_E_TIMEOUT);
        jposConst.put(FiscalCurrency.BRAZILIAN_CRUCEIRO, jpos.FiscalPrinterConst.FPTR_AC_BGL);
        jposConst.put(FiscalCurrency.BULGARIAN_LEV, jpos.FiscalPrinterConst.FPTR_AC_BRC);
        jposConst.put(FiscalCurrency.CZECHIAN_KORUNA, jpos.FiscalPrinterConst.FPTR_AC_CZK);
        jposConst.put(FiscalCurrency.EURO, jpos.FiscalPrinterConst.FPTR_AC_EUR);
        jposConst.put(FiscalCurrency.GREEK_DRACHMA, jpos.FiscalPrinterConst.FPTR_AC_GRD);
        jposConst.put(FiscalCurrency.HUNGARIAN_FORINT, jpos.FiscalPrinterConst.FPTR_AC_HUF);
        jposConst.put(FiscalCurrency.ITALIAN_LIRA, jpos.FiscalPrinterConst.FPTR_AC_ITL);
        jposConst.put(FiscalCurrency.OTHER, jpos.FiscalPrinterConst.FPTR_AC_OTHER);
        jposConst.put(FiscalCurrency.POLISH_ZLOTY, jpos.FiscalPrinterConst.FPTR_AC_PLZ);
        jposConst.put(FiscalCurrency.ROMANIAN_LEU, jpos.FiscalPrinterConst.FPTR_AC_ROL);
        jposConst.put(FiscalCurrency.RUSSIAN_ROUBLE, jpos.FiscalPrinterConst.FPTR_AC_RUR);
        jposConst.put(FiscalCurrency.SWEDISH_KRONA, 13); //jpos.FiscalPrinterConst.FPTR_AC_SEK);
        jposConst.put(FiscalCurrency.TURKISH_LIRA, jpos.FiscalPrinterConst.FPTR_AC_TRL);
        jposConst.put(FiscalCurrency.UKRAINIAN_HRYVNIA, jpos.FiscalPrinterConst.FPTR_AC_UAH);
        jposConst.put(FiscalContractorID.FIRST, jpos.FiscalPrinterConst.FPTR_CID_FIRST);
        jposConst.put(FiscalContractorID.SECOND, jpos.FiscalPrinterConst.FPTR_CID_SECOND);
        jposConst.put(FiscalContractorID.SINGLE, jpos.FiscalPrinterConst.FPTR_CID_SINGLE);
        jposConst.put(FiscalDateType.CONFIGURATION, jpos.FiscalPrinterConst.FPTR_DT_CONF);
        jposConst.put(FiscalDateType.END_OF_DAY, jpos.FiscalPrinterConst.FPTR_DT_EOD);
        jposConst.put(FiscalDateType.REAL_TIME_CLOCK, jpos.FiscalPrinterConst.FPTR_DT_RTC);
        jposConst.put(FiscalDateType.RESET, jpos.FiscalPrinterConst.FPTR_DT_RESET);
        jposConst.put(FiscalDateType.START, jpos.FiscalPrinterConst.FPTR_DT_START);
        jposConst.put(FiscalDateType.VAT_CHANGE, jpos.FiscalPrinterConst.FPTR_DT_VAT);
        jposConst.put(FiscalErrorLevel.BLOCKED, jpos.FiscalPrinterConst.FPTR_EL_BLOCKED);
        jposConst.put(FiscalErrorLevel.FATAL, jpos.FiscalPrinterConst.FPTR_EL_FATAL);
        jposConst.put(FiscalErrorLevel.NONE, jpos.FiscalPrinterConst.FPTR_EL_NONE);
        jposConst.put(FiscalErrorLevel.RECOVERABLE, jpos.FiscalPrinterConst.FPTR_EL_RECOVERABLE);
        jposConst.put(FiscalPrinterState.FISCAL_DOCUMENT, jpos.FiscalPrinterConst.FPTR_PS_FISCAL_DOCUMENT);
        jposConst.put(FiscalPrinterState.FISCAL_RECEIPT, jpos.FiscalPrinterConst.FPTR_PS_FISCAL_RECEIPT);
        jposConst.put(FiscalPrinterState.FISCAL_RECEIPT_ENDING, jpos.FiscalPrinterConst.FPTR_PS_FISCAL_RECEIPT_ENDING);
        jposConst.put(FiscalPrinterState.FISCAL_RECEIPT_TOTAL, jpos.FiscalPrinterConst.FPTR_PS_FISCAL_RECEIPT_TOTAL);
        jposConst.put(FiscalPrinterState.FIXED_OUTPUT, jpos.FiscalPrinterConst.FPTR_PS_FIXED_OUTPUT);
        jposConst.put(FiscalPrinterState.ITEM_LIST, jpos.FiscalPrinterConst.FPTR_PS_ITEM_LIST);
        jposConst.put(FiscalPrinterState.LOCKED, jpos.FiscalPrinterConst.FPTR_PS_LOCKED);
        jposConst.put(FiscalPrinterState.MONITOR, jpos.FiscalPrinterConst.FPTR_PS_MONITOR);
        jposConst.put(FiscalPrinterState.NON_FISCAL, jpos.FiscalPrinterConst.FPTR_PS_NONFISCAL);
        jposConst.put(FiscalPrinterState.REPORT, jpos.FiscalPrinterConst.FPTR_PS_REPORT);
        jposConst.put(FiscalPrinterStations.JOURNAL, jpos.FiscalPrinterConst.FPTR_S_JOURNAL);
        jposConst.put(FiscalPrinterStations.JOURNAL_RECEIPT, jpos.FiscalPrinterConst.FPTR_S_JOURNAL_RECEIPT);
        jposConst.put(FiscalPrinterStations.JOURNAL_SLIP, 5); //jpos.FiscalPrinterConst.FPTR_S_JOURNAL_SLIP);
        jposConst.put(FiscalPrinterStations.RECEIPT, jpos.FiscalPrinterConst.FPTR_S_RECEIPT);
        jposConst.put(FiscalPrinterStations.RECEIPT_SLIP, 6); //jpos.FiscalPrinterConst.FPTR_S_RECEIPT_SLIP);
        jposConst.put(FiscalPrinterStations.SLIP, jpos.FiscalPrinterConst.FPTR_S_SLIP);
        jposConst.put(FiscalReceiptStation.RECEIPT, jpos.FiscalPrinterConst.FPTR_RS_RECEIPT);
        jposConst.put(FiscalReceiptStation.SLIP, jpos.FiscalPrinterConst.FPTR_RS_SLIP);
        jposConst.put(FiscalReceiptType.CASH_IN, jpos.FiscalPrinterConst.FPTR_RT_CASH_IN);
        jposConst.put(FiscalReceiptType.CASH_OUT, jpos.FiscalPrinterConst.FPTR_RT_CASH_OUT);
        jposConst.put(FiscalReceiptType.GENERIC, jpos.FiscalPrinterConst.FPTR_RT_GENERIC);
        jposConst.put(FiscalReceiptType.REFUND, jpos.FiscalPrinterConst.FPTR_RT_REFUND);
        jposConst.put(FiscalReceiptType.SALES, jpos.FiscalPrinterConst.FPTR_RT_SALES);
        jposConst.put(FiscalReceiptType.SERVICE, jpos.FiscalPrinterConst.FPTR_RT_SERVICE);
        jposConst.put(FiscalReceiptType.SIMPLE_INVOICE, jpos.FiscalPrinterConst.FPTR_RT_SIMPLE_INVOICE);
        jposConst.put(FiscalMessageType.ADVANCE, jpos.FiscalPrinterConst.FPTR_MT_ADVANCE);
        jposConst.put(FiscalMessageType.ADVANCE_PAID, jpos.FiscalPrinterConst.FPTR_MT_ADVANCE_PAID);
        jposConst.put(FiscalMessageType.AMOUNT_TO_BE_PAID, jpos.FiscalPrinterConst.FPTR_MT_AMOUNT_TO_BE_PAID);
        jposConst.put(FiscalMessageType.AMOUNT_TO_BE_PAID_BACK, jpos.FiscalPrinterConst.FPTR_MT_AMOUNT_TO_BE_PAID_BACK);
        jposConst.put(FiscalMessageType.CARD, jpos.FiscalPrinterConst.FPTR_MT_CARD);
        jposConst.put(FiscalMessageType.CARD_NUMBER, jpos.FiscalPrinterConst.FPTR_MT_CARD_NUMBER);
        jposConst.put(FiscalMessageType.CARD_TYPE, jpos.FiscalPrinterConst.FPTR_MT_CARD_TYPE);
        jposConst.put(FiscalMessageType.CASH, jpos.FiscalPrinterConst.FPTR_MT_CASH);
        jposConst.put(FiscalMessageType.CASHIER, jpos.FiscalPrinterConst.FPTR_MT_CASHIER);
        jposConst.put(FiscalMessageType.CASH_REGISTER_NUMBER, jpos.FiscalPrinterConst.FPTR_MT_CASH_REGISTER_NUMBER);
        jposConst.put(FiscalMessageType.CHANGE, jpos.FiscalPrinterConst.FPTR_MT_CHANGE);
        jposConst.put(FiscalMessageType.CHEQUE, jpos.FiscalPrinterConst.FPTR_MT_CHEQUE);
        jposConst.put(FiscalMessageType.CLIENT_NUMBER, jpos.FiscalPrinterConst.FPTR_MT_CLIENT_NUMBER);
        jposConst.put(FiscalMessageType.CLIENT_SIGNATURE, jpos.FiscalPrinterConst.FPTR_MT_CLIENT_SIGNATURE);
        jposConst.put(FiscalMessageType.COUNTER_STATE, jpos.FiscalPrinterConst.FPTR_MT_COUNTER_STATE);
        jposConst.put(FiscalMessageType.CREDIT_CARD, jpos.FiscalPrinterConst.FPTR_MT_CREDIT_CARD);
        jposConst.put(FiscalMessageType.CURRENCY, jpos.FiscalPrinterConst.FPTR_MT_CURRENCY);
        jposConst.put(FiscalMessageType.CURRENCY_VALUE, jpos.FiscalPrinterConst.FPTR_MT_CURRENCY_VALUE);
        jposConst.put(FiscalMessageType.DEPOSIT, jpos.FiscalPrinterConst.FPTR_MT_DEPOSIT);
        jposConst.put(FiscalMessageType.DEPOSIT_RETURNED, jpos.FiscalPrinterConst.FPTR_MT_DEPOSIT_RETURNED);
        jposConst.put(FiscalMessageType.DOT_LINE, jpos.FiscalPrinterConst.FPTR_MT_DOT_LINE);
        jposConst.put(FiscalMessageType.DRIVER_NUMBER, jpos.FiscalPrinterConst.FPTR_MT_DRIVER_NUMB);
        jposConst.put(FiscalMessageType.EMPTY_LINE, jpos.FiscalPrinterConst.FPTR_MT_EMPTY_LINE);
        jposConst.put(FiscalMessageType.FREE_TEXT, jpos.FiscalPrinterConst.FPTR_MT_FREE_TEXT);
        jposConst.put(FiscalMessageType.FREE_TEXT_WITH_DAY_LIMIT, jpos.FiscalPrinterConst.FPTR_MT_FREE_TEXT_WITH_DAY_LIMIT);
        jposConst.put(FiscalMessageType.GIVEN_DISCOUNT, jpos.FiscalPrinterConst.FPTR_MT_GIVEN_DISCOUNT);
        jposConst.put(FiscalMessageType.LOCAL_CREDIT, jpos.FiscalPrinterConst.FPTR_MT_LOCAL_CREDIT);
        jposConst.put(FiscalMessageType.MILEAGE_KILOMETERS, jpos.FiscalPrinterConst.FPTR_MT_MILEAGE_KM);
        jposConst.put(FiscalMessageType.NOTE, jpos.FiscalPrinterConst.FPTR_MT_NOTE);
        jposConst.put(FiscalMessageType.PAID, jpos.FiscalPrinterConst.FPTR_MT_PAID);
        jposConst.put(FiscalMessageType.PAY_IN, jpos.FiscalPrinterConst.FPTR_MT_PAY_IN);
        jposConst.put(FiscalMessageType.POINTS_BONUS, jpos.FiscalPrinterConst.FPTR_MT_POINTS_BONUS);
        jposConst.put(FiscalMessageType.POINTS_RECEIPT, jpos.FiscalPrinterConst.FPTR_MT_POINTS_RECEIPT);
        jposConst.put(FiscalMessageType.POINTS_TOTAL, jpos.FiscalPrinterConst.FPTR_MT_POINTS_TOTAL);
        jposConst.put(FiscalMessageType.POINT_GRANTED, jpos.FiscalPrinterConst.FPTR_MT_POINT_GRANTED);
        jposConst.put(FiscalMessageType.PROFITED, jpos.FiscalPrinterConst.FPTR_MT_PROFITED);
        jposConst.put(FiscalMessageType.RATE, jpos.FiscalPrinterConst.FPTR_MT_RATE);
        jposConst.put(FiscalMessageType.REGISTER_NUMBER, jpos.FiscalPrinterConst.FPTR_MT_REGISTER_NUMB);
        jposConst.put(FiscalMessageType.SHIFT_NUMBER, jpos.FiscalPrinterConst.FPTR_MT_SHIFT_NUMBER);
        jposConst.put(FiscalMessageType.STATE_OF_AN_ACCOUNT, jpos.FiscalPrinterConst.FPTR_MT_STATE_OF_AN_ACCOUNT);
        jposConst.put(FiscalMessageType.SUBSCRIPTION, jpos.FiscalPrinterConst.FPTR_MT_SUBSCRIPTION);
        jposConst.put(FiscalMessageType.TABLE, jpos.FiscalPrinterConst.FPTR_MT_TABLE);
        jposConst.put(FiscalMessageType.THANK_YOU_FOR_LOYALTY, jpos.FiscalPrinterConst.FPTR_MT_THANK_YOU_FOR_LOYALTY);
        jposConst.put(FiscalMessageType.TRANSACTION_NUMBER, jpos.FiscalPrinterConst.FPTR_MT_TRANSACTION_NUMB);
        jposConst.put(FiscalMessageType.VALID_TO, jpos.FiscalPrinterConst.FPTR_MT_VALID_TO);
        jposConst.put(FiscalMessageType.VOUCHER, jpos.FiscalPrinterConst.FPTR_MT_VOUCHER);
        jposConst.put(FiscalMessageType.VOUCHER_PAID, jpos.FiscalPrinterConst.FPTR_MT_VOUCHER_PAID);
        jposConst.put(FiscalMessageType.VOUCHER_VALUE, jpos.FiscalPrinterConst.FPTR_MT_VOUCHER_VALUE);
        jposConst.put(FiscalMessageType.WITHOUT_UPLIFT, jpos.FiscalPrinterConst.FPTR_MT_WITHOUT_UPLIFT);
        jposConst.put(FiscalMessageType.WITH_DISCOUNT, jpos.FiscalPrinterConst.FPTR_MT_WITH_DISCOUNT);
        jposConst.put(FiscalSlipSelection.FULL_LENGTH, jpos.FiscalPrinterConst.FPTR_SS_FULL_LENGTH);
        jposConst.put(FiscalSlipSelection.VALIDATION, jpos.FiscalPrinterConst.FPTR_SS_VALIDATION);
        jposConst.put(FiscalTotalizerType.DAY, jpos.FiscalPrinterConst.FPTR_TT_DAY);
        jposConst.put(FiscalTotalizerType.DOCUMENT, jpos.FiscalPrinterConst.FPTR_TT_DOCUMENT);
        jposConst.put(FiscalTotalizerType.GRAND, jpos.FiscalPrinterConst.FPTR_TT_GRAND);
        jposConst.put(FiscalTotalizerType.RECEIPT, jpos.FiscalPrinterConst.FPTR_TT_RECEIPT);
        jposConst.put(FiscalAdjustment.AMOUNT_DISCOUNT, jpos.FiscalPrinterConst.FPTR_AT_AMOUNT_DISCOUNT);
        jposConst.put(FiscalAdjustment.AMOUNT_SURCHARGE, jpos.FiscalPrinterConst.FPTR_AT_AMOUNT_SURCHARGE);
        jposConst.put(FiscalAdjustment.COUPON_AMOUNT_DISCOUNT, jpos.FiscalPrinterConst.FPTR_AT_COUPON_AMOUNT_DISCOUNT);
        jposConst.put(FiscalAdjustment.COUPON_PERCENTAGE_DISCOUNT, jpos.FiscalPrinterConst.FPTR_AT_COUPON_PERCENTAGE_DISCOUNT);
        jposConst.put(FiscalAdjustment.PERCENTAGE_DISCOUNT, jpos.FiscalPrinterConst.FPTR_AT_PERCENTAGE_DISCOUNT);
        jposConst.put(FiscalAdjustment.PERCENTAGE_SURCHARGE, jpos.FiscalPrinterConst.FPTR_AT_PERCENTAGE_SURCHARGE);
        jposConst.put(FiscalAdjustmentType.DISCOUNT, 1); //jpos.FiscalPrinterConst.FPTR_AT_DISCOUNT);
        jposConst.put(FiscalAdjustmentType.SURCHARGE, 2); //jpos.FiscalPrinterConst.FPTR_AT_SURCHARGE);
        jposConst.put(ReportType.DATE, jpos.FiscalPrinterConst.FPTR_RT_DATE);
        jposConst.put(ReportType.END_OF_DAY_ORDINAL, jpos.FiscalPrinterConst.FPTR_RT_EOD_ORDINAL);
        jposConst.put(ReportType.ORDINAL, jpos.FiscalPrinterConst.FPTR_RT_ORDINAL);
        jposConst.put(FiscalData.CURRENT_TOTAL, jpos.FiscalPrinterConst.FPTR_GD_CURRENT_TOTAL);
        jposConst.put(FiscalData.DAILY_TOTAL, jpos.FiscalPrinterConst.FPTR_GD_DAILY_TOTAL);
        jposConst.put(FiscalData.DESCRIPTION_LENGTH, jpos.FiscalPrinterConst.FPTR_GD_DESCRIPTION_LENGTH);
        jposConst.put(FiscalData.FIRMWARE, jpos.FiscalPrinterConst.FPTR_GD_FIRMWARE);
        jposConst.put(FiscalData.FISCAL_DOCUMENT, jpos.FiscalPrinterConst.FPTR_GD_FISCAL_DOC);
        jposConst.put(FiscalData.FISCAL_DOCUMENT_VOID, jpos.FiscalPrinterConst.FPTR_GD_FISCAL_DOC_VOID);
        jposConst.put(FiscalData.FISCAL_RECEIPT, jpos.FiscalPrinterConst.FPTR_GD_FISCAL_REC);
        jposConst.put(FiscalData.FISCAL_RECEIPT_VOID, jpos.FiscalPrinterConst.FPTR_GD_FISCAL_REC_VOID);
        jposConst.put(FiscalData.GRAND_TOTAL, jpos.FiscalPrinterConst.FPTR_GD_GRAND_TOTAL);
        jposConst.put(FiscalData.LINE_COUNT, jpos.FiscalPrinterConst.FPTR_GD_LINECOUNT);
        jposConst.put(FiscalData.NON_FISCAL_DOCUMENT, jpos.FiscalPrinterConst.FPTR_GD_NONFISCAL_DOC);
        jposConst.put(FiscalData.NON_FISCAL_DOCUMENT_VOID, jpos.FiscalPrinterConst.FPTR_GD_NONFISCAL_DOC_VOID);
        jposConst.put(FiscalData.NON_FISCAL_RECEIPT, jpos.FiscalPrinterConst.FPTR_GD_NONFISCAL_REC);
        jposConst.put(FiscalData.NOT_PAID, jpos.FiscalPrinterConst.FPTR_GD_NOT_PAID);
        jposConst.put(FiscalData.NUMBER_OF_CONFIGURATION_BLOCKS, jpos.FiscalPrinterConst.FPTR_GD_NUMB_CONFIG_BLOCK);
        jposConst.put(FiscalData.NUMBER_OF_CURRENCY_BLOCKS, jpos.FiscalPrinterConst.FPTR_GD_NUMB_CURRENCY_BLOCK);
        jposConst.put(FiscalData.NUMBER_OF_HEADER_BLOCKS, jpos.FiscalPrinterConst.FPTR_GD_NUMB_HDR_BLOCK);
        jposConst.put(FiscalData.NUMBER_OF_RESET_BLOCKS, jpos.FiscalPrinterConst.FPTR_GD_NUMB_RESET_BLOCK);
        jposConst.put(FiscalData.NUMBER_OF_VAT_BLOCKS, jpos.FiscalPrinterConst.FPTR_GD_NUMB_VAT_BLOCK);
        jposConst.put(FiscalData.NUMBER_OF_VOIDED_RECEIPTS, jpos.FiscalPrinterConst.FPTR_GD_MID_VOID);
        jposConst.put(FiscalData.PRINTER_ID, jpos.FiscalPrinterConst.FPTR_GD_PRINTER_ID);
        jposConst.put(FiscalData.RECEIPT_NUMBER, jpos.FiscalPrinterConst.FPTR_GD_RECEIPT_NUMBER);
        jposConst.put(FiscalData.REFUND, jpos.FiscalPrinterConst.FPTR_GD_REFUND);
        jposConst.put(FiscalData.REFUND_VOID, jpos.FiscalPrinterConst.FPTR_GD_REFUND_VOID);
        jposConst.put(FiscalData.RESTART, jpos.FiscalPrinterConst.FPTR_GD_RESTART);
        jposConst.put(FiscalData.SIMPLIFIED_INVOICE, jpos.FiscalPrinterConst.FPTR_GD_SIMP_INVOICE);
        jposConst.put(FiscalData.TENDER, jpos.FiscalPrinterConst.FPTR_GD_TENDER);
        jposConst.put(FiscalData.Z_REPORT, jpos.FiscalPrinterConst.FPTR_GD_Z_REPORT);
        jposConst.put(FiscalTotalizer.DISCOUNT, jpos.FiscalPrinterConst.FPTR_GT_DISCOUNT);
        jposConst.put(FiscalTotalizer.DISCOUNT_VOID, jpos.FiscalPrinterConst.FPTR_GT_DISCOUNT_VOID);
        jposConst.put(FiscalTotalizer.GROSS, jpos.FiscalPrinterConst.FPTR_GT_GROSS);
        jposConst.put(FiscalTotalizer.ITEM, jpos.FiscalPrinterConst.FPTR_GT_ITEM);
        jposConst.put(FiscalTotalizer.ITEM_VOID, jpos.FiscalPrinterConst.FPTR_GT_ITEM_VOID);
        jposConst.put(FiscalTotalizer.NET, jpos.FiscalPrinterConst.FPTR_GT_NET);
        jposConst.put(FiscalTotalizer.NOT_PAID, jpos.FiscalPrinterConst.FPTR_GT_NOT_PAID);
        jposConst.put(FiscalTotalizer.REFUND, jpos.FiscalPrinterConst.FPTR_GT_REFUND);
        jposConst.put(FiscalTotalizer.REFUND_VOID, jpos.FiscalPrinterConst.FPTR_GT_REFUND_VOID);
        jposConst.put(FiscalTotalizer.SUBTOTAL_DISCOUNT, jpos.FiscalPrinterConst.FPTR_GT_SUBTOTAL_DISCOUNT);
        jposConst.put(FiscalTotalizer.SUBTOTAL_DISCOUNT_VOID, jpos.FiscalPrinterConst.FPTR_GT_SUBTOTAL_DISCOUNT_VOID);
        jposConst.put(FiscalTotalizer.SUBTOTAL_SURCHARGES, jpos.FiscalPrinterConst.FPTR_GT_SUBTOTAL_SURCHARGES);
        jposConst.put(FiscalTotalizer.SUBTOTAL_SURCHARGES_VOID, jpos.FiscalPrinterConst.FPTR_GT_SURCHARGE_VOID);
        jposConst.put(FiscalTotalizer.SURCHARGE, jpos.FiscalPrinterConst.FPTR_GT_SURCHARGE);
        jposConst.put(FiscalTotalizer.SURCHARGE_VOID, jpos.FiscalPrinterConst.FPTR_GT_SURCHARGE_VOID);
        jposConst.put(FiscalTotalizer.VAT, jpos.FiscalPrinterConst.FPTR_GT_VAT);
        jposConst.put(FiscalTotalizer.VAT_CATEGORY, jpos.FiscalPrinterConst.FPTR_GT_VAT_CATEGORY);

        powerReporting = new HashMap<Integer, PowerReporting>();
        powerReporting.put(jpos.FiscalPrinter.JPOS_PR_ADVANCED, PowerReporting.ADVANCED);
        powerReporting.put(jpos.FiscalPrinter.JPOS_PR_NONE, PowerReporting.NONE);
        powerReporting.put(jpos.FiscalPrinter.JPOS_PR_STANDARD, PowerReporting.STANDARD);

        powerNotification = new HashMap<Integer, PowerNotification>();
        powerNotification.put(jpos.FiscalPrinter.JPOS_PN_DISABLED, PowerNotification.DISABLED);
        powerNotification.put(jpos.FiscalPrinter.JPOS_PN_ENABLED, PowerNotification.ENABLED);

        powerState = new HashMap<Integer, PowerState>();
        powerState.put(jpos.FiscalPrinter.JPOS_PS_OFF, PowerState.OFF);
        powerState.put(jpos.FiscalPrinter.JPOS_PS_OFFLINE, PowerState.OFFLINE);
        powerState.put(jpos.FiscalPrinter.JPOS_PS_OFF_OFFLINE, PowerState.OFF_OFFLINE);
        powerState.put(jpos.FiscalPrinter.JPOS_PS_ONLINE, PowerState.ONLINE);
        powerState.put(jpos.FiscalPrinter.JPOS_PS_UNKNOWN, PowerState.UNKNOWN);

        controlState = new HashMap<Integer, ControlState>();
        controlState.put(jpos.FiscalPrinter.JPOS_S_BUSY, ControlState.BUSY);
        controlState.put(jpos.FiscalPrinter.JPOS_S_CLOSED, ControlState.CLOSED);
        controlState.put(jpos.FiscalPrinter.JPOS_S_ERROR, ControlState.ERROR);
        controlState.put(jpos.FiscalPrinter.JPOS_S_IDLE, ControlState.IDLE);

        healthCheckLevel = new HashMap<Integer, HealthCheckLevel>();
        healthCheckLevel.put(jpos.FiscalPrinter.JPOS_CH_EXTERNAL, HealthCheckLevel.EXTERNAL);
        healthCheckLevel.put(jpos.FiscalPrinter.JPOS_CH_INTERACTIVE, HealthCheckLevel.INTERACTIVE);
        healthCheckLevel.put(jpos.FiscalPrinter.JPOS_CH_INTERNAL, HealthCheckLevel.INTERNAL);

        compareFirmwareResult = new HashMap<Integer, CompareFirmwareResult>();
        compareFirmwareResult.put(jpos.FiscalPrinter.JPOS_CFV_FIRMWARE_DIFFERENT, CompareFirmwareResult.DIFFERENT);
        compareFirmwareResult.put(jpos.FiscalPrinter.JPOS_CFV_FIRMWARE_NEWER, CompareFirmwareResult.NEWER);
        compareFirmwareResult.put(jpos.FiscalPrinter.JPOS_CFV_FIRMWARE_OLDER, CompareFirmwareResult.OLDER);
        compareFirmwareResult.put(jpos.FiscalPrinter.JPOS_CFV_FIRMWARE_SAME, CompareFirmwareResult.SAME);
        compareFirmwareResult.put(jpos.FiscalPrinter.JPOS_CFV_FIRMWARE_UNKNOWN, CompareFirmwareResult.UNKNOWN);

        errorCode = new HashMap<Integer, ErrorCode>();
        errorCode.put(jpos.FiscalPrinter.JPOS_E_BUSY, ErrorCode.BUSY);
        errorCode.put(jpos.FiscalPrinter.JPOS_E_CLAIMED, ErrorCode.CLAIMED);
        errorCode.put(jpos.FiscalPrinter.JPOS_E_CLOSED, ErrorCode.CLOSED);
        errorCode.put(jpos.FiscalPrinter.JPOS_E_DEPRECATED, ErrorCode.DEPRECATED);
        errorCode.put(jpos.FiscalPrinter.JPOS_E_DISABLED, ErrorCode.DISABLED);
        errorCode.put(jpos.FiscalPrinter.JPOS_E_EXISTS, ErrorCode.EXISTS);
        errorCode.put(jpos.FiscalPrinter.JPOS_E_EXTENDED, ErrorCode.EXTENDED);
        errorCode.put(jpos.FiscalPrinter.JPOS_E_FAILURE, ErrorCode.FAILURE);
        errorCode.put(jpos.FiscalPrinter.JPOS_E_ILLEGAL, ErrorCode.ILLEGAL);
        errorCode.put(jpos.FiscalPrinter.JPOS_E_NOEXIST, ErrorCode.NO_EXIST);
        errorCode.put(jpos.FiscalPrinter.JPOS_E_NOHARDWARE, ErrorCode.NO_HARDWARE);
        errorCode.put(jpos.FiscalPrinter.JPOS_E_NOSERVICE, ErrorCode.NO_SERVICE);
        errorCode.put(jpos.FiscalPrinter.JPOS_E_NOTCLAIMED, ErrorCode.NOT_CLAIMED);
        errorCode.put(jpos.FiscalPrinter.JPOS_E_OFFLINE, ErrorCode.OFFLINE);
        errorCode.put(0, ErrorCode.SUCCESS);
        errorCode.put(jpos.FiscalPrinter.JPOS_E_TIMEOUT, ErrorCode.TIMEOUT);

        fiscalCurrency = new HashMap<Integer, FiscalCurrency>();
        fiscalCurrency.put(jpos.FiscalPrinterConst.FPTR_AC_BGL, FiscalCurrency.BRAZILIAN_CRUCEIRO);
        fiscalCurrency.put(jpos.FiscalPrinterConst.FPTR_AC_BRC, FiscalCurrency.BULGARIAN_LEV);
        fiscalCurrency.put(jpos.FiscalPrinterConst.FPTR_AC_CZK, FiscalCurrency.CZECHIAN_KORUNA);
        fiscalCurrency.put(jpos.FiscalPrinterConst.FPTR_AC_EUR, FiscalCurrency.EURO);
        fiscalCurrency.put(jpos.FiscalPrinterConst.FPTR_AC_GRD, FiscalCurrency.GREEK_DRACHMA);
        fiscalCurrency.put(jpos.FiscalPrinterConst.FPTR_AC_HUF, FiscalCurrency.HUNGARIAN_FORINT);
        fiscalCurrency.put(jpos.FiscalPrinterConst.FPTR_AC_ITL, FiscalCurrency.ITALIAN_LIRA);
        fiscalCurrency.put(jpos.FiscalPrinterConst.FPTR_AC_OTHER, FiscalCurrency.OTHER);
        fiscalCurrency.put(jpos.FiscalPrinterConst.FPTR_AC_PLZ, FiscalCurrency.POLISH_ZLOTY);
        fiscalCurrency.put(jpos.FiscalPrinterConst.FPTR_AC_ROL, FiscalCurrency.ROMANIAN_LEU);
        fiscalCurrency.put(jpos.FiscalPrinterConst.FPTR_AC_RUR, FiscalCurrency.RUSSIAN_ROUBLE);
        fiscalCurrency.put(13, FiscalCurrency.SWEDISH_KRONA); //jpos.FiscalPrinterConst.FPTR_AC_SEK
        fiscalCurrency.put(jpos.FiscalPrinterConst.FPTR_AC_TRL, FiscalCurrency.TURKISH_LIRA);
        fiscalCurrency.put(jpos.FiscalPrinterConst.FPTR_AC_UAH, FiscalCurrency.UKRAINIAN_HRYVNIA);

        fiscalContractorID = new HashMap<Integer, FiscalContractorID>();
        fiscalContractorID.put(jpos.FiscalPrinterConst.FPTR_CID_FIRST, FiscalContractorID.FIRST);
        fiscalContractorID.put(jpos.FiscalPrinterConst.FPTR_CID_SECOND, FiscalContractorID.SECOND);
        fiscalContractorID.put(jpos.FiscalPrinterConst.FPTR_CID_SINGLE, FiscalContractorID.SINGLE);

        fiscalDateType = new HashMap<Integer, FiscalDateType>();
        fiscalDateType.put(jpos.FiscalPrinterConst.FPTR_DT_CONF, FiscalDateType.CONFIGURATION);
        fiscalDateType.put(jpos.FiscalPrinterConst.FPTR_DT_EOD, FiscalDateType.END_OF_DAY);
        fiscalDateType.put(jpos.FiscalPrinterConst.FPTR_DT_RTC, FiscalDateType.REAL_TIME_CLOCK);
        fiscalDateType.put(jpos.FiscalPrinterConst.FPTR_DT_RESET, FiscalDateType.RESET);
        fiscalDateType.put(jpos.FiscalPrinterConst.FPTR_DT_START, FiscalDateType.START);
        fiscalDateType.put(jpos.FiscalPrinterConst.FPTR_DT_VAT, FiscalDateType.VAT_CHANGE);

        fiscalErrorLevel = new HashMap<Integer, FiscalErrorLevel>();
        fiscalErrorLevel.put(jpos.FiscalPrinterConst.FPTR_EL_BLOCKED, FiscalErrorLevel.BLOCKED);
        fiscalErrorLevel.put(jpos.FiscalPrinterConst.FPTR_EL_FATAL, FiscalErrorLevel.FATAL);
        fiscalErrorLevel.put(jpos.FiscalPrinterConst.FPTR_EL_NONE, FiscalErrorLevel.NONE);
        fiscalErrorLevel.put(jpos.FiscalPrinterConst.FPTR_EL_RECOVERABLE, FiscalErrorLevel.RECOVERABLE);

        fiscalPrinterState = new HashMap<Integer, FiscalPrinterState>();
        fiscalPrinterState.put(jpos.FiscalPrinterConst.FPTR_PS_FISCAL_DOCUMENT, FiscalPrinterState.FISCAL_DOCUMENT);
        fiscalPrinterState.put(jpos.FiscalPrinterConst.FPTR_PS_FISCAL_RECEIPT, FiscalPrinterState.FISCAL_RECEIPT);
        fiscalPrinterState.put(jpos.FiscalPrinterConst.FPTR_PS_FISCAL_RECEIPT_ENDING, FiscalPrinterState.FISCAL_RECEIPT_ENDING);
        fiscalPrinterState.put(jpos.FiscalPrinterConst.FPTR_PS_FISCAL_RECEIPT_TOTAL, FiscalPrinterState.FISCAL_RECEIPT_TOTAL);
        fiscalPrinterState.put(jpos.FiscalPrinterConst.FPTR_PS_FIXED_OUTPUT, FiscalPrinterState.FIXED_OUTPUT);
        fiscalPrinterState.put(jpos.FiscalPrinterConst.FPTR_PS_ITEM_LIST, FiscalPrinterState.ITEM_LIST);
        fiscalPrinterState.put(jpos.FiscalPrinterConst.FPTR_PS_LOCKED, FiscalPrinterState.LOCKED);
        fiscalPrinterState.put(jpos.FiscalPrinterConst.FPTR_PS_MONITOR, FiscalPrinterState.MONITOR);
        fiscalPrinterState.put(jpos.FiscalPrinterConst.FPTR_PS_NONFISCAL, FiscalPrinterState.NON_FISCAL);
        fiscalPrinterState.put(jpos.FiscalPrinterConst.FPTR_PS_REPORT, FiscalPrinterState.REPORT);

        fiscalPrinterStations = new HashMap<Integer, FiscalPrinterStations>();
        fiscalPrinterStations.put(jpos.FiscalPrinterConst.FPTR_S_JOURNAL, FiscalPrinterStations.JOURNAL);
        fiscalPrinterStations.put(jpos.FiscalPrinterConst.FPTR_S_JOURNAL_RECEIPT, FiscalPrinterStations.JOURNAL_RECEIPT);
        fiscalPrinterStations.put(5, FiscalPrinterStations.JOURNAL_SLIP); //jpos.FiscalPrinterConst.FPTR_S_JOURNAL_SLIP
        fiscalPrinterStations.put(jpos.FiscalPrinterConst.FPTR_S_RECEIPT, FiscalPrinterStations.RECEIPT);
        fiscalPrinterStations.put(6, FiscalPrinterStations.RECEIPT_SLIP); //jpos.FiscalPrinterConst.FPTR_S_RECEIPT_SLIP
        fiscalPrinterStations.put(jpos.FiscalPrinterConst.FPTR_S_SLIP, FiscalPrinterStations.SLIP);

        fiscalReceiptStation = new HashMap<Integer, FiscalReceiptStation>();
        fiscalReceiptStation.put(jpos.FiscalPrinterConst.FPTR_RS_RECEIPT, FiscalReceiptStation.RECEIPT);
        fiscalReceiptStation.put(jpos.FiscalPrinterConst.FPTR_RS_SLIP, FiscalReceiptStation.SLIP);

        fiscalReceiptType = new HashMap<Integer, FiscalReceiptType>();
        fiscalReceiptType.put(jpos.FiscalPrinterConst.FPTR_RT_CASH_IN, FiscalReceiptType.CASH_IN);
        fiscalReceiptType.put(jpos.FiscalPrinterConst.FPTR_RT_CASH_OUT, FiscalReceiptType.CASH_OUT);
        fiscalReceiptType.put(jpos.FiscalPrinterConst.FPTR_RT_GENERIC, FiscalReceiptType.GENERIC);
        fiscalReceiptType.put(jpos.FiscalPrinterConst.FPTR_RT_REFUND, FiscalReceiptType.REFUND);
        fiscalReceiptType.put(jpos.FiscalPrinterConst.FPTR_RT_SALES, FiscalReceiptType.SALES);
        fiscalReceiptType.put(jpos.FiscalPrinterConst.FPTR_RT_SERVICE, FiscalReceiptType.SERVICE);
        fiscalReceiptType.put(jpos.FiscalPrinterConst.FPTR_RT_SIMPLE_INVOICE, FiscalReceiptType.SIMPLE_INVOICE);

        fiscalMessageType = new HashMap<Integer, FiscalMessageType>();
        fiscalMessageType.put(jpos.FiscalPrinterConst.FPTR_MT_ADVANCE, FiscalMessageType.ADVANCE);
        fiscalMessageType.put(jpos.FiscalPrinterConst.FPTR_MT_ADVANCE_PAID, FiscalMessageType.ADVANCE_PAID);
        fiscalMessageType.put(jpos.FiscalPrinterConst.FPTR_MT_AMOUNT_TO_BE_PAID, FiscalMessageType.AMOUNT_TO_BE_PAID);
        fiscalMessageType.put(jpos.FiscalPrinterConst.FPTR_MT_AMOUNT_TO_BE_PAID_BACK, FiscalMessageType.AMOUNT_TO_BE_PAID_BACK);
        fiscalMessageType.put(jpos.FiscalPrinterConst.FPTR_MT_CARD, FiscalMessageType.CARD);
        fiscalMessageType.put(jpos.FiscalPrinterConst.FPTR_MT_CARD_NUMBER, FiscalMessageType.CARD_NUMBER);
        fiscalMessageType.put(jpos.FiscalPrinterConst.FPTR_MT_CARD_TYPE, FiscalMessageType.CARD_TYPE);
        fiscalMessageType.put(jpos.FiscalPrinterConst.FPTR_MT_CASH, FiscalMessageType.CASH);
        fiscalMessageType.put(jpos.FiscalPrinterConst.FPTR_MT_CASHIER, FiscalMessageType.CASHIER);
        fiscalMessageType.put(jpos.FiscalPrinterConst.FPTR_MT_CASH_REGISTER_NUMBER, FiscalMessageType.CASH_REGISTER_NUMBER);
        fiscalMessageType.put(jpos.FiscalPrinterConst.FPTR_MT_CHANGE, FiscalMessageType.CHANGE);
        fiscalMessageType.put(jpos.FiscalPrinterConst.FPTR_MT_CHEQUE, FiscalMessageType.CHEQUE);
        fiscalMessageType.put(jpos.FiscalPrinterConst.FPTR_MT_CLIENT_NUMBER, FiscalMessageType.CLIENT_NUMBER);
        fiscalMessageType.put(jpos.FiscalPrinterConst.FPTR_MT_CLIENT_SIGNATURE, FiscalMessageType.CLIENT_SIGNATURE);
        fiscalMessageType.put(jpos.FiscalPrinterConst.FPTR_MT_COUNTER_STATE, FiscalMessageType.COUNTER_STATE);
        fiscalMessageType.put(jpos.FiscalPrinterConst.FPTR_MT_CREDIT_CARD, FiscalMessageType.CREDIT_CARD);
        fiscalMessageType.put(jpos.FiscalPrinterConst.FPTR_MT_CURRENCY, FiscalMessageType.CURRENCY);
        fiscalMessageType.put(jpos.FiscalPrinterConst.FPTR_MT_CURRENCY_VALUE, FiscalMessageType.CURRENCY_VALUE);
        fiscalMessageType.put(jpos.FiscalPrinterConst.FPTR_MT_DEPOSIT, FiscalMessageType.DEPOSIT);
        fiscalMessageType.put(jpos.FiscalPrinterConst.FPTR_MT_DEPOSIT_RETURNED, FiscalMessageType.DEPOSIT_RETURNED);
        fiscalMessageType.put(jpos.FiscalPrinterConst.FPTR_MT_DOT_LINE, FiscalMessageType.DOT_LINE);
        fiscalMessageType.put(jpos.FiscalPrinterConst.FPTR_MT_DRIVER_NUMB, FiscalMessageType.DRIVER_NUMBER);
        fiscalMessageType.put(jpos.FiscalPrinterConst.FPTR_MT_EMPTY_LINE, FiscalMessageType.EMPTY_LINE);
        fiscalMessageType.put(jpos.FiscalPrinterConst.FPTR_MT_FREE_TEXT, FiscalMessageType.FREE_TEXT);
        fiscalMessageType.put(jpos.FiscalPrinterConst.FPTR_MT_FREE_TEXT_WITH_DAY_LIMIT, FiscalMessageType.FREE_TEXT_WITH_DAY_LIMIT);
        fiscalMessageType.put(jpos.FiscalPrinterConst.FPTR_MT_GIVEN_DISCOUNT, FiscalMessageType.GIVEN_DISCOUNT);
        fiscalMessageType.put(jpos.FiscalPrinterConst.FPTR_MT_LOCAL_CREDIT, FiscalMessageType.LOCAL_CREDIT);
        fiscalMessageType.put(jpos.FiscalPrinterConst.FPTR_MT_MILEAGE_KM, FiscalMessageType.MILEAGE_KILOMETERS);
        fiscalMessageType.put(jpos.FiscalPrinterConst.FPTR_MT_NOTE, FiscalMessageType.NOTE);
        fiscalMessageType.put(jpos.FiscalPrinterConst.FPTR_MT_PAID, FiscalMessageType.PAID);
        fiscalMessageType.put(jpos.FiscalPrinterConst.FPTR_MT_PAY_IN, FiscalMessageType.PAY_IN);
        fiscalMessageType.put(jpos.FiscalPrinterConst.FPTR_MT_POINTS_BONUS, FiscalMessageType.POINTS_BONUS);
        fiscalMessageType.put(jpos.FiscalPrinterConst.FPTR_MT_POINTS_RECEIPT, FiscalMessageType.POINTS_RECEIPT);
        fiscalMessageType.put(jpos.FiscalPrinterConst.FPTR_MT_POINTS_TOTAL, FiscalMessageType.POINTS_TOTAL);
        fiscalMessageType.put(jpos.FiscalPrinterConst.FPTR_MT_POINT_GRANTED, FiscalMessageType.POINT_GRANTED);
        fiscalMessageType.put(jpos.FiscalPrinterConst.FPTR_MT_PROFITED, FiscalMessageType.PROFITED);
        fiscalMessageType.put(jpos.FiscalPrinterConst.FPTR_MT_RATE, FiscalMessageType.RATE);
        fiscalMessageType.put(jpos.FiscalPrinterConst.FPTR_MT_REGISTER_NUMB, FiscalMessageType.REGISTER_NUMBER);
        fiscalMessageType.put(jpos.FiscalPrinterConst.FPTR_MT_SHIFT_NUMBER, FiscalMessageType.SHIFT_NUMBER);
        fiscalMessageType.put(jpos.FiscalPrinterConst.FPTR_MT_STATE_OF_AN_ACCOUNT, FiscalMessageType.STATE_OF_AN_ACCOUNT);
        fiscalMessageType.put(jpos.FiscalPrinterConst.FPTR_MT_SUBSCRIPTION, FiscalMessageType.SUBSCRIPTION);
        fiscalMessageType.put(jpos.FiscalPrinterConst.FPTR_MT_TABLE, FiscalMessageType.TABLE);
        fiscalMessageType.put(jpos.FiscalPrinterConst.FPTR_MT_THANK_YOU_FOR_LOYALTY, FiscalMessageType.THANK_YOU_FOR_LOYALTY);
        fiscalMessageType.put(jpos.FiscalPrinterConst.FPTR_MT_TRANSACTION_NUMB, FiscalMessageType.TRANSACTION_NUMBER);
        fiscalMessageType.put(jpos.FiscalPrinterConst.FPTR_MT_VALID_TO, FiscalMessageType.VALID_TO);
        fiscalMessageType.put(jpos.FiscalPrinterConst.FPTR_MT_VOUCHER, FiscalMessageType.VOUCHER);
        fiscalMessageType.put(jpos.FiscalPrinterConst.FPTR_MT_VOUCHER_PAID, FiscalMessageType.VOUCHER_PAID);
        fiscalMessageType.put(jpos.FiscalPrinterConst.FPTR_MT_VOUCHER_VALUE, FiscalMessageType.VOUCHER_VALUE);
        fiscalMessageType.put(jpos.FiscalPrinterConst.FPTR_MT_WITHOUT_UPLIFT, FiscalMessageType.WITHOUT_UPLIFT);
        fiscalMessageType.put(jpos.FiscalPrinterConst.FPTR_MT_WITH_DISCOUNT, FiscalMessageType.WITH_DISCOUNT);

        fiscalSlipSelection = new HashMap<Integer, FiscalSlipSelection>();
        fiscalSlipSelection.put(jpos.FiscalPrinterConst.FPTR_SS_FULL_LENGTH, FiscalSlipSelection.FULL_LENGTH);
        fiscalSlipSelection.put(jpos.FiscalPrinterConst.FPTR_SS_VALIDATION, FiscalSlipSelection.VALIDATION);

        fiscalTotalizerType = new HashMap<Integer, FiscalTotalizerType>();
        fiscalTotalizerType.put(jpos.FiscalPrinterConst.FPTR_TT_DAY, FiscalTotalizerType.DAY);
        fiscalTotalizerType.put(jpos.FiscalPrinterConst.FPTR_TT_DOCUMENT, FiscalTotalizerType.DOCUMENT);
        fiscalTotalizerType.put(jpos.FiscalPrinterConst.FPTR_TT_GRAND, FiscalTotalizerType.GRAND);
        fiscalTotalizerType.put(jpos.FiscalPrinterConst.FPTR_TT_RECEIPT, FiscalTotalizerType.RECEIPT);

        fiscalAdjustment = new HashMap<Integer, FiscalAdjustment>();
        fiscalAdjustment.put(jpos.FiscalPrinterConst.FPTR_AT_AMOUNT_DISCOUNT, FiscalAdjustment.AMOUNT_DISCOUNT);
        fiscalAdjustment.put(jpos.FiscalPrinterConst.FPTR_AT_AMOUNT_SURCHARGE, FiscalAdjustment.AMOUNT_SURCHARGE);
        fiscalAdjustment.put(jpos.FiscalPrinterConst.FPTR_AT_COUPON_AMOUNT_DISCOUNT, FiscalAdjustment.COUPON_AMOUNT_DISCOUNT);
        fiscalAdjustment.put(jpos.FiscalPrinterConst.FPTR_AT_COUPON_PERCENTAGE_DISCOUNT, FiscalAdjustment.COUPON_PERCENTAGE_DISCOUNT);
        fiscalAdjustment.put(jpos.FiscalPrinterConst.FPTR_AT_PERCENTAGE_DISCOUNT, FiscalAdjustment.PERCENTAGE_DISCOUNT);
        fiscalAdjustment.put(jpos.FiscalPrinterConst.FPTR_AT_PERCENTAGE_SURCHARGE, FiscalAdjustment.PERCENTAGE_SURCHARGE);

        fiscalAdjustmentType = new HashMap<Integer, FiscalAdjustmentType>();
        fiscalAdjustmentType.put(1, FiscalAdjustmentType.DISCOUNT); //jpos.FiscalPrinterConst.FPTR_AT_DISCOUNT
        fiscalAdjustmentType.put(2, FiscalAdjustmentType.SURCHARGE); //jpos.FiscalPrinterConst.FPTR_AT_SURCHARGE

        reportType = new HashMap<Integer, ReportType>();
        reportType.put(jpos.FiscalPrinterConst.FPTR_RT_DATE, ReportType.DATE);
        reportType.put(jpos.FiscalPrinterConst.FPTR_RT_EOD_ORDINAL, ReportType.END_OF_DAY_ORDINAL);
        reportType.put(jpos.FiscalPrinterConst.FPTR_RT_ORDINAL, ReportType.ORDINAL);

        fiscalData = new HashMap<Integer, FiscalData>();
        fiscalData.put(jpos.FiscalPrinterConst.FPTR_GD_CURRENT_TOTAL, FiscalData.CURRENT_TOTAL);
        fiscalData.put(jpos.FiscalPrinterConst.FPTR_GD_DAILY_TOTAL, FiscalData.DAILY_TOTAL);
        fiscalData.put(jpos.FiscalPrinterConst.FPTR_GD_DESCRIPTION_LENGTH, FiscalData.DESCRIPTION_LENGTH);
        fiscalData.put(jpos.FiscalPrinterConst.FPTR_GD_FIRMWARE, FiscalData.FIRMWARE);
        fiscalData.put(jpos.FiscalPrinterConst.FPTR_GD_FISCAL_DOC, FiscalData.FISCAL_DOCUMENT);
        fiscalData.put(jpos.FiscalPrinterConst.FPTR_GD_FISCAL_DOC_VOID, FiscalData.FISCAL_DOCUMENT_VOID);
        fiscalData.put(jpos.FiscalPrinterConst.FPTR_GD_FISCAL_REC, FiscalData.FISCAL_RECEIPT);
        fiscalData.put(jpos.FiscalPrinterConst.FPTR_GD_FISCAL_REC_VOID, FiscalData.FISCAL_RECEIPT_VOID);
        fiscalData.put(jpos.FiscalPrinterConst.FPTR_GD_GRAND_TOTAL, FiscalData.GRAND_TOTAL);
        fiscalData.put(jpos.FiscalPrinterConst.FPTR_GD_LINECOUNT, FiscalData.LINE_COUNT);
        fiscalData.put(jpos.FiscalPrinterConst.FPTR_GD_NONFISCAL_DOC, FiscalData.NON_FISCAL_DOCUMENT);
        fiscalData.put(jpos.FiscalPrinterConst.FPTR_GD_NONFISCAL_DOC_VOID, FiscalData.NON_FISCAL_DOCUMENT_VOID);
        fiscalData.put(jpos.FiscalPrinterConst.FPTR_GD_NONFISCAL_REC, FiscalData.NON_FISCAL_RECEIPT);
        fiscalData.put(jpos.FiscalPrinterConst.FPTR_GD_NOT_PAID, FiscalData.NOT_PAID);
        fiscalData.put(jpos.FiscalPrinterConst.FPTR_GD_NUMB_CONFIG_BLOCK, FiscalData.NUMBER_OF_CONFIGURATION_BLOCKS);
        fiscalData.put(jpos.FiscalPrinterConst.FPTR_GD_NUMB_CURRENCY_BLOCK, FiscalData.NUMBER_OF_CURRENCY_BLOCKS);
        fiscalData.put(jpos.FiscalPrinterConst.FPTR_GD_NUMB_HDR_BLOCK, FiscalData.NUMBER_OF_HEADER_BLOCKS);
        fiscalData.put(jpos.FiscalPrinterConst.FPTR_GD_NUMB_RESET_BLOCK, FiscalData.NUMBER_OF_RESET_BLOCKS);
        fiscalData.put(jpos.FiscalPrinterConst.FPTR_GD_NUMB_VAT_BLOCK, FiscalData.NUMBER_OF_VAT_BLOCKS);
        fiscalData.put(jpos.FiscalPrinterConst.FPTR_GD_MID_VOID, FiscalData.NUMBER_OF_VOIDED_RECEIPTS);
        fiscalData.put(jpos.FiscalPrinterConst.FPTR_GD_PRINTER_ID, FiscalData.PRINTER_ID);
        fiscalData.put(jpos.FiscalPrinterConst.FPTR_GD_RECEIPT_NUMBER, FiscalData.RECEIPT_NUMBER);
        fiscalData.put(jpos.FiscalPrinterConst.FPTR_GD_REFUND, FiscalData.REFUND);
        fiscalData.put(jpos.FiscalPrinterConst.FPTR_GD_REFUND_VOID, FiscalData.REFUND_VOID);
        fiscalData.put(jpos.FiscalPrinterConst.FPTR_GD_RESTART, FiscalData.RESTART);
        fiscalData.put(jpos.FiscalPrinterConst.FPTR_GD_SIMP_INVOICE, FiscalData.SIMPLIFIED_INVOICE);
        fiscalData.put(jpos.FiscalPrinterConst.FPTR_GD_TENDER, FiscalData.TENDER);
        fiscalData.put(jpos.FiscalPrinterConst.FPTR_GD_Z_REPORT, FiscalData.Z_REPORT);

        fiscalTotalizer = new HashMap<Integer, FiscalTotalizer>();
        fiscalTotalizer.put(jpos.FiscalPrinterConst.FPTR_GT_DISCOUNT, FiscalTotalizer.DISCOUNT);
        fiscalTotalizer.put(jpos.FiscalPrinterConst.FPTR_GT_DISCOUNT_VOID, FiscalTotalizer.DISCOUNT_VOID);
        fiscalTotalizer.put(jpos.FiscalPrinterConst.FPTR_GT_GROSS, FiscalTotalizer.GROSS);
        fiscalTotalizer.put(jpos.FiscalPrinterConst.FPTR_GT_ITEM, FiscalTotalizer.ITEM);
        fiscalTotalizer.put(jpos.FiscalPrinterConst.FPTR_GT_ITEM_VOID, FiscalTotalizer.ITEM_VOID);
        fiscalTotalizer.put(jpos.FiscalPrinterConst.FPTR_GT_NET, FiscalTotalizer.NET);
        fiscalTotalizer.put(jpos.FiscalPrinterConst.FPTR_GT_NOT_PAID, FiscalTotalizer.NOT_PAID);
        fiscalTotalizer.put(jpos.FiscalPrinterConst.FPTR_GT_REFUND, FiscalTotalizer.REFUND);
        fiscalTotalizer.put(jpos.FiscalPrinterConst.FPTR_GT_REFUND_VOID, FiscalTotalizer.REFUND_VOID);
        fiscalTotalizer.put(jpos.FiscalPrinterConst.FPTR_GT_SUBTOTAL_DISCOUNT, FiscalTotalizer.SUBTOTAL_DISCOUNT);
        fiscalTotalizer.put(jpos.FiscalPrinterConst.FPTR_GT_SUBTOTAL_DISCOUNT_VOID, FiscalTotalizer.SUBTOTAL_DISCOUNT_VOID);
        fiscalTotalizer.put(jpos.FiscalPrinterConst.FPTR_GT_SUBTOTAL_SURCHARGES, FiscalTotalizer.SUBTOTAL_SURCHARGES);
        fiscalTotalizer.put(jpos.FiscalPrinterConst.FPTR_GT_SURCHARGE_VOID, FiscalTotalizer.SUBTOTAL_SURCHARGES_VOID);
        fiscalTotalizer.put(jpos.FiscalPrinterConst.FPTR_GT_SURCHARGE, FiscalTotalizer.SURCHARGE);
        fiscalTotalizer.put(jpos.FiscalPrinterConst.FPTR_GT_SURCHARGE_VOID, FiscalTotalizer.SURCHARGE_VOID);
        fiscalTotalizer.put(jpos.FiscalPrinterConst.FPTR_GT_VAT, FiscalTotalizer.VAT);
        fiscalTotalizer.put(jpos.FiscalPrinterConst.FPTR_GT_VAT_CATEGORY, FiscalTotalizer.VAT_CATEGORY);

        jposEventConst = new HashMap<Enum, Integer>();
        jposEventConst.put(org.nrf_arts.unifiedpos.fiscalprinterevents.ErrorCode.BUSY, jpos.FiscalPrinter.JPOS_E_BUSY);
        jposEventConst.put(org.nrf_arts.unifiedpos.fiscalprinterevents.ErrorCode.CLAIMED, jpos.FiscalPrinter.JPOS_E_CLAIMED);
        jposEventConst.put(org.nrf_arts.unifiedpos.fiscalprinterevents.ErrorCode.CLOSED, jpos.FiscalPrinter.JPOS_E_CLOSED);
        jposEventConst.put(org.nrf_arts.unifiedpos.fiscalprinterevents.ErrorCode.DEPRECATED, jpos.FiscalPrinter.JPOS_E_DEPRECATED);
        jposEventConst.put(org.nrf_arts.unifiedpos.fiscalprinterevents.ErrorCode.DISABLED, jpos.FiscalPrinter.JPOS_E_DISABLED);
        jposEventConst.put(org.nrf_arts.unifiedpos.fiscalprinterevents.ErrorCode.EXISTS, jpos.FiscalPrinter.JPOS_E_EXISTS);
        jposEventConst.put(org.nrf_arts.unifiedpos.fiscalprinterevents.ErrorCode.EXTENDED, jpos.FiscalPrinter.JPOS_E_EXTENDED);
        jposEventConst.put(org.nrf_arts.unifiedpos.fiscalprinterevents.ErrorCode.FAILURE, jpos.FiscalPrinter.JPOS_E_FAILURE);
        jposEventConst.put(org.nrf_arts.unifiedpos.fiscalprinterevents.ErrorCode.ILLEGAL, jpos.FiscalPrinter.JPOS_E_ILLEGAL);
        jposEventConst.put(org.nrf_arts.unifiedpos.fiscalprinterevents.ErrorCode.NO_EXIST, jpos.FiscalPrinter.JPOS_E_NOEXIST);
        jposEventConst.put(org.nrf_arts.unifiedpos.fiscalprinterevents.ErrorCode.NO_HARDWARE, jpos.FiscalPrinter.JPOS_E_NOHARDWARE);
        jposEventConst.put(org.nrf_arts.unifiedpos.fiscalprinterevents.ErrorCode.NO_SERVICE, jpos.FiscalPrinter.JPOS_E_NOSERVICE);
        jposEventConst.put(org.nrf_arts.unifiedpos.fiscalprinterevents.ErrorCode.NOT_CLAIMED, jpos.FiscalPrinter.JPOS_E_NOTCLAIMED);
        jposEventConst.put(org.nrf_arts.unifiedpos.fiscalprinterevents.ErrorCode.OFFLINE, jpos.FiscalPrinter.JPOS_E_OFFLINE);
        jposEventConst.put(org.nrf_arts.unifiedpos.fiscalprinterevents.ErrorCode.SUCCESS, 0);
        jposEventConst.put(org.nrf_arts.unifiedpos.fiscalprinterevents.ErrorCode.TIMEOUT, jpos.FiscalPrinter.JPOS_E_TIMEOUT);
        jposEventConst.put(org.nrf_arts.unifiedpos.fiscalprinterevents.ErrorLocus.INPUT, jpos.FiscalPrinter.JPOS_EL_INPUT);
        jposEventConst.put(org.nrf_arts.unifiedpos.fiscalprinterevents.ErrorLocus.INPUT_DATA, jpos.FiscalPrinter.JPOS_EL_INPUT_DATA);
        jposEventConst.put(org.nrf_arts.unifiedpos.fiscalprinterevents.ErrorLocus.OUTPUT, jpos.FiscalPrinter.JPOS_EL_OUTPUT);
        jposEventConst.put(org.nrf_arts.unifiedpos.fiscalprinterevents.ErrorResponse.CLEAR, jpos.FiscalPrinter.JPOS_ER_CLEAR);
        jposEventConst.put(org.nrf_arts.unifiedpos.fiscalprinterevents.ErrorResponse.CONTINUE_INPUT, jpos.FiscalPrinter.JPOS_ER_CONTINUEINPUT);
        jposEventConst.put(org.nrf_arts.unifiedpos.fiscalprinterevents.ErrorResponse.RETRY, jpos.FiscalPrinter.JPOS_ER_RETRY);

        eventErrorCode = new HashMap<Integer, org.nrf_arts.unifiedpos.fiscalprinterevents.ErrorCode>();
        eventErrorCode.put(jpos.FiscalPrinter.JPOS_E_BUSY, org.nrf_arts.unifiedpos.fiscalprinterevents.ErrorCode.BUSY);
        eventErrorCode.put(jpos.FiscalPrinter.JPOS_E_CLAIMED, org.nrf_arts.unifiedpos.fiscalprinterevents.ErrorCode.CLAIMED);
        eventErrorCode.put(jpos.FiscalPrinter.JPOS_E_CLOSED, org.nrf_arts.unifiedpos.fiscalprinterevents.ErrorCode.CLOSED);
        eventErrorCode.put(jpos.FiscalPrinter.JPOS_E_DEPRECATED, org.nrf_arts.unifiedpos.fiscalprinterevents.ErrorCode.DEPRECATED);
        eventErrorCode.put(jpos.FiscalPrinter.JPOS_E_DISABLED, org.nrf_arts.unifiedpos.fiscalprinterevents.ErrorCode.DISABLED);
        eventErrorCode.put(jpos.FiscalPrinter.JPOS_E_EXISTS, org.nrf_arts.unifiedpos.fiscalprinterevents.ErrorCode.EXISTS);
        eventErrorCode.put(jpos.FiscalPrinter.JPOS_E_EXTENDED, org.nrf_arts.unifiedpos.fiscalprinterevents.ErrorCode.EXTENDED);
        eventErrorCode.put(jpos.FiscalPrinter.JPOS_E_FAILURE, org.nrf_arts.unifiedpos.fiscalprinterevents.ErrorCode.FAILURE);
        eventErrorCode.put(jpos.FiscalPrinter.JPOS_E_ILLEGAL, org.nrf_arts.unifiedpos.fiscalprinterevents.ErrorCode.ILLEGAL);
        eventErrorCode.put(jpos.FiscalPrinter.JPOS_E_NOEXIST, org.nrf_arts.unifiedpos.fiscalprinterevents.ErrorCode.NO_EXIST);
        eventErrorCode.put(jpos.FiscalPrinter.JPOS_E_NOHARDWARE, org.nrf_arts.unifiedpos.fiscalprinterevents.ErrorCode.NO_HARDWARE);
        eventErrorCode.put(jpos.FiscalPrinter.JPOS_E_NOSERVICE, org.nrf_arts.unifiedpos.fiscalprinterevents.ErrorCode.NO_SERVICE);
        eventErrorCode.put(jpos.FiscalPrinter.JPOS_E_NOTCLAIMED, org.nrf_arts.unifiedpos.fiscalprinterevents.ErrorCode.NOT_CLAIMED);
        eventErrorCode.put(jpos.FiscalPrinter.JPOS_E_OFFLINE, org.nrf_arts.unifiedpos.fiscalprinterevents.ErrorCode.OFFLINE);
        eventErrorCode.put(0, org.nrf_arts.unifiedpos.fiscalprinterevents.ErrorCode.SUCCESS);
        eventErrorCode.put(jpos.FiscalPrinter.JPOS_E_TIMEOUT, org.nrf_arts.unifiedpos.fiscalprinterevents.ErrorCode.TIMEOUT);

        eventErrorLocus = new HashMap<Integer, org.nrf_arts.unifiedpos.fiscalprinterevents.ErrorLocus>();
        eventErrorLocus.put(jpos.FiscalPrinter.JPOS_EL_INPUT, org.nrf_arts.unifiedpos.fiscalprinterevents.ErrorLocus.INPUT);
        eventErrorLocus.put(jpos.FiscalPrinter.JPOS_EL_INPUT_DATA, org.nrf_arts.unifiedpos.fiscalprinterevents.ErrorLocus.INPUT_DATA);
        eventErrorLocus.put(jpos.FiscalPrinter.JPOS_EL_OUTPUT, org.nrf_arts.unifiedpos.fiscalprinterevents.ErrorLocus.OUTPUT);

        eventErrorResponse = new HashMap<Integer, org.nrf_arts.unifiedpos.fiscalprinterevents.ErrorResponse>();
        eventErrorResponse.put(jpos.FiscalPrinter.JPOS_ER_CLEAR, org.nrf_arts.unifiedpos.fiscalprinterevents.ErrorResponse.CLEAR);
        eventErrorResponse.put(jpos.FiscalPrinter.JPOS_ER_CONTINUEINPUT, org.nrf_arts.unifiedpos.fiscalprinterevents.ErrorResponse.CONTINUE_INPUT);
        eventErrorResponse.put(jpos.FiscalPrinter.JPOS_ER_RETRY, org.nrf_arts.unifiedpos.fiscalprinterevents.ErrorResponse.RETRY);
    }

    private String deviceName;
    private UposVersion deviceControlVersion;
    private org.nrf_arts.unifiedpos.fiscalprinterevents.FiscalPrinterEvent deviceEvent;
    private jpos.FiscalPrinter device = new jpos.FiscalPrinter();
    private DatatypeFactory datatypeFactory;
    private Pattern pattern = Pattern.compile("\\\\u([0-9a-fA-F]{4})|(\\\\\\\\)|(\\\\n)|(\\\\r)|(\\\\t)|(\\\\f)|(\\\\b)");

    private String processEscapeSequence(String data) {
        Matcher m = pattern.matcher(data);
        StringBuffer s = new StringBuffer();
        while (m.find()) {
            if (m.group(1) != null) {
                m.appendReplacement(s, String.valueOf((char)Integer.parseInt(m.group(1), 16)));
            }
            else if (m.group(2) != null) {
                m.appendReplacement(s, "\\\\");
            }
            else if (m.group(3) != null) {
                m.appendReplacement(s, "\n");
            }
            else if (m.group(4) != null) {
                m.appendReplacement(s, "\r");
            }
            else if (m.group(5) != null) {
                m.appendReplacement(s, "\t");
            }
            else if (m.group(6) != null) {
                m.appendReplacement(s, "\f");
            }
            else if (m.group(7) != null) {
                m.appendReplacement(s, "\b");
            }
        }
        m.appendTail(s);
        return s.toString();
    }

    public FiscalPrinterService(String logicalDeviceName) {
        deviceName = logicalDeviceName;
        deviceControlVersion = new UposVersion();
        deviceControlVersion.setMajor(1);
        deviceControlVersion.setMinor(13);
        deviceControlVersion.setBuild(1);
        try {
            datatypeFactory = DatatypeFactory.newInstance();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    //
    // FiscalPrinter Member
    //

    public void beginFiscalDocument(Integer documentAmount) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.beginFiscalDocument(documentAmount);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void beginFiscalReceipt(Boolean printHeader) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.beginFiscalReceipt(printHeader);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void beginFixedOutput(FiscalReceiptStation station, Integer documentType) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.beginFixedOutput(jposConst.get(station), documentType);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void beginInsertion(Integer timeout) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.beginInsertion(timeout);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void beginItemList(Integer vatID) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.beginItemList(vatID);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void beginNonFiscal() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.beginNonFiscal();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void beginRemoval(Integer timeout) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.beginRemoval(timeout);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void beginTraining() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.beginTraining();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void checkHealth(HealthCheckLevel level) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.checkHealth(jposConst.get(level));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void claim(Integer timeout) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.claim(timeout);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void clearError() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.clearError();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void clearOutput() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.clearOutput();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void close(String endpointAddress) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            if (deviceEvent != null)
            {
                device.removeDirectIOListener(this);
                device.removeErrorListener(this);
                device.removeOutputCompleteListener(this);
                device.removeStatusUpdateListener(this);
                deviceEvent = null;
            }
            device.close();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public CompareFirmwareResult compareFirmwareVersion(String firmwareFileName) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            int[] param = new int[1];
            device.compareFirmwareVersion(firmwareFileName, param);
            return compareFirmwareResult.get(param[0]);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public DirectIOData directIO(Integer command, Integer data, Object obj) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            DirectIOData res = new DirectIOData();
            int[] param = new int[] { data };
            device.directIO(command, param, obj);
            res.setData(param[0]);
            res.setObj(obj);
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void endFiscalDocument() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.endFiscalDocument();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void endFiscalReceipt(Boolean printHeader) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.endFiscalReceipt(printHeader);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void endFixedOutput() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.endFixedOutput();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void endInsertion() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.endInsertion();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void endItemList() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.endItemList();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void endNonFiscal() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.endNonFiscal();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void endRemoval() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.endRemoval();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void endTraining() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.endTraining();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public FiscalCurrency getActualCurrency() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return fiscalCurrency.get(device.getActualCurrency());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getAdditionalHeader() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getAdditionalHeader();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getAdditionalTrailer() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getAdditionalTrailer();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getAmountDecimalPlaces() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getAmountDecimalPlaces();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getAsyncMode() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getAsyncMode();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapAdditionalHeader() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapAdditionalHeader();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapAdditionalLines() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapAdditionalLines();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapAdditionalTrailer() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapAdditionalTrailer();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapAmountAdjustment() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapAmountAdjustment();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapChangeDue() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapChangeDue();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapCheckTotal() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapCheckTotal();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapCompareFirmwareVersion() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapCompareFirmwareVersion();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapCoverSensor() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapCoverSensor();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapDoubleWidth() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapDoubleWidth();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapDuplicateReceipt() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapDuplicateReceipt();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapEmptyReceiptIsVoidable() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapEmptyReceiptIsVoidable();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapFiscalReceiptStation() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapFiscalReceiptStation();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapFiscalReceiptType() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapFiscalReceiptType();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapFixedOutput() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapFixedOutput();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapHasVatTable() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapHasVatTable();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapIndependentHeader() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapIndependentHeader();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapItemList() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapItemList();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapJrnEmptySensor() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapJrnEmptySensor();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapJrnNearEndSensor() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapJrnNearEndSensor();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapJrnPresent() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapJrnPresent();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapMultiContractor() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapMultiContractor();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapNonFiscalMode() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapNonFiscalMode();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapOnlyVoidLastItem() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapOnlyVoidLastItem();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapOrderAdjustmentFirst() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapOrderAdjustmentFirst();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapPackageAdjustment() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapPackageAdjustment();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapPercentAdjustment() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapPercentAdjustment();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapPositiveAdjustment() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapPositiveAdjustment();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapPositiveSubtotalAdjustment() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapPositiveSubtotalAdjustment();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapPostPreLine() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapPostPreLine();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapPowerLossReport() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapPowerLossReport();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public PowerReporting getCapPowerReporting() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return powerReporting.get(device.getCapPowerReporting());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapPredefinedPaymentLines() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapPredefinedPaymentLines();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapRecEmptySensor() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapRecEmptySensor();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapRecNearEndSensor() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapRecNearEndSensor();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapRecPresent() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapRecPresent();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapReceiptNotPaid() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapReceiptNotPaid();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapRemainingFiscalMemory() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapRemainingFiscalMemory();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapReservedWord() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapReservedWord();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapSetCurrency() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapSetCurrency();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapSetHeader() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapSetHeader();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapSetPOSID() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapSetPOSID();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapSetStoreFiscalID() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapSetStoreFiscalID();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapSetTrailer() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapSetTrailer();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapSetVatTable() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapSetVatTable();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapSlpEmptySensor() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapSlpEmptySensor();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapSlpFiscalDocument() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapSlpFiscalDocument();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapSlpFullSlip() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapSlpFullSlip();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapSlpNearEndSensor() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapSlpNearEndSensor();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapSlpPresent() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapSlpPresent();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapSlpValidation() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapSlpValidation();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapStatisticsReporting() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapStatisticsReporting();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapSubAmountAdjustment() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapSubAmountAdjustment();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapSubPercentAdjustment() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapSubPercentAdjustment();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapSubtotal() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapSubtotal();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapTotalizerType() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapTotalizerType();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapTrainingMode() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapTrainingMode();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapUpdateFirmware() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapUpdateFirmware();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapUpdateStatistics() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapUpdateStatistics();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapValidateJournal() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapValidateJournal();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapXReport() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapXReport();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getChangeDue() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getChangeDue();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getCheckHealthText() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCheckHealthText();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCheckTotal() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCheckTotal();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getClaimed() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getClaimed();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public FiscalContractorID getContractorID() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return fiscalContractorID.get(device.getContractorId());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getCountryCode() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCountryCode();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCoverOpen() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCoverOpen();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public FiscalDataItem getData(FiscalData dataItem, Integer optArgs) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            FiscalDataItem res = new FiscalDataItem();
            int[] opt = new int[] { optArgs };
            String[] data = new String[1];
            device.getData(jposConst.get(dataItem), opt, data);
            res.setItemOption(opt[0]);
            res.setData(data[0]);
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public XMLGregorianCalendar getDate() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            String[] res = new String[1];
            device.getDate(res);
            GregorianCalendar cal = new GregorianCalendar();
            int date = Integer.valueOf(res[0].substring(0, 2));
            int month = Integer.valueOf(res[0].substring(2, 2)) - 1;
            int year = Integer.valueOf(res[0].substring(4, 4));
            int hourOfDay = Integer.valueOf(res[0].substring(8, 2));
            int minute = Integer.valueOf(res[0].substring(10, 2));
            cal.set(year, month, date, hourOfDay, minute);
            return datatypeFactory.newXMLGregorianCalendar(cal);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public FiscalDateType getDateType() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return fiscalDateType.get(device.getDateType());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getDayOpened() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getDayOpened();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getDescriptionLength() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getDescriptionLength();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getDeviceControlDescription() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        return device.getDeviceControlDescription();
    }

    public UposVersion getDeviceControlVersion() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        UposVersion res = new UposVersion();
        int version = device.getDeviceControlVersion();
        res.setMajor(version / 1000000 % 1000);
        res.setMinor(version / 1000 % 1000);
        res.setBuild(version % 1000);
        return res;
    }

    public Boolean getDeviceEnabled() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getDeviceEnabled();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getDeviceServiceDescription() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getDeviceServiceDescription();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public UposVersion getDeviceServiceVersion() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            UposVersion res = new UposVersion();
            int version = device.getDeviceServiceVersion();
            res.setMajor(version / 1000000 % 1000);
            res.setMinor(version / 1000 % 1000);
            res.setBuild(version % 1000);
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getDuplicateReceipt() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getDuplicateReceipt();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public FiscalErrorLevel getErrorLevel() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return fiscalErrorLevel.get(device.getErrorLevel());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getErrorOutID() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getErrorOutID();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public FiscalPrinterState getErrorState() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return fiscalPrinterState.get(device.getErrorState());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public FiscalPrinterStations getErrorStation() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return fiscalPrinterStations.get(device.getErrorStation());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getErrorString() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getErrorString();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public FiscalReceiptStation getFiscalReceiptStation() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return fiscalReceiptStation.get(device.getFiscalReceiptStation());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public FiscalReceiptType getFiscalReceiptType() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return fiscalReceiptType.get(device.getFiscalReceiptType());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getFlagWhenIdle() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getFlagWhenIdle();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getFreezeEvents() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getFreezeEvents();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getJrnEmpty() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getJrnEmpty();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getJrnNearEnd() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getJrnNearEnd();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getMessageLength() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getMessageLength();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public FiscalMessageType getMessageType() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return fiscalMessageType.get(device.getMessageType());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getNumHeaderLines() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getNumHeaderLines();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getNumTrailerLines() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getNumTrailerLines();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getNumVatRates() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getNumVatRates();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getOutputID() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getOutputID();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getPhysicalDeviceDescription() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getPhysicalDeviceDescription();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getPhysicalDeviceName() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getPhysicalDeviceName();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getPostLine() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getPostLine();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public PowerNotification getPowerNotify() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return powerNotification.get(device.getPowerNotify());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public PowerState getPowerState() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return powerState.get(device.getPowerState());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getPreLine() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getPreLine();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public PaymentLinesList getPredefinedPaymentLines() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            PaymentLinesList res = new PaymentLinesList();
            List<String> list = res.getPaymentLines();
            for (String s : device.getPredefinedPaymentLines().split(",")) {
                list.add(s);
            }
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public FiscalPrinterState getPrinterState() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return fiscalPrinterState.get(device.getPrinterState());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getQuantityDecimalPlaces() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getQuantityDecimalPlaces();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getQuantityLength() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getQuantityLength();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getRecEmpty() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getRecEmpty();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getRecNearEnd() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getRecNearEnd();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getRemainingFiscalMemory() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getRemainingFiscalMemory();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getReservedWord() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getReservedWord();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public FiscalSlipSelection getSlipSelection() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return fiscalSlipSelection.get(device.getSlipSelection());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getSlpEmpty() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getSlpEmpty();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getSlpNearEnd() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getSlpNearEnd();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public ControlState getState() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        return controlState.get(device.getState());
    }

    public String getTotalizer(Integer vatID, FiscalTotalizer optArgs) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            String[] res = new String[1];
            device.getTotalizer(vatID, jposConst.get(optArgs), res);
            return res[0];
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public FiscalTotalizerType getTotalizerType() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return fiscalTotalizerType.get(device.getTotalizerType());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getTrainingModeActive() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getTrainingModeActive();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getVatEntry(Integer vatID, Integer optArgs) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            int[] res = new int[1];
            device.getVatEntry(vatID, optArgs, res);
            return res[0];
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void open(String endpointAddress) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.open(deviceName);
            if (endpointAddress != null)
            {
                try {
                    Service service = Service.create(
                            new URL(endpointAddress + "?wsdl"),
                            new QName("http://www.nrf-arts.org/UnifiedPOS/FiscalPrinterEvents/", "FiscalPrinterEventService"));
                    deviceEvent = service.getPort(org.nrf_arts.unifiedpos.fiscalprinterevents.FiscalPrinterEvent.class);
                    device.addDirectIOListener(this);
                    device.addErrorListener(this);
                    device.addOutputCompleteListener(this);
                    device.addStatusUpdateListener(this);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void printDuplicateReceipt() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.printDuplicateReceipt();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void printFiscalDocumentLine(String documentLine) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.printFiscalDocumentLine(documentLine);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void printFixedOutput(Integer documentType, Integer lineNumber, String data) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.printFixedOutput(documentType, lineNumber, data);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void printNormal(FiscalPrinterStations station, String data) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.printNormal(jposConst.get(station), processEscapeSequence(data));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void printPeriodicTotalsReport(XMLGregorianCalendar date1, XMLGregorianCalendar date2) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            GregorianCalendar cal = date1.toGregorianCalendar();
            int day = cal.get(GregorianCalendar.DAY_OF_MONTH);
            int month = cal.get(GregorianCalendar.MONTH) + 1;
            int year = cal.get(GregorianCalendar.YEAR);
            int hour = cal.get(GregorianCalendar.HOUR_OF_DAY);
            int minute = cal.get(GregorianCalendar.MINUTE);
            StringBuffer start = new StringBuffer();
            start.append(day / 10).append(day % 10).append(month / 10).append(month % 10).append(year).
                    append(hour / 10).append(hour % 10).append(minute / 10).append(minute % 10);
            cal = date2.toGregorianCalendar();
            day = cal.get(GregorianCalendar.DAY_OF_MONTH);
            month = cal.get(GregorianCalendar.MONTH) + 1;
            year = cal.get(GregorianCalendar.YEAR);
            hour = cal.get(GregorianCalendar.HOUR_OF_DAY);
            minute = cal.get(GregorianCalendar.MINUTE);
            StringBuffer end = new StringBuffer();
            end.append(day / 10).append(day % 10).append(month / 10).append(month % 10).append(year).
                    append(hour / 10).append(hour % 10).append(minute / 10).append(minute % 10);
            device.printPeriodicTotalsReport(start.toString(), end.toString());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void printPowerLossReport() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.printPowerLossReport();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void printRecCash(BigDecimal amount) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.printRecCash(amount.scaleByPowerOfTen(4).longValue());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void printRecItem(String description, BigDecimal price, Integer quantity, Integer vatInfo, BigDecimal unitPrice, String unitName) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.printRecItem(description, price.scaleByPowerOfTen(4).longValue(), quantity, vatInfo, unitPrice.scaleByPowerOfTen(4).longValue(), unitName);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void printRecItemAdjustment(FiscalAdjustment adjustmentType, String description, BigDecimal amount, Integer vatInfo) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.printRecItemAdjustment(jposConst.get(adjustmentType), description, amount.scaleByPowerOfTen(4).longValue(), vatInfo);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void printRecItemAdjustmentVoid(FiscalAdjustment adjustmentType, String description, BigDecimal amount, Integer vatInfo) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.printRecItemAdjustmentVoid(jposConst.get(adjustmentType), description, amount.scaleByPowerOfTen(4).longValue(), vatInfo);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void printRecItemFuel(String description, BigDecimal price, Integer quantity, Integer vatInfo, BigDecimal unitPrice, String unitName, BigDecimal specialTax, String specialTaxName) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.printRecItemFuel(description, price.scaleByPowerOfTen(4).longValue(), quantity, vatInfo, unitPrice.scaleByPowerOfTen(4).longValue(), unitName, specialTax.scaleByPowerOfTen(4).longValue(), specialTaxName);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void printRecItemFuelVoid(String description, BigDecimal price, Integer vatInfo, BigDecimal specialTax) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.printRecItemFuelVoid(description, price.scaleByPowerOfTen(4).longValue(), vatInfo, specialTax.scaleByPowerOfTen(4).longValue());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void printRecItemRefund(String description, BigDecimal amount, Integer quantity, Integer vatInfo, BigDecimal unitAmount, String unitName) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.printRecItemRefund(description, amount.scaleByPowerOfTen(4).longValue(), quantity, vatInfo, unitAmount.scaleByPowerOfTen(4).longValue(), unitName);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void printRecItemRefundVoid(String description, BigDecimal amount, Integer quantity, Integer vatInfo, BigDecimal unitAmount, String unitName) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.printRecItemRefundVoid(description, amount.scaleByPowerOfTen(4).longValue(), quantity, vatInfo, unitAmount.scaleByPowerOfTen(4).longValue(), unitName);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void printRecItemVoid(String description, BigDecimal price, Integer quantity, Integer vatInfo, BigDecimal unitPrice, String unitName) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.printRecItemVoid(description, price.scaleByPowerOfTen(4).longValue(), quantity, vatInfo, unitPrice.scaleByPowerOfTen(4).longValue(), unitName);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void printRecMessage(String message) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.printRecMessage(message);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void printRecNotPaid(String description, BigDecimal amount) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.printRecNotPaid(description, amount.scaleByPowerOfTen(4).longValue());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void printRecPackageAdjustVoid(FiscalAdjustmentType adjustmentType, VatInfoList vatAdjustments) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            StringBuffer s = new StringBuffer();
            for (VatInfo v : vatAdjustments.getVatInfo()) {
                s.append(",").append(v.getID()).append(",").append(v.getAmount());
            }
            device.printRecPackageAdjustVoid(jposConst.get(adjustmentType), s.substring(1));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void printRecPackageAdjustment(FiscalAdjustmentType adjustmentType, String description, VatInfoList vatAdjustments) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            StringBuffer s = new StringBuffer();
            for (VatInfo v : vatAdjustments.getVatInfo()) {
                s.append(",").append(v.getID()).append(",").append(v.getAmount());
            }
            device.printRecPackageAdjustment(jposConst.get(adjustmentType), description, s.substring(1));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void printRecRefund(String description, BigDecimal amount, Integer vatInfo) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.printRecRefund(description, amount.scaleByPowerOfTen(4).longValue(), vatInfo);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void printRecRefundVoid(String description, BigDecimal amount, Integer vatInfo) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.printRecRefundVoid(description, amount.scaleByPowerOfTen(4).longValue(), vatInfo);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void printRecSubtotal(BigDecimal amount) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.printRecSubtotal(amount.scaleByPowerOfTen(4).longValue());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void printRecSubtotalAdjustVoid(FiscalAdjustment adjustmentType, BigDecimal amount) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.printRecSubtotalAdjustVoid(jposConst.get(adjustmentType), amount.scaleByPowerOfTen(4).longValue());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void printRecSubtotalAdjustment(FiscalAdjustment adjustmentType, String description, BigDecimal amount) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.printRecSubtotalAdjustment(jposConst.get(adjustmentType), description, amount.scaleByPowerOfTen(4).longValue());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void printRecTaxID(String taxID) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.printRecTaxID(taxID);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void printRecTotal(BigDecimal total, BigDecimal payment, String description) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.printRecTotal(total.scaleByPowerOfTen(4).longValue(), payment.scaleByPowerOfTen(4).longValue(), description);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void printRecVoid(String description) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.printRecVoid(description);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void printReport(ReportType reportType, String startNum, String endNum) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.printReport(jposConst.get(reportType), startNum, endNum);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void printXReport() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.printXReport();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void printZReport() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.printZReport();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void release() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.release();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void resetPrinter() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.resetPrinter();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void resetStatistics(StatisticList statisticsBuffer) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            String param = null;
            List<Statistic> list = statisticsBuffer.getStatistic();
            switch (list.size()) {
                case 0:
                    param = "";
                    break;
                case 1:
                    String name = list.get(0).getName();
                    if (name.equals(StatisticCategories.ALL)) {
                        param = "";
                    }
                    else if (name.equals(StatisticCategories.MANUFACTURER)) {
                        param = "M_";
                    }
                    else if (name.equals(StatisticCategories.UPOS)) {
                        param = "U_";
                    }
                    else {
                        param = name;
                    }
                    break;
                default:
                    StringBuffer buffer = new StringBuffer();
                    for (Statistic statistic : statisticsBuffer.getStatistic()) {
                        buffer.append(",").append(statistic.getName());
                    }
                    param = buffer.substring(1);
                    break;
            }
            device.resetStatistics(param);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String retrieveStatistics(StatisticList statisticsBuffer) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            String[] param = new String[1];
            List<Statistic> list = statisticsBuffer.getStatistic();
            switch (list.size()) {
                case 0:
                    param[0] = "";
                    break;
                case 1:
                    String name = list.get(0).getName();
                    if (name.equals(StatisticCategories.ALL)) {
                        param[0] = "";
                    }
                    else if (name.equals(StatisticCategories.MANUFACTURER)) {
                        param[0] = "M_";
                    }
                    else if (name.equals(StatisticCategories.UPOS)) {
                        param[0] = "U_";
                    }
                    else {
                        param[0] = name;
                    }
                    break;
                default:
                    StringBuffer buffer = new StringBuffer();
                    for (Statistic statistic : statisticsBuffer.getStatistic()) {
                        buffer.append(",").append(statistic.getName());
                    }
                    param[0] = buffer.substring(1);
                    break;
            }
            device.retrieveStatistics(param);
            return param[0];
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setAdditionalHeader(String additionalHeader) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setAdditionalHeader(additionalHeader);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setAdditionalTrailer(String additionalTrailer) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setAdditionalTrailer(additionalTrailer);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setAsyncMode(Boolean asyncMode) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setAsyncMode(asyncMode);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setChangeDue(String changeDue) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setChangeDue(changeDue);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setCheckTotal(Boolean checkTotal) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setCheckTotal(checkTotal);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setContractorID(FiscalContractorID contractorID) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setContractorId(jposConst.get(contractorID));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setCurrency(FiscalCurrency newCurrency) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setCurrency(jposConst.get(newCurrency));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setDate(XMLGregorianCalendar date) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            GregorianCalendar cal = date.toGregorianCalendar();
            int day = cal.get(GregorianCalendar.DAY_OF_MONTH);
            int month = cal.get(GregorianCalendar.MONTH) + 1;
            int year = cal.get(GregorianCalendar.YEAR);
            int hour = cal.get(GregorianCalendar.HOUR_OF_DAY);
            int minute = cal.get(GregorianCalendar.MINUTE);
            StringBuffer s = new StringBuffer();
            s.append(day / 10).append(day % 10).append(month / 10).append(month % 10).append(year).
                    append(hour / 10).append(hour % 10).append(minute / 10).append(minute % 10);
            device.setDate(s.toString());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setDateType(FiscalDateType dateType) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setDateType(jposConst.get(dateType));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setDeviceEnabled(Boolean deviceEnabled) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setDeviceEnabled(deviceEnabled);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setDuplicateReceipt(Boolean duplicateReceipt) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setDuplicateReceipt(duplicateReceipt);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setFiscalReceiptStation(FiscalReceiptStation fiscalReceiptStation) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setFiscalReceiptStation(jposConst.get(fiscalReceiptStation));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setFiscalReceiptType(FiscalReceiptType fiscalReceiptType) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setFiscalReceiptType(jposConst.get(fiscalReceiptType));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setFlagWhenIdle(Boolean flagWhenIdle) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setFlagWhenIdle(flagWhenIdle);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setFreezeEvents(Boolean freezeEvents) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setFreezeEvents(freezeEvents);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setHeaderLine(Integer lineNumber, String text, Boolean doubleWidth) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setHeaderLine(lineNumber, text, doubleWidth);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setMessageType(FiscalMessageType messageType) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setMessageType(jposConst.get(messageType));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setPOSID(String posID, String cashierID) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setPOSID(posID, cashierID);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setPostLine(String postLine) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setPostLine(postLine);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setPowerNotify(PowerNotification powerNotify) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setPowerNotify(jposConst.get(powerNotify));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setPreLine(String preLine) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setPreLine(preLine);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setSlipSelection(FiscalSlipSelection slipSelection) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setSlipSelection(jposConst.get(slipSelection));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setStoreFiscalID(String id) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setStoreFiscalID(id);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setTotalizerType(FiscalTotalizerType totalizerType) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setTotalizerType(jposConst.get(totalizerType));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setTrailerLine(Integer lineNumber, String text, Boolean doubleWidth) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setTrailerLine(lineNumber, text, doubleWidth);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setVatTable() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setVatTable();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setVatValue(Integer vatID, String vatValue) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setVatValue(vatID, vatValue);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void updateFirmware(String firmwareFileName) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.updateFirmware(firmwareFileName);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void updateStatistics(StatisticList statisticsBuffer) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            String param = null;
            List<Statistic> list = statisticsBuffer.getStatistic();
            switch (list.size()) {
                case 0:
                    param = "";
                    break;
                case 1:
                    Statistic s = list.get(0);
                    String name = s.getName();
                    String value = s.getValue();
                    if (name.equals(StatisticCategories.ALL)) {
                        param = "=" + value;
                    }
                    else if (name.equals(StatisticCategories.MANUFACTURER)) {
                        param = "M_=" + value;
                    }
                    else if (name.equals(StatisticCategories.UPOS)) {
                        param = "U_=" + value;
                    }
                    else {
                        param = name + "=" + value;
                    }
                    break;
                default:
                    StringBuffer buffer = new StringBuffer();
                    for (Statistic statistic : statisticsBuffer.getStatistic()) {
                        buffer.append(",").append(statistic.getName()).append("=").append(statistic.getValue());
                    }
                    param = buffer.substring(1);
                    break;
            }
            device.updateStatistics(param);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void verifyItem(String itemName, Integer vatID) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.verifyItem(itemName, vatID);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    //
    // FiscalPrinterEvent Member
    //

    public void directIOOccurred(DirectIOEvent dioe) {
        //throw new UnsupportedOperationException("Not supported yet.");
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(new Date(dioe.getWhen()));
        org.nrf_arts.unifiedpos.fiscalprinterevents.DirectIOData value = deviceEvent.directIOEvent(
                dioe.getSource().toString(),
                (int)dioe.getSequenceNumber(),
                datatypeFactory.newXMLGregorianCalendar(cal),
                dioe.getEventNumber(),
                dioe.getData(),
                dioe.getObject());
        dioe.setData(value.getData());
        dioe.setObject(value.getObj());
    }

    public void errorOccurred(ErrorEvent ee) {
        //throw new UnsupportedOperationException("Not supported yet.");
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(new Date(ee.getWhen()));
        org.nrf_arts.unifiedpos.fiscalprinterevents.ErrorResponse value = deviceEvent.errorEvent(
                ee.getSource().toString(),
                (int)ee.getSequenceNumber(),
                datatypeFactory.newXMLGregorianCalendar(cal),
                eventErrorCode.get(ee.getErrorCode()),
                ee.getErrorCodeExtended(),
                eventErrorLocus.get(ee.getErrorLocus()),
                eventErrorResponse.get(ee.getErrorResponse()));
        ee.setErrorResponse(jposEventConst.get(value));
    }

    public void outputCompleteOccurred(OutputCompleteEvent oce) {
        //throw new UnsupportedOperationException("Not supported yet.");
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(new Date(oce.getWhen()));
        deviceEvent.statusUpdateEvent(
                oce.getSource().toString(),
                (int)oce.getSequenceNumber(),
                datatypeFactory.newXMLGregorianCalendar(cal),
                oce.getOutputID());
    }

    public void statusUpdateOccurred(StatusUpdateEvent sue) {
        //throw new UnsupportedOperationException("Not supported yet.");
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(new Date(sue.getWhen()));
        deviceEvent.statusUpdateEvent(
                sue.getSource().toString(),
                (int)sue.getSequenceNumber(),
                datatypeFactory.newXMLGregorianCalendar(cal),
                sue.getStatus());
    }

}
