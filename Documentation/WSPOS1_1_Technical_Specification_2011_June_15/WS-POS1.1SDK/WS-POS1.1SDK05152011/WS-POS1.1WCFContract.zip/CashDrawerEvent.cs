﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace UnifiedPOS.CashDrawerEvents
{
    [ServiceContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CashDrawerEvents/")]
    public interface CashDrawerEvent
    {

        //
        // Events
        //

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashDrawerEvents/DataEvent", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashDrawerEvents/DataEventResponse")]
        // void DataEvent(string Source, int EventID, DateTime TimeStamp, int Status);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashDrawerEvents/DirectIOEvent", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashDrawerEvents/DirectIOEventResponse")]
        DirectIOData DirectIOEvent(string Source, int EventID, DateTime TimeStamp, int EventNumber, int Data, object Obj);

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashDrawerEvents/ErrorEvent", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashDrawerEvents/ErrorEventResponse")]
        // ErrorResponse ErrorEvent(string Source, int EventID, DateTime TimeStamp, ErrorCode ErrorCode, int ErrorCodeExtended, ErrorLocus ErrorLocus, ErrorResponse ErrorResponse);

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashDrawerEvents/OutputCompleteEvent", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashDrawerEvents/OutputCompleteEventResponse")]
        // void OutputCompleteEvent(string Source, int EventID, DateTime TimeStamp, int OutputID);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashDrawerEvents/StatusUpdateEvent", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashDrawerEvents/StatusUpdateEventResponse")]
        void StatusUpdateEvent(string Source, int EventID, DateTime TimeStamp, int Status);
    }

    //
    // Common Data Types
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CashDrawerEvents/")]
    public class DirectIOData
    {
        [DataMember]
        public int Data { get; set; }
        [DataMember]
        public object Obj { get; set; }
    }

    //
    // Common Enumerations
    //

    /*
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CashDrawerEvents/")]
    public enum ErrorCode
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Claimed,
        [EnumMember]
        Closed,
        [EnumMember]
        Deprecated,
        [EnumMember]
        Disabled,
        [EnumMember]
        Exists,
        [EnumMember]
        Extended,
        [EnumMember]
        Failure,
        [EnumMember]
        Illegal,
        [EnumMember]
        NoExist,
        [EnumMember]
        NoHardware,
        [EnumMember]
        NoService,
        [EnumMember]
        NotClaimed,
        [EnumMember]
        Offline,
        [EnumMember]
        Success,
        [EnumMember]
        Timeout,
    }
    */

    /*
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CashDrawerEvents/")]
    public enum ErrorLocus
    {
        [EnumMember]
        Input,
        [EnumMember]
        InputData,
        [EnumMember]
        Output,
    }
    */

    /*
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CashDrawerEvents/")]
    public enum ErrorResponse
    {
        [EnumMember]
        Clear,
        [EnumMember]
        ContinueInput,
        [EnumMember]
        Retry,
    }
    */

    //
    // Specific Data Types
    //

    //
    // Specific Enumerations
    //

    //
    // Constants
    //

    /*
    public class Constants
    {
        public const int StatusClosed = 0;
        public const int StatusOpen = 1;
        public const int StatusPowerOff = 2002;
        public const int StatusPowerOffline = 2003;
        public const int StatusPowerOffOffline = 2004;
        public const int StatusPowerOnline = 2001;
        public const int StatusUpdateFirmwareComplete = 2200;
        public const int StatusUpdateFirmwareCompleteDeviceNotRestored = 2205;
        public const int StatusUpdateFirmwareFailedDeviceNeedsFirmware = 2203;
        public const int StatusUpdateFirmwareFailedDeviceOk = 2201;
        public const int StatusUpdateFirmwareFailedDeviceUnknown = 2204;
        public const int StatusUpdateFirmwareFailedDeviceUnrecoverable = 2202;
        public const int StatusUpdateFirmwareProgress = 2100;
    }
    */

    public class Status
    {
        public const int Closed = 0;
        public const int Open = 1;
        public const int PowerOff = 2002;
        public const int PowerOffline = 2003;
        public const int PowerOffOffline = 2004;
        public const int PowerOnline = 2001;
        public const int UpdateFirmwareComplete = 2200;
        public const int UpdateFirmwareCompleteDeviceNotRestored = 2205;
        public const int UpdateFirmwareFailedDeviceNeedsFirmware = 2203;
        public const int UpdateFirmwareFailedDeviceOk = 2201;
        public const int UpdateFirmwareFailedDeviceUnknown = 2204;
        public const int UpdateFirmwareFailedDeviceUnrecoverable = 2202;
        public const int UpdateFirmwareProgress = 2100;
    }
}
