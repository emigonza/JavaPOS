@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.nrf-arts.org/UnifiedPOS/Belt/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package org.nrf_arts.unifiedpos.belt;
