
package org.nrf_arts.unifiedpos.billdispenserevents;

public class Status {
    public static final int ASYNC = 91;
    public static final int EMPTY = 11;
    public static final int EMPTY_OK = 13;
    public static final int JAM = 31;
    public static final int JAM_OK = 32;
    public static final int NEAR_EMPTY = 12;
    public static final int MOTION_ABSENT = 2;
    public static final int MOTION_PRESENT = 1;
    public static final int POWER_OFF = 2002;
    public static final int POWER_OFFLINE = 2003;
    public static final int POWER_OFF_OFFLINE = 2004;
    public static final int POWER_ONLINE = 2001;
    public static final int UPDATE_FIRMWARE_COMPLETE = 2200;
    public static final int UPDATE_FIRMWARE_COMPLETE_DEVICE_NOT_RESTORED = 2205;
    public static final int UPDATE_FIRMWARE_FAILED_DEVICE_NEEDS_FIRMWARE = 2203;
    public static final int UPDATE_FIRMWARE_FAILED_DEVICE_OK = 2201;
    public static final int UPDATE_FIRMWARE_FAILED_DEVICE_UNKNOWN = 2204;
    public static final int UPDATE_FIRMWARE_FAILED_DEVICE_UNRECOVERABLE = 2202;
    public static final int UPDATE_FIRMWARE_PROGRESS = 2100;

}
