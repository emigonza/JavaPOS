
package org.nrf_arts.unifiedpos.billacceptor;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for HealthCheckLevel.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="HealthCheckLevel">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="External"/>
 *     &lt;enumeration value="Interactive"/>
 *     &lt;enumeration value="Internal"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "HealthCheckLevel")
@XmlEnum
public enum HealthCheckLevel {

    @XmlEnumValue("External")
    EXTERNAL("External"),
    @XmlEnumValue("Interactive")
    INTERACTIVE("Interactive"),
    @XmlEnumValue("Internal")
    INTERNAL("Internal");
    private final String value;

    HealthCheckLevel(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static HealthCheckLevel fromValue(String v) {
        for (HealthCheckLevel c: HealthCheckLevel.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
