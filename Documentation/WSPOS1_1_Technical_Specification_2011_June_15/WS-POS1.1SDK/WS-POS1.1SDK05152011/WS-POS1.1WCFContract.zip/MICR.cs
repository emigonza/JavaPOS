﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace UnifiedPOS.MICR
{
    [ServiceContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/MICR/")]
    public interface MICR
    {

        //
        // Common Properties
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetAutoDisableResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/UposException", Name = "UposException")]
        bool GetAutoDisable();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/SetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MICR/SetAutoDisableResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/UposException", Name = "UposException")]
        void SetAutoDisable(bool AutoDisable);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetCapCompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetCapCompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/UposException", Name = "UposException")]
        bool GetCapCompareFirmwareVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetCapPowerReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetCapPowerReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/UposException", Name = "UposException")]
        PowerReporting GetCapPowerReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetCapStatisticsReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetCapStatisticsReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/UposException", Name = "UposException")]
        bool GetCapStatisticsReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetCapUpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetCapUpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/UposException", Name = "UposException")]
        bool GetCapUpdateFirmware();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetCapUpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetCapUpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/UposException", Name = "UposException")]
        bool GetCapUpdateStatistics();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetCheckHealthText", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetCheckHealthTextResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/UposException", Name = "UposException")]
        string GetCheckHealthText();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetClaimed", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetClaimedResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/UposException", Name = "UposException")]
        bool GetClaimed();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetDataCount", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetDataCountResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/UposException", Name = "UposException")]
        int GetDataCount();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetDataEventEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/UposException", Name = "UposException")]
        bool GetDataEventEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/SetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MICR/SetDataEventEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/UposException", Name = "UposException")]
        void SetDataEventEnabled(bool DataEventEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/UposException", Name = "UposException")]
        bool GetDeviceEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/SetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MICR/SetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/UposException", Name = "UposException")]
        void SetDeviceEnabled(bool DeviceEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/UposException", Name = "UposException")]
        bool GetFreezeEvents();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/SetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MICR/SetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/UposException", Name = "UposException")]
        void SetFreezeEvents(bool FreezeEvents);

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetOutputID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetOutputIDResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/UposException", Name = "UposException")]
        // int GetOutputID();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/UposException", Name = "UposException")]
        PowerNotification GetPowerNotify();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/SetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MICR/SetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/UposException", Name = "UposException")]
        void SetPowerNotify(PowerNotification PowerNotify);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetPowerState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetPowerStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/UposException", Name = "UposException")]
        PowerState GetPowerState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/UposException", Name = "UposException")]
        ControlState GetState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetDeviceControlDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetDeviceControlDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/UposException", Name = "UposException")]
        string GetDeviceControlDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetDeviceControlVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetDeviceControlVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/UposException", Name = "UposException")]
        UposVersion GetDeviceControlVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetDeviceServiceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetDeviceServiceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/UposException", Name = "UposException")]
        string GetDeviceServiceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetDeviceServiceVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetDeviceServiceVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/UposException", Name = "UposException")]
        UposVersion GetDeviceServiceVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetPhysicalDeviceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetPhysicalDeviceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/UposException", Name = "UposException")]
        string GetPhysicalDeviceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetPhysicalDeviceName", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetPhysicalDeviceNameResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/UposException", Name = "UposException")]
        string GetPhysicalDeviceName();

        //
        // Specific Properties
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetAccountNumber", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetAccountNumberResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/UposException", Name = "UposException")]
        string GetAccountNumber();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetAmount", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetAmountResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/UposException", Name = "UposException")]
        string GetAmount();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetBankNumber", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetBankNumberResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/UposException", Name = "UposException")]
        string GetBankNumber();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetCapValidationDevice", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetCapValidationDeviceResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/UposException", Name = "UposException")]
        bool GetCapValidationDevice();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetCheckType", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetCheckTypeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/UposException", Name = "UposException")]
        CheckType GetCheckType();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetCountryCode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetCountryCodeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/UposException", Name = "UposException")]
        CheckCountryCode GetCountryCode();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetEPC", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetEPCResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/UposException", Name = "UposException")]
        string GetEPC();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetRawData", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetRawDataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/UposException", Name = "UposException")]
        string GetRawData();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetSerialNumber", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetSerialNumberResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/UposException", Name = "UposException")]
        string GetSerialNumber();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetTransitNumber", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MICR/GetTransitNumberResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/UposException", Name = "UposException")]
        string GetTransitNumber();

        //
        // Common Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/Open", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MICR/OpenResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/UposException", Name = "UposException")]
        void Open(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/Close", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MICR/CloseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/UposException", Name = "UposException")]
        void Close(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/Claim", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MICR/ClaimResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/UposException", Name = "UposException")]
        void Claim(int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/Release", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MICR/ReleaseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/UposException", Name = "UposException")]
        void Release();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/CheckHealth", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MICR/CheckHealthResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/UposException", Name = "UposException")]
        void CheckHealth(HealthCheckLevel Level);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/ClearInput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MICR/ClearInputResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/UposException", Name = "UposException")]
        void ClearInput();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/ClearInputProperties", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MICR/ClearInputPropertiesResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/UposException", Name = "UposException")]
        void ClearInputProperties();

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/ClearOutput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MICR/ClearOutputResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/UposException", Name = "UposException")]
        // void ClearOutput();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/DirectIO", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MICR/DirectIOResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/UposException", Name = "UposException")]
        DirectIOData DirectIO(int Command, int Data, object Obj);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/CompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MICR/CompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/UposException", Name = "UposException")]
        CompareFirmwareResult CompareFirmwareVersion(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/ResetStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MICR/ResetStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/UposException", Name = "UposException")]
        void ResetStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/RetrieveStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MICR/RetrieveStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/UposException", Name = "UposException")]
        string RetrieveStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/UpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MICR/UpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/UposException", Name = "UposException")]
        void UpdateFirmware(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/UpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MICR/UpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/UposException", Name = "UposException")]
        void UpdateStatistics(StatisticList StatisticsBuffer);

        //
        // Specific Methods
        //
        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/BeginInsertion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MICR/BeginInsertionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/UposException", Name = "UposException")]
        void BeginInsertion(int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/BeginRemoval", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MICR/BeginRemovalResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/UposException", Name = "UposException")]
        void BeginRemoval(int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/EndInsertion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MICR/EndInsertionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/UposException", Name = "UposException")]
        void EndInsertion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/EndRemoval", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MICR/EndRemovalResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MICR/UposException", Name = "UposException")]
        void EndRemoval();

    }

    //
    // Common Data Types
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/MICR/")]
    public class DirectIOData
    {
        [DataMember]
        public int Data { get; set; }
        [DataMember]
        public object Obj { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/MICR/")]
    public class UposException
    {
        [DataMember]
        public ErrorCode ErrorCode { get; set; }
        [DataMember]
        public int ErrorCodeExtended { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/MICR/")]
    public class UposVersion
    {
        [DataMember]
        public int Major { get; set; }
        [DataMember]
        public int Minor { get; set; }
        [DataMember]
        public int Build { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/MICR/")]
    public class Statistic
    {
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public string Value { get; set; }
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/MICR/", ItemName = "Statistic")]
    public class StatisticList : List<Statistic>
    {
    }

    //
    // Common Enumerations
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/MICR/")]
    public enum CompareFirmwareResult
    {
        [EnumMember]
        Different,
        [EnumMember]
        Newer,
        [EnumMember]
        Older,
        [EnumMember]
        Same,
        [EnumMember]
        Unknown,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/MICR/")]
    public enum ControlState
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Closed,
        [EnumMember]
        Error,
        [EnumMember]
        Idle,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/MICR/")]
    public enum ErrorCode
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Claimed,
        [EnumMember]
        Closed,
        [EnumMember]
        Deprecated,
        [EnumMember]
        Disabled,
        [EnumMember]
        Exists,
        [EnumMember]
        Extended,
        [EnumMember]
        Failure,
        [EnumMember]
        Illegal,
        [EnumMember]
        NoExist,
        [EnumMember]
        NoHardware,
        [EnumMember]
        NoService,
        [EnumMember]
        NotClaimed,
        [EnumMember]
        Offline,
        [EnumMember]
        Success,
        [EnumMember]
        Timeout,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/MICR/")]
    public enum HealthCheckLevel
    {
        [EnumMember]
        External,
        [EnumMember]
        Interactive,
        [EnumMember]
        Internal,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/MICR/")]
    public enum PowerNotification
    {
        [EnumMember]
        Disabled,
        [EnumMember]
        Enabled,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/MICR/")]
    public enum PowerReporting
    {
        [EnumMember]
        Advanced,
        [EnumMember]
        None,
        [EnumMember]
        Standard,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/MICR/")]
    public enum PowerState
    {
        [EnumMember]
        Off,
        [EnumMember]
        Offline,
        [EnumMember]
        OffOffline,
        [EnumMember]
        Online,
        [EnumMember]
        Unknown,
    }

    /*
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/MICR/")]
    public enum StatisticCategories
    {
        [EnumMember]
        All,
        [EnumMember]
        Manufacturer,
        [EnumMember]
        Upos,
    }
    */
    public class StatisticCategories
    {
        public const string All = "";
        public const string Manufacturer = "M_";
        public const string Upos = "U_";
    }

    //
    // Specific Data Types
    //

    //
    // Specific Enumerations
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/MICR/")]
    public enum CheckCountryCode
    {
        [EnumMember]
        Canada,
        [EnumMember]
        Cmc7,
        [EnumMember]
        Mexico,
        [EnumMember]
        Other,
        [EnumMember]
        Unknown,
        [EnumMember]
        Usa,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/MICR/")]
    public enum CheckType
    {
        [EnumMember]
        Business,
        [EnumMember]
        Personal,
        [EnumMember]
        Unknown,
    }

    //
    // Constants
    //

    /*
    public class Constants
    {
        public const int ExtendedErrorBadData = 203;
        public const int ExtendedErrorBadSize = 205;
        public const int ExtendedErrorCheck = 202;
        public const int ExtendedErrorCheckDigit = 207;
        public const int ExtendedErrorCoverOpen = 208;
        public const int ExtendedErrorFirmwareBadFile = 281;
        public const int ExtendedErrorJam = 206;
        public const int ExtendedErrorNoCheck = 201;
        public const int ExtendedErrorNoData = 204;
        public const int ExtendedErrorStatistics = 280;
        public const int ExtendedErrorStatisticsDependency = 282;
        public const string StatisticCommunicationErrorCount = "CommunicationErrorCount";
        public const string StatisticDeviceCategory = "DeviceCategory";
        public const string StatisticFailedDataParseCount = "FailedDataParseCount";
        public const string StatisticFailedReadCount = "FailedReadCount";
        public const string StatisticFirmwareRevision = "FirmwareRevision";
        public const string StatisticGoodReadCount = "GoodReadCount";
        public const string StatisticHoursPoweredCount = "HoursPoweredCount";
        public const string StatisticInstallationDate = "InstallationDate";
        public const string StatisticInterface = "Interface";
        public const string StatisticManufactureDate = "ManufactureDate";
        public const string StatisticManufacturerName = "ManufacturerName";
        public const string StatisticMechanicalRevision = "MechanicalRevision";
        public const string StatisticModelName = "ModelName";
        public const string StatisticSerialNumber = "SerialNumber";
        public const string StatisticUnifiedPOSVersion = "UnifiedPOSVersion";
        public const int StatusPowerOff = 2002;
        public const int StatusPowerOffline = 2003;
        public const int StatusPowerOffOffline = 2004;
        public const int StatusPowerOnline = 2001;
        public const int StatusUpdateFirmwareComplete = 2200;
        public const int StatusUpdateFirmwareCompleteDeviceNotRestored = 2205;
        public const int StatusUpdateFirmwareFailedDeviceNeedsFirmware = 2203;
        public const int StatusUpdateFirmwareFailedDeviceOk = 2201;
        public const int StatusUpdateFirmwareFailedDeviceUnknown = 2204;
        public const int StatusUpdateFirmwareFailedDeviceUnrecoverable = 2202;
        public const int StatusUpdateFirmwareProgress = 2100;
        public const int WaitForever = -1;
    }
    */

    public class ExtendedError
    {
        public const int BadData = 203;
        public const int BadSize = 205;
        public const int Check = 202;
        public const int CheckDigit = 207;
        public const int CoverOpen = 208;
        public const int FirmwareBadFile = 281;
        public const int Jam = 206;
        public const int NoCheck = 201;
        public const int NoData = 204;
        public const int Statistics = 280;
        public const int StatisticsDependency = 282;
    }

    public class StatisticProperties
    {
        public const string CommunicationErrorCount = "CommunicationErrorCount";
        public const string DeviceCategory = "DeviceCategory";
        public const string FailedDataParseCount = "FailedDataParseCount";
        public const string FailedReadCount = "FailedReadCount";
        public const string FirmwareRevision = "FirmwareRevision";
        public const string GoodReadCount = "GoodReadCount";
        public const string HoursPoweredCount = "HoursPoweredCount";
        public const string InstallationDate = "InstallationDate";
        public const string Interface = "Interface";
        public const string ManufactureDate = "ManufactureDate";
        public const string ManufacturerName = "ManufacturerName";
        public const string MechanicalRevision = "MechanicalRevision";
        public const string ModelName = "ModelName";
        public const string SerialNumber = "SerialNumber";
        public const string UnifiedPOSVersion = "UnifiedPOSVersion";
    }

    public class Wait
    {
        public const int Forever = -1;
    }
}
