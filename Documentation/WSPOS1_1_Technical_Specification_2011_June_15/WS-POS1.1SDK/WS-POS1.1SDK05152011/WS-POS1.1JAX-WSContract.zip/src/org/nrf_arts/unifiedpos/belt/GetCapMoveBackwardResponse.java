
package org.nrf_arts.unifiedpos.belt;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="GetCapMoveBackwardResult" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "getCapMoveBackwardResult"
})
@XmlRootElement(name = "GetCapMoveBackwardResponse")
public class GetCapMoveBackwardResponse {

    @XmlElement(name = "GetCapMoveBackwardResult")
    protected Boolean getCapMoveBackwardResult;

    /**
     * Gets the value of the getCapMoveBackwardResult property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isGetCapMoveBackwardResult() {
        return getCapMoveBackwardResult;
    }

    /**
     * Sets the value of the getCapMoveBackwardResult property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setGetCapMoveBackwardResult(Boolean value) {
        this.getCapMoveBackwardResult = value;
    }

}
