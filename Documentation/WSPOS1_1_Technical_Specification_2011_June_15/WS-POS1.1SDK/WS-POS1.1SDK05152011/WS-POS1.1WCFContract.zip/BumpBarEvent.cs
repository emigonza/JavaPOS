﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace UnifiedPOS.BumpBarEvents
{
    [ServiceContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BumpBarEvents/")]
    public interface BumpBarEvent
    {

        //
        // Events
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBarEvents/DataEvent", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBarEvents/DataEventResponse")]
        void DataEvent(string Source, int EventID, DateTime TimeStamp, int Status);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBarEvents/DirectIOEvent", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBarEvents/DirectIOEventResponse")]
        DirectIOData DirectIOEvent(string Source, int EventID, DateTime TimeStamp, int EventNumber, int Data, object Obj);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBarEvents/ErrorEvent", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBarEvents/ErrorEventResponse")]
        ErrorResponse ErrorEvent(string Source, int EventID, DateTime TimeStamp, ErrorCode ErrorCode, int ErrorCodeExtended, ErrorLocus ErrorLocus, ErrorResponse ErrorResponse);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBarEvents/OutputCompleteEvent", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBarEvents/OutputCompleteEventResponse")]
        void OutputCompleteEvent(string Source, int EventID, DateTime TimeStamp, int OutputID);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBarEvents/StatusUpdateEvent", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBarEvents/StatusUpdateEventResponse")]
        void StatusUpdateEvent(string Source, int EventID, DateTime TimeStamp, int Status);
    }

    //
    // Common Data Types
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BumpBarEvents/")]
    public class DirectIOData
    {
        [DataMember]
        public int Data { get; set; }
        [DataMember]
        public object Obj { get; set; }
    }

    //
    // Common Enumerations
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BumpBarEvents/")]
    public enum ErrorCode
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Claimed,
        [EnumMember]
        Closed,
        [EnumMember]
        Deprecated,
        [EnumMember]
        Disabled,
        [EnumMember]
        Exists,
        [EnumMember]
        Extended,
        [EnumMember]
        Failure,
        [EnumMember]
        Illegal,
        [EnumMember]
        NoExist,
        [EnumMember]
        NoHardware,
        [EnumMember]
        NoService,
        [EnumMember]
        NotClaimed,
        [EnumMember]
        Offline,
        [EnumMember]
        Success,
        [EnumMember]
        Timeout,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BumpBarEvents/")]
    public enum ErrorLocus
    {
        [EnumMember]
        Input,
        [EnumMember]
        InputData,
        [EnumMember]
        Output,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BumpBarEvents/")]
    public enum ErrorResponse
    {
        [EnumMember]
        Clear,
        [EnumMember]
        ContinueInput,
        [EnumMember]
        Retry,
    }

    //
    // Specific Data Types
    //

    //
    // Specific Enumerations
    //

    //
    // Constants
    //

    public class ExtendedError
    {
        public const int FirmwareBadFile = 281;
        public const int Statistics = 280;
        public const int StatisticsDependency = 282;
    }

    public class Status
    {
        public const int PowerOff = 2002;
        public const int PowerOffline = 2003;
        public const int PowerOffOffline = 2004;
        public const int PowerOnline = 2001;
        public const int UpdateFirmwareComplete = 2200;
        public const int UpdateFirmwareCompleteDeviceNotRestored = 2205;
        public const int UpdateFirmwareFailedDeviceNeedsFirmware = 2203;
        public const int UpdateFirmwareFailedDeviceOk = 2201;
        public const int UpdateFirmwareFailedDeviceUnknown = 2204;
        public const int UpdateFirmwareFailedDeviceUnrecoverable = 2202;
        public const int UpdateFirmwareProgress = 2100;
    }

    public class DataEventStatus
    {
        public const int Key = 1;
    }
}
