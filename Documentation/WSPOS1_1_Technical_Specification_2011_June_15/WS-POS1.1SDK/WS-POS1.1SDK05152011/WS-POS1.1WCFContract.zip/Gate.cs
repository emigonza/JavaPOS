﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace UnifiedPOS.Gate
{
    [ServiceContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Gate/")]
    public interface Gate
    {

        //
        // Common Properties
        //

//        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/GetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Gate/GetAutoDisableResponse")]
//        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/UposException", Name = "UposException")]
//        bool GetAutoDisable();

//        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/SetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Gate/SetAutoDisableResponse")]
//        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/UposException", Name = "UposException")]
//       void SetAutoDisable(bool AutoDisable);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/GetCapCompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Gate/GetCapCompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/UposException", Name = "UposException")]
        bool GetCapCompareFirmwareVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/GetCapPowerReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Gate/GetCapPowerReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/UposException", Name = "UposException")]
        PowerReporting GetCapPowerReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/GetCapStatisticsReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Gate/GetCapStatisticsReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/UposException", Name = "UposException")]
        bool GetCapStatisticsReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/GetCapUpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Gate/GetCapUpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/UposException", Name = "UposException")]
        bool GetCapUpdateFirmware();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/GetCapUpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Gate/GetCapUpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/UposException", Name = "UposException")]
        bool GetCapUpdateStatistics();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/GetCheckHealthText", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Gate/GetCheckHealthTextResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/UposException", Name = "UposException")]
        string GetCheckHealthText();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/GetClaimed", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Gate/GetClaimedResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/UposException", Name = "UposException")]
        bool GetClaimed();

//        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/GetDataCount", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Gate/GetDataCountResponse")]
//       [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/UposException", Name = "UposException")]
//        int GetDataCount();

//        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/GetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Gate/GetDataEventEnabledResponse")]
//        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/UposException", Name = "UposException")]
//        bool GetDataEventEnabled();

//        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/SetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Gate/SetDataEventEnabledResponse")]
//        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/UposException", Name = "UposException")]
//        void SetDataEventEnabled(bool DataEventEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/GetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Gate/GetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/UposException", Name = "UposException")]
        bool GetDeviceEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/SetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Gate/SetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/UposException", Name = "UposException")]
        void SetDeviceEnabled(bool DeviceEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/GetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Gate/GetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/UposException", Name = "UposException")]
        bool GetFreezeEvents();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/SetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Gate/SetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/UposException", Name = "UposException")]
        void SetFreezeEvents(bool FreezeEvents);

//        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/GetOutputID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Gate/GetOutputIDResponse")]
//        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/UposException", Name = "UposException")]
//        int GetOutputID();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/GetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Gate/GetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/UposException", Name = "UposException")]
        PowerNotification GetPowerNotify();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/SetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Gate/SetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/UposException", Name = "UposException")]
        void SetPowerNotify(PowerNotification PowerNotify);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/GetPowerState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Gate/GetPowerStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/UposException", Name = "UposException")]
        PowerState GetPowerState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/GetState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Gate/GetStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/UposException", Name = "UposException")]
        ControlState GetState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/GetDeviceControlDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Gate/GetDeviceControlDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/UposException", Name = "UposException")]
        string GetDeviceControlDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/GetDeviceControlVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Gate/GetDeviceControlVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/UposException", Name = "UposException")]
        UposVersion GetDeviceControlVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/GetDeviceServiceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Gate/GetDeviceServiceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/UposException", Name = "UposException")]
        string GetDeviceServiceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/GetDeviceServiceVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Gate/GetDeviceServiceVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/UposException", Name = "UposException")]
        UposVersion GetDeviceServiceVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/GetPhysicalDeviceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Gate/GetPhysicalDeviceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/UposException", Name = "UposException")]
        string GetPhysicalDeviceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/GetPhysicalDeviceName", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Gate/GetPhysicalDeviceNameResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/UposException", Name = "UposException")]
        string GetPhysicalDeviceName();

        //
        // Specific Properties
        //
        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/GetCapGateStatus", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Gate/GetPhysicalDeviceNameResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/UposException", Name = "UposException")]
        bool GetCapGateStatus();


        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/GetGateStatus", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Gate/GetPhysicalDeviceNameResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/UposException", Name = "UposException")]
        GateStatus GetGateStatus();

        //
        // Common Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/Open", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Gate/OpenResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/UposException", Name = "UposException")]
        void Open(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/Close", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Gate/CloseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/UposException", Name = "UposException")]
        void Close(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/Claim", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Gate/ClaimResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/UposException", Name = "UposException")]
        void Claim(int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/Release", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Gate/ReleaseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/UposException", Name = "UposException")]
        void Release();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/CheckHealth", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Gate/CheckHealthResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/UposException", Name = "UposException")]
        void CheckHealth(HealthCheckLevel Level);

//        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/ClearInput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Gate/ClearInputResponse")]
//        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/UposException", Name = "UposException")]
//        void ClearInput();

//        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/ClearInputProperties", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Gate/ClearInputPropertiesResponse")]
//        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/UposException", Name = "UposException")]
//        void ClearInputProperties();

//        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/ClearOutput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Gate/ClearOutputResponse")]
//        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/UposException", Name = "UposException")]
//        void ClearOutput();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/DirectIO", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Gate/DirectIOResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/UposException", Name = "UposException")]
        DirectIOData DirectIO(int Command, int Data, object Obj);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/CompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Gate/CompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/UposException", Name = "UposException")]
        CompareFirmwareResult CompareFirmwareVersion(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/ResetStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Gate/ResetStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/UposException", Name = "UposException")]
        void ResetStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/RetrieveStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Gate/RetrieveStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/UposException", Name = "UposException")]
        string RetrieveStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/UpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Gate/UpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/UposException", Name = "UposException")]
        void UpdateFirmware(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/UpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Gate/UpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/UposException", Name = "UposException")]
        void UpdateStatistics(StatisticList StatisticsBuffer);

        //
        // Specific Methods
        //
        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/OpenGate", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Gate/GetPhysicalDeviceNameResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/UposException", Name = "UposException")]
        void OpenGate();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/WaitForGateClose", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Gate/GetPhysicalDeviceNameResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Gate/UposException", Name = "UposException")]
        void WaitForGateClose(int Timeout);


    }

    //
    // Common Data Types
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Gate/")]
    public class DirectIOData
    {
        [DataMember]
        public int Data { get; set; }
        [DataMember]
        public object Obj { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Gate/")]
    public class UposException
    {
        [DataMember]
        public ErrorCode ErrorCode { get; set; }
        [DataMember]
        public int ErrorCodeExtended { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Gate/")]
    public class UposVersion
    {
        [DataMember]
        public int Major { get; set; }
        [DataMember]
        public int Minor { get; set; }
        [DataMember]
        public int Build { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Gate/")]
    public class Statistic
    {
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public string Value { get; set; }
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Gate/", ItemName = "Statistic")]
    public class StatisticList : List<Statistic>
    {
    }

    //
    // Common Enumerations
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Gate/")]
    public enum CompareFirmwareResult
    {
        [EnumMember]
        Different,
        [EnumMember]
        Newer,
        [EnumMember]
        Older,
        [EnumMember]
        Same,
        [EnumMember]
        Unknown,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Gate/")]
    public enum ControlState
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Closed,
        [EnumMember]
        Error,
        [EnumMember]
        Idle,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Gate/")]
    public enum ErrorCode
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Claimed,
        [EnumMember]
        Closed,
        [EnumMember]
        Deprecated,
        [EnumMember]
        Disabled,
        [EnumMember]
        Exists,
        [EnumMember]
        Extended,
        [EnumMember]
        Failure,
        [EnumMember]
        Illegal,
        [EnumMember]
        NoExist,
        [EnumMember]
        NoHardware,
        [EnumMember]
        NoService,
        [EnumMember]
        NotClaimed,
        [EnumMember]
        Offline,
        [EnumMember]
        Success,
        [EnumMember]
        Timeout,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Gate/")]
    public enum HealthCheckLevel
    {
        [EnumMember]
        External,
        [EnumMember]
        Interactive,
        [EnumMember]
        Internal,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Gate/")]
    public enum PowerNotification
    {
        [EnumMember]
        Disabled,
        [EnumMember]
        Enabled,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Gate/")]
    public enum PowerReporting
    {
        [EnumMember]
        Advanced,
        [EnumMember]
        None,
        [EnumMember]
        Standard,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Gate/")]
    public enum PowerState
    {
        [EnumMember]
        Off,
        [EnumMember]
        Offline,
        [EnumMember]
        OffOffline,
        [EnumMember]
        Online,
        [EnumMember]
        Unknown,
    }

    /*
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Gate/")]
    public enum StatisticCategories
    {
        [EnumMember]
        All,
        [EnumMember]
        Manufacturer,
        [EnumMember]
        Upos,
    }
    */
    public class StatisticCategories
    {
        public const string All = "";
        public const string Manufacturer = "M_";
        public const string Upos = "U_";
    }

    //
    // Specific Data Types
    //

    //
    // Specific Enumerations
    //
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Gate/")]
    public enum GateStatus
    {
        //The gate is closed.
        [EnumMember]
        Closed,
        //The gate is open.
        [EnumMember]
        Open,
        //The gate is blocked.
        [EnumMember]
        Blocked,
        //The gate has a hardware problem. Technical help is needed.
        [EnumMember]
        Malfunction,
    }


    //
    // Constants
    //

    public class ExtendedError
    {
        public const int FirmwareBadFile = 281;
        public const int Statistics = 280;
        public const int StatisticsDependency = 282;
    }

    public class StatisticProperties
    {
        public const string CommunicationErrorCount = "CommunicationErrorCount";
        public const string DeviceCategory = "DeviceCategory";
        public const string FirmwareRevision = "FirmwareRevision";
        public const string HoursPoweredCount = "HoursPoweredCount";
        public const string InstallationDate = "InstallationDate";
        public const string Interface = "Interface";
        public const string ManufactureDate = "ManufactureDate";
        public const string ManufacturerName = "ManufacturerName";
        public const string MechanicalRevision = "MechanicalRevision";
        public const string ModelName = "ModelName";
        public const string SerialNumber = "SerialNumber";
        public const string UnifiedPOSVersion = "UnifiedPOSVersion";
    }

    public class Wait
    {
        public const int Forever = -1;
    }
}
