﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace UnifiedPOS.MotionSensor
{
    [ServiceContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/")]
    public interface MotionSensor
    {

        //
        // Common Properties
        //

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/GetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/GetAutoDisableResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/UposException", Name = "UposException")]
        // bool GetAutoDisable();

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/SetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/SetAutoDisableResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/UposException", Name = "UposException")]
        // void SetAutoDisable(bool AutoDisable);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/GetCapCompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/GetCapCompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/UposException", Name = "UposException")]
        bool GetCapCompareFirmwareVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/GetCapPowerReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/GetCapPowerReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/UposException", Name = "UposException")]
        PowerReporting GetCapPowerReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/GetCapStatisticsReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/GetCapStatisticsReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/UposException", Name = "UposException")]
        bool GetCapStatisticsReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/GetCapUpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/GetCapUpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/UposException", Name = "UposException")]
        bool GetCapUpdateFirmware();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/GetCapUpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/GetCapUpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/UposException", Name = "UposException")]
        bool GetCapUpdateStatistics();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/GetCheckHealthText", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/GetCheckHealthTextResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/UposException", Name = "UposException")]
        string GetCheckHealthText();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/GetClaimed", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/GetClaimedResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/UposException", Name = "UposException")]
        bool GetClaimed();

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/GetDataCount", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/GetDataCountResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/UposException", Name = "UposException")]
        // int GetDataCount();

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/GetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/GetDataEventEnabledResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/UposException", Name = "UposException")]
        // bool GetDataEventEnabled();

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/SetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/SetDataEventEnabledResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/UposException", Name = "UposException")]
        // void SetDataEventEnabled(bool DataEventEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/GetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/GetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/UposException", Name = "UposException")]
        bool GetDeviceEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/SetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/SetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/UposException", Name = "UposException")]
        void SetDeviceEnabled(bool DeviceEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/GetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/GetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/UposException", Name = "UposException")]
        bool GetFreezeEvents();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/SetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/SetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/UposException", Name = "UposException")]
        void SetFreezeEvents(bool FreezeEvents);

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/GetOutputID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/GetOutputIDResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/UposException", Name = "UposException")]
        // int GetOutputID();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/GetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/GetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/UposException", Name = "UposException")]
        PowerNotification GetPowerNotify();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/SetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/SetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/UposException", Name = "UposException")]
        void SetPowerNotify(PowerNotification PowerNotify);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/GetPowerState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/GetPowerStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/UposException", Name = "UposException")]
        PowerState GetPowerState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/GetState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/GetStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/UposException", Name = "UposException")]
        ControlState GetState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/GetDeviceControlDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/GetDeviceControlDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/UposException", Name = "UposException")]
        string GetDeviceControlDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/GetDeviceControlVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/GetDeviceControlVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/UposException", Name = "UposException")]
        UposVersion GetDeviceControlVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/GetDeviceServiceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/GetDeviceServiceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/UposException", Name = "UposException")]
        string GetDeviceServiceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/GetDeviceServiceVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/GetDeviceServiceVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/UposException", Name = "UposException")]
        UposVersion GetDeviceServiceVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/GetPhysicalDeviceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/GetPhysicalDeviceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/UposException", Name = "UposException")]
        string GetPhysicalDeviceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/GetPhysicalDeviceName", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/GetPhysicalDeviceNameResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/UposException", Name = "UposException")]
        string GetPhysicalDeviceName();

        //
        // Specific Properties
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/GetMotion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/GetMotionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/UposException", Name = "UposException")]
        bool GetMotion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/GetTimeout", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/GetTimeoutResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/UposException", Name = "UposException")]
        int GetTimeout();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/SetTimeout", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/SetTimeoutResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/UposException", Name = "UposException")]
        void SetTimeout(int Timeout);

        //
        // Common Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/Open", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/OpenResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/UposException", Name = "UposException")]
        void Open(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/Close", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/CloseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/UposException", Name = "UposException")]
        void Close(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/Claim", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/ClaimResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/UposException", Name = "UposException")]
        void Claim(int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/Release", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/ReleaseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/UposException", Name = "UposException")]
        void Release();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/CheckHealth", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/CheckHealthResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/UposException", Name = "UposException")]
        void CheckHealth(HealthCheckLevel Level);

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/ClearInput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/ClearInputResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/UposException", Name = "UposException")]
        // void ClearInput();

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/ClearInputProperties", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/ClearInputPropertiesResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/UposException", Name = "UposException")]
        // void ClearInputProperties();

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/ClearOutput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/ClearOutputResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/UposException", Name = "UposException")]
        // void ClearOutput();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/DirectIO", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/DirectIOResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/UposException", Name = "UposException")]
        DirectIOData DirectIO(int Command, int Data, object Obj);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/CompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/CompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/UposException", Name = "UposException")]
        CompareFirmwareResult CompareFirmwareVersion(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/ResetStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/ResetStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/UposException", Name = "UposException")]
        void ResetStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/RetrieveStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/RetrieveStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/UposException", Name = "UposException")]
        string RetrieveStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/UpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/UpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/UposException", Name = "UposException")]
        void UpdateFirmware(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/UpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/UpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/UposException", Name = "UposException")]
        void UpdateStatistics(StatisticList StatisticsBuffer);

        //
        // Specific Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/WaitForMotion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/WaitForMotionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/UposException", Name = "UposException")]
        void WaitForMotion(int Timeout);

    }

    //
    // Common Data Types
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/")]
    public class DirectIOData
    {
        [DataMember]
        public int Data { get; set; }
        [DataMember]
        public object Obj { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/")]
    public class UposException
    {
        [DataMember]
        public ErrorCode ErrorCode { get; set; }
        [DataMember]
        public int ErrorCodeExtended { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/")]
    public class UposVersion
    {
        [DataMember]
        public int Major { get; set; }
        [DataMember]
        public int Minor { get; set; }
        [DataMember]
        public int Build { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/")]
    public class Statistic
    {
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public string Value { get; set; }
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/", ItemName = "Statistic")]
    public class StatisticList : List<Statistic>
    {
    }

    //
    // Common Enumerations
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/")]
    public enum CompareFirmwareResult
    {
        [EnumMember]
        Different,
        [EnumMember]
        Newer,
        [EnumMember]
        Older,
        [EnumMember]
        Same,
        [EnumMember]
        Unknown,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/")]
    public enum ControlState
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Closed,
        [EnumMember]
        Error,
        [EnumMember]
        Idle,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/")]
    public enum ErrorCode
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Claimed,
        [EnumMember]
        Closed,
        [EnumMember]
        Deprecated,
        [EnumMember]
        Disabled,
        [EnumMember]
        Exists,
        [EnumMember]
        Extended,
        [EnumMember]
        Failure,
        [EnumMember]
        Illegal,
        [EnumMember]
        NoExist,
        [EnumMember]
        NoHardware,
        [EnumMember]
        NoService,
        [EnumMember]
        NotClaimed,
        [EnumMember]
        Offline,
        [EnumMember]
        Success,
        [EnumMember]
        Timeout,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/")]
    public enum HealthCheckLevel
    {
        [EnumMember]
        External,
        [EnumMember]
        Interactive,
        [EnumMember]
        Internal,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/")]
    public enum PowerNotification
    {
        [EnumMember]
        Disabled,
        [EnumMember]
        Enabled,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/")]
    public enum PowerReporting
    {
        [EnumMember]
        Advanced,
        [EnumMember]
        None,
        [EnumMember]
        Standard,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/")]
    public enum PowerState
    {
        [EnumMember]
        Off,
        [EnumMember]
        Offline,
        [EnumMember]
        OffOffline,
        [EnumMember]
        Online,
        [EnumMember]
        Unknown,
    }

    /*
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/MotionSensor/")]
    public enum StatisticCategories
    {
        [EnumMember]
        All,
        [EnumMember]
        Manufacturer,
        [EnumMember]
        Upos,
    }
    */
    public class StatisticCategories
    {
        public const string All = "";
        public const string Manufacturer = "M_";
        public const string Upos = "U_";
    }

    //
    // Specific Data Types
    //

    //
    // Specific Enumerations
    //

    //
    // Constants
    //

    public class ExtendedError
    {
        public const int FirmwareBadFile = 281;
        public const int Statistics = 280;
        public const int StatisticsDependency = 282;
    }

    public class StatisticProperties
    {
        public const string CommunicationErrorCount = "CommunicationErrorCount";
        public const string DeviceCategory = "DeviceCategory";
        public const string FirmwareRevision = "FirmwareRevision";
        public const string HoursPoweredCount = "HoursPoweredCount";
        public const string InstallationDate = "InstallationDate";
        public const string Interface = "Interface";
        public const string ManufactureDate = "ManufactureDate";
        public const string ManufacturerName = "ManufacturerName";
        public const string MechanicalRevision = "MechanicalRevision";
        public const string ModelName = "ModelName";
        public const string MotionEventCount = "MotionEventCount";
        public const string SerialNumber = "SerialNumber";
        public const string UnifiedPOSVersion = "UnifiedPOSVersion";
    }

    public class Wait
    {
        public const int Forever = -1;
    }
}
