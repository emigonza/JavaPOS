﻿using UnifiedPOS.CashChangerEvents;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace Wspos
{
    [ServiceBehavior(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CashChangerEvents/", InstanceContextMode = InstanceContextMode.Single)]
    public class CashChangerEventService : CashChangerEvent
    {
        private static Dictionary<int, string> Convert = new Dictionary<int, string>()
            {
                { Status.Async, "Async" },
                { Status.Empty, "Empty" },
                { Status.EmptyOK, "EmptyOK" },
                { Status.Full, "Full" },
                { Status.FullOK, "FullOK" },
                { Status.Jam, "Jam" },
                { Status.JamOK, "JamOK" },
                { Status.NearEmpty, "NearEmpty" },
                { Status.NearFull, "NearFull" },
                { Status.OK, "OK" },
                { Status.PowerOff, "PowerOff" },
                { Status.PowerOffline, "PowerOffline" },
                { Status.PowerOffOffline, "PowerOffOffline" },
                { Status.PowerOnline, "PowerOnline" },
                { Status.UpdateFirmwareComplete, "UpdateFirmwareComplete" },
                { Status.UpdateFirmwareCompleteDeviceNotRestored, "UpdateFirmwareCompleteDeviceNotRestored" },
                { Status.UpdateFirmwareFailedDeviceNeedsFirmware, "UpdateFirmwareFailedDeviceNeedsFirmware" },
                { Status.UpdateFirmwareFailedDeviceOk, "UpdateFirmwareFailedDeviceOk" },
                { Status.UpdateFirmwareFailedDeviceUnknown, "UpdateFirmwareFailedDeviceUnknown" },
                { Status.UpdateFirmwareFailedDeviceUnrecoverable, "UpdateFirmwareFailedDeviceUnrecoverable" },
                { Status.UpdateFirmwareProgress, "UpdateFirmwareProgress" },
            };

        #region CashChangerEvent Member

        public void DataEvent(string Source, int EventID, DateTime TimeStamp, int Status)
        {
            //throw new NotImplementedException();
            Console.WriteLine("{0}, {1}, DataEvent, {2}", EventID, TimeStamp, Status);
        }

        public DirectIOData DirectIOEvent(string Source, int EventID, DateTime TimeStamp, int EventNumber, int Data, object Obj)
        {
            //throw new NotImplementedException();
            Console.WriteLine("{0}, {1}, DirectIOEvent, {2}, {3}, {4}", EventID, TimeStamp, EventNumber, Data, Obj);
            return new DirectIOData() { Data = Data, Obj = Obj };
        }

        public void StatusUpdateEvent(string Source, int EventID, DateTime TimeStamp, int Status)
        {
            //throw new NotImplementedException();
            int p = UnifiedPOS.CashChangerEvents.Status.UpdateFirmwareProgress;
            Console.WriteLine("{0}, {1}, StatusUpdateEvent, {2}", EventID, TimeStamp, (Status > p && Status < p + 100) ? Convert[p] + " + " + (Status - p) : Convert[Status]);
        }

        #endregion
    }
}
