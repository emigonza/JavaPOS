
package org.nrf_arts.unifiedpos.biometrics;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="DirectIOResult" type="{http://www.nrf-arts.org/UnifiedPOS/Biometrics/}DirectIOData" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "directIOResult"
})
@XmlRootElement(name = "DirectIOResponse")
public class DirectIOResponse {

    @XmlElement(name = "DirectIOResult", nillable = true)
    protected DirectIOData directIOResult;

    /**
     * Gets the value of the directIOResult property.
     * 
     * @return
     *     possible object is
     *     {@link DirectIOData }
     *     
     */
    public DirectIOData getDirectIOResult() {
        return directIOResult;
    }

    /**
     * Sets the value of the directIOResult property.
     * 
     * @param value
     *     allowed object is
     *     {@link DirectIOData }
     *     
     */
    public void setDirectIOResult(DirectIOData value) {
        this.directIOResult = value;
    }

}
