﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace UnifiedPOS.RemoteOrderDisplay
{
    [ServiceContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/")]
    public interface RemoteOrderDisplay
    {

        //
        // Common Properties
        //

        //[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetAutoDisableResponse")]
        //[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        //bool GetAutoDisable();

        //[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/SetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/SetAutoDisableResponse")]
        //[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        //void SetAutoDisable(bool AutoDisable);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetCapCompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetCapCompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        bool GetCapCompareFirmwareVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetCapPowerReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetCapPowerReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        PowerReporting GetCapPowerReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetCapStatisticsReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetCapStatisticsReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        bool GetCapStatisticsReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetCapUpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetCapUpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        bool GetCapUpdateFirmware();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetCapUpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetCapUpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        bool GetCapUpdateStatistics();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetCheckHealthText", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetCheckHealthTextResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        string GetCheckHealthText();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetClaimed", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetClaimedResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        bool GetClaimed();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetDataCount", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetDataCountResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        int GetDataCount();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetDataEventEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        bool GetDataEventEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/SetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/SetDataEventEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        void SetDataEventEnabled(bool DataEventEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        bool GetDeviceEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/SetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/SetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        void SetDeviceEnabled(bool DeviceEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        bool GetFreezeEvents();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/SetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/SetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        void SetFreezeEvents(bool FreezeEvents);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetOutputID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetOutputIDResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        int GetOutputID();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        PowerNotification GetPowerNotify();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/SetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/SetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        void SetPowerNotify(PowerNotification PowerNotify);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetPowerState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetPowerStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        PowerState GetPowerState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        ControlState GetState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetDeviceControlDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetDeviceControlDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        string GetDeviceControlDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetDeviceControlVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetDeviceControlVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        UposVersion GetDeviceControlVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetDeviceServiceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetDeviceServiceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        string GetDeviceServiceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetDeviceServiceVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetDeviceServiceVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        UposVersion GetDeviceServiceVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetPhysicalDeviceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetPhysicalDeviceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        string GetPhysicalDeviceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetPhysicalDeviceName", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetPhysicalDeviceNameResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        string GetPhysicalDeviceName();

        //
        // Specific Properties
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetCapMapCharacterSet", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetCapMapCharacterSetResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        bool GetCapMapCharacterSet();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetCapSelectCharacterSet", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetCapSelectCharacterSetResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        bool GetCapSelectCharacterSet();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetCapTone", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetCapToneResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        bool GetCapTone();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetCapTouch", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetCapTouchResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        bool GetCapTouch();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetCapTransaction", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetCapTransactionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        bool GetCapTransaction();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetAsyncMode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetAsyncModeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        bool GetAsyncMode();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/SetAsyncMode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/SetAsyncModeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        void SetAsyncMode(bool AsyncMode);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetAutoToneDuration", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetAutoToneDurationResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        int GetAutoToneDuration();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/SetAutoToneDuration", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/SetAutoToneDurationResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        void SetAutoToneDuration(int AutoToneDuration);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetAutoToneFrequency", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetAutoToneFrequencyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        int GetAutoToneFrequency();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/SetAutoToneFrequency", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/SetAutoToneFrequencyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        void SetAutoToneFrequency(int AutoToneFrequency);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetCharacterSet", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetCharacterSetResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        int GetCharacterSet();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetCharacterSetList", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetCharacterSetListResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        //int[] GetCharacterSetList();
        CharacterSetList GetCharacterSetList();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetClocks", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetClocksResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        int GetClocks();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetCurrentUnitID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetCurrentUnitIDResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        int GetCurrentUnitID();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/SetCurrentUnitID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/SetCurrentUnitIDResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        void SetCurrentUnitID(int CurrentUnitID);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetErrorString", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetErrorStringResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        string GetErrorString();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetErrorUnits", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetErrorUnitsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        int GetErrorUnits();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetEventString", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetEventStringResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        string GetEventString();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetEventType", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetEventTypeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        int GetEventType();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/SetEventType", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/SetEventTypeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        void SetEventType(int EventType);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetEventUnitID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetEventUnitIDResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        int GetEventUnitID();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetEventUnits", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetEventUnitsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        int GetEventUnits();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetMapCharacterSet", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetMapCharacterSetResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        bool GetMapCharacterSet();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/SetMapCharacterSet", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/SetMapCharacterSetResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        void SetMapCharacterSet(bool MapCharacterSet);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetSystemClocks", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetSystemClocksResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        int GetSystemClocks();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetSystemVideoSaveBuffers", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetSystemVideoSaveBuffersResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        int GetSystemVideoSaveBuffers();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetTimeout", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetTimeoutResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        int GetTimeout();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/SetTimeout", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/SetTimeoutResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        void SetTimeout(int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetUnitsOnline", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetUnitsOnlineResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        int GetUnitsOnline();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetVideoDataCount", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetVideoDataCountResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        int GetVideoDataCount();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetVideoMode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetVideoModeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        int GetVideoMode();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/SetVideoMode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/SetVideoModeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        void SetVideoMode(int VideoMode);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetVideoModesList", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetVideoModesListResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        //VideoMode[] GetVideoModesList();
        VideoModesList GetVideoModesList();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetVideoSaveBuffers", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/GetVideoSaveBuffersResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        int GetVideoSaveBuffers();

        //
        // Common Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/Open", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/OpenResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        void Open(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/Close", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/CloseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        void Close(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/Claim", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/ClaimResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        void Claim(int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/Release", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/ReleaseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        void Release();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/CheckHealth", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/CheckHealthResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        void CheckHealth(HealthCheckLevel Level);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/ClearInput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/ClearInputResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        void ClearInput();

       // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/ClearInputProperties", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/ClearInputPropertiesResponse")]
       // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
       // void ClearInputProperties();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/ClearOutput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/ClearOutputResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        void ClearOutput();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/DirectIO", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/DirectIOResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        DirectIOData DirectIO(int Command, int Data, object Obj);
        
        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/CompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/CompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        CompareFirmwareResult CompareFirmwareVersion(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/ResetStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/ResetStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        void ResetStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/RetrieveStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/RetrieveStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        string RetrieveStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        void UpdateFirmware(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        void UpdateStatistics(StatisticList StatisticsBuffer);

        //
        // Specific Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/ClearVideo", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/ClearVideoResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        void ClearVideo(int Units, int Attribute);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/ClearVideoRegion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/ClearVideoRegionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        void ClearVideoRegion(int Row, int Column, int Height, int Width, int Attribute);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/ControlClock", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/ControlClockResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        void ControlClock(int Units, ClockFunction ClockFunction, int ClockId, int Hours, int Minutes, int Seconds, int Row, int Column, int Attribute, ClockMode Mode);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/ControlCursor", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/ControlCursorResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        void ControlCursor(int Units, VideoCursorType CursorType);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/CopyVideoRegion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/CopyVideoRegionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        void CopyVideoRegion(int Units, int Row, int Column, int Height, int Width, int TargetRow, int TargetColumn);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/DisplayData", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/DisplayDataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        void DisplayData(int Units, int Row, int Column, int Attribute, string Data);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/DrawBox", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/DrawBoxResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        void DrawBox(int Units, int Row, int Column, int Height, int Width, int Attribute, BorderType BorderType);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/FreeVideoRegion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/FreeVideoRegionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        void FreeVideoRegion(int Units, int BufferId);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/ResetVideo", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/ResetVideoResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        void ResetVideo(int Units);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/RestoreVideoRegion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/RestoreVideoRegionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        void RestoreVideoRegion(int Units, int TargetRow, int TargetColumn, int BufferId);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/SaveVideoRegion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/SaveVideoRegionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        void SaveVideoRegion(int Units, int Row, int Column, int Height, int Width, int BufferId);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/SelectCharacterSet", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/SelectCharacterSetResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        void SelectCharacterSet(int Units, int CharacterSet);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/SetCursor", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/SetCursorResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        void SetCursor(int Units, int Row, int Column);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/TransactionDisplay", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/TransactionDisplayResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        void TransactionDisplay(int Units, RemoteOrderDisplayTransaction TransactionFunction);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UpdateVideoRegionAttribute", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UpdateVideoRegionAttributeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        void UpdateVideoRegionAttribute(int Units, VideoAttributeCommand AttributeFunction, int Column, int Height, int Width, int Attribute);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/VideoSound", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/VideoSoundResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/UposException", Name = "UposException")]
        void VideoSound(int Units, int Frequency, int Duration, int NumberOfCycles, int InterSoundWait);
        
    }

    //
    // Common Data Types
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/")]
    public class DirectIOData
    {
        [DataMember]
        public int Data { get; set; }
        [DataMember]
        public object Obj { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/")]
    public class UposException
    {
        [DataMember]
        public ErrorCode ErrorCode { get; set; }
        [DataMember]
        public int ErrorCodeExtended { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/")]
    public class UposVersion
    {
        [DataMember]
        public int Major { get; set; }
        [DataMember]
        public int Minor { get; set; }
        [DataMember]
        public int Build { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/")]
    public class Statistic
    {
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public string Value { get; set; }
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/", ItemName = "Statistic")]
    public class StatisticList : List<Statistic>
    {

    }

   
    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/", ItemName = "CharacterSet")]
    public class CharacterSetList : List<int>
    {

    }


    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/", ItemName = "VideoModes")]
    public class VideoModesList : List<VideoMode>
    {

    }

    //
    // Common Enumerations
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/")]
    public enum CompareFirmwareResult
    {
        [EnumMember]
        Different,
        [EnumMember]
        Newer,
        [EnumMember]
        Older,
        [EnumMember]
        Same,
        [EnumMember]
        Unknown,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/")]
    public enum ControlState
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Closed,
        [EnumMember]
        Error,
        [EnumMember]
        Idle,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/")]
    public enum ErrorCode
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Claimed,
        [EnumMember]
        Closed,
        [EnumMember]
        Deprecated,
        [EnumMember]
        Disabled,
        [EnumMember]
        Exists,
        [EnumMember]
        Extended,
        [EnumMember]
        Failure,
        [EnumMember]
        Illegal,
        [EnumMember]
        NoExist,
        [EnumMember]
        NoHardware,
        [EnumMember]
        NoService,
        [EnumMember]
        NotClaimed,
        [EnumMember]
        Offline,
        [EnumMember]
        Success,
        [EnumMember]
        Timeout,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/")]
    public enum HealthCheckLevel
    {
        [EnumMember]
        External,
        [EnumMember]
        Interactive,
        [EnumMember]
        Internal,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/")]
    public enum PowerNotification
    {
        [EnumMember]
        Disabled,
        [EnumMember]
        Enabled,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/")]
    public enum PowerReporting
    {
        [EnumMember]
        Advanced,
        [EnumMember]
        None,
        [EnumMember]
        Standard,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/")]
    public enum PowerState
    {
        [EnumMember]
        Off,
        [EnumMember]
        Offline,
        [EnumMember]
        OffOffline,
        [EnumMember]
        Online,
        [EnumMember]
        Unknown,
    }

    /*
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/")]
    public enum StatisticCategories
    {
        [EnumMember]
        All,
        [EnumMember]
        Manufacturer,
        [EnumMember]
        Upos,
    }
    */
    public class StatisticCategories
    {
        public const string All = "";
        public const string Manufacturer = "M_";
        public const string Upos = "U_";
    }

    //
    // Specific Data Types
    //

    //
    // Specific Enumerations
    //

    
    //[DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/")]
    //public enum DeviceUnits
    //{       
    //    [EnumMember]
    //    Unit1,
    //    [EnumMember]
    //    Unit10,
    //    [EnumMember]
    //    Unit11,
    //    [EnumMember]
    //    Unit12,
    //    [EnumMember]
    //    Unit13,
    //    [EnumMember]
    //    Unit14,
    //    [EnumMember]
    //    Unit15,
    //    [EnumMember]
    //    Unit16,
    //    [EnumMember]
    //    Unit17,
    //    [EnumMember]
    //    Unit18,
    //    [EnumMember]
    //    Unit19,
    //    [EnumMember]
    //    Unit2,
    //    [EnumMember]
    //    Unit20,
    //    [EnumMember]
    //    Unit21,
    //    [EnumMember]
    //    Unit22,
    //    [EnumMember]
    //    Unit23,
    //    [EnumMember]
    //    Unit24,
    //    [EnumMember]
    //    Unit25,
    //    [EnumMember]
    //    Unit26,
    //    [EnumMember]
    //    Unit27,
    //    [EnumMember]
    //    Unit28,
    //    [EnumMember]
    //    Unit29,
    //    [EnumMember]
    //    Unit3,
    //    [EnumMember]
    //    Unit31,
    //    [EnumMember]
    //    Unit32,
    //    [EnumMember]
    //    Unit4,
    //    [EnumMember]
    //    Unit5,
    //    [EnumMember]
    //    Unit6,
    //    [EnumMember]
    //    Unit7,
    //    [EnumMember]
    //    Unit8,
    //    [EnumMember]
    //    Unit9,
    //}

    //[DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/")]
    public class DeviceUnits
    {
        public const int Unit32 = -2147483648;
        public const int Unit1 = 1;
        public const int Unit2 = 2;
        public const int Unit3 = 4;
        public const int Unit4 = 8;
        public const int Unit5 = 16;
        public const int Unit6 = 32;
        public const int Unit7 = 64;
        public const int Unit8 = 128;
        public const int Unit9 = 256;
        public const int Unit10 = 512;
        public const int Unit11 = 1024;
        public const int Unit12 = 2048;
        public const int Unit13 = 4096;
        public const int Unit14 = 8192;
        public const int Unit15 = 16384;
        public const int Unit16 = 32768;
        public const int Unit17 = 65536;
        public const int Unit18 = 131072;
        public const int Unit19 = 262144;
        public const int Unit20 = 524288;
        public const int Unit21 = 1048576;
        public const int Unit22 = 2097152;
        public const int Unit23 = 4194304;
        public const int Unit24 = 8388608;
        public const int Unit25 = 16777216;
        public const int Unit26 = 33554432;
        public const int Unit27 = 67108864;
        public const int Unit28 = 134217728;
        public const int Unit29 = 268435456;
        public const int Unit30 = 536870912;
        public const int Unit31 = 1073741824;
    }

    //[DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/")]
    //public enum VideoAttributes
    //{        
    //    [EnumMember]
    //    BackgroundBlack,
    //    [EnumMember]
    //    BackgroundBlue,
    //    [EnumMember]
    //    BackgroundBrown,
    //    [EnumMember]
    //    BackgroundCyan,
    //    [EnumMember]
    //    BackgroundGray,
    //    [EnumMember]
    //    BackgroundGreen,
    //    [EnumMember]
    //    BackgroundMagenta,
    //    [EnumMember]
    //    BackgroundRed,
    //    [EnumMember]
    //    ForegroundBlack,
    //    [EnumMember]
    //    ForegroundBlue,
    //    [EnumMember]
    //    ForegroundBrown,
    //    [EnumMember]
    //    ForegroundCyan,
    //    [EnumMember]
    //    ForegroundGray,
    //    [EnumMember]
    //    ForegroundGreen,
    //    [EnumMember]
    //    ForegroundMagenta,
    //    [EnumMember]
    //    ForegroundRed,
    //    [EnumMember]
    //    Intensity,
    //  }

    //[DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/")]
    public class VideoAttributes
    {
        public const int BackgroundBlack = 0;
        public const int ForegroundBlack = 0;
        public const int ForegroundBlue = 1;
        public const int ForegroundGreen = 2;
        public const int ForegroundCyan = 3;
        public const int ForegroundRed = 4;
        public const int ForegroundMagenta = 5;
        public const int ForegroundBrown = 6;
        public const int ForegroundGray = 7;
        public const int Intensity = 8;
        public const int BackgroundBlue = 16;
        public const int BackgroundGreen = 32;
        public const int BackgroundCyan = 48;
        public const int BackgroundRed = 64;
        public const int BackgroundMagenta = 80;
        public const int BackgroundBrown = 96;
        public const int BackgroundGray = 112;
        public const int Blink = 128;
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/")]
    public enum ClockFunction
    {
        [EnumMember]
        Move,
        [EnumMember]
        Pause,
        [EnumMember]
        Resume,
        [EnumMember]
        Start,
        [EnumMember]
        Stop,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/")]
    public enum ClockMode
    {
        [EnumMember]
        Hours12,
        [EnumMember]
        Hours24,
        [EnumMember]
        Normal,
        [EnumMember]
        Short,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/")]
    public enum VideoCursorType
    {
        [EnumMember]
        Block,
        [EnumMember]
        BlockBlink,
        [EnumMember]
        Line,
        [EnumMember]
        LineBlink,
        [EnumMember]
        Off,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/")]
    public enum BorderType
    {
       [EnumMember]
        Double,
        [EnumMember]
        Single,
        [EnumMember]
        Solid,    
    }

    //[DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/")]
    //public enum RemoteOrderDisplayEventTypes
    //{
    //    [EnumMember]
    //    TouchDown,
    //    [EnumMember]
    //    TouchMove,
    //    [EnumMember]
    //    TouchUp,
    //}

    //[DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/")]
    public class RemoteOrderDisplayEventTypes
    {
        public const int TouchUp = 1;
        public const int TouchDown = 2;
        public const int TouchMove = 4;
    }


    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/")]
    public enum RemoteOrderDisplayTransaction
    {
        [EnumMember]
        Normal,
        [EnumMember]
        Transaction,
   }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/")]
    public enum VideoAttributeCommand
    {
        [EnumMember]
        BlinkOff,
        [EnumMember]
        BlinkOn,
        [EnumMember]
        IntensityOff,
        [EnumMember]
        IntensityOn,
        [EnumMember]
        ReverseOff,
        [EnumMember]
        ReverseOn,
        [EnumMember]
        Set,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/RemoteOrderDisplay/")]
    public class VideoMode
    {
        [DataMember]
        public int Colors { get; set; }
        [DataMember]
        public int Columns { get; set; }
        [DataMember]
        public bool IsColor { get; set; }
        [DataMember]
        public int ModeId { get; set; }
        [DataMember]
        public int Rows { get; set; }
    }
    


    //
    // Constants
    //

    public class ExtendedError
    {
        public const int FirmwareBadFile = 281;
        public const int Statistics = 280;
        public const int StatisticsDependency = 282;
        public const int BadClock = 201;
        public const int NoBuffers = 204;
        public const int NoClocks = 202;
        public const int NoRegion = 203;
        public const int NoRoom = 205;
    }
    
    public class StatisticProperties
    {
        public const string CommunicationErrorCount = "CommunicationErrorCount";
        public const string DeviceCategory = "DeviceCategory";
        public const string FirmwareRevision = "FirmwareRevision";
        public const string HoursPoweredCount = "HoursPoweredCount";
        public const string InstallationDate = "InstallationDate";
        public const string Interface = "Interface";
        public const string ManufactureDate = "ManufactureDate";
        public const string ManufacturerName = "ManufacturerName";
        public const string MechanicalRevision = "MechanicalRevision";
        public const string ModelName = "ModelName";
        public const string SerialNumber = "SerialNumber";
        public const string UnifiedPOSVersion = "UnifiedPOSVersion";
    }

    public class Wait
    {
        public const int Forever = -1;
    }

    public class CharacterSet
    {
        public const int Ansi = 999;
        public const int Ascii = 998;
        public const int Unicode = 997;
     }

    public class ClockId
    {
        public const int All = 0;
    }
}
