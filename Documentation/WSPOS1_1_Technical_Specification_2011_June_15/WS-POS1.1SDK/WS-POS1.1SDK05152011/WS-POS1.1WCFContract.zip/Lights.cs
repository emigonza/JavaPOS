﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace UnifiedPOS.Lights
{
    [ServiceContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Lights/")]
    public interface Lights
    {

        //
        // Common Properties
        //

        //[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/GetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Lights/GetAutoDisableResponse")]
        //[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/UposException", Name = "UposException")]
        //bool GetAutoDisable();

        //[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/SetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Lights/SetAutoDisableResponse")]
        //[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/UposException", Name = "UposException")]
        //void SetAutoDisable(bool AutoDisable);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/GetCapCompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Lights/GetCapCompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/UposException", Name = "UposException")]
        bool GetCapCompareFirmwareVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/GetCapPowerReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Lights/GetCapPowerReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/UposException", Name = "UposException")]
        PowerReporting GetCapPowerReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/GetCapStatisticsReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Lights/GetCapStatisticsReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/UposException", Name = "UposException")]
        bool GetCapStatisticsReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/GetCapUpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Lights/GetCapUpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/UposException", Name = "UposException")]
        bool GetCapUpdateFirmware();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/GetCapUpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Lights/GetCapUpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/UposException", Name = "UposException")]
        bool GetCapUpdateStatistics();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/GetCheckHealthText", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Lights/GetCheckHealthTextResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/UposException", Name = "UposException")]
        string GetCheckHealthText();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/GetClaimed", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Lights/GetClaimedResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/UposException", Name = "UposException")]
        bool GetClaimed();

        //[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/GetDataCount", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Lights/GetDataCountResponse")]
        //[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/UposException", Name = "UposException")]
        //int GetDataCount();

        //[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/GetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Lights/GetDataEventEnabledResponse")]
        //[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/UposException", Name = "UposException")]
        //bool GetDataEventEnabled();

        //[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/SetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Lights/SetDataEventEnabledResponse")]
        //[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/UposException", Name = "UposException")]
        //void SetDataEventEnabled(bool DataEventEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/GetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Lights/GetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/UposException", Name = "UposException")]
        bool GetDeviceEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/SetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Lights/SetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/UposException", Name = "UposException")]
        void SetDeviceEnabled(bool DeviceEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/GetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Lights/GetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/UposException", Name = "UposException")]
        bool GetFreezeEvents();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/SetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Lights/SetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/UposException", Name = "UposException")]
        void SetFreezeEvents(bool FreezeEvents);

        //[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/GetOutputID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Lights/GetOutputIDResponse")]
        //[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/UposException", Name = "UposException")]
        //int GetOutputID();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/GetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Lights/GetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/UposException", Name = "UposException")]
        PowerNotification GetPowerNotify();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/SetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Lights/SetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/UposException", Name = "UposException")]
        void SetPowerNotify(PowerNotification PowerNotify);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/GetPowerState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Lights/GetPowerStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/UposException", Name = "UposException")]
        PowerState GetPowerState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/GetState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Lights/GetStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/UposException", Name = "UposException")]
        ControlState GetState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/GetDeviceControlDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Lights/GetDeviceControlDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/UposException", Name = "UposException")]
        string GetDeviceControlDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/GetDeviceControlVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Lights/GetDeviceControlVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/UposException", Name = "UposException")]
        UposVersion GetDeviceControlVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/GetDeviceServiceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Lights/GetDeviceServiceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/UposException", Name = "UposException")]
        string GetDeviceServiceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/GetDeviceServiceVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Lights/GetDeviceServiceVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/UposException", Name = "UposException")]
        UposVersion GetDeviceServiceVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/GetPhysicalDeviceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Lights/GetPhysicalDeviceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/UposException", Name = "UposException")]
        string GetPhysicalDeviceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/GetPhysicalDeviceName", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Lights/GetPhysicalDeviceNameResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/UposException", Name = "UposException")]
        string GetPhysicalDeviceName();

        //
        // Specific Properties
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/GetCapAlarm", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Lights/GetCapAlarmResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/UposException", Name = "UposException")]
        int GetCapAlarm();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/GetCapBlink", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Lights/GetCapBlinkResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/UposException", Name = "UposException")]
        bool GetCapBlink();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/GetCapColor", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Lights/GetCapColorResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/UposException", Name = "UposException")]
        int GetCapColor();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/GetMaxLights", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Lights/GetMaxLightsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/UposException", Name = "UposException")]
        int GetMaxLights();

        //
        // Common Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/Open", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Lights/OpenResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/UposException", Name = "UposException")]
        void Open(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/Close", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Lights/CloseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/UposException", Name = "UposException")]
        void Close(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/Claim", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Lights/ClaimResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/UposException", Name = "UposException")]
        void Claim(int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/Release", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Lights/ReleaseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/UposException", Name = "UposException")]
        void Release();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/CheckHealth", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Lights/CheckHealthResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/UposException", Name = "UposException")]
        void CheckHealth(HealthCheckLevel Level);

        //[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/ClearInput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Lights/ClearInputResponse")]
        //[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/UposException", Name = "UposException")]
        //void ClearInput();

        //[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/ClearInputProperties", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Lights/ClearInputPropertiesResponse")]
        //[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/UposException", Name = "UposException")]
        //void ClearInputProperties();

        //[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/ClearOutput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Lights/ClearOutputResponse")]
        //[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/UposException", Name = "UposException")]
        //void ClearOutput();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/DirectIO", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Lights/DirectIOResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/UposException", Name = "UposException")]
        DirectIOData DirectIO(int Command, int Data, object Obj);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/CompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Lights/CompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/UposException", Name = "UposException")]
        CompareFirmwareResult CompareFirmwareVersion(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/ResetStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Lights/ResetStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/UposException", Name = "UposException")]
        void ResetStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/RetrieveStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Lights/RetrieveStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/UposException", Name = "UposException")]
        string RetrieveStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/UpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Lights/UpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/UposException", Name = "UposException")]
        void UpdateFirmware(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/UpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Lights/UpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/UposException", Name = "UposException")]
        void UpdateStatistics(StatisticList StatisticsBuffer);

        //
        // Specific Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/SwitchOff", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Lights/SwitchOffResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/UposException", Name = "UposException")]
        void SwitchOff(int LightNumber);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/SwitchOn", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Lights/SwitchOnResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Lights/UposException", Name = "UposException")]
        void SwitchOn(int LightNumber, int BlinkOnCycle, int BlinkOffCycle, int Color, int Alarm);

    }

    //
    // Common Data Types
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Lights/")]
    public class DirectIOData
    {
        [DataMember]
        public int Data { get; set; }
        [DataMember]
        public object Obj { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Lights/")]
    public class UposException
    {
        [DataMember]
        public ErrorCode ErrorCode { get; set; }
        [DataMember]
        public int ErrorCodeExtended { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Lights/")]
    public class UposVersion
    {
        [DataMember]
        public int Major { get; set; }
        [DataMember]
        public int Minor { get; set; }
        [DataMember]
        public int Build { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Lights/")]
    public class Statistic
    {
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public string Value { get; set; }
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Lights/", ItemName = "Statistic")]
    public class StatisticList : List<Statistic>
    {
    }

    //
    // Common Enumerations
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Lights/")]
    public enum CompareFirmwareResult
    {
        [EnumMember]
        Different,
        [EnumMember]
        Newer,
        [EnumMember]
        Older,
        [EnumMember]
        Same,
        [EnumMember]
        Unknown,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Lights/")]
    public enum ControlState
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Closed,
        [EnumMember]
        Error,
        [EnumMember]
        Idle,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Lights/")]
    public enum ErrorCode
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Claimed,
        [EnumMember]
        Closed,
        [EnumMember]
        Deprecated,
        [EnumMember]
        Disabled,
        [EnumMember]
        Exists,
        [EnumMember]
        Extended,
        [EnumMember]
        Failure,
        [EnumMember]
        Illegal,
        [EnumMember]
        NoExist,
        [EnumMember]
        NoHardware,
        [EnumMember]
        NoService,
        [EnumMember]
        NotClaimed,
        [EnumMember]
        Offline,
        [EnumMember]
        Success,
        [EnumMember]
        Timeout,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Lights/")]
    public enum HealthCheckLevel
    {
        [EnumMember]
        External,
        [EnumMember]
        Interactive,
        [EnumMember]
        Internal,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Lights/")]
    public enum PowerNotification
    {
        [EnumMember]
        Disabled,
        [EnumMember]
        Enabled,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Lights/")]
    public enum PowerReporting
    {
        [EnumMember]
        Advanced,
        [EnumMember]
        None,
        [EnumMember]
        Standard,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Lights/")]
    public enum PowerState
    {
        [EnumMember]
        Off,
        [EnumMember]
        Offline,
        [EnumMember]
        OffOffline,
        [EnumMember]
        Online,
        [EnumMember]
        Unknown,
    }

    /*
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Lights/")]
    public enum StatisticCategories
    {
        [EnumMember]
        All,
        [EnumMember]
        Manufacturer,
        [EnumMember]
        Upos,
    }
    */
    public class StatisticCategories
    {
        public const string All = "";
        public const string Manufacturer = "M_";
        public const string Upos = "U_";
    }

    //
    // Specific Data Types
    //

    //
    // Specific Enumerations
    //

    //
    // Constants
    //

    public class ExtendedError
    {
        public const int FirmwareBadFile = 281;
        public const int Statistics = 280;
        public const int StatisticsDependency = 282;
    }

    public class StatisticProperties
    {
        public const string CommunicationErrorCount = "CommunicationErrorCount";
        public const string DeviceCategory = "DeviceCategory";
        public const string FirmwareRevision = "FirmwareRevision";
        public const string HoursPoweredCount = "HoursPoweredCount";
        public const string InstallationDate = "InstallationDate";
        public const string Interface = "Interface";
        public const string ManufactureDate = "ManufactureDate";
        public const string ManufacturerName = "ManufacturerName";
        public const string MechanicalRevision = "MechanicalRevision";
        public const string ModelName = "ModelName";
        public const string SerialNumber = "SerialNumber";
        public const string UnifiedPOSVersion = "UnifiedPOSVersion";
    }

    public class Wait
    {
        public const int Forever = -1;
    }

    public class LightAlarms
    {
        public const int None = 1;
        public const int Slow = 16;
        public const int Medium = 32;
        public const int Fast = 64;
        public const int Custom1 = 65536;
        public const int Custom2 = 131072;
    }

    public class LightColors
    {
        public const int Primary = 1;
        public const int Custom1 = 65536;
        public const int Custom2 = 131072;
        public const int Custom3 = 262144;
        public const int Custom4 = 524288;
        public const int Custom5 = 1048576;
    }
}
