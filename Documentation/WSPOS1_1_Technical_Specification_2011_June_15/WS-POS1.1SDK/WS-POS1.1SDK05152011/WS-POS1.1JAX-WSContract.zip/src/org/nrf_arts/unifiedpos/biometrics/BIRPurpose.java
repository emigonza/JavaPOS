
package org.nrf_arts.unifiedpos.biometrics;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for BIRPurpose.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="BIRPurpose">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="Unspecified"/>
 *     &lt;enumeration value="Verify"/>
 *     &lt;enumeration value="Identify"/>
 *     &lt;enumeration value="Enroll"/>
 *     &lt;enumeration value="EnrollForVerificationOnly"/>
 *     &lt;enumeration value="EnrollForIdentificationOnly"/>
 *     &lt;enumeration value="Audit"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "BIRPurpose")
@XmlEnum
public enum BIRPurpose {

    @XmlEnumValue("Unspecified")
    UNSPECIFIED("Unspecified"),
    @XmlEnumValue("Verify")
    VERIFY("Verify"),
    @XmlEnumValue("Identify")
    IDENTIFY("Identify"),
    @XmlEnumValue("Enroll")
    ENROLL("Enroll"),
    @XmlEnumValue("EnrollForVerificationOnly")
    ENROLL_FOR_VERIFICATION_ONLY("EnrollForVerificationOnly"),
    @XmlEnumValue("EnrollForIdentificationOnly")
    ENROLL_FOR_IDENTIFICATION_ONLY("EnrollForIdentificationOnly"),
    @XmlEnumValue("Audit")
    AUDIT("Audit");
    private final String value;

    BIRPurpose(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static BIRPurpose fromValue(String v) {
        for (BIRPurpose c: BIRPurpose.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
