﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace UnifiedPOS.PINPad
{
    [ServiceContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/PINPad/")]
    public interface PINPad
    {

        //
        // Common Properties
        //

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetAutoDisableResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        // int GetAutoDisable();

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/SetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/SetAutoDisableResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        // void SetAutoDisable(int AutoDisable);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetCapCompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetCapCompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        bool GetCapCompareFirmwareVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetCapPowerReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetCapPowerReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        PowerReporting GetCapPowerReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetCapStatisticsReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetCapStatisticsReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        bool GetCapStatisticsReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetCapUpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetCapUpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        bool GetCapUpdateFirmware();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetCapUpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetCapUpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        bool GetCapUpdateStatistics();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetCheckHealthText", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetCheckHealthTextResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        string GetCheckHealthText();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetClaimed", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetClaimedResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        bool GetClaimed();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetDataCount", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetDataCountResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        int GetDataCount();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetDataEventEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        bool GetDataEventEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/SetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/SetDataEventEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        void SetDataEventEnabled(bool DataEventEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        bool GetDeviceEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/SetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/SetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        void SetDeviceEnabled(bool DeviceEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        bool GetFreezeEvents();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/SetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/SetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        void SetFreezeEvents(bool FreezeEvents);

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetOutputID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetOutputIDResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        // int GetOutputID();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        PowerNotification GetPowerNotify();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/SetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/SetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        void SetPowerNotify(PowerNotification PowerNotify);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetPowerState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetPowerStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        PowerState GetPowerState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        ControlState GetState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetDeviceControlDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetDeviceControlDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        string GetDeviceControlDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetDeviceControlVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetDeviceControlVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        UposVersion GetDeviceControlVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetDeviceServiceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetDeviceServiceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        string GetDeviceServiceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetDeviceServiceVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetDeviceServiceVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        UposVersion GetDeviceServiceVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetPhysicalDeviceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetPhysicalDeviceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        string GetPhysicalDeviceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetPhysicalDeviceName", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetPhysicalDeviceNameResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        string GetPhysicalDeviceName();

        //
        // Specific Properties
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetCapDisplay", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetCapDisplayResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        PINPadDisplay GetCapDisplay();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetCapKeyboard", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetCapKeyboardResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        bool GetCapKeyboard();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetCapLanguage", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetCapLanguageResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        PINPadLanguage GetCapLanguage();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetCapMACCalculation", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetCapMACCalculationResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        bool GetCapMACCalculation();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetCapTone", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetCapToneResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        bool GetCapTone();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetAccountNumber", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetAccountNumberResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        string GetAccountNumber();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/SetAccountNumber", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/SetAccountNumberResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        void SetAccountNumber(string AccountNumber);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetAdditionalSecurityInformation", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetAdditionalSecurityInformationResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        string GetAdditionalSecurityInformation();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetAmount", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetAmountResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        decimal GetAmount();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/SetAmount", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/SetAmountResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        void SetAmount(decimal Amount);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetAvailableLanguagesList", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetAvailableLanguagesListResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        LanguageList GetAvailableLanguagesList();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetAvailablePromptsList", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetAvailablePromptsListResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        PINPadMessageList GetAvailablePromptsList();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetEncryptedPIN", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetEncryptedPINResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        string GetEncryptedPIN();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetMaximumPINLength", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetMaximumPINLengthResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        int GetMaximumPINLength();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/SetMaximumPINLength", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/SetMaximumPINLengthResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        void SetMaximumPINLength(int MaximumPINLength);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetMerchantID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetMerchantIDResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        string GetMerchantID();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/SetMerchantID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/SetMerchantIDResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        void SetMerchantID(string MerchantID);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetMinimumPINLength", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetMinimumPINLengthResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        int GetMinimumPINLength();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/SetMinimumPINLength", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/SetMinimumPINLengthResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        void SetMinimumPINLength(int MinimumPINLength);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetPINEntryEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetPINEntryEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        bool GetPINEntryEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetPrompt", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetPromptResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        int GetPrompt();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/SetPrompt", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/SetPromptResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        void SetPrompt(int Prompt);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetPromptLanguage", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetPromptLanguageResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        string GetPromptLanguage();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/SetPromptLanguage", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/SetPromptLanguageResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        void SetPromptLanguage(string PromptLanguage);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetTerminalID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetTerminalIDResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        string GetTerminalID();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/SetTerminalID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/SetTerminalIDResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        void SetTerminalID(string TerminalID);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetTrack1Data", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetTrack1DataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        byte[] GetTrack1Data();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/SetTrack1Data", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/SetTrack1DataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        void SetTrack1Data(byte[] Track1Data);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetTrack2Data", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetTrack2DataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        byte[] GetTrack2Data();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/SetTrack2Data", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/SetTrack2DataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        void SetTrack2Data(byte[] Track2Data);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetTrack3Data", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetTrack3DataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        byte[] GetTrack3Data();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/SetTrack3Data", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/SetTrack3DataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        void SetTrack3Data(byte[] Track3Data);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetTrack4Data", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetTrack4DataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        byte[] GetTrack4Data();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/SetTrack4Data", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/SetTrack4DataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        void SetTrack4Data(byte[] Track4Data);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetTransactionType", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/GetTransactionTypeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        EFTTransactionType GetTransactionType();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/SetTransactionType", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/SetTransactionTypeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        void SetTransactionType(EFTTransactionType TransactionType);

        //
        // Common Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/Open", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/OpenResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        void Open(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/Close", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/CloseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        void Close(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/Claim", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/ClaimResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        void Claim(int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/Release", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/ReleaseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        void Release();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/CheckHealth", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/CheckHealthResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        void CheckHealth(HealthCheckLevel Level);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/ClearInput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/ClearInputResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        void ClearInput();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/ClearInputProperties", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/ClearInputPropertiesResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        void ClearInputProperties();

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/ClearOutput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/ClearOutputResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        // void ClearOutput();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/DirectIO", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/DirectIOResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        DirectIOData DirectIO(int Command, int Data, object Obj);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/CompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/CompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        CompareFirmwareResult CompareFirmwareVersion(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/ResetStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/ResetStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        void ResetStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/RetrieveStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/RetrieveStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        string RetrieveStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        void UpdateFirmware(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        void UpdateStatistics(StatisticList StatisticsBuffer);

        //
        // Specific Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/BeginEFTTransaction", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/BeginEFTTransactionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        void BeginEFTTransaction(PINPadSystem PINPadSystem, int TransactionHost);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/ComputeMAC", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/ComputeMACResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        string ComputeMAC(string InMsg);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/EnablePINEntry", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/EnablePINEntryResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        void EnablePINEntry();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/EndEFTTransaction", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/EndEFTTransactionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        void EndEFTTransaction(EFTTransactionCompletion CompletionCode);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UpdateKey", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UpdateKeyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        void UpdateKey(int KeyNum, string Key);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/VerifyMAC", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PINPad/VerifyMACResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PINPad/UposException", Name = "UposException")]
        void VerifyMAC(string Message);
    }

    //
    // Common Data Types
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/PINPad/")]
    public class DirectIOData
    {
        [DataMember]
        public int Data { get; set; }
        [DataMember]
        public object Obj { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/PINPad/")]
    public class UposException
    {
        [DataMember]
        public ErrorCode ErrorCode { get; set; }
        [DataMember]
        public int ErrorCodeExtended { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/PINPad/")]
    public class UposVersion
    {
        [DataMember]
        public int Major { get; set; }
        [DataMember]
        public int Minor { get; set; }
        [DataMember]
        public int Build { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/PINPad/")]
    public class Statistic
    {
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public string Value { get; set; }
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/PINPad/", ItemName = "Statistic")]
    public class StatisticList : List<Statistic>
    {
    }

    //
    // Common Enumerations
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/PINPad/")]
    public enum CompareFirmwareResult
    {
        [EnumMember]
        Different,
        [EnumMember]
        Newer,
        [EnumMember]
        Older,
        [EnumMember]
        Same,
        [EnumMember]
        Unknown,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/PINPad/")]
    public enum ControlState
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Closed,
        [EnumMember]
        Error,
        [EnumMember]
        Idle,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/PINPad/")]
    public enum ErrorCode
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Claimed,
        [EnumMember]
        Closed,
        [EnumMember]
        Deprecated,
        [EnumMember]
        Disabled,
        [EnumMember]
        Exists,
        [EnumMember]
        Extended,
        [EnumMember]
        Failure,
        [EnumMember]
        Illegal,
        [EnumMember]
        NoExist,
        [EnumMember]
        NoHardware,
        [EnumMember]
        NoService,
        [EnumMember]
        NotClaimed,
        [EnumMember]
        Offline,
        [EnumMember]
        Success,
        [EnumMember]
        Timeout,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/PINPad/")]
    public enum HealthCheckLevel
    {
        [EnumMember]
        External,
        [EnumMember]
        Interactive,
        [EnumMember]
        Internal,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/PINPad/")]
    public enum PowerNotification
    {
        [EnumMember]
        Disabled,
        [EnumMember]
        Enabled,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/PINPad/")]
    public enum PowerReporting
    {
        [EnumMember]
        Advanced,
        [EnumMember]
        None,
        [EnumMember]
        Standard,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/PINPad/")]
    public enum PowerState
    {
        [EnumMember]
        Off,
        [EnumMember]
        Offline,
        [EnumMember]
        OffOffline,
        [EnumMember]
        Online,
        [EnumMember]
        Unknown,
    }

    /*
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/PINPad/")]
    public enum StatisticCategories
    {
        [EnumMember]
        All,
        [EnumMember]
        Manufacturer,
        [EnumMember]
        Upos,
    }
    */
    public class StatisticCategories
    {
        public const string All = "";
        public const string Manufacturer = "M_";
        public const string Upos = "U_";
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/PINPad/", ItemName = "Language")]
    public class LanguageList : List<string>
    {
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/PINPad/", ItemName = "PINPadMessage")]
    public class PINPadMessageList : List<int>
    {
    }

    //
    // Specific Enumerations
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/PINPad/")]
    public enum EFTTransactionCompletion
    {
        [EnumMember]
        Abnormal,
        [EnumMember]
        Normal,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/PINPad/")]
    public enum EFTTransactionType
    {
        [EnumMember]
        Admin,
        [EnumMember]
        Credit,
        [EnumMember]
        Debit,
        [EnumMember]
        Inquiry,
        [EnumMember]
        Reconcile,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/PINPad/")]
    public enum PINPadDisplay
    {
        [EnumMember]
        None,
        [EnumMember]
        PinRestricted,
        [EnumMember]
        RestrictedList,
        [EnumMember]
        RestrictedOrder,
        [EnumMember]
        Unrestricted,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/PINPad/")]
    public enum PINPadLanguage
    {
        [EnumMember]
        None,
        [EnumMember]
        One,
        [EnumMember]
        PinRestricted,
        [EnumMember]
        Unrestricted,
    }

    /*
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/PINPad/")]
    public enum PINPadMessage
    {
        [EnumMember]
        AmountOK,
        [EnumMember]
        Approved,
        [EnumMember]
        Canceled,
        [EnumMember]
        Declined,
        [EnumMember]
        EnterPin,
        [EnumMember]
        EnterValidPin,
        [EnumMember]
        Idle,
        [EnumMember]
        InsertCard,
        [EnumMember]
        NotReady,
        [EnumMember]
        PleaseWait,
        [EnumMember]
        RetriesExceeded,
        [EnumMember]
        SelectCardType,
        [EnumMember]
        SlideCard,
    }
    */
    public class PINPadMessage
    {
        public const int AmountOK = 8;
        public const int Approved = 5;
        public const int Canceled = 7;
        public const int Declined = 6;
        public const int EnterPin = 1;
        public const int EnterValidPin = 3;
        public const int Idle = 10;
        public const int InsertCard = 12;
        public const int NotReady = 9;
        public const int PleaseWait = 2;
        public const int RetriesExceeded = 4;
        public const int SelectCardType = 13;
        public const int SlideCard = 11;
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/PINPad/")]
    public enum PINPadSystem
    {
        [EnumMember]
        Apacs40,
        [EnumMember]
        AS2805,
        [EnumMember]
        Dukpt,
        [EnumMember]
        Hgepos,
        [EnumMember]
        Jdebit2,
        [EnumMember]
        MasterSession,
    }

    //
    // Constants
    //

    /*
    public class Constants
    {
        public const int ExtendedErrorBadKey = 201;
        public const int ExtendedErrorFirmwareBadFile = 281;
        public const int ExtendedErrorStatistics = 280;
        public const int ExtendedErrorStatisticsDependency = 282;
        public const string StatisticCommunicationErrorCount = "CommunicationErrorCount";
        public const string StatisticDeviceCategory = "DeviceCategory";
        public const string StatisticFirmwareRevision = "FirmwareRevision";
        public const string StatisticHoursPoweredCount = "HoursPoweredCount";
        public const string StatisticInstallationDate = "InstallationDate";
        public const string StatisticInterface = "Interface";
        public const string StatisticInvalidPINEntryCount = "InvalidPINEntryCount";
        public const string StatisticManufactureDate = "ManufactureDate";
        public const string StatisticManufacturerName = "ManufacturerName";
        public const string StatisticMechanicalRevision = "MechanicalRevision";
        public const string StatisticModelName = "ModelName";
        public const string StatisticSerialNumber = "SerialNumber";
        public const string StatisticUnifiedPOSVersion = "UnifiedPOSVersion";
        public const string StatisticValidPINEntryCount = "ValidPINEntryCount";
        public const int WaitForever = -1;
    }
    */

    public class ExtendedError
    {
        public const int BadKey = 201;
        public const int FirmwareBadFile = 281;
        public const int Statistics = 280;
        public const int StatisticsDependency = 282;
    }

    public class StatisticProperties
    {
        public const string CommunicationErrorCount = "CommunicationErrorCount";
        public const string DeviceCategory = "DeviceCategory";
        public const string FirmwareRevision = "FirmwareRevision";
        public const string HoursPoweredCount = "HoursPoweredCount";
        public const string InstallationDate = "InstallationDate";
        public const string Interface = "Interface";
        public const string InvalidPINEntryCount = "InvalidPINEntryCount";
        public const string ManufactureDate = "ManufactureDate";
        public const string ManufacturerName = "ManufacturerName";
        public const string MechanicalRevision = "MechanicalRevision";
        public const string ModelName = "ModelName";
        public const string SerialNumber = "SerialNumber";
        public const string UnifiedPOSVersion = "UnifiedPOSVersion";
        public const string ValidPINEntryCount = "ValidPINEntryCount";
    }

    public class Wait
    {
        public const int Forever = -1;
    }
}
