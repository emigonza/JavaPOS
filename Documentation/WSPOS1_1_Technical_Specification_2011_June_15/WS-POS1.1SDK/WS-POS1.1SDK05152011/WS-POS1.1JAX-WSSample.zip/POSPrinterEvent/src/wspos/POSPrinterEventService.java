/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package wspos;

import javax.xml.datatype.XMLGregorianCalendar;
import org.nrf_arts.unifiedpos.posprinterevents.*;
import javax.jws.WebService;
import java.util.HashMap;

/**
 *
 * @author hideon
 */
@WebService(serviceName = "POSPrinterEventService", endpointInterface = "org.nrf_arts.unifiedpos.posprinterevents.POSPrinterEvent", targetNamespace = "http://www.nrf-arts.org/UnifiedPOS/POSPrinterEvents/")
public class POSPrinterEventService implements POSPrinterEvent {

    private static HashMap<Integer, String> convert;

    static {
        convert = new HashMap<Integer, String>();
        convert.put(Status.COVER_OK, "CoverOK");
        convert.put(Status.COVER_OPEN, "CoverOpen");
        convert.put(Status.IDLE, "Idle");
        convert.put(Status.JOURNAL_CARTRIDGE_EMPTY, "JournalCartridgeEmpty");
        convert.put(Status.JOURNAL_CARTRIDGE_NEAR_EMPTY, "JournalCartridgeNearEmpty");
        convert.put(Status.JOURNAL_CARTRIDGE_OK, "JournalCartridgeOK");
        convert.put(Status.JOURNAL_COVER_OK, "JournalCoverOK");
        convert.put(Status.JOURNAL_COVER_OPEN, "JournalCoverOpen");
        convert.put(Status.JOURNAL_EMPTY, "JournalEmpty");
        convert.put(Status.JOURNAL_HEAD_CLEANING, "JournalHeadCleaning");
        convert.put(Status.JOURNAL_NEAR_EMPTY, "JournalNearEmpty");
        convert.put(Status.JOURNAL_PAPER_OK, "JournalPaperOK");
        convert.put(Status.POWER_OFF, "PowerOff");
        convert.put(Status.POWER_OFFLINE, "PowerOffline");
        convert.put(Status.POWER_OFF_OFFLINE, "PowerOffOffline");
        convert.put(Status.POWER_ONLINE, "PowerOnline");
        convert.put(Status.RECEIPT_CARTRIDGE_EMPTY, "ReceiptCartridgeEmpty");
        convert.put(Status.RECEIPT_CARTRIDGE_NEAR_EMPTY, "ReceiptCartridgeNearEmpty");
        convert.put(Status.RECEIPT_CARTRIDGE_OK, "ReceiptCartridgeOK");
        convert.put(Status.RECEIPT_COVER_OK, "ReceiptCoverOK");
        convert.put(Status.RECEIPT_COVER_OPEN, "ReceiptCoverOpen");
        convert.put(Status.RECEIPT_EMPTY, "ReceiptEmpty");
        convert.put(Status.RECEIPT_HEAD_CLEANING, "ReceiptHeadCleaning");
        convert.put(Status.RECEIPT_NEAR_EMPTY, "ReceiptNearEmpty");
        convert.put(Status.RECEIPT_PAPER_OK, "ReceiptPaperOK");
        convert.put(Status.SLIP_CARTRIDGE_EMPTY, "SlipCartridgeEmpty");
        convert.put(Status.SLIP_CARTRIDGE_NEAR_EMPTY, "SlipCartridgeNearEmpty");
        convert.put(Status.SLIP_CARTRIDGE_OK, "SlipCartridgeOK");
        convert.put(Status.SLIP_COVER_OK, "SlipCoverOK");
        convert.put(Status.SLIP_COVER_OPEN, "SlipCoverOpen");
        convert.put(Status.SLIP_EMPTY, "SlipEmpty");
        convert.put(Status.SLIP_HEAD_CLEANING, "SlipHeadCleaning");
        convert.put(Status.SLIP_NEAR_EMPTY, "SlipNearEmpty");
        convert.put(Status.SLIP_PAPER_OK, "SlipPaperOK");
        convert.put(Status.UPDATE_FIRMWARE_COMPLETE, "UpdateFirmwareComplete");
        convert.put(Status.UPDATE_FIRMWARE_COMPLETE_DEVICE_NOT_RESTORED, "UpdateFirmwareCompleteDeviceNotRestored");
        convert.put(Status.UPDATE_FIRMWARE_FAILED_DEVICE_NEEDS_FIRMWARE, "UpdateFirmwareFailedDeviceNeedsFirmware");
        convert.put(Status.UPDATE_FIRMWARE_FAILED_DEVICE_OK, "UpdateFirmwareFailedDeviceOk");
        convert.put(Status.UPDATE_FIRMWARE_FAILED_DEVICE_UNKNOWN, "UpdateFirmwareFailedDeviceUnknown");
        convert.put(Status.UPDATE_FIRMWARE_FAILED_DEVICE_UNRECOVERABLE, "UpdateFirmwareFailedDeviceUnrecoverable");
        convert.put(Status.UPDATE_FIRMWARE_PROGRESS, "UpdateFirmwareProgress");
    }

    //
    // POSPrinterEvent Member
    //

    public DirectIOData directIOEvent(String source, Integer eventID, XMLGregorianCalendar timeStamp, Integer eventNumber, Integer data, Object obj) {
        //throw new UnsupportedOperationException("Not supported yet.");
        System.out.println(eventID + ", " + timeStamp + ", DirectIOEvent, " + eventNumber + ", " + data + ", " + obj);
        DirectIOData res = new DirectIOData();
        res.setData(data);
        res.setObj(obj);
        return res;
    }

    public ErrorResponse errorEvent(String source, Integer eventID, XMLGregorianCalendar timeStamp, ErrorCode errorCode, Integer errorCodeExtended, ErrorLocus errorLocus, ErrorResponse errorResponse) {
        //throw new UnsupportedOperationException("Not supported yet.");
        System.out.println(eventID + ", " + timeStamp + ", ErrorEvent, " + errorCode + ", " + errorCodeExtended + ", " + errorLocus + ", " + errorResponse);
        return ErrorResponse.CLEAR;
    }

    public void outputCompleteEvent(String source, Integer eventID, XMLGregorianCalendar timeStamp, Integer outputID) {
        //throw new UnsupportedOperationException("Not supported yet.");
        System.out.println(eventID + ", " + timeStamp + ", OutputCompleteEvent, " + outputID);
    }

    public void statusUpdateEvent(String source, Integer eventID, XMLGregorianCalendar timeStamp, Integer status) {
        //throw new UnsupportedOperationException("Not supported yet.");
        int p = Status.UPDATE_FIRMWARE_PROGRESS;
        String s = (status > p && status < p + 100) ? convert.get(p) + " + " + (status - p) : convert.get(status);
        System.out.println(eventID + ", " + timeStamp + ", StatusUpdateEvent, " + s);
    }
}
