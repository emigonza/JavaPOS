﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;

namespace Wspos
{
    class ElectronicValueRWServiceHost
    {
        public void Start()
        {
            using (ServiceHost serviceHost = new ServiceHost(typeof(ElectronicValueRWService)))
            {
                Console.WriteLine("WS-POS 1.1 WCF Service");
                serviceHost.Open();

                Console.WriteLine("Press [Enter] to close.");
                Console.ReadLine();
                serviceHost.Close();
            }
        }

        static void Main(string[] args)
        {
            ElectronicValueRWServiceHost program = new ElectronicValueRWServiceHost();
            program.Start();
        }
    }
}
