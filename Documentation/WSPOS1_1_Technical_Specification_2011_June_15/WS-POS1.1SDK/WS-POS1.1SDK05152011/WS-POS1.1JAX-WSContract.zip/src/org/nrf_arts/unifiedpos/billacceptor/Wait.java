
package org.nrf_arts.unifiedpos.billacceptor;

public class Wait {

    public static final int FOREVER = -1;

}
