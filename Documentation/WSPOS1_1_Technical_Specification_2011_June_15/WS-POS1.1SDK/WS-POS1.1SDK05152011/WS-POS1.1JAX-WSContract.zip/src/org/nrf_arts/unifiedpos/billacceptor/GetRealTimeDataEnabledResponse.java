
package org.nrf_arts.unifiedpos.billacceptor;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="GetRealTimeDataEnabledResult" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "getRealTimeDataEnabledResult"
})
@XmlRootElement(name = "GetRealTimeDataEnabledResponse")
public class GetRealTimeDataEnabledResponse {

    @XmlElement(name = "GetRealTimeDataEnabledResult")
    protected Boolean getRealTimeDataEnabledResult;

    /**
     * Gets the value of the getRealTimeDataEnabledResult property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isGetRealTimeDataEnabledResult() {
        return getRealTimeDataEnabledResult;
    }

    /**
     * Sets the value of the getRealTimeDataEnabledResult property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setGetRealTimeDataEnabledResult(Boolean value) {
        this.getRealTimeDataEnabledResult = value;
    }

}
