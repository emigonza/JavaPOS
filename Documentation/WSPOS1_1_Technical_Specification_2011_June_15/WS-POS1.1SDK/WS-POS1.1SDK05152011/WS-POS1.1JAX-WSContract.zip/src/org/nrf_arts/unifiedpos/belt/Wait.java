
package org.nrf_arts.unifiedpos.belt;

public class Wait {

    public static final int FOREVER = -1;

}
