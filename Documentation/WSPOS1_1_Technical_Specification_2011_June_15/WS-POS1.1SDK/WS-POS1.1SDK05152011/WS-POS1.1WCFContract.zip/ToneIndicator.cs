﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace UnifiedPOS.ToneIndicator
{
    [ServiceContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/")]
    public interface ToneIndicator
    {

        //
        // Common Properties
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetCapCompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetCapCompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UposException", Name = "UposException")]
        bool GetCapCompareFirmwareVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetCapPowerReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetCapPowerReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UposException", Name = "UposException")]
        PowerReporting GetCapPowerReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetCapStatisticsReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetCapStatisticsReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UposException", Name = "UposException")]
        bool GetCapStatisticsReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetCapUpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetCapUpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UposException", Name = "UposException")]
        bool GetCapUpdateFirmware();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetCapUpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetCapUpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UposException", Name = "UposException")]
        bool GetCapUpdateStatistics();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetCheckHealthText", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetCheckHealthTextResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UposException", Name = "UposException")]
        string GetCheckHealthText();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetClaimed", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetClaimedResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UposException", Name = "UposException")]
        bool GetClaimed();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UposException", Name = "UposException")]
        bool GetDeviceEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/SetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/SetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UposException", Name = "UposException")]
        void SetDeviceEnabled(bool DeviceEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UposException", Name = "UposException")]
        bool GetFreezeEvents();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/SetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/SetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UposException", Name = "UposException")]
        void SetFreezeEvents(bool FreezeEvents);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetOutputID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetOutputIDResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UposException", Name = "UposException")]
        int GetOutputID();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UposException", Name = "UposException")]
        PowerNotification GetPowerNotify();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/SetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/SetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UposException", Name = "UposException")]
        void SetPowerNotify(PowerNotification PowerNotify);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetPowerState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetPowerStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UposException", Name = "UposException")]
        PowerState GetPowerState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UposException", Name = "UposException")]
        ControlState GetState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetDeviceControlDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetDeviceControlDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UposException", Name = "UposException")]
        string GetDeviceControlDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetDeviceControlVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetDeviceControlVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UposException", Name = "UposException")]
        UposVersion GetDeviceControlVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetDeviceServiceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetDeviceServiceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UposException", Name = "UposException")]
        string GetDeviceServiceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetDeviceServiceVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetDeviceServiceVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UposException", Name = "UposException")]
        UposVersion GetDeviceServiceVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetPhysicalDeviceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetPhysicalDeviceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UposException", Name = "UposException")]
        string GetPhysicalDeviceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetPhysicalDeviceName", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetPhysicalDeviceNameResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UposException", Name = "UposException")]
        string GetPhysicalDeviceName();

        //
        // Specific Properties
        //
        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetAsyncMode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetAsyncModeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UposException", Name = "UposException")]
        bool GetAsyncMode();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/SetAsyncMode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/SetAsyncModeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UposException", Name = "UposException")]
        void SetAsyncMode(bool AsyncMode);    
        
        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetCapPitch", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetCapPitchResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UposException", Name = "UposException")]
        bool GetCapPitch();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetCapVolume", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetCapVolumeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UposException", Name = "UposException")]
        bool GetCapVolume();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetInterToneWait", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetInterToneWaitResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UposException", Name = "UposException")]
        int GetInterToneWait();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/SetInterToneWait", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/SetInterToneWaitResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UposException", Name = "UposException")]
        void SetInterToneWait(int InterToneWait);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetTone1Duration", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetTone1DurationResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UposException", Name = "UposException")]
        int GetTone1Duration();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/SetTone1Duration", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/SetTone1DurationResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UposException", Name = "UposException")]
        void SetTone1Duration(int Tone1Duration);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetTone1Pitch", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetTone1PitchResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UposException", Name = "UposException")]
        int GetTone1Pitch();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/SetTone1Pitch", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/SetTone1PitchResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UposException", Name = "UposException")]
        void SetTone1Pitch(int Tone1Pitch);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetTone1Volume", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetTone1VolumeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UposException", Name = "UposException")]
        int GetTone1Volume();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/SetTone1Volume", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/SetTone1VolumeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UposException", Name = "UposException")]
        void SetTone1Volume(int Tone1Volume);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetTone2Duration", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetTone2DurationResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UposException", Name = "UposException")]
        int GetTone2Duration();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/SetTone2Duration", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/SetTone2DurationResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UposException", Name = "UposException")]
        void SetTone2Duration(int Tone2Duration);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetTone2Pitch", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetTone2PitchResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UposException", Name = "UposException")]
        int GetTone2Pitch();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/SetTone2Pitch", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/SetTone2PitchResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UposException", Name = "UposException")]
        void SetTone2Pitch(int Tone2Pitch);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetTone2Volume", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetTone2VolumeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UposException", Name = "UposException")]
        int GetTone2Volume();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/SetTone2Volume", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/SetTone2VolumeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UposException", Name = "UposException")]
        void SetTone2Volume(int Tone2Volume);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetCapMelody", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetCapMelodyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UposException", Name = "UposException")]
        int GetCapMelody();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetMelodyType", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetMelodyTypeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UposException", Name = "UposException")]
        int GetMelodyType();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/SetMelodyType", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/SetMelodyTypeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UposException", Name = "UposException")]
        void SetMelodyType(int MelodyType);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetMelodyVolume", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/GetMelodyVolumeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UposException", Name = "UposException")]
        int GetMelodyVolume();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/SetMelodyVolume", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/SetMelodyVolumeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UposException", Name = "UposException")]
        void SetMelodyVolume(int MelodyVolume);

        //
        // Common Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/Open", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/OpenResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UposException", Name = "UposException")]
        void Open(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/Close", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/CloseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UposException", Name = "UposException")]
        void Close(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/Claim", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/ClaimResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UposException", Name = "UposException")]
        void Claim(int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/Release", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/ReleaseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UposException", Name = "UposException")]
        void Release();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/CheckHealth", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/CheckHealthResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UposException", Name = "UposException")]
        void CheckHealth(HealthCheckLevel Level);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/ClearOutput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/ClearOutputResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UposException", Name = "UposException")]
        void ClearOutput();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/DirectIO", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/DirectIOResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UposException", Name = "UposException")]
        DirectIOData DirectIO(int Command, int Data, object Obj);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/CompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/CompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UposException", Name = "UposException")]
        CompareFirmwareResult CompareFirmwareVersion(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/ResetStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/ResetStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UposException", Name = "UposException")]
        void ResetStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/RetrieveStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/RetrieveStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UposException", Name = "UposException")]
        string RetrieveStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UposException", Name = "UposException")]
        void UpdateFirmware(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UposException", Name = "UposException")]
        void UpdateStatistics(StatisticList StatisticsBuffer);

        //
        // Specific Methods
        //
        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/Sound", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/SoundResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UposException", Name = "UposException")]
        void Sound(int NumberOfCycles, int InterSoundWait);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/SoundImmediate", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/SoundImmediateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/UposException", Name = "UposException")]
        void SoundImmediate();
    }

    //
    // Common Data Types
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/")]
    public class DirectIOData
    {
        [DataMember]
        public int Data { get; set; }
        [DataMember]
        public object Obj { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/")]
    public class UposException
    {
        [DataMember]
        public ErrorCode ErrorCode { get; set; }
        [DataMember]
        public int ErrorCodeExtended { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/")]
    public class UposVersion
    {
        [DataMember]
        public int Major { get; set; }
        [DataMember]
        public int Minor { get; set; }
        [DataMember]
        public int Build { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/")]
    public class Statistic
    {
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public string Value { get; set; }
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/", ItemName = "Statistic")]
    public class StatisticList : List<Statistic>
    {
    }

    //
    // Common Enumerations
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/")]
    public enum CompareFirmwareResult
    {
        [EnumMember]
        Different,
        [EnumMember]
        Newer,
        [EnumMember]
        Older,
        [EnumMember]
        Same,
        [EnumMember]
        Unknown,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/")]
    public enum ControlState
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Closed,
        [EnumMember]
        Error,
        [EnumMember]
        Idle,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/")]
    public enum ErrorCode
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Claimed,
        [EnumMember]
        Closed,
        [EnumMember]
        Deprecated,
        [EnumMember]
        Disabled,
        [EnumMember]
        Exists,
        [EnumMember]
        Extended,
        [EnumMember]
        Failure,
        [EnumMember]
        Illegal,
        [EnumMember]
        NoExist,
        [EnumMember]
        NoHardware,
        [EnumMember]
        NoService,
        [EnumMember]
        NotClaimed,
        [EnumMember]
        Offline,
        [EnumMember]
        Success,
        [EnumMember]
        Timeout,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/")]
    public enum HealthCheckLevel
    {
        [EnumMember]
        External,
        [EnumMember]
        Interactive,
        [EnumMember]
        Internal,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/")]
    public enum PowerNotification
    {
        [EnumMember]
        Disabled,
        [EnumMember]
        Enabled,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/")]
    public enum PowerReporting
    {
        [EnumMember]
        Advanced,
        [EnumMember]
        None,
        [EnumMember]
        Standard,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/")]
    public enum PowerState
    {
        [EnumMember]
        Off,
        [EnumMember]
        Offline,
        [EnumMember]
        OffOffline,
        [EnumMember]
        Online,
        [EnumMember]
        Unknown,
    }

    /*
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ToneIndicator/")]
    public enum StatisticCategories
    {
        [EnumMember]
        All,
        [EnumMember]
        Manufacturer,
        [EnumMember]
        Upos,
    }
    */
    public class StatisticCategories
    {
        public const string All = "";
        public const string Manufacturer = "M_";
        public const string Upos = "U_";
    }

    //
    // Specific Data Types
    //

    //
    // Specific Enumerations
    //

    //
    // Constants
    //

    public class ExtendedError
    {
        public const int FirmwareBadFile = 281;
        public const int Statistics = 280;
        public const int StatisticsDependency = 282;
    }

    public class StatisticProperties
    {
        public const string CommunicationErrorCount = "CommunicationErrorCount";
        public const string DeviceCategory = "DeviceCategory";
        public const string FirmwareRevision = "FirmwareRevision";
        public const string HoursPoweredCount = "HoursPoweredCount";
        public const string InstallationDate = "InstallationDate";
        public const string Interface = "Interface";
        public const string ManufactureDate = "ManufactureDate";
        public const string ManufacturerName = "ManufacturerName";
        public const string MechanicalRevision = "MechanicalRevision";
        public const string ModelName = "ModelName";
        public const string SerialNumber = "SerialNumber";
        public const string ToneSoundedCount = "ToneSoundedCount";
        public const string UnifiedPOSVersion = "UnifiedPOSVersion";
    }

    public class Wait
    {
        public const int Forever = -1;
    }

    public class Melody
    {
        public const int None = 0;
        public const int Type1 = 1;
        public const int Type2 = 2;
        public const int Type3 = 3;
        public const int Type4 = 4;
        public const int Type5 = 5;
    }
}
