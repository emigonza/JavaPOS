﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;

namespace Wspos
{
    class ScannerEventServiceHost
    {
        public void Start()
        {
            using (ServiceHost serviceHost = new ServiceHost(typeof(ScannerEventService)))
            {
                Console.WriteLine("WS-POS 1.1 WCF Service");
                serviceHost.Open();

                Console.WriteLine("Press [Enter] to close.");
                Console.ReadLine();
                serviceHost.Close();
            }
        }

        static void Main(string[] args)
        {
            ScannerEventServiceHost program = new ScannerEventServiceHost();
            program.Start();
        }
    }
}
