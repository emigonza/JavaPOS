﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace UnifiedPOS.ElectronicValueRW
{
    [ServiceContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/")]
    public interface ElectronicValueRW
    {

        //
        // Common Properties
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetAutoDisableResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        bool GetAutoDisable();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/SetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/SetAutoDisableResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        void SetAutoDisable(bool AutoDisable);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetCapCompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetCapCompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        bool GetCapCompareFirmwareVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetCapPowerReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetCapPowerReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        PowerReporting GetCapPowerReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetCapStatisticsReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetCapStatisticsReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        bool GetCapStatisticsReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetCapUpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetCapUpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        bool GetCapUpdateFirmware();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetCapUpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetCapUpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        bool GetCapUpdateStatistics();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetCheckHealthText", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetCheckHealthTextResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        string GetCheckHealthText();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetClaimed", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetClaimedResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        bool GetClaimed();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetDataCount", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetDataCountResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        int GetDataCount();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetDataEventEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        bool GetDataEventEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/SetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/SetDataEventEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        void SetDataEventEnabled(bool DataEventEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        bool GetDeviceEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/SetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/SetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        void SetDeviceEnabled(bool DeviceEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        bool GetFreezeEvents();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/SetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/SetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        void SetFreezeEvents(bool FreezeEvents);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetOutputID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetOutputIDResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        int GetOutputID();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        PowerNotification GetPowerNotify();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/SetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/SetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        void SetPowerNotify(PowerNotification PowerNotify);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetPowerState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetPowerStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        PowerState GetPowerState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        ControlState GetState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetDeviceControlDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetDeviceControlDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        string GetDeviceControlDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetDeviceControlVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetDeviceControlVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        UposVersion GetDeviceControlVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetDeviceServiceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetDeviceServiceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        string GetDeviceServiceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetDeviceServiceVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetDeviceServiceVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        UposVersion GetDeviceServiceVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetPhysicalDeviceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetPhysicalDeviceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        string GetPhysicalDeviceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetPhysicalDeviceName", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetPhysicalDeviceNameResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        string GetPhysicalDeviceName();

        //
        // Specific Properties
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetCapActivateService", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetCapActivateServiceResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        bool GetCapActivateService();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetCapAddValue", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetCapAddValueResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        bool GetCapAddValue();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetCapCancelValue", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetCapCancelValueResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        bool GetCapCancelValue();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetCapCardSensor", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetCapCardSensorResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        int GetCapCardSensor();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetCapDetectionControl", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetCapDetectionControlResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        int GetCapDetectionControl();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetCapElectronicMoney", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetCapElectronicMoneyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        bool GetCapElectronicMoney();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetCapEnumerateCardServices", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetCapEnumerateCardServicesResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        bool GetCapEnumerateCardServices();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetCapIndirectTransactionLog", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetCapIndirectTransactionLogResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        bool GetCapIndirectTransactionLog();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetCapLockTerminal", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetCapLockTerminalResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        bool GetCapLockTerminal();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetCapLogStatus", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetCapLogStatusResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        bool GetCapLogStatus();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetCapMediumID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetCapMediumIDResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        bool GetCapMediumID();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetCapPoint", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetCapPointResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        bool GetCapPoint();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetCapSubtractValue", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetCapSubtractValueResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        bool GetCapSubtractValue();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetCapTransaction", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetCapTransactionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        bool GetCapTransaction();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetCapTransactionLog", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetCapTransactionLogResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        bool GetCapTransactionLog();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetCapUnlockTerminal", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetCapUnlockTerminalResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        bool GetCapUnlockTerminal();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetCapUpdateKey", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetCapUpdateKeyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        bool GetCapUpdateKey();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetCapVoucher", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetCapVoucherResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        bool GetCapVoucher();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetCapWriteValue", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetCapWriteValueResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        bool GetCapWriteValue();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetAccountNumber", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetAccountNumberResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        string GetAccountNumber();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetAdditionalSecurityInformation", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetAdditionalSecurityInformationResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        string GetAdditionalSecurityInformation();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/SetAdditionalSecurityInformation", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/SetAdditionalSecurityInformationResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        void SetAdditionalSecurityInformation(string AdditionalSecurityInformation);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetAmount", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetAmountResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        decimal GetAmount();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/SetAmount", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/SetAmountResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        void SetAmount(decimal Amount);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetApprovalCode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetApprovalCodeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        string GetApprovalCode();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/SetApprovalCode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/SetApprovalCodeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        void SetApprovalCode(string ApprovalCode);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetAsyncMode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetAsyncModeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        bool GetAsyncMode();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/SetAsyncMode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/SetAsyncModeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        void SetAsyncMode(bool AsyncMode);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetBalance", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetBalanceResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        decimal GetBalance();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetBalanceOfPoint", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetBalanceOfPointResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        decimal GetBalanceOfPoint();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetCardServiceList", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetCardServiceListResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        CardServiceList GetCardServiceList();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetCurrentService", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetCurrentServiceResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        string GetCurrentService();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/SetCurrentService", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/SetCurrentServiceResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        void SetCurrentService(string CurrentService);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetDetectionControl", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetDetectionControlResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        bool GetDetectionControl();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/SetDetectionControl", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/SetDetectionControlResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        void SetDetectionControl(bool DetectionControl);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetDetectionStatus", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetDetectionStatusResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        DetectionState GetDetectionStatus();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetExpirationDate", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetExpirationDateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        DateTime GetExpirationDate();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetLastUsedDate", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetLastUsedDateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        DateTime GetLastUsedDate();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetLogStatus", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetLogStatusResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        LogState GetLogStatus();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetMediumID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetMediumIDResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        string GetMediumID();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/SetMediumID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/SetMediumIDResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        void SetMediumID(string MediumID);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetPoint", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetPointResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        decimal GetPoint();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/SetPoint", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/SetPointResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        void SetPoint(decimal Point);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetReaderWriterServiceList", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetReaderWriterServiceListResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        ReaderWriterServiceList GetReaderWriterServiceList();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetSequenceNumber", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetSequenceNumberResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        int GetSequenceNumber();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetSettledAmount", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetSettledAmountResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        decimal GetSettledAmount();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetSettledPoint", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetSettledPointResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        decimal GetSettledPoint();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetTransactionLog", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetTransactionLogResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        string GetTransactionLog();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetVoucherID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetVoucherIDResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        VoucherID GetVoucherID();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/SetVoucherID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/SetVoucherIDResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        void SetVoucherID(VoucherID VoucherID);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetVoucherIDList", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/GetVoucherIDListResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        VoucherIDList GetVoucherIDList();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/SetVoucherIDList", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/SetVoucherIDListResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        void SetVoucherIDList(VoucherIDList VoucherIDList);

        //
        // Common Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/Open", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/OpenResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        void Open(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/Close", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/CloseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        void Close(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/Claim", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/ClaimResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        void Claim(int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/Release", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/ReleaseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        void Release();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/CheckHealth", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/CheckHealthResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        void CheckHealth(HealthCheckLevel Level);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/ClearInput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/ClearInputResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        void ClearInput();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/ClearInputProperties", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/ClearInputPropertiesResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        void ClearInputProperties();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/ClearOutput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/ClearOutputResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        void ClearOutput();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/DirectIO", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/DirectIOResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        DirectIOData DirectIO(int Command, int Data, object Obj);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/CompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/CompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        CompareFirmwareResult CompareFirmwareVersion(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/ResetStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/ResetStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        void ResetStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/RetrieveStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/RetrieveStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        string RetrieveStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        void UpdateFirmware(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        void UpdateStatistics(StatisticList StatisticsBuffer);

        //
        // Specific Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/AccessLog", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/AccessLogResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        void AccessLog(int SequenceNumber, TransactionLogType Type, int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/ActivateService", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/ActivateServiceResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        EVRWResult ActivateService(int Data, object Obj);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/AddValue", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/AddValueResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        void AddValue(int SequenceNumber, int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/BeginDetection", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/BeginDetectionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        void BeginDetection(BeginDetectionType Type, int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/BeginRemoval", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/BeginRemovalResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        void BeginRemoval(int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/CancelValue", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/CancelValueResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        void CancelValue(int SequenceNumber, int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/CaptureCard", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/CaptureCardResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        void CaptureCard();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/EndDetection", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/EndDetectionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        void EndDetection();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/EndRemoval", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/EndRemovalResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        void EndRemoval();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/EnumerateCardServices", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/EnumerateCardServicesResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        void EnumerateCardServices();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/LockTerminal", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/LockTerminalResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        void LockTerminal();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/ReadValue", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/ReadValueResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        void ReadValue(int SequenceNumber, int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/SubtractValue", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/SubtractValueResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        void SubtractValue(int SequenceNumber, int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/TransactionAccess", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/TransactionAccessResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        void TransactionAccess(TransactionControl Control);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UnlockTerminal", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UnlockTerminalResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        void UnlockTerminal();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UpdateKey", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UpdateKeyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        EVRWResult UpdateKey(int Data, object Obj);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/WriteValue", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/WriteValueResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/UposException", Name = "UposException")]
        void WriteValue(int SequenceNumber, int Timeout);
    }

    //
    // Common Data Types
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/")]
    public class DirectIOData
    {
        [DataMember]
        public int Data { get; set; }
        [DataMember]
        public object Obj { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/")]
    public class UposException
    {
        [DataMember]
        public ErrorCode ErrorCode { get; set; }
        [DataMember]
        public int ErrorCodeExtended { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/")]
    public class UposVersion
    {
        [DataMember]
        public int Major { get; set; }
        [DataMember]
        public int Minor { get; set; }
        [DataMember]
        public int Build { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/")]
    public class Statistic
    {
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public string Value { get; set; }
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/", ItemName = "Statistic")]
    public class StatisticList : List<Statistic>
    {
    }

    //
    // Common Enumerations
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/")]
    public enum CompareFirmwareResult
    {
        [EnumMember]
        Different,
        [EnumMember]
        Newer,
        [EnumMember]
        Older,
        [EnumMember]
        Same,
        [EnumMember]
        Unknown,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/")]
    public enum ControlState
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Closed,
        [EnumMember]
        Error,
        [EnumMember]
        Idle,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/")]
    public enum ErrorCode
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Claimed,
        [EnumMember]
        Closed,
        [EnumMember]
        Deprecated,
        [EnumMember]
        Disabled,
        [EnumMember]
        Exists,
        [EnumMember]
        Extended,
        [EnumMember]
        Failure,
        [EnumMember]
        Illegal,
        [EnumMember]
        NoExist,
        [EnumMember]
        NoHardware,
        [EnumMember]
        NoService,
        [EnumMember]
        NotClaimed,
        [EnumMember]
        Offline,
        [EnumMember]
        Success,
        [EnumMember]
        Timeout,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/")]
    public enum HealthCheckLevel
    {
        [EnumMember]
        External,
        [EnumMember]
        Interactive,
        [EnumMember]
        Internal,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/")]
    public enum PowerNotification
    {
        [EnumMember]
        Disabled,
        [EnumMember]
        Enabled,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/")]
    public enum PowerReporting
    {
        [EnumMember]
        Advanced,
        [EnumMember]
        None,
        [EnumMember]
        Standard,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/")]
    public enum PowerState
    {
        [EnumMember]
        Off,
        [EnumMember]
        Offline,
        [EnumMember]
        OffOffline,
        [EnumMember]
        Online,
        [EnumMember]
        Unknown,
    }

    /*
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/")]
    public enum StatisticCategories
    {
        [EnumMember]
        All,
        [EnumMember]
        Manufacturer,
        [EnumMember]
        Upos,
    }
    */
    public class StatisticCategories
    {
        public const string All = "";
        public const string Manufacturer = "M_";
        public const string Upos = "U_";
    }

    //
    // Specific Data Types
    //

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/", ItemName = "CardService")]
    public class CardServiceList : List<string>
    {
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/")]
    public class EVRWResult
    {
        [DataMember]
        public int Data { get; set; }
        [DataMember]
        public object Obj { get; set; }
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/", ItemName = "ReaderWriterService")]
    public class ReaderWriterServiceList : List<string>
    {
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/")]
    public class VoucherID
    {
        [DataMember]
        public int Count { get; set; }
        [DataMember]
        public string TicketID { get; set; }
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/", ItemName = "VoucherID")]
    public class VoucherIDList : List<VoucherID>
    {
    }

    //
    // Specific Enumerations
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/")]
    public enum BeginDetectionType
    {
        [EnumMember]
        Any,
        [EnumMember]
        Specific,
    }

    /*
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/")]
    public enum CardDetectionControl
    {
        [EnumMember]
        Application,
        [EnumMember]
        Device,
    }
    */
    public class CardDetectionControl
    {
        public const int Application = 2;
        public const int Device = 1;
    }

    /*
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/")]
    public enum CardDetectionTypes
    {
        [EnumMember]
        Capture,
        [EnumMember]
        Detect,
        [EnumMember]
        Entry,
    }
    */
    public class CardDetectionTypes
    {
        public const int Capture = 4;
        public const int Detect = 2;
        public const int Entry = 1;
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/")]
    public enum DetectionState
    {
        [EnumMember]
        Captured,
        [EnumMember]
        Detected,
        [EnumMember]
        Entered,
        [EnumMember]
        NoCard,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/")]
    public enum LogState
    {
        [EnumMember]
        Full,
        [EnumMember]
        NearFull,
        [EnumMember]
        Ok,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/")]
    public enum TransactionControl
    {
        [EnumMember]
        Normal,
        [EnumMember]
        Transaction,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRW/")]
    public enum TransactionLogType
    {
        [EnumMember]
        Reporting,
        [EnumMember]
        Settlement,
    }

    //
    // Constants
    //

    /*
    public class Constants
    {
        public const int ExtendedErrorCenterError = 203;
        public const int ExtendedErrorCommandError = 204;
        public const int ExtendedErrorCommunicationError = 206;
        public const int ExtendedErrorDailyLogOverflow = 208;
        public const int ExtendedErrorDeficient = 209;
        public const int ExtendedErrorFirmwareBadFile = 281;
        public const int ExtendedErrorLogOverflow = 207;
        public const int ExtendedErrorNoCard = 201;
        public const int ExtendedErrorOverdeposit = 210;
        public const int ExtendedErrorRelease = 202;
        public const int ExtendedErrorReset = 205;
        public const int ExtendedErrorStatistics = 280;
        public const int ExtendedErrorStatisticsDependency = 282;
        public const string StatisticCommunicationErrorCount = "CommunicationErrorCount";
        public const string StatisticDeviceCategory = "DeviceCategory";
        public const string StatisticFirmwareRevision = "FirmwareRevision";
        public const string StatisticHoursPoweredCount = "HoursPoweredCount";
        public const string StatisticInstallationDate = "InstallationDate";
        public const string StatisticInterface = "Interface";
        public const string StatisticManufactureDate = "ManufactureDate";
        public const string StatisticManufacturerName = "ManufacturerName";
        public const string StatisticMechanicalRevision = "MechanicalRevision";
        public const string StatisticModelName = "ModelName";
        public const string StatisticSerialNumber = "SerialNumber";
        public const string StatisticUnifiedPOSVersion = "UnifiedPOSVersion";
        public const int WaitForever = -1;
    }
    */

    public class ExtendedError
    {
        public const int CenterError = 203;
        public const int CommandError = 204;
        public const int CommunicationError = 206;
        public const int DailyLogOverflow = 208;
        public const int Deficient = 209;
        public const int FirmwareBadFile = 281;
        public const int LogOverflow = 207;
        public const int NoCard = 201;
        public const int Overdeposit = 210;
        public const int Release = 202;
        public const int Reset = 205;
        public const int Statistics = 280;
        public const int StatisticsDependency = 282;
    }

    public class StatisticProperties
    {
        public const string CommunicationErrorCount = "CommunicationErrorCount";
        public const string DeviceCategory = "DeviceCategory";
        public const string FirmwareRevision = "FirmwareRevision";
        public const string HoursPoweredCount = "HoursPoweredCount";
        public const string InstallationDate = "InstallationDate";
        public const string Interface = "Interface";
        public const string ManufactureDate = "ManufactureDate";
        public const string ManufacturerName = "ManufacturerName";
        public const string MechanicalRevision = "MechanicalRevision";
        public const string ModelName = "ModelName";
        public const string SerialNumber = "SerialNumber";
        public const string UnifiedPOSVersion = "UnifiedPOSVersion";
    }

    public class Wait
    {
        public const int Forever = -1;
    }
}
