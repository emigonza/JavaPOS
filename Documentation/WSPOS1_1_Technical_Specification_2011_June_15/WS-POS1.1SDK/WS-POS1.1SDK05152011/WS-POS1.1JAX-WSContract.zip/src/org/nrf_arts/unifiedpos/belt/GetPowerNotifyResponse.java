
package org.nrf_arts.unifiedpos.belt;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="GetPowerNotifyResult" type="{http://www.nrf-arts.org/UnifiedPOS/Belt/}PowerNotification" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "getPowerNotifyResult"
})
@XmlRootElement(name = "GetPowerNotifyResponse")
public class GetPowerNotifyResponse {

    @XmlElement(name = "GetPowerNotifyResult")
    protected PowerNotification getPowerNotifyResult;

    /**
     * Gets the value of the getPowerNotifyResult property.
     * 
     * @return
     *     possible object is
     *     {@link PowerNotification }
     *     
     */
    public PowerNotification getGetPowerNotifyResult() {
        return getPowerNotifyResult;
    }

    /**
     * Sets the value of the getPowerNotifyResult property.
     * 
     * @param value
     *     allowed object is
     *     {@link PowerNotification }
     *     
     */
    public void setGetPowerNotifyResult(PowerNotification value) {
        this.getPowerNotifyResult = value;
    }

}
