
package org.nrf_arts.unifiedpos.belt;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="GetCapAutoStopForwardResult" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "getCapAutoStopForwardResult"
})
@XmlRootElement(name = "GetCapAutoStopForwardResponse")
public class GetCapAutoStopForwardResponse {

    @XmlElement(name = "GetCapAutoStopForwardResult")
    protected Boolean getCapAutoStopForwardResult;

    /**
     * Gets the value of the getCapAutoStopForwardResult property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isGetCapAutoStopForwardResult() {
        return getCapAutoStopForwardResult;
    }

    /**
     * Sets the value of the getCapAutoStopForwardResult property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setGetCapAutoStopForwardResult(Boolean value) {
        this.getCapAutoStopForwardResult = value;
    }

}
