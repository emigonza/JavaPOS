
package org.nrf_arts.unifiedpos.billdispenser;

public class StatisticProperties {

    public static final String COMMUNICATION_ERROR_COUNT = "CommunicationErrorCount";
    public static final String DEVICE_CATEGORY = "DeviceCategory";
    public static final String FIRMWARE_REVISION = "FirmwareRevision";
    public static final String HOURS_POWERED_COUNT = "HoursPoweredCount";
    public static final String INSTALLATION_DATE = "InstallationDate";
    public static final String INTERFACE = "Interface";
    public static final String MANUFACTURE_DATE = "ManufactureDate";
    public static final String MANUFACTURER_NAME = "ManufacturerName";
    public static final String MECHANICAL_REVISION = "MechanicalRevision";
    public static final String MODEL_NAME = "ModelName";
    public static final String SERIAL_NUMBER = "SerialNumber";
    public static final String UNIFIEDPOS_VERSION = "UnifiedPOSVersion";

}
