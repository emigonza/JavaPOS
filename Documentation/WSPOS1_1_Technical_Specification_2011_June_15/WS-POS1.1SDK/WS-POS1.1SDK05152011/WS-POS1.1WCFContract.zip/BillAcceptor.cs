﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace UnifiedPOS.BillAcceptor
{
    [ServiceContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/")]
    public interface BillAcceptor
    {

        //
        // Common Properties
        //

        /* NOT SUPPORTED
        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetAutoDisableResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        bool GetAutoDisable();
        */

        /* NOT SUPPORTED
        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/SetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/SetAutoDisableResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        void SetAutoDisable(bool AutoDisable);
        */

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetCapCompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetCapCompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        bool GetCapCompareFirmwareVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetCapPowerReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetCapPowerReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        PowerReporting GetCapPowerReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetCapStatisticsReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetCapStatisticsReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        bool GetCapStatisticsReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetCapUpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetCapUpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        bool GetCapUpdateFirmware();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetCapUpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetCapUpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        bool GetCapUpdateStatistics();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetCheckHealthText", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetCheckHealthTextResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        string GetCheckHealthText();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetClaimed", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetClaimedResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        bool GetClaimed();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetDataCount", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetDataCountResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        int GetDataCount();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetDataEventEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        bool GetDataEventEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/SetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/SetDataEventEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        void SetDataEventEnabled(bool DataEventEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        bool GetDeviceEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/SetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/SetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        void SetDeviceEnabled(bool DeviceEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        bool GetFreezeEvents();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/SetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/SetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        void SetFreezeEvents(bool FreezeEvents);

        /* NOT SUPPORTED
        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetOutputID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetOutputIDResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        int GetOutputID();
        */

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        PowerNotification GetPowerNotify();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/SetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/SetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        void SetPowerNotify(PowerNotification PowerNotify);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetPowerState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetPowerStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        PowerState GetPowerState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        ControlState GetState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetDeviceControlDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetDeviceControlDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        string GetDeviceControlDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetDeviceControlVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetDeviceControlVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        UposVersion GetDeviceControlVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetDeviceServiceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetDeviceServiceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        string GetDeviceServiceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetDeviceServiceVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetDeviceServiceVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        UposVersion GetDeviceServiceVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetPhysicalDeviceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetPhysicalDeviceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        string GetPhysicalDeviceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetPhysicalDeviceName", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetPhysicalDeviceNameResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        string GetPhysicalDeviceName();

        //
        // Specific Properties
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetCapDiscrepancy", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetCapDiscrepancyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        bool GetCapDiscrepancy();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetCapFullSensor", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetCapFullSensorResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        bool GetCapFullSensor();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetCapJamSensor", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetCapJamSensorResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        bool GetCapJamSensor();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetCapNearFullSensor", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetCapNearFullSensorResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        bool GetCapNearFullSensor();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetCapPauseDeposit", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetCapPauseDepositResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        bool GetCapPauseDeposit();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetCapRealTimeData", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetCapRealTimeDataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        bool GetCapRealTimeData();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetCurrencyCode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetCurrencyCodeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        string GetCurrencyCode();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/SetCurrencyCode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/SetCurrencyCodeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        void SetCurrencyCode(string CurrencyCode);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetDepositAmount", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetDepositAmountResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        int GetDepositAmount();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetDepositCashList", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetDepositCashListResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        CashUnits GetDepositCashList();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetDepositCodeList", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetDepositCodeListResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        DepositCodeList GetDepositCodeList();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetDepositCounts", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetDepositCountsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        CashCountList GetDepositCounts();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetDepositStatus", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetDepositStatusResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        DepositStatus GetDepositStatus();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetFullStatus", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetFullStatusResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        CashChangerFullStatus GetFullStatus();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetRealTimeDataEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/GetRealTimeDataEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        bool GetRealTimeDataEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/SetRealTimeDataEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/SetRealTimeDataEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        void SetRealTimeDataEnabled(bool RealTimeDataEnabled);


        //
        // Common Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/Open", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/OpenResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        void Open(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/Close", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/CloseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        void Close(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/Claim", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/ClaimResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        void Claim(int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/Release", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/ReleaseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        void Release();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/CheckHealth", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/CheckHealthResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        void CheckHealth(HealthCheckLevel Level);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/ClearInput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/ClearInputResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        void ClearInput();

        /* NOT SUPPORTED
        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/ClearInputProperties", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/ClearInputPropertiesResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        void ClearInputProperties();
        */

        /* NOT SUPPORTED
        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/ClearOutput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/ClearOutputResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        void ClearOutput();
        */

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/DirectIO", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/DirectIOResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        DirectIOData DirectIO(int Command, int Data, object Obj);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/CompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/CompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        CompareFirmwareResult CompareFirmwareVersion(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/ResetStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/ResetStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        void ResetStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/RetrieveStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/RetrieveStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        string RetrieveStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        void UpdateFirmware(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        void UpdateStatistics(StatisticList StatisticsBuffer);

        //
        // Specific Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/AdjustCashCounts", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/AdjustCashCountsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        void AdjustCashCounts(CashCountList CashCounts);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/BeginDeposit", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/BeginDepositResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        void BeginDeposit();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/EndDeposit", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/EndDepositResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        void EndDeposit(EndDepositAction Success);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/FixDeposit", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/FixDepositResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        void FixDeposit();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/PauseDeposit", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/PauseDepositResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        void PauseDeposit(CashDepositPause Control);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/ReadCashCounts", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/ReadCashCountsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/UposException", Name = "UposException")]
        CashCounts ReadCashCounts();

    }

    //
    // Common Data Types
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/")]
    public class DirectIOData
    {
        [DataMember]
        public int Data { get; set; }
        [DataMember]
        public object Obj { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/")]
    public class UposException
    {
        [DataMember]
        public ErrorCode ErrorCode { get; set; }
        [DataMember]
        public int ErrorCodeExtended { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/")]
    public class UposVersion
    {
        [DataMember]
        public int Major { get; set; }
        [DataMember]
        public int Minor { get; set; }
        [DataMember]
        public int Build { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/")]
    public class Statistic
    {
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public string Value { get; set; }
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/", ItemName = "Statistic")]
    public class StatisticList : List<Statistic>
    {
    }

    //
    // Common Enumerations
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/")]
    public enum CompareFirmwareResult
    {
        [EnumMember]
        Different,
        [EnumMember]
        Newer,
        [EnumMember]
        Older,
        [EnumMember]
        Same,
        [EnumMember]
        Unknown,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/")]
    public enum ControlState
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Closed,
        [EnumMember]
        Error,
        [EnumMember]
        Idle,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/")]
    public enum ErrorCode
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Claimed,
        [EnumMember]
        Closed,
        [EnumMember]
        Deprecated,
        [EnumMember]
        Disabled,
        [EnumMember]
        Exists,
        [EnumMember]
        Extended,
        [EnumMember]
        Failure,
        [EnumMember]
        Illegal,
        [EnumMember]
        NoExist,
        [EnumMember]
        NoHardware,
        [EnumMember]
        NoService,
        [EnumMember]
        NotClaimed,
        [EnumMember]
        Offline,
        [EnumMember]
        Success,
        [EnumMember]
        Timeout,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/")]
    public enum HealthCheckLevel
    {
        [EnumMember]
        External,
        [EnumMember]
        Interactive,
        [EnumMember]
        Internal,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/")]
    public enum PowerNotification
    {
        [EnumMember]
        Disabled,
        [EnumMember]
        Enabled,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/")]
    public enum PowerReporting
    {
        [EnumMember]
        Advanced,
        [EnumMember]
        None,
        [EnumMember]
        Standard,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/")]
    public enum PowerState
    {
        [EnumMember]
        Off,
        [EnumMember]
        Offline,
        [EnumMember]
        OffOffline,
        [EnumMember]
        Online,
        [EnumMember]
        Unknown,
    }

    /*
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/")]
    public enum StatisticCategories
    {
        [EnumMember]
        All,
        [EnumMember]
        Manufacturer,
        [EnumMember]
        Upos,
    }
    */
    public class StatisticCategories
    {
        public const string All = "";
        public const string Manufacturer = "M_";
        public const string Upos = "U_";
    }

    //
    // Specific Data Types
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/")]
    public class CashCount
    {
        [DataMember]
        public int Count { get; set;  }
        [DataMember]
        public int NominalValue { get; set; }
        [DataMember]
        public CashCountType Type { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/")]
    public class CashUnits
    {
        [DataMember]
        public BillList Bills { get; set; }
        [DataMember]
        public CoinList Coins { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/")]
    public class CashCounts
    {
        [DataMember]
        public CashCountList Counts { get; set; }
        [DataMember]
        public bool Discrepancy { get; set; }
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/")]
    public class DepositCodeList : List<string>
    {
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/")]
    public class CashCountList : List<CashCount>
    {
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/")]
    public class BillList : List<int>
    {
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/")]
    public class CoinList : List<int>
    {
    }


    //
    // Specific Enumerations
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/")]
    public enum DepositStatus
    {
        [EnumMember]
        Start,
        [EnumMember]
        End,
        [EnumMember]
        Count,
        [EnumMember]
        Jam,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/")]
    public enum EndDepositAction
    {
        [EnumMember]
        Complete
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/")]
    public enum CashChangerFullStatus
    {
        [EnumMember]
        OK,
        [EnumMember]
        Full,
        [EnumMember]
        NearFull,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/")]
    public enum CashDepositPause
    {
        [EnumMember]
        Pause,
        [EnumMember]
        Restart,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/")]
    public enum CashCountType
    {
        [EnumMember]
        Bill,
        [EnumMember]
        Coin,
    }

    //
    // Constants
    //

    public class ExtendedError
    {
        public const int FirmwareBadFile = 281;
        public const int Statistics = 280;
        public const int StatisticsDependency = 282;
    }

    public class StatisticProperties
    {
        public const string CommunicationErrorCount = "CommunicationErrorCount";
        public const string DeviceCategory = "DeviceCategory";
        public const string FirmwareRevision = "FirmwareRevision";
        public const string HoursPoweredCount = "HoursPoweredCount";
        public const string InstallationDate = "InstallationDate";
        public const string Interface = "Interface";
        public const string ManufactureDate = "ManufactureDate";
        public const string ManufacturerName = "ManufacturerName";
        public const string MechanicalRevision = "MechanicalRevision";
        public const string ModelName = "ModelName";
        public const string SerialNumber = "SerialNumber";
        public const string UnifiedPOSVersion = "UnifiedPOSVersion";
    }

    public class Wait
    {
        public const int Forever = -1;
    }
}
