/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package wspos;

import java.net.URL;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import jpos.events.DataEvent;
import jpos.events.DirectIOEvent;
import jpos.events.StatusUpdateEvent;
import org.nrf_arts.unifiedpos.cashchanger.*;
import javax.jws.WebService;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.namespace.QName;
import javax.xml.ws.Service;

/**
 *
 * @author hideon
 */
@WebService(serviceName = "CashChangerService", endpointInterface = "org.nrf_arts.unifiedpos.cashchanger.CashChanger", targetNamespace = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/")
public class CashChangerService implements CashChanger, jpos.events.DataListener, jpos.events.DirectIOListener, jpos.events.StatusUpdateListener {

    //
    // CashChanger Enumration Converter
    //

    private static HashMap<Enum, Integer> jposConst;
    private static HashMap<Integer, PowerReporting> powerReporting;
    private static HashMap<Integer, PowerNotification> powerNotification;
    private static HashMap<Integer, PowerState> powerState;
    private static HashMap<Integer, ControlState> controlState;
    private static HashMap<Integer, HealthCheckLevel> healthCheckLevel;
    private static HashMap<Integer, CompareFirmwareResult> compareFirmwareResult;
    private static HashMap<Integer, ErrorCode> errorCode;
    //private static HashMap<Integer, CashCountType> cashCountType;
    private static HashMap<Integer, CashDepositStatus> cashDepositStatus;
    private static HashMap<Integer, CashChangerStatus> cashChangerStatus;
    private static HashMap<Integer, CashChangerFullStatus> cashChangerFullStatus;
    private static HashMap<Integer, CashDepositAction> cashDepositAction;
    private static HashMap<Integer, CashDepositPause> cashDepositPause;

    static {
        jposConst = new HashMap<Enum, Integer>();
        jposConst.put(PowerReporting.ADVANCED, jpos.CashChanger.JPOS_PR_ADVANCED);
        jposConst.put(PowerReporting.NONE, jpos.CashChanger.JPOS_PR_NONE);
        jposConst.put(PowerReporting.STANDARD, jpos.CashChanger.JPOS_PR_STANDARD);
        jposConst.put(PowerNotification.DISABLED, jpos.CashChanger.JPOS_PN_DISABLED);
        jposConst.put(PowerNotification.ENABLED, jpos.CashChanger.JPOS_PN_ENABLED);
        jposConst.put(PowerState.OFF, jpos.CashChanger.JPOS_PS_OFF);
        jposConst.put(PowerState.OFFLINE, jpos.CashChanger.JPOS_PS_OFFLINE);
        jposConst.put(PowerState.OFF_OFFLINE, jpos.CashChanger.JPOS_PS_OFF_OFFLINE);
        jposConst.put(PowerState.ONLINE, jpos.CashChanger.JPOS_PS_ONLINE);
        jposConst.put(PowerState.UNKNOWN, jpos.CashChanger.JPOS_PS_UNKNOWN);
        jposConst.put(ControlState.BUSY, jpos.CashChanger.JPOS_S_BUSY);
        jposConst.put(ControlState.CLOSED, jpos.CashChanger.JPOS_S_CLOSED);
        jposConst.put(ControlState.ERROR, jpos.CashChanger.JPOS_S_ERROR);
        jposConst.put(ControlState.IDLE, jpos.CashChanger.JPOS_S_IDLE);
        jposConst.put(HealthCheckLevel.EXTERNAL, jpos.CashChanger.JPOS_CH_EXTERNAL);
        jposConst.put(HealthCheckLevel.INTERACTIVE, jpos.CashChanger.JPOS_CH_INTERACTIVE);
        jposConst.put(HealthCheckLevel.INTERNAL, jpos.CashChanger.JPOS_CH_INTERNAL);
        jposConst.put(CompareFirmwareResult.DIFFERENT, jpos.CashChanger.JPOS_CFV_FIRMWARE_DIFFERENT);
        jposConst.put(CompareFirmwareResult.NEWER, jpos.CashChanger.JPOS_CFV_FIRMWARE_NEWER);
        jposConst.put(CompareFirmwareResult.OLDER, jpos.CashChanger.JPOS_CFV_FIRMWARE_OLDER);
        jposConst.put(CompareFirmwareResult.SAME, jpos.CashChanger.JPOS_CFV_FIRMWARE_SAME);
        jposConst.put(CompareFirmwareResult.UNKNOWN, jpos.CashChanger.JPOS_CFV_FIRMWARE_UNKNOWN);
        jposConst.put(ErrorCode.BUSY, jpos.CashChanger.JPOS_E_BUSY);
        jposConst.put(ErrorCode.CLAIMED, jpos.CashChanger.JPOS_E_CLAIMED);
        jposConst.put(ErrorCode.CLOSED, jpos.CashChanger.JPOS_E_CLOSED);
        jposConst.put(ErrorCode.DEPRECATED, jpos.CashChanger.JPOS_E_DEPRECATED);
        jposConst.put(ErrorCode.DISABLED, jpos.CashChanger.JPOS_E_DISABLED);
        jposConst.put(ErrorCode.EXISTS, jpos.CashChanger.JPOS_E_EXISTS);
        jposConst.put(ErrorCode.EXTENDED, jpos.CashChanger.JPOS_E_EXTENDED);
        jposConst.put(ErrorCode.FAILURE, jpos.CashChanger.JPOS_E_FAILURE);
        jposConst.put(ErrorCode.ILLEGAL, jpos.CashChanger.JPOS_E_ILLEGAL);
        jposConst.put(ErrorCode.NO_EXIST, jpos.CashChanger.JPOS_E_NOEXIST);
        jposConst.put(ErrorCode.NO_HARDWARE, jpos.CashChanger.JPOS_E_NOHARDWARE);
        jposConst.put(ErrorCode.NO_SERVICE, jpos.CashChanger.JPOS_E_NOSERVICE);
        jposConst.put(ErrorCode.NOT_CLAIMED, jpos.CashChanger.JPOS_E_NOTCLAIMED);
        jposConst.put(ErrorCode.OFFLINE, jpos.CashChanger.JPOS_E_OFFLINE);
        jposConst.put(ErrorCode.SUCCESS, 0);
        jposConst.put(ErrorCode.TIMEOUT, jpos.CashChanger.JPOS_E_TIMEOUT);
        //jposConst.put(CashCountType.BILL, 0);
        //jposConst.put(CashCountType.COIN, 0);
        jposConst.put(CashDepositStatus.COUNT, jpos.CashChangerConst.CHAN_STATUS_DEPOSIT_COUNT);
        jposConst.put(CashDepositStatus.END, jpos.CashChangerConst.CHAN_STATUS_DEPOSIT_END);
        jposConst.put(CashDepositStatus.JAM, jpos.CashChangerConst.CHAN_STATUS_DEPOSIT_JAM);
        jposConst.put(CashDepositStatus.NONE, jpos.CashChangerConst.CHAN_STATUS_DEPOSIT_NONE);
        jposConst.put(CashDepositStatus.START, jpos.CashChangerConst.CHAN_STATUS_DEPOSIT_START);
        jposConst.put(CashChangerStatus.EMPTY, jpos.CashChangerConst.CHAN_STATUS_EMPTY);
        jposConst.put(CashChangerStatus.JAM, jpos.CashChangerConst.CHAN_STATUS_JAM);
        jposConst.put(CashChangerStatus.NEAR_EMPTY, jpos.CashChangerConst.CHAN_STATUS_NEAREMPTY);
        jposConst.put(CashChangerStatus.OK, jpos.CashChangerConst.CHAN_STATUS_OK);
        jposConst.put(CashChangerFullStatus.FULL, jpos.CashChangerConst.CHAN_STATUS_FULL);
        jposConst.put(CashChangerFullStatus.NEAR_FULL, jpos.CashChangerConst.CHAN_STATUS_NEARFULL);
        jposConst.put(CashChangerFullStatus.OK, jpos.CashChangerConst.CHAN_STATUS_OK);
        jposConst.put(CashDepositAction.CHANGE, jpos.CashChangerConst.CHAN_DEPOSIT_CHANGE);
        jposConst.put(CashDepositAction.NO_CHANGE, jpos.CashChangerConst.CHAN_DEPOSIT_NOCHANGE);
        jposConst.put(CashDepositAction.REPAY, jpos.CashChangerConst.CHAN_DEPOSIT_REPAY);
        jposConst.put(CashDepositPause.PAUSE, jpos.CashChangerConst.CHAN_DEPOSIT_PAUSE);
        jposConst.put(CashDepositPause.RESTART, jpos.CashChangerConst.CHAN_DEPOSIT_RESTART);

        powerReporting = new HashMap<Integer, PowerReporting>();
        powerReporting.put(jpos.CashChanger.JPOS_PR_ADVANCED, PowerReporting.ADVANCED);
        powerReporting.put(jpos.CashChanger.JPOS_PR_NONE, PowerReporting.NONE);
        powerReporting.put(jpos.CashChanger.JPOS_PR_STANDARD, PowerReporting.STANDARD);

        powerNotification = new HashMap<Integer, PowerNotification>();
        powerNotification.put(jpos.CashChanger.JPOS_PN_DISABLED, PowerNotification.DISABLED);
        powerNotification.put(jpos.CashChanger.JPOS_PN_ENABLED, PowerNotification.ENABLED);

        powerState = new HashMap<Integer, PowerState>();
        powerState.put(jpos.CashChanger.JPOS_PS_OFF, PowerState.OFF);
        powerState.put(jpos.CashChanger.JPOS_PS_OFFLINE, PowerState.OFFLINE);
        powerState.put(jpos.CashChanger.JPOS_PS_OFF_OFFLINE, PowerState.OFF_OFFLINE);
        powerState.put(jpos.CashChanger.JPOS_PS_ONLINE, PowerState.ONLINE);
        powerState.put(jpos.CashChanger.JPOS_PS_UNKNOWN, PowerState.UNKNOWN);

        controlState = new HashMap<Integer, ControlState>();
        controlState.put(jpos.CashChanger.JPOS_S_BUSY, ControlState.BUSY);
        controlState.put(jpos.CashChanger.JPOS_S_CLOSED, ControlState.CLOSED);
        controlState.put(jpos.CashChanger.JPOS_S_ERROR, ControlState.ERROR);
        controlState.put(jpos.CashChanger.JPOS_S_IDLE, ControlState.IDLE);

        healthCheckLevel = new HashMap<Integer, HealthCheckLevel>();
        healthCheckLevel.put(jpos.CashChanger.JPOS_CH_EXTERNAL, HealthCheckLevel.EXTERNAL);
        healthCheckLevel.put(jpos.CashChanger.JPOS_CH_INTERACTIVE, HealthCheckLevel.INTERACTIVE);
        healthCheckLevel.put(jpos.CashChanger.JPOS_CH_INTERNAL, HealthCheckLevel.INTERNAL);

        compareFirmwareResult = new HashMap<Integer, CompareFirmwareResult>();
        compareFirmwareResult.put(jpos.CashChanger.JPOS_CFV_FIRMWARE_DIFFERENT, CompareFirmwareResult.DIFFERENT);
        compareFirmwareResult.put(jpos.CashChanger.JPOS_CFV_FIRMWARE_NEWER, CompareFirmwareResult.NEWER);
        compareFirmwareResult.put(jpos.CashChanger.JPOS_CFV_FIRMWARE_OLDER, CompareFirmwareResult.OLDER);
        compareFirmwareResult.put(jpos.CashChanger.JPOS_CFV_FIRMWARE_SAME, CompareFirmwareResult.SAME);
        compareFirmwareResult.put(jpos.CashChanger.JPOS_CFV_FIRMWARE_UNKNOWN, CompareFirmwareResult.UNKNOWN);

        errorCode = new HashMap<Integer, ErrorCode>();
        errorCode.put(jpos.CashChanger.JPOS_E_BUSY, ErrorCode.BUSY);
        errorCode.put(jpos.CashChanger.JPOS_E_CLAIMED, ErrorCode.CLAIMED);
        errorCode.put(jpos.CashChanger.JPOS_E_CLOSED, ErrorCode.CLOSED);
        errorCode.put(jpos.CashChanger.JPOS_E_DEPRECATED, ErrorCode.DEPRECATED);
        errorCode.put(jpos.CashChanger.JPOS_E_DISABLED, ErrorCode.DISABLED);
        errorCode.put(jpos.CashChanger.JPOS_E_EXISTS, ErrorCode.EXISTS);
        errorCode.put(jpos.CashChanger.JPOS_E_EXTENDED, ErrorCode.EXTENDED);
        errorCode.put(jpos.CashChanger.JPOS_E_FAILURE, ErrorCode.FAILURE);
        errorCode.put(jpos.CashChanger.JPOS_E_ILLEGAL, ErrorCode.ILLEGAL);
        errorCode.put(jpos.CashChanger.JPOS_E_NOEXIST, ErrorCode.NO_EXIST);
        errorCode.put(jpos.CashChanger.JPOS_E_NOHARDWARE, ErrorCode.NO_HARDWARE);
        errorCode.put(jpos.CashChanger.JPOS_E_NOSERVICE, ErrorCode.NO_SERVICE);
        errorCode.put(jpos.CashChanger.JPOS_E_NOTCLAIMED, ErrorCode.NOT_CLAIMED);
        errorCode.put(jpos.CashChanger.JPOS_E_OFFLINE, ErrorCode.OFFLINE);
        errorCode.put(0, ErrorCode.SUCCESS);
        errorCode.put(jpos.CashChanger.JPOS_E_TIMEOUT, ErrorCode.TIMEOUT);

        //cashCountType = new HashMap<Integer, CashCountType>();
        //cashCountType.put(0, CashCountType.BILL);
        //cashCountType.put(0, CashCountType.COIN);

        cashDepositStatus = new HashMap<Integer, CashDepositStatus>();
        cashDepositStatus.put(jpos.CashChangerConst.CHAN_STATUS_DEPOSIT_COUNT, CashDepositStatus.COUNT);
        cashDepositStatus.put(jpos.CashChangerConst.CHAN_STATUS_DEPOSIT_END, CashDepositStatus.END);
        cashDepositStatus.put(jpos.CashChangerConst.CHAN_STATUS_DEPOSIT_JAM, CashDepositStatus.JAM);
        cashDepositStatus.put(jpos.CashChangerConst.CHAN_STATUS_DEPOSIT_NONE, CashDepositStatus.NONE);
        cashDepositStatus.put(jpos.CashChangerConst.CHAN_STATUS_DEPOSIT_START, CashDepositStatus.START);

        cashChangerStatus = new HashMap<Integer, CashChangerStatus>();
        cashChangerStatus.put(jpos.CashChangerConst.CHAN_STATUS_EMPTY, CashChangerStatus.EMPTY);
        cashChangerStatus.put(jpos.CashChangerConst.CHAN_STATUS_JAM, CashChangerStatus.JAM);
        cashChangerStatus.put(jpos.CashChangerConst.CHAN_STATUS_NEAREMPTY, CashChangerStatus.NEAR_EMPTY);
        cashChangerStatus.put(jpos.CashChangerConst.CHAN_STATUS_OK, CashChangerStatus.OK);

        cashChangerFullStatus = new HashMap<Integer, CashChangerFullStatus>();
        cashChangerFullStatus.put(jpos.CashChangerConst.CHAN_STATUS_FULL, CashChangerFullStatus.FULL);
        cashChangerFullStatus.put(jpos.CashChangerConst.CHAN_STATUS_NEARFULL, CashChangerFullStatus.NEAR_FULL);
        cashChangerFullStatus.put(jpos.CashChangerConst.CHAN_STATUS_OK, CashChangerFullStatus.OK);

        cashDepositAction = new HashMap<Integer, CashDepositAction>();
        cashDepositAction.put(jpos.CashChangerConst.CHAN_DEPOSIT_CHANGE, CashDepositAction.CHANGE);
        cashDepositAction.put(jpos.CashChangerConst.CHAN_DEPOSIT_NOCHANGE, CashDepositAction.NO_CHANGE);
        cashDepositAction.put(jpos.CashChangerConst.CHAN_DEPOSIT_REPAY, CashDepositAction.REPAY);

        cashDepositPause = new HashMap<Integer, CashDepositPause>();
        cashDepositPause.put(jpos.CashChangerConst.CHAN_DEPOSIT_PAUSE, CashDepositPause.PAUSE);
        cashDepositPause.put(jpos.CashChangerConst.CHAN_DEPOSIT_RESTART, CashDepositPause.RESTART);
    }

    private String deviceName;
    private UposVersion deviceControlVersion;
    private org.nrf_arts.unifiedpos.cashchangerevents.CashChangerEvent deviceEvent;
    private jpos.CashChanger device = new jpos.CashChanger();
    private DatatypeFactory datatypeFactory;

    public CashChangerService(String logicalDeviceName) {
        deviceName = logicalDeviceName;
        deviceControlVersion = new UposVersion();
        deviceControlVersion.setMajor(1);
        deviceControlVersion.setMinor(13);
        deviceControlVersion.setBuild(1);
        try {
            datatypeFactory = DatatypeFactory.newInstance();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    //
    // CashChanger Member
    //

    public void adjustCashCounts(CashCountList cashCounts) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            StringBuffer bills = new StringBuffer();
            StringBuffer coins = new StringBuffer();
            for (CashCount count : cashCounts.getCashCount()) {
                if (count.getType().equals(CashCountType.BILL)) {
                    bills.append(",").append(count.getNominalValue()).append(":").append(count.getCount());
                }
                else if (count.getType().equals(CashCountType.COIN)) {
                    coins.append(",").append(count.getNominalValue()).append(":").append(count.getCount());
                }
            }
            device.adjustCashCounts(coins.substring(1) + ";" + bills.substring(1));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void beginDeposit() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.beginDeposit();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void checkHealth(HealthCheckLevel level) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.checkHealth(jposConst.get(level));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void claim(Integer timeout) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.claim(timeout);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void clearInput() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.clearInput();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void close(String endpointAddress) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            if (deviceEvent != null)
            {
                device.removeDataListener(this);
                device.removeDirectIOListener(this);
                device.removeStatusUpdateListener(this);
                deviceEvent = null;
            }
            device.close();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public CompareFirmwareResult compareFirmwareVersion(String firmwareFileName) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            int[] param = new int[1];
            device.compareFirmwareVersion(firmwareFileName, param);
            return compareFirmwareResult.get(param[0]);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public DirectIOData directIO(Integer command, Integer data, Object obj) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            DirectIOData res = new DirectIOData();
            int[] param = new int[] { data };
            device.directIO(command, param, obj);
            res.setData(param[0]);
            res.setObj(obj);
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void dispenseCash(CashCountList cashCounts) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            StringBuffer bills = new StringBuffer();
            StringBuffer coins = new StringBuffer();
            for (CashCount count : cashCounts.getCashCount()) {
                if (count.getType().equals(CashCountType.BILL)) {
                    bills.append(",").append(count.getNominalValue()).append(":").append(count.getCount());
                }
                else if (count.getType().equals(CashCountType.COIN)) {
                    coins.append(",").append(count.getNominalValue()).append(":").append(count.getCount());
                }
            }
            device.dispenseCash(coins.substring(1) + ";" + bills.substring(1));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void dispenseChange(Integer amount) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.dispenseChange(amount);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void endDeposit(CashDepositAction success) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.endDeposit(jposConst.get(success));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void fixDeposit() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.fixDeposit();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getAsyncMode() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getAsyncMode();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getAsyncResultCode() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getAsyncResultCode();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getAsyncResultCodeExtended() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getAsyncResultCodeExtended();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapCompareFirmwareVersion() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapCompareFirmwareVersion();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapDeposit() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapDeposit();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapDepositDataEvent() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapDepositDataEvent();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapDiscrepancy() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapDiscrepancy();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapEmptySensor() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapEmptySensor();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapFullSensor() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapFullSensor();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapJamSensor() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapJamSensor();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapNearEmptySensor() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapNearEmptySensor();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapNearFullSensor() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapNearFullSensor();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapPauseDeposit() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapPauseDeposit();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public PowerReporting getCapPowerReporting() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return powerReporting.get(device.getCapPowerReporting());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapRealTimeData() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapRealTimeData();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapRepayDeposit() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapRepayDeposit();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapStatisticsReporting() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapStatisticsReporting();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapUpdateFirmware() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapUpdateFirmware();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapUpdateStatistics() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapUpdateStatistics();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getCheckHealthText() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCheckHealthText();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getClaimed() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getClaimed();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public CashUnits getCurrencyCashList() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            CashUnits res = new CashUnits();
            res.setBills(new BillList());
            res.setCoins(new CoinList());
            String[] cashList = device.getCurrencyCashList().split(";");
            if (cashList.length > 0) {
                List<Integer> list = res.getCoins().getCoin();
                for (String s : cashList[0].split(",")) {
                    list.add(Integer.valueOf(s));
                }
            }
            if (cashList.length > 1) {
                List<Integer> list = res.getBills().getBill();
                for (String s : cashList[1].split(",")) {
                    list.add(Integer.valueOf(s));
                }
            }
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getCurrencyCode() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCurrencyCode();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public CurrencyCodeList getCurrencyCodeList() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            CurrencyCodeList res = new CurrencyCodeList();
            List<String> list = res.getCurrencyCode();
            for (String s : device.getCurrencyCodeList().split(",")) {
                list.add(s);
            }
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getCurrentExit() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCurrentExit();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getCurrentService() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCurrentService();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getDataCount() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getDataCount();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getDataEventEnabled() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getDataEventEnabled();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getDepositAmount() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getDepositAmount();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public CashUnits getDepositCashList() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            CashUnits res = new CashUnits();
            res.setBills(new BillList());
            res.setCoins(new CoinList());
            String[] cashList = device.getDepositCashList().split(";");
            if (cashList.length > 0) {
                List<Integer> list = res.getCoins().getCoin();
                for (String s : cashList[0].split(",")) {
                    list.add(Integer.valueOf(s));
                }
            }
            if (cashList.length > 1) {
                List<Integer> list = res.getBills().getBill();
                for (String s : cashList[1].split(",")) {
                    list.add(Integer.valueOf(s));
                }
            }
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public DepositCodeList getDepositCodeList() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            DepositCodeList res = new DepositCodeList();
            List<String> list = res.getDepositCode();
            for (String s : device.getDepositCodeList().split(",")) {
                list.add(s);
            }
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public CashCountList getDepositCounts() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            CashCountList res = new CashCountList();
            List<CashCount> list = res.getCashCount();
            String[] count = device.getDepositCounts().split(";");
            if (count.length > 0) {
                for (String coins : count[0].split(",")) {
                    String[] s = coins.split(":");
                    if (s.length > 1) {
                        CashCount c = new CashCount();
                        c.setCount(Integer.valueOf(s[0]));
                        c.setNominalValue(Integer.valueOf(s[1]));
                        c.setType(CashCountType.COIN);
                        list.add(c);
                    }
                }
            }
            else if (count.length > 1) {
                for (String bills : count[1].split(",")) {
                    String[] s = bills.split(":");
                    if (s.length > 1) {
                        CashCount c = new CashCount();
                        c.setCount(Integer.valueOf(s[0]));
                        c.setNominalValue(Integer.valueOf(s[1]));
                        c.setType(CashCountType.BILL);
                        list.add(c);
                    }
                }
            }
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public CashDepositStatus getDepositStatus() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return cashDepositStatus.get(device.getDepositStatus());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getDeviceControlDescription() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        return device.getDeviceControlDescription();
    }

    public UposVersion getDeviceControlVersion() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        UposVersion res = new UposVersion();
        int version = device.getDeviceControlVersion();
        res.setMajor(version / 1000000 % 1000);
        res.setMinor(version / 1000 % 1000);
        res.setBuild(version % 1000);
        return res;
    }

    public Boolean getDeviceEnabled() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getDeviceEnabled();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getDeviceExits() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getDeviceExits();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getDeviceServiceDescription() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getDeviceServiceDescription();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public UposVersion getDeviceServiceVersion() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            UposVersion res = new UposVersion();
            int version = device.getDeviceServiceVersion();
            res.setMajor(version / 1000000 % 1000);
            res.setMinor(version / 1000 % 1000);
            res.setBuild(version % 1000);
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public CashChangerStatus getDeviceStatus() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return cashChangerStatus.get(device.getDeviceStatus());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public CashUnits getExitCashList() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            CashUnits res = new CashUnits();
            res.setBills(new BillList());
            res.setCoins(new CoinList());
            String[] cashList = device.getExitCashList().split(";");
            if (cashList.length > 0) {
                List<Integer> list = res.getCoins().getCoin();
                for (String s : cashList[0].split(",")) {
                    list.add(Integer.valueOf(s));
                }
            }
            if (cashList.length > 1) {
                List<Integer> list = res.getBills().getBill();
                for (String s : cashList[1].split(",")) {
                    list.add(Integer.valueOf(s));
                }
            }
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getFreezeEvents() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getFreezeEvents();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public CashChangerFullStatus getFullStatus() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return cashChangerFullStatus.get(device.getFullStatus());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getPhysicalDeviceDescription() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getPhysicalDeviceDescription();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getPhysicalDeviceName() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getPhysicalDeviceName();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public PowerNotification getPowerNotify() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return powerNotification.get(device.getPowerNotify());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public PowerState getPowerState() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return powerState.get(device.getPowerState());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getRealTimeDataEnabled() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getRealTimeDataEnabled();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getServiceCount() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getServiceCount();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public ServiceIndex getServiceIndex() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            ServiceIndex res = new ServiceIndex();
            int index = device.getServiceIndex();
            res.setBillDispenser(index >> 24 & 0xff);
            res.setBillAcceptor(index >> 16 & 0xff);
            res.setCoinDispenser(index >> 8 & 0xff);
            res.setCoinAcceptor(index & 0xff);
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public ControlState getState() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        this.statusUpdateOccurred(new StatusUpdateEvent(this, 2200));
        return controlState.get(device.getState());
    }

    public void open(String endpointAddress) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.open(deviceName);
            if (endpointAddress != null)
            {
                try {
                    Service service = Service.create(
                            new URL(endpointAddress + "?wsdl"),
                            new QName("http://www.nrf-arts.org/UnifiedPOS/CashChangerEvents/", "CashChangerEventService"));
                    deviceEvent = service.getPort(org.nrf_arts.unifiedpos.cashchangerevents.CashChangerEvent.class);
                    device.addDataListener(this);
                    device.addDirectIOListener(this);
                    device.addStatusUpdateListener(this);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void pauseDeposit(CashDepositPause control) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.pauseDeposit(jposConst.get(control));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public CashCounts readCashCounts() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            CashCounts res = new CashCounts();
            res.setCounts(new CashCountList());
            String[] param = new String[1];
            boolean[] discrepancy = new boolean[1];
            device.readCashCounts(param, discrepancy);
            res.setDiscrepancy(discrepancy[0]);
            List<CashCount> list = res.getCounts().getCashCount();
            String[] count = param[0].split(";");
            if (count.length > 0) {
                for (String coins : count[0].split(",")) {
                    String[] s = coins.split(":");
                    if (s.length > 1) {
                        CashCount c = new CashCount();
                        c.setCount(Integer.valueOf(s[0]));
                        c.setNominalValue(Integer.valueOf(s[1]));
                        c.setType(CashCountType.COIN);
                        list.add(c);
                    }
                }
            }
            if (count.length > 1) {
                for (String bills : count[1].split(",")) {
                    String[] s = bills.split(":");
                    if (s.length > 1) {
                        CashCount c = new CashCount();
                        c.setCount(Integer.valueOf(s[0]));
                        c.setNominalValue(Integer.valueOf(s[1]));
                        c.setType(CashCountType.BILL);
                        list.add(c);
                    }
                }
            }
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void release() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.release();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void resetStatistics(StatisticList statisticsBuffer) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            String param = null;
            List<Statistic> list = statisticsBuffer.getStatistic();
            switch (list.size()) {
                case 0:
                    param = "";
                    break;
                case 1:
                    String name = list.get(0).getName();
                    if (name.equals(StatisticCategories.ALL)) {
                        param = "";
                    }
                    else if (name.equals(StatisticCategories.MANUFACTURER)) {
                        param = "M_";
                    }
                    else if (name.equals(StatisticCategories.UPOS)) {
                        param = "U_";
                    }
                    else {
                        param = name;
                    }
                    break;
                default:
                    StringBuffer buffer = new StringBuffer();
                    for (Statistic statistic : statisticsBuffer.getStatistic()) {
                        buffer.append(",").append(statistic.getName());
                    }
                    param = buffer.substring(1);
                    break;
            }
            device.resetStatistics(param);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String retrieveStatistics(StatisticList statisticsBuffer) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            String[] param = new String[1];
            List<Statistic> list = statisticsBuffer.getStatistic();
            switch (list.size()) {
                case 0:
                    param[0] = "";
                    break;
                case 1:
                    String name = list.get(0).getName();
                    if (name.equals(StatisticCategories.ALL)) {
                        param[0] = "";
                    }
                    else if (name.equals(StatisticCategories.MANUFACTURER)) {
                        param[0] = "M_";
                    }
                    else if (name.equals(StatisticCategories.UPOS)) {
                        param[0] = "U_";
                    }
                    else {
                        param[0] = name;
                    }
                    break;
                default:
                    StringBuffer buffer = new StringBuffer();
                    for (Statistic statistic : statisticsBuffer.getStatistic()) {
                        buffer.append(",").append(statistic.getName());
                    }
                    param[0] = buffer.substring(1);
                    break;
            }
            device.retrieveStatistics(param);
            return param[0];
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setAsyncMode(Boolean asyncMode) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setAsyncMode(asyncMode);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setCurrencyCode(String currencyCode) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setCurrencyCode(currencyCode);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setCurrentExit(Integer currentExit) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setCurrentExit(currentExit);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setCurrentService(Integer currentService) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setCurrentService(currentService);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setDataEventEnabled(Boolean dataEventEnabled) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setDataEventEnabled(dataEventEnabled);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setDeviceEnabled(Boolean deviceEnabled) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setDeviceEnabled(deviceEnabled);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setFreezeEvents(Boolean freezeEvents) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setFreezeEvents(freezeEvents);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setPowerNotify(PowerNotification powerNotify) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setPowerNotify(jposConst.get(powerNotify));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setRealTimeDataEnabled(Boolean realTimeDataEnabled) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setRealTimeDataEnabled(realTimeDataEnabled);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void updateFirmware(String firmwareFileName) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.updateFirmware(firmwareFileName);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void updateStatistics(StatisticList statisticsBuffer) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            String param = null;
            List<Statistic> list = statisticsBuffer.getStatistic();
            switch (list.size()) {
                case 0:
                    param = "";
                    break;
                case 1:
                    Statistic s = list.get(0);
                    String name = s.getName();
                    String value = s.getValue();
                    if (name.equals(StatisticCategories.ALL)) {
                        param = "=" + value;
                    }
                    else if (name.equals(StatisticCategories.MANUFACTURER)) {
                        param = "M_=" + value;
                    }
                    else if (name.equals(StatisticCategories.UPOS)) {
                        param = "U_=" + value;
                    }
                    else {
                        param = name + "=" + value;
                    }
                    break;
                default:
                    StringBuffer buffer = new StringBuffer();
                    for (Statistic statistic : statisticsBuffer.getStatistic()) {
                        buffer.append(",").append(statistic.getName()).append("=").append(statistic.getValue());
                    }
                    param = buffer.substring(1);
                    break;
            }
            device.updateStatistics(param);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    //
    // CashChangerEvent Member
    //

    public void dataOccurred(DataEvent de) {
        //throw new UnsupportedOperationException("Not supported yet.");
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(new Date(de.getWhen()));
        deviceEvent.dataEvent(
                de.getSource().toString(),
                (int)de.getSequenceNumber(),
                datatypeFactory.newXMLGregorianCalendar(cal),
                de.getStatus());
    }

    public void directIOOccurred(DirectIOEvent dioe) {
        //throw new UnsupportedOperationException("Not supported yet.");
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(new Date(dioe.getWhen()));
        org.nrf_arts.unifiedpos.cashchangerevents.DirectIOData value = deviceEvent.directIOEvent(
                dioe.getSource().toString(),
                (int)dioe.getSequenceNumber(),
                datatypeFactory.newXMLGregorianCalendar(cal),
                dioe.getEventNumber(),
                dioe.getData(),
                dioe.getObject());
        dioe.setData(value.getData());
        dioe.setObject(value.getObj());
    }

    public void statusUpdateOccurred(StatusUpdateEvent sue) {
        //throw new UnsupportedOperationException("Not supported yet.");
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(new Date(sue.getWhen()));
        deviceEvent.statusUpdateEvent(
                sue.getSource().toString(),
                (int)sue.getSequenceNumber(),
                datatypeFactory.newXMLGregorianCalendar(cal),
                sue.getStatus());
    }

}
