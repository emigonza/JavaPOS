﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace UnifiedPOS.LineDisplay
{
    [ServiceContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/")]
    public interface LineDisplay
    {

        //
        // Common Properties
        //

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetAutoDisableResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        // int GetAutoDisable();

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/SetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/SetAutoDisableResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        // void SetAutoDisable(int AutoDisable);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetCapCompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetCapCompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        bool GetCapCompareFirmwareVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetCapPowerReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetCapPowerReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        PowerReporting GetCapPowerReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetCapStatisticsReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetCapStatisticsReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        bool GetCapStatisticsReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetCapUpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetCapUpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        bool GetCapUpdateFirmware();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetCapUpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetCapUpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        bool GetCapUpdateStatistics();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetCheckHealthText", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetCheckHealthTextResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        string GetCheckHealthText();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetClaimed", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetClaimedResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        bool GetClaimed();

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetDataCount", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetDataCountResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        // int GetDataCount();

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetDataEventEnabledResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        // bool GetDataEventEnabled();

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/SetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/SetDataEventEnabledResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        // void SetDataEventEnabled(bool DataEventEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        bool GetDeviceEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/SetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/SetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        void SetDeviceEnabled(bool DeviceEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        bool GetFreezeEvents();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/SetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/SetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        void SetFreezeEvents(bool FreezeEvents);

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetOutputID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetOutputIDResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        // int GetOutputID();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        PowerNotification GetPowerNotify();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/SetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/SetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        void SetPowerNotify(PowerNotification PowerNotify);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetPowerState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetPowerStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        PowerState GetPowerState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        ControlState GetState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetDeviceControlDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetDeviceControlDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        string GetDeviceControlDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetDeviceControlVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetDeviceControlVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        UposVersion GetDeviceControlVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetDeviceServiceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetDeviceServiceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        string GetDeviceServiceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetDeviceServiceVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetDeviceServiceVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        UposVersion GetDeviceServiceVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetPhysicalDeviceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetPhysicalDeviceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        string GetPhysicalDeviceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetPhysicalDeviceName", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetPhysicalDeviceNameResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        string GetPhysicalDeviceName();

        //
        // Specific Properties
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetCapBlink", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetCapBlinkResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        DisplayBlink GetCapBlink();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetCapBitmap", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetCapBitmapResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        bool GetCapBitmap();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetCapBlinkRate", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetCapBlinkRateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        bool GetCapBlinkRate();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetCapBrightness", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetCapBrightnessResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        bool GetCapBrightness();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetCapCharacterSet", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetCapCharacterSetResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        CharacterSetCapability GetCapCharacterSet();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetCapCursorType", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetCapCursorTypeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        int GetCapCursorType();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetCapCustomGlyph", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetCapCustomGlyphResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        bool GetCapCustomGlyph();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetCapDescriptors", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetCapDescriptorsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        bool GetCapDescriptors();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetCapHMarquee", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetCapHMarqueeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        bool GetCapHMarquee();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetCapICharWait", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetCapICharWaitResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        bool GetCapICharWait();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetCapMapCharacterSet", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetCapMapCharacterSetResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        bool GetCapMapCharacterSet();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetCapReadBack", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetCapReadBackResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        DisplayReadBack GetCapReadBack();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetCapReverse", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetCapReverseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        DisplayReverse GetCapReverse();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetCapScreenMode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetCapScreenModeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        bool GetCapScreenMode();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetCapVMarquee", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetCapVMarqueeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        bool GetCapVMarquee();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetBlinkRate", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetBlinkRateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        int GetBlinkRate();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/SetBlinkRate", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/SetBlinkRateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        void SetBlinkRate(int BlinkRate);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetCharacterSet", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetCharacterSetResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        int GetCharacterSet();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/SetCharacterSet", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/SetCharacterSetResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        void SetCharacterSet(int CharacterSet);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetCharacterSetList", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetCharacterSetListResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        CharacterSetList GetCharacterSetList();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetColumns", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetColumnsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        int GetColumns();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetCurrentWindow", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetCurrentWindowResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        int GetCurrentWindow();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/SetCurrentWindow", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/SetCurrentWindowResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        void SetCurrentWindow(int CurrentWindow);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetCursorColumn", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetCursorColumnResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        int GetCursorColumn();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/SetCursorColumn", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/SetCursorColumnResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        void SetCursorColumn(int CursorColumn);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetCursorRow", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetCursorRowResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        int GetCursorRow();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/SetCursorRow", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/SetCursorRowResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        void SetCursorRow(int CursorRow);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetCursorType", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetCursorTypeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        int GetCursorType();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/SetCursorType", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/SetCursorTypeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        void SetCursorType(int CursorType);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetCursorUpdate", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetCursorUpdateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        bool GetCursorUpdate();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/SetCursorUpdate", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/SetCursorUpdateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        void SetCursorUpdate(bool CursorUpdate);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetCustomGlyphList", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetCustomGlyphListResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        CustomGlyphList GetCustomGlyphList();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetDeviceBrightness", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetDeviceBrightnessResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        int GetDeviceBrightness();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/SetDeviceBrightness", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/SetDeviceBrightnessResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        void SetDeviceBrightness(int DeviceBrightness);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetDeviceColumns", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetDeviceColumnsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        int GetDeviceColumns();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetDeviceDescriptors", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetDeviceDescriptorsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        int GetDeviceDescriptors();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetDeviceRows", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetDeviceRowsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        int GetDeviceRows();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetDeviceWindows", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetDeviceWindowsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        int GetDeviceWindows();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetGlyphHeight", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetGlyphHeightResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        int GetGlyphHeight();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetGlyphWidth", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetGlyphWidthResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        int GetGlyphWidth();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetInterCharacterWait", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetInterCharacterWaitResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        int GetInterCharacterWait();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/SetInterCharacterWait", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/SetInterCharacterWaitResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        void SetInterCharacterWait(int InterCharacterWait);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetMapCharacterSet", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetMapCharacterSetResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        bool GetMapCharacterSet();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/SetMapCharacterSet", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/SetMapCharacterSetResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        void SetMapCharacterSet(bool MapCharacterSet);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetMarqueeFormat", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetMarqueeFormatResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        DisplayMarqueeFormat GetMarqueeFormat();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/SetMarqueeFormat", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/SetMarqueeFormatResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        void SetMarqueeFormat(DisplayMarqueeFormat MarqueeFormat);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetMarqueeRepeatWait", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetMarqueeRepeatWaitResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        int GetMarqueeRepeatWait();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/SetMarqueeRepeatWait", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/SetMarqueeRepeatWaitResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        void SetMarqueeRepeatWait(int MarqueeRepeatWait);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetMarqueeType", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetMarqueeTypeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        DisplayMarqueeType GetMarqueeType();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/SetMarqueeType", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/SetMarqueeTypeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        void SetMarqueeType(DisplayMarqueeType MarqueeType);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetMarqueeUnitWait", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetMarqueeUnitWaitResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        int GetMarqueeUnitWait();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/SetMarqueeUnitWait", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/SetMarqueeUnitWaitResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        void SetMarqueeUnitWait(int MarqueeUnitWait);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetMaximumX", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetMaximumXResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        int GetMaximumX();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetMaximumY", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetMaximumYResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        int GetMaximumY();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetRows", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetRowsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        int GetRows();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetScreenMode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetScreenModeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        int GetScreenMode();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/SetScreenMode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/SetScreenModeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        void SetScreenMode(int ScreenMode);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetScreenModeList", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/GetScreenModeListResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        DisplayScreenModeList GetScreenModeList();

        //
        // Common Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/Open", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/OpenResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        void Open(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/Close", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/CloseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        void Close(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/Claim", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/ClaimResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        void Claim(int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/Release", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/ReleaseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        void Release();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/CheckHealth", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/CheckHealthResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        void CheckHealth(HealthCheckLevel Level);

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/ClearInput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/ClearInputResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        // void ClearInput();

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/ClearInputProperties", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/ClearInputPropertiesResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        // void ClearInputProperties();

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/ClearOutput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/ClearOutputResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        // void ClearOutput();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/DirectIO", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/DirectIOResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        DirectIOData DirectIO(int Command, int Data, object Obj);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/CompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/CompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        CompareFirmwareResult CompareFirmwareVersion(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/ResetStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/ResetStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        void ResetStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/RetrieveStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/RetrieveStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        string RetrieveStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        void UpdateFirmware(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        void UpdateStatistics(StatisticList StatisticsBuffer);

        //
        // Specific Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/ClearText", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/ClearTextResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        void ClearText();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/DisplayText", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/DisplayTextResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        void DisplayText(string Data, DisplayTextMode Attribute);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/DisplayTextAt", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/DisplayTextAtResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        void DisplayTextAt(int Row, int Column, string Data, DisplayTextMode Attribute);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/ScrollText", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/ScrollTextResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        void ScrollText(DisplayScrollText Direction, int Units);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/ClearDescriptors", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/ClearDescriptorsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        void ClearDescriptors();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/SetDescriptor", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/SetDescriptorResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        void SetDescriptor(int Descriptor, DisplaySetDescriptor Attribute);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/CreateWindow", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/CreateWindowResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        void CreateWindow(int ViewportRow, int ViewportColumn, int ViewportHeight, int ViewportWidth, int WindowHeight, int WindowWidth);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/DestroyWindow", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/DestroyWindowResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        void DestroyWindow();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/RefreshWindow", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/RefreshWindowResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        void RefreshWindow(int Window);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/DefineGlyph", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/DefineGlyphResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        void DefineGlyph(int GlyphCode, byte[] Glyph);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/ReadCharacterAtCursor", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/ReadCharacterAtCursorResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        int ReadCharacterAtCursor();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/DisplayBitmap", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/DisplayBitmapResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        void DisplayBitmap(string FileName, int Width, int AlignmentX, int AlignmentY);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/SetBitmap", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/SetBitmapResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/UposException", Name = "UposException")]
        void SetBitmap(int BitmapNumber, string FileName, int Width, int AlignmentX, int AlignmentY);
    }

    //
    // Common Data Types
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/")]
    public class DirectIOData
    {
        [DataMember]
        public int Data { get; set; }
        [DataMember]
        public object Obj { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/")]
    public class UposException
    {
        [DataMember]
        public ErrorCode ErrorCode { get; set; }
        [DataMember]
        public int ErrorCodeExtended { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/")]
    public class UposVersion
    {
        [DataMember]
        public int Major { get; set; }
        [DataMember]
        public int Minor { get; set; }
        [DataMember]
        public int Build { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/")]
    public class Statistic
    {
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public string Value { get; set; }
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/", ItemName = "Statistic")]
    public class StatisticList : List<Statistic>
    {
    }

    //
    // Common Enumerations
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/")]
    public enum CompareFirmwareResult
    {
        [EnumMember]
        Different,
        [EnumMember]
        Newer,
        [EnumMember]
        Older,
        [EnumMember]
        Same,
        [EnumMember]
        Unknown,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/")]
    public enum ControlState
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Closed,
        [EnumMember]
        Error,
        [EnumMember]
        Idle,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/")]
    public enum ErrorCode
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Claimed,
        [EnumMember]
        Closed,
        [EnumMember]
        Deprecated,
        [EnumMember]
        Disabled,
        [EnumMember]
        Exists,
        [EnumMember]
        Extended,
        [EnumMember]
        Failure,
        [EnumMember]
        Illegal,
        [EnumMember]
        NoExist,
        [EnumMember]
        NoHardware,
        [EnumMember]
        NoService,
        [EnumMember]
        NotClaimed,
        [EnumMember]
        Offline,
        [EnumMember]
        Success,
        [EnumMember]
        Timeout,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/")]
    public enum HealthCheckLevel
    {
        [EnumMember]
        External,
        [EnumMember]
        Interactive,
        [EnumMember]
        Internal,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/")]
    public enum PowerNotification
    {
        [EnumMember]
        Disabled,
        [EnumMember]
        Enabled,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/")]
    public enum PowerReporting
    {
        [EnumMember]
        Advanced,
        [EnumMember]
        None,
        [EnumMember]
        Standard,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/")]
    public enum PowerState
    {
        [EnumMember]
        Off,
        [EnumMember]
        Offline,
        [EnumMember]
        OffOffline,
        [EnumMember]
        Online,
        [EnumMember]
        Unknown,
    }

    /*
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/")]
    public enum StatisticCategories
    {
        [EnumMember]
        All,
        [EnumMember]
        Manufacturer,
        [EnumMember]
        Upos,
    }
    */
    public class StatisticCategories
    {
        public const string All = "";
        public const string Manufacturer = "M_";
        public const string Upos = "U_";
    }

    //
    // Specific Data Types
    //

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/", ItemName = "CharacterSet")]
    public class CharacterSetList : List<int>
    {
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/", ItemName = "CustomGlyph")]
    public class CustomGlyphList : List<RangeOfCharacters>
    {
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/")]
    public class DisplayScreenMode
    {
        [DataMember]
        public int Columns { get; set; }
        [DataMember]
        public int Rows { get; set; }
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/", ItemName = "DisplayScreenMode")]
    public class DisplayScreenModeList : List<DisplayScreenMode>
    {
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/")]
    public class RangeOfCharacters
    {
        [DataMember]
        public int From { get; set; }
        [DataMember]
        public int To { get; set; }
    }

    //
    // Specific Enumerations
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/")]
    public enum CharacterSetCapability
    {
        [EnumMember]
        Alpha,
        [EnumMember]
        Ascii,
        [EnumMember]
        Kana,
        [EnumMember]
        Kanji,
        [EnumMember]
        Numeric,
        [EnumMember]
        Unicode,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/")]
    public enum DisplayBlink
    {
        [EnumMember]
        All,
        [EnumMember]
        Each,
        [EnumMember]
        None,
    }

    /*
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/")]
    public enum DisplayCursors
    {
        [EnumMember]
        Blink,
        [EnumMember]
        Block,
        [EnumMember]
        Fixed,
        [EnumMember]
        HalfBlock,
        [EnumMember]
        None,
        [EnumMember]
        Other,
        [EnumMember]
        Reverse,
        [EnumMember]
        Underline,
    }
    */
    public class DisplayCursors
    {
        public const int Blink = 64;
        public const int Block = 2;
        public const int Fixed = 1;
        public const int HalfBlock = 4;
        public const int None = 0;
        public const int Other = 32;
        public const int Reverse = 16;
        public const int Underline = 8;
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/")]
    public enum DisplayMarqueeFormat
    {
        [EnumMember]
        Place,
        [EnumMember]
        Walk,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/")]
    public enum DisplayMarqueeType
    {
        [EnumMember]
        Down,
        [EnumMember]
        Init,
        [EnumMember]
        Left,
        [EnumMember]
        None,
        [EnumMember]
        Right,
        [EnumMember]
        Up,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/")]
    public enum DisplayReadBack
    {
        [EnumMember]
        None,
        [EnumMember]
        Single,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/")]
    public enum DisplayReverse
    {
        [EnumMember]
        All,
        [EnumMember]
        Each,
        [EnumMember]
        None,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/")]
    public enum DisplayScrollText
    {
        [EnumMember]
        Down,
        [EnumMember]
        Left,
        [EnumMember]
        Right,
        [EnumMember]
        Up,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/")]
    public enum DisplaySetDescriptor
    {
        [EnumMember]
        Blink,
        [EnumMember]
        Off,
        [EnumMember]
        On,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/")]
    public enum DisplayTextMode
    {
        [EnumMember]
        Blink,
        [EnumMember]
        BlinkReverse,
        [EnumMember]
        Normal,
        [EnumMember]
        Reverse,
    }

    //
    // Constants
    //

    /*
    public class Constants
    {
        public const int CharacterSetAnsi = 999;
        public const int CharacterSetAscii = 998;
        public const int CharacterSetUnicode = 997;
        public const int DisplayBitmapAsIs = -11;
        public const int DisplayBitmapBottom = -3;
        public const int DisplayBitmapCenter = -2;
        public const int DisplayBitmapLeft = -1;
        public const int DisplayBitmapRight = -3;
        public const int DisplayBitmapTop = -1;
        public const int ExtendedErrorBadFormat = 202;
        public const int ExtendedErrorFirmwareBadFile = 281;
        public const int ExtendedErrorStatistics = 280;
        public const int ExtendedErrorStatisticsDependency = 282;
        public const int ExtendedErrorTooBig = 201;
        public const string StatisticCommunicationErrorCount = "CommunicationErrorCount";
        public const string StatisticDeviceCategory = "DeviceCategory";
        public const string StatisticFirmwareRevision = "FirmwareRevision";
        public const string StatisticHoursPoweredCount = "HoursPoweredCount";
        public const string StatisticInstallationDate = "InstallationDate";
        public const string StatisticInterface = "Interface";
        public const string StatisticManufactureDate = "ManufactureDate";
        public const string StatisticManufacturerName = "ManufacturerName";
        public const string StatisticMechanicalRevision = "MechanicalRevision";
        public const string StatisticModelName = "ModelName";
        public const string StatisticOnlineTransitionCount = "OnlineTransitionCount";
        public const string StatisticSerialNumber = "SerialNumber";
        public const string StatisticUnifiedPOSVersion = "UnifiedPOSVersion";
        public const int WaitForever = -1;
    }
    */

    public class CharacterSet
    {
        public const int Ansi = 999;
        public const int Ascii = 998;
        public const int Unicode = 997;
    }

    public class DisplayBitmap
    {
        public const int AsIs = -11;
        public const int Bottom = -3;
        public const int Center = -2;
        public const int Left = -1;
        public const int Right = -3;
        public const int Top = -1;
    }

    public class ExtendedError
    {
        public const int BadFormat = 202;
        public const int FirmwareBadFile = 281;
        public const int Statistics = 280;
        public const int StatisticsDependency = 282;
        public const int TooBig = 201;
    }

    public class StatisticProperties
    {
        public const string CommunicationErrorCount = "CommunicationErrorCount";
        public const string DeviceCategory = "DeviceCategory";
        public const string FirmwareRevision = "FirmwareRevision";
        public const string HoursPoweredCount = "HoursPoweredCount";
        public const string InstallationDate = "InstallationDate";
        public const string Interface = "Interface";
        public const string ManufactureDate = "ManufactureDate";
        public const string ManufacturerName = "ManufacturerName";
        public const string MechanicalRevision = "MechanicalRevision";
        public const string ModelName = "ModelName";
        public const string OnlineTransitionCount = "OnlineTransitionCount";
        public const string SerialNumber = "SerialNumber";
        public const string UnifiedPOSVersion = "UnifiedPOSVersion";
    }

    public class Wait
    {
        public const int Forever = -1;
    }
}
