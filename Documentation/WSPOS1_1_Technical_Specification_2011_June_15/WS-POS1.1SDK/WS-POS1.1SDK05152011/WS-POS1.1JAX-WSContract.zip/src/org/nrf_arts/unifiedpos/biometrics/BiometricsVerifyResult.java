
package org.nrf_arts.unifiedpos.biometrics;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for BiometricsVerifyResult complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BiometricsVerifyResult">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="AdaptedBIR" type="{http://www.nrf-arts.org/UnifiedPOS/Biometrics/}BiometricsInformationRecord" minOccurs="0"/>
 *         &lt;element name="FARAchieved" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="FRRAchieved" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="Result" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="Payload" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BiometricsVerifyResult", propOrder = {
    "adaptedBIR",
    "farAchieved",
    "frrAchieved",
    "result",
    "payload"
})
public class BiometricsVerifyResult {

    @XmlElement(name = "AdaptedBIR", nillable = true)
    protected BiometricsInformationRecord adaptedBIR;
    @XmlElement(name = "FARAchieved")
    protected Integer farAchieved;
    @XmlElement(name = "FRRAchieved")
    protected Integer frrAchieved;
    @XmlElement(name = "Result")
    protected Boolean result;
    @XmlElement(name = "Payload", nillable = true)
    protected byte[] payload;

    /**
     * Gets the value of the adaptedBIR property.
     * 
     * @return
     *     possible object is
     *     {@link BiometricsInformationRecord }
     *     
     */
    public BiometricsInformationRecord getAdaptedBIR() {
        return adaptedBIR;
    }

    /**
     * Sets the value of the adaptedBIR property.
     * 
     * @param value
     *     allowed object is
     *     {@link BiometricsInformationRecord }
     *     
     */
    public void setAdaptedBIR(BiometricsInformationRecord value) {
        this.adaptedBIR = value;
    }

    /**
     * Gets the value of the farAchieved property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getFARAchieved() {
        return farAchieved;
    }

    /**
     * Sets the value of the farAchieved property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setFARAchieved(Integer value) {
        this.farAchieved = value;
    }

    /**
     * Gets the value of the frrAchieved property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getFRRAchieved() {
        return frrAchieved;
    }

    /**
     * Sets the value of the frrAchieved property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setFRRAchieved(Integer value) {
        this.frrAchieved = value;
    }

    /**
     * Gets the value of the result property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isResult() {
        return result;
    }

    /**
     * Sets the value of the result property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setResult(Boolean value) {
        this.result = value;
    }

    /**
     * Gets the value of the payload property.
     *
     * @return
     *     possible object is
     *     {@link byte[] }
     *
     */
    public byte[] getPayload() {
        return payload;
    }

    /**
     * Sets the value of the payload property.
     *
     * @param value
     *     allowed object is
     *     {@link byte[] }
     *
     */
    public void Payload(byte[] value) {
        this.payload = value;
    }

}
