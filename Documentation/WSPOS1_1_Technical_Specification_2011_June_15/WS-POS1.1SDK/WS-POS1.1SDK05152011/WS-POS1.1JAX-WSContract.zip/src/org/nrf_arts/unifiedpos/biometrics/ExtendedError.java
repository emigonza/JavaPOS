/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.nrf_arts.unifiedpos.biometrics;

/**
 *
 * @author Administrator
 */
public class ExtendedError {
    public static final int FIRMWARE_BAD_FILE = 281;
    public static final int STATISTICS = 280;
    public static final int STATISTICS_DEPENDENCY = 282;
}
