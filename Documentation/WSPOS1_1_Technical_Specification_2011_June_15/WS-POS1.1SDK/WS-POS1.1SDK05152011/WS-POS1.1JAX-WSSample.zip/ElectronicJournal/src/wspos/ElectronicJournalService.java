/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package wspos;

import java.math.BigDecimal;
import java.net.URL;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import jpos.events.DataEvent;
import jpos.events.DirectIOEvent;
import jpos.events.ErrorEvent;
import jpos.events.OutputCompleteEvent;
import jpos.events.StatusUpdateEvent;
import org.nrf_arts.unifiedpos.electronicjournal.*;
import javax.jws.WebService;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.namespace.QName;
import javax.xml.ws.Service;

/**
 *
 * @author hideon
 */
@WebService(serviceName = "ElectronicJournalService", endpointInterface = "org.nrf_arts.unifiedpos.electronicjournal.ElectronicJournal", targetNamespace = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/")
public class ElectronicJournalService implements ElectronicJournal, jpos.events.DataListener, jpos.events.DirectIOListener, jpos.events.ErrorListener, jpos.events.OutputCompleteListener, jpos.events.StatusUpdateListener {

    //
    // ElectronicJournal Enumration Converter
    //

    private static HashMap<Enum, Integer> jposConst;
    private static HashMap<Integer, PowerReporting> powerReporting;
    private static HashMap<Integer, PowerNotification> powerNotification;
    private static HashMap<Integer, PowerState> powerState;
    private static HashMap<Integer, ControlState> controlState;
    private static HashMap<Integer, HealthCheckLevel> healthCheckLevel;
    private static HashMap<Integer, CompareFirmwareResult> compareFirmwareResult;
    private static HashMap<Integer, ErrorCode> errorCode;
    private static HashMap<Integer, MarkerType> markerType;

    private static HashMap<Enum, Integer> jposEventConst;
    private static HashMap<Integer, org.nrf_arts.unifiedpos.electronicjournalevents.ErrorCode> eventErrorCode;
    private static HashMap<Integer, org.nrf_arts.unifiedpos.electronicjournalevents.ErrorLocus> eventErrorLocus;
    private static HashMap<Integer, org.nrf_arts.unifiedpos.electronicjournalevents.ErrorResponse> eventErrorResponse;

    static {
        jposConst = new HashMap<Enum, Integer>();
        jposConst.put(PowerReporting.ADVANCED, jpos.ElectronicJournal.JPOS_PR_ADVANCED);
        jposConst.put(PowerReporting.NONE, jpos.ElectronicJournal.JPOS_PR_NONE);
        jposConst.put(PowerReporting.STANDARD, jpos.ElectronicJournal.JPOS_PR_STANDARD);
        jposConst.put(PowerNotification.DISABLED, jpos.ElectronicJournal.JPOS_PN_DISABLED);
        jposConst.put(PowerNotification.ENABLED, jpos.ElectronicJournal.JPOS_PN_ENABLED);
        jposConst.put(PowerState.OFF, jpos.ElectronicJournal.JPOS_PS_OFF);
        jposConst.put(PowerState.OFFLINE, jpos.ElectronicJournal.JPOS_PS_OFFLINE);
        jposConst.put(PowerState.OFF_OFFLINE, jpos.ElectronicJournal.JPOS_PS_OFF_OFFLINE);
        jposConst.put(PowerState.ONLINE, jpos.ElectronicJournal.JPOS_PS_ONLINE);
        jposConst.put(PowerState.UNKNOWN, jpos.ElectronicJournal.JPOS_PS_UNKNOWN);
        jposConst.put(ControlState.BUSY, jpos.ElectronicJournal.JPOS_S_BUSY);
        jposConst.put(ControlState.CLOSED, jpos.ElectronicJournal.JPOS_S_CLOSED);
        jposConst.put(ControlState.ERROR, jpos.ElectronicJournal.JPOS_S_ERROR);
        jposConst.put(ControlState.IDLE, jpos.ElectronicJournal.JPOS_S_IDLE);
        jposConst.put(HealthCheckLevel.EXTERNAL, jpos.ElectronicJournal.JPOS_CH_EXTERNAL);
        jposConst.put(HealthCheckLevel.INTERACTIVE, jpos.ElectronicJournal.JPOS_CH_INTERACTIVE);
        jposConst.put(HealthCheckLevel.INTERNAL, jpos.ElectronicJournal.JPOS_CH_INTERNAL);
        jposConst.put(CompareFirmwareResult.DIFFERENT, jpos.ElectronicJournal.JPOS_CFV_FIRMWARE_DIFFERENT);
        jposConst.put(CompareFirmwareResult.NEWER, jpos.ElectronicJournal.JPOS_CFV_FIRMWARE_NEWER);
        jposConst.put(CompareFirmwareResult.OLDER, jpos.ElectronicJournal.JPOS_CFV_FIRMWARE_OLDER);
        jposConst.put(CompareFirmwareResult.SAME, jpos.ElectronicJournal.JPOS_CFV_FIRMWARE_SAME);
        jposConst.put(CompareFirmwareResult.UNKNOWN, jpos.ElectronicJournal.JPOS_CFV_FIRMWARE_UNKNOWN);
        jposConst.put(ErrorCode.BUSY, jpos.ElectronicJournal.JPOS_E_BUSY);
        jposConst.put(ErrorCode.CLAIMED, jpos.ElectronicJournal.JPOS_E_CLAIMED);
        jposConst.put(ErrorCode.CLOSED, jpos.ElectronicJournal.JPOS_E_CLOSED);
        jposConst.put(ErrorCode.DEPRECATED, jpos.ElectronicJournal.JPOS_E_DEPRECATED);
        jposConst.put(ErrorCode.DISABLED, jpos.ElectronicJournal.JPOS_E_DISABLED);
        jposConst.put(ErrorCode.EXISTS, jpos.ElectronicJournal.JPOS_E_EXISTS);
        jposConst.put(ErrorCode.EXTENDED, jpos.ElectronicJournal.JPOS_E_EXTENDED);
        jposConst.put(ErrorCode.FAILURE, jpos.ElectronicJournal.JPOS_E_FAILURE);
        jposConst.put(ErrorCode.ILLEGAL, jpos.ElectronicJournal.JPOS_E_ILLEGAL);
        jposConst.put(ErrorCode.NO_EXIST, jpos.ElectronicJournal.JPOS_E_NOEXIST);
        jposConst.put(ErrorCode.NO_HARDWARE, jpos.ElectronicJournal.JPOS_E_NOHARDWARE);
        jposConst.put(ErrorCode.NO_SERVICE, jpos.ElectronicJournal.JPOS_E_NOSERVICE);
        jposConst.put(ErrorCode.NOT_CLAIMED, jpos.ElectronicJournal.JPOS_E_NOTCLAIMED);
        jposConst.put(ErrorCode.OFFLINE, jpos.ElectronicJournal.JPOS_E_OFFLINE);
        jposConst.put(ErrorCode.SUCCESS, 0);
        jposConst.put(ErrorCode.TIMEOUT, jpos.ElectronicJournal.JPOS_E_TIMEOUT);
        jposConst.put(MarkerType.DOCUMENT, jpos.ElectronicJournalConst.EJ_MT_DOCUMENT);
        jposConst.put(MarkerType.HEAD, jpos.ElectronicJournalConst.EJ_MT_HEAD);
        jposConst.put(MarkerType.SESSION_BEGIN, jpos.ElectronicJournalConst.EJ_MT_SESSION_BEG);
        jposConst.put(MarkerType.SESSION_END, jpos.ElectronicJournalConst.EJ_MT_SESSION_END);
        jposConst.put(MarkerType.TAIL, jpos.ElectronicJournalConst.EJ_MT_TAIL);

        powerReporting = new HashMap<Integer, PowerReporting>();
        powerReporting.put(jpos.ElectronicJournal.JPOS_PR_ADVANCED, PowerReporting.ADVANCED);
        powerReporting.put(jpos.ElectronicJournal.JPOS_PR_NONE, PowerReporting.NONE);
        powerReporting.put(jpos.ElectronicJournal.JPOS_PR_STANDARD, PowerReporting.STANDARD);

        powerNotification = new HashMap<Integer, PowerNotification>();
        powerNotification.put(jpos.ElectronicJournal.JPOS_PN_DISABLED, PowerNotification.DISABLED);
        powerNotification.put(jpos.ElectronicJournal.JPOS_PN_ENABLED, PowerNotification.ENABLED);

        powerState = new HashMap<Integer, PowerState>();
        powerState.put(jpos.ElectronicJournal.JPOS_PS_OFF, PowerState.OFF);
        powerState.put(jpos.ElectronicJournal.JPOS_PS_OFFLINE, PowerState.OFFLINE);
        powerState.put(jpos.ElectronicJournal.JPOS_PS_OFF_OFFLINE, PowerState.OFF_OFFLINE);
        powerState.put(jpos.ElectronicJournal.JPOS_PS_ONLINE, PowerState.ONLINE);
        powerState.put(jpos.ElectronicJournal.JPOS_PS_UNKNOWN, PowerState.UNKNOWN);

        controlState = new HashMap<Integer, ControlState>();
        controlState.put(jpos.ElectronicJournal.JPOS_S_BUSY, ControlState.BUSY);
        controlState.put(jpos.ElectronicJournal.JPOS_S_CLOSED, ControlState.CLOSED);
        controlState.put(jpos.ElectronicJournal.JPOS_S_ERROR, ControlState.ERROR);
        controlState.put(jpos.ElectronicJournal.JPOS_S_IDLE, ControlState.IDLE);

        healthCheckLevel = new HashMap<Integer, HealthCheckLevel>();
        healthCheckLevel.put(jpos.ElectronicJournal.JPOS_CH_EXTERNAL, HealthCheckLevel.EXTERNAL);
        healthCheckLevel.put(jpos.ElectronicJournal.JPOS_CH_INTERACTIVE, HealthCheckLevel.INTERACTIVE);
        healthCheckLevel.put(jpos.ElectronicJournal.JPOS_CH_INTERNAL, HealthCheckLevel.INTERNAL);

        compareFirmwareResult = new HashMap<Integer, CompareFirmwareResult>();
        compareFirmwareResult.put(jpos.ElectronicJournal.JPOS_CFV_FIRMWARE_DIFFERENT, CompareFirmwareResult.DIFFERENT);
        compareFirmwareResult.put(jpos.ElectronicJournal.JPOS_CFV_FIRMWARE_NEWER, CompareFirmwareResult.NEWER);
        compareFirmwareResult.put(jpos.ElectronicJournal.JPOS_CFV_FIRMWARE_OLDER, CompareFirmwareResult.OLDER);
        compareFirmwareResult.put(jpos.ElectronicJournal.JPOS_CFV_FIRMWARE_SAME, CompareFirmwareResult.SAME);
        compareFirmwareResult.put(jpos.ElectronicJournal.JPOS_CFV_FIRMWARE_UNKNOWN, CompareFirmwareResult.UNKNOWN);

        errorCode = new HashMap<Integer, ErrorCode>();
        errorCode.put(jpos.ElectronicJournal.JPOS_E_BUSY, ErrorCode.BUSY);
        errorCode.put(jpos.ElectronicJournal.JPOS_E_CLAIMED, ErrorCode.CLAIMED);
        errorCode.put(jpos.ElectronicJournal.JPOS_E_CLOSED, ErrorCode.CLOSED);
        errorCode.put(jpos.ElectronicJournal.JPOS_E_DEPRECATED, ErrorCode.DEPRECATED);
        errorCode.put(jpos.ElectronicJournal.JPOS_E_DISABLED, ErrorCode.DISABLED);
        errorCode.put(jpos.ElectronicJournal.JPOS_E_EXISTS, ErrorCode.EXISTS);
        errorCode.put(jpos.ElectronicJournal.JPOS_E_EXTENDED, ErrorCode.EXTENDED);
        errorCode.put(jpos.ElectronicJournal.JPOS_E_FAILURE, ErrorCode.FAILURE);
        errorCode.put(jpos.ElectronicJournal.JPOS_E_ILLEGAL, ErrorCode.ILLEGAL);
        errorCode.put(jpos.ElectronicJournal.JPOS_E_NOEXIST, ErrorCode.NO_EXIST);
        errorCode.put(jpos.ElectronicJournal.JPOS_E_NOHARDWARE, ErrorCode.NO_HARDWARE);
        errorCode.put(jpos.ElectronicJournal.JPOS_E_NOSERVICE, ErrorCode.NO_SERVICE);
        errorCode.put(jpos.ElectronicJournal.JPOS_E_NOTCLAIMED, ErrorCode.NOT_CLAIMED);
        errorCode.put(jpos.ElectronicJournal.JPOS_E_OFFLINE, ErrorCode.OFFLINE);
        errorCode.put(0, ErrorCode.SUCCESS);
        errorCode.put(jpos.ElectronicJournal.JPOS_E_TIMEOUT, ErrorCode.TIMEOUT);

        markerType = new HashMap<Integer, MarkerType>();
        markerType.put(jpos.ElectronicJournalConst.EJ_MT_DOCUMENT, MarkerType.DOCUMENT);
        markerType.put(jpos.ElectronicJournalConst.EJ_MT_HEAD, MarkerType.HEAD);
        markerType.put(jpos.ElectronicJournalConst.EJ_MT_SESSION_BEG, MarkerType.SESSION_BEGIN);
        markerType.put(jpos.ElectronicJournalConst.EJ_MT_SESSION_END, MarkerType.SESSION_END);
        markerType.put(jpos.ElectronicJournalConst.EJ_MT_TAIL, MarkerType.TAIL);

        jposEventConst = new HashMap<Enum, Integer>();
        jposEventConst.put(org.nrf_arts.unifiedpos.electronicjournalevents.ErrorCode.BUSY, jpos.ElectronicJournal.JPOS_E_BUSY);
        jposEventConst.put(org.nrf_arts.unifiedpos.electronicjournalevents.ErrorCode.CLAIMED, jpos.ElectronicJournal.JPOS_E_CLAIMED);
        jposEventConst.put(org.nrf_arts.unifiedpos.electronicjournalevents.ErrorCode.CLOSED, jpos.ElectronicJournal.JPOS_E_CLOSED);
        jposEventConst.put(org.nrf_arts.unifiedpos.electronicjournalevents.ErrorCode.DEPRECATED, jpos.ElectronicJournal.JPOS_E_DEPRECATED);
        jposEventConst.put(org.nrf_arts.unifiedpos.electronicjournalevents.ErrorCode.DISABLED, jpos.ElectronicJournal.JPOS_E_DISABLED);
        jposEventConst.put(org.nrf_arts.unifiedpos.electronicjournalevents.ErrorCode.EXISTS, jpos.ElectronicJournal.JPOS_E_EXISTS);
        jposEventConst.put(org.nrf_arts.unifiedpos.electronicjournalevents.ErrorCode.EXTENDED, jpos.ElectronicJournal.JPOS_E_EXTENDED);
        jposEventConst.put(org.nrf_arts.unifiedpos.electronicjournalevents.ErrorCode.FAILURE, jpos.ElectronicJournal.JPOS_E_FAILURE);
        jposEventConst.put(org.nrf_arts.unifiedpos.electronicjournalevents.ErrorCode.ILLEGAL, jpos.ElectronicJournal.JPOS_E_ILLEGAL);
        jposEventConst.put(org.nrf_arts.unifiedpos.electronicjournalevents.ErrorCode.NO_EXIST, jpos.ElectronicJournal.JPOS_E_NOEXIST);
        jposEventConst.put(org.nrf_arts.unifiedpos.electronicjournalevents.ErrorCode.NO_HARDWARE, jpos.ElectronicJournal.JPOS_E_NOHARDWARE);
        jposEventConst.put(org.nrf_arts.unifiedpos.electronicjournalevents.ErrorCode.NO_SERVICE, jpos.ElectronicJournal.JPOS_E_NOSERVICE);
        jposEventConst.put(org.nrf_arts.unifiedpos.electronicjournalevents.ErrorCode.NOT_CLAIMED, jpos.ElectronicJournal.JPOS_E_NOTCLAIMED);
        jposEventConst.put(org.nrf_arts.unifiedpos.electronicjournalevents.ErrorCode.OFFLINE, jpos.ElectronicJournal.JPOS_E_OFFLINE);
        jposEventConst.put(org.nrf_arts.unifiedpos.electronicjournalevents.ErrorCode.SUCCESS, 0);
        jposEventConst.put(org.nrf_arts.unifiedpos.electronicjournalevents.ErrorCode.TIMEOUT, jpos.ElectronicJournal.JPOS_E_TIMEOUT);
        jposEventConst.put(org.nrf_arts.unifiedpos.electronicjournalevents.ErrorLocus.INPUT, jpos.ElectronicJournal.JPOS_EL_INPUT);
        jposEventConst.put(org.nrf_arts.unifiedpos.electronicjournalevents.ErrorLocus.INPUT_DATA, jpos.ElectronicJournal.JPOS_EL_INPUT_DATA);
        jposEventConst.put(org.nrf_arts.unifiedpos.electronicjournalevents.ErrorLocus.OUTPUT, jpos.ElectronicJournal.JPOS_EL_OUTPUT);
        jposEventConst.put(org.nrf_arts.unifiedpos.electronicjournalevents.ErrorResponse.CLEAR, jpos.ElectronicJournal.JPOS_ER_CLEAR);
        jposEventConst.put(org.nrf_arts.unifiedpos.electronicjournalevents.ErrorResponse.CONTINUE_INPUT, jpos.ElectronicJournal.JPOS_ER_CONTINUEINPUT);
        jposEventConst.put(org.nrf_arts.unifiedpos.electronicjournalevents.ErrorResponse.RETRY, jpos.ElectronicJournal.JPOS_ER_RETRY);

        eventErrorCode = new HashMap<Integer, org.nrf_arts.unifiedpos.electronicjournalevents.ErrorCode>();
        eventErrorCode.put(jpos.ElectronicJournal.JPOS_E_BUSY, org.nrf_arts.unifiedpos.electronicjournalevents.ErrorCode.BUSY);
        eventErrorCode.put(jpos.ElectronicJournal.JPOS_E_CLAIMED, org.nrf_arts.unifiedpos.electronicjournalevents.ErrorCode.CLAIMED);
        eventErrorCode.put(jpos.ElectronicJournal.JPOS_E_CLOSED, org.nrf_arts.unifiedpos.electronicjournalevents.ErrorCode.CLOSED);
        eventErrorCode.put(jpos.ElectronicJournal.JPOS_E_DEPRECATED, org.nrf_arts.unifiedpos.electronicjournalevents.ErrorCode.DEPRECATED);
        eventErrorCode.put(jpos.ElectronicJournal.JPOS_E_DISABLED, org.nrf_arts.unifiedpos.electronicjournalevents.ErrorCode.DISABLED);
        eventErrorCode.put(jpos.ElectronicJournal.JPOS_E_EXISTS, org.nrf_arts.unifiedpos.electronicjournalevents.ErrorCode.EXISTS);
        eventErrorCode.put(jpos.ElectronicJournal.JPOS_E_EXTENDED, org.nrf_arts.unifiedpos.electronicjournalevents.ErrorCode.EXTENDED);
        eventErrorCode.put(jpos.ElectronicJournal.JPOS_E_FAILURE, org.nrf_arts.unifiedpos.electronicjournalevents.ErrorCode.FAILURE);
        eventErrorCode.put(jpos.ElectronicJournal.JPOS_E_ILLEGAL, org.nrf_arts.unifiedpos.electronicjournalevents.ErrorCode.ILLEGAL);
        eventErrorCode.put(jpos.ElectronicJournal.JPOS_E_NOEXIST, org.nrf_arts.unifiedpos.electronicjournalevents.ErrorCode.NO_EXIST);
        eventErrorCode.put(jpos.ElectronicJournal.JPOS_E_NOHARDWARE, org.nrf_arts.unifiedpos.electronicjournalevents.ErrorCode.NO_HARDWARE);
        eventErrorCode.put(jpos.ElectronicJournal.JPOS_E_NOSERVICE, org.nrf_arts.unifiedpos.electronicjournalevents.ErrorCode.NO_SERVICE);
        eventErrorCode.put(jpos.ElectronicJournal.JPOS_E_NOTCLAIMED, org.nrf_arts.unifiedpos.electronicjournalevents.ErrorCode.NOT_CLAIMED);
        eventErrorCode.put(jpos.ElectronicJournal.JPOS_E_OFFLINE, org.nrf_arts.unifiedpos.electronicjournalevents.ErrorCode.OFFLINE);
        eventErrorCode.put(0, org.nrf_arts.unifiedpos.electronicjournalevents.ErrorCode.SUCCESS);
        eventErrorCode.put(jpos.ElectronicJournal.JPOS_E_TIMEOUT, org.nrf_arts.unifiedpos.electronicjournalevents.ErrorCode.TIMEOUT);

        eventErrorLocus = new HashMap<Integer, org.nrf_arts.unifiedpos.electronicjournalevents.ErrorLocus>();
        eventErrorLocus.put(jpos.ElectronicJournal.JPOS_EL_INPUT, org.nrf_arts.unifiedpos.electronicjournalevents.ErrorLocus.INPUT);
        eventErrorLocus.put(jpos.ElectronicJournal.JPOS_EL_INPUT_DATA, org.nrf_arts.unifiedpos.electronicjournalevents.ErrorLocus.INPUT_DATA);
        eventErrorLocus.put(jpos.ElectronicJournal.JPOS_EL_OUTPUT, org.nrf_arts.unifiedpos.electronicjournalevents.ErrorLocus.OUTPUT);

        eventErrorResponse = new HashMap<Integer, org.nrf_arts.unifiedpos.electronicjournalevents.ErrorResponse>();
        eventErrorResponse.put(jpos.ElectronicJournal.JPOS_ER_CLEAR, org.nrf_arts.unifiedpos.electronicjournalevents.ErrorResponse.CLEAR);
        eventErrorResponse.put(jpos.ElectronicJournal.JPOS_ER_CONTINUEINPUT, org.nrf_arts.unifiedpos.electronicjournalevents.ErrorResponse.CONTINUE_INPUT);
        eventErrorResponse.put(jpos.ElectronicJournal.JPOS_ER_RETRY, org.nrf_arts.unifiedpos.electronicjournalevents.ErrorResponse.RETRY);
    }

    private String deviceName;
    private UposVersion deviceControlVersion;
    private org.nrf_arts.unifiedpos.electronicjournalevents.ElectronicJournalEvent deviceEvent;
    private jpos.ElectronicJournal device = new jpos.ElectronicJournal();
    private DatatypeFactory datatypeFactory;

    public ElectronicJournalService(String logicalDeviceName) {
        deviceName = logicalDeviceName;
        deviceControlVersion = new UposVersion();
        deviceControlVersion.setMajor(1);
        deviceControlVersion.setMinor(13);
        deviceControlVersion.setBuild(1);
        try {
            datatypeFactory = DatatypeFactory.newInstance();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    //
    // ElectronicJournal Member
    //

    public void addMarker(String marker) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.addMarker(marker);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void cancelPrintContent() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.cancelPrintContent();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void cancelQueryContent() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.cancelQueryContent();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void checkHealth(HealthCheckLevel level) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.checkHealth(jposConst.get(level));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void claim(Integer timeout) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.claim(timeout);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void clearInput() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.clearInput();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void clearOutput() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.clearOutput();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void close(String endpointAddress) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            if (deviceEvent != null)
            {
                device.removeDataListener(this);
                device.removeDirectIOListener(this);
                device.removeErrorListener(this);
                device.removeOutputCompleteListener(this);
                device.removeStatusUpdateListener(this);
                deviceEvent = null;
            }
            device.close();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public CompareFirmwareResult compareFirmwareVersion(String firmwareFileName) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            int[] param = new int[1];
            device.compareFirmwareVersion(firmwareFileName, param);
            return compareFirmwareResult.get(param[0]);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public DirectIOData directIO(Integer command, Integer data, Object obj) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            DirectIOData res = new DirectIOData();
            int[] param = new int[] { data };
            device.directIO(command, param, obj);
            res.setData(param[0]);
            res.setObj(obj);
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void eraseMedium() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.eraseMedium();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getAsyncMode() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getAsyncMode();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getAutoDisable() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getAutoDisable();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapAddMarker() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapAddMarker();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapCompareFirmwareVersion() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapCompareFirmwareVersion();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapErasableMedium() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapErasableMedium();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapInitializeMedium() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapInitializeMedium();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapMediumIsAvailable() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapMediumIsAvailable();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public PowerReporting getCapPowerReporting() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return powerReporting.get(device.getCapPowerReporting());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapPrintContent() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapPrintContent();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapPrintContentFile() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapPrintContentFile();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapRetrieveCurrentMarker() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapRetrieveCurrentMarker();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapRetrieveMarker() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapRetrieveMarker();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapRetrieveMarkerByDateTime() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapRetrieveMarkerByDateTime();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapRetrieveMarkersDateTime() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapRetrieveMarkersDateTime();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getCapStation() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapStation();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapStatisticsReporting() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapStatisticsReporting();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapStorageEnabled() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapStorageEnabled();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapSuspendPrintContent() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapSuspendPrintContent();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapSuspendQueryContent() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapSuspendQueryContent();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapUpdateFirmware() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapUpdateFirmware();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapUpdateStatistics() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapUpdateStatistics();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapWaterMark() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapWaterMark();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getCheckHealthText() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCheckHealthText();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getClaimed() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getClaimed();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getDataCount() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getDataCount();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getDataEventEnabled() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getDataEventEnabled();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getDeviceControlDescription() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        return device.getDeviceControlDescription();
    }

    public UposVersion getDeviceControlVersion() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        UposVersion res = new UposVersion();
        int version = device.getDeviceControlVersion();
        res.setMajor(version / 1000000 % 1000);
        res.setMinor(version / 1000 % 1000);
        res.setBuild(version % 1000);
        return res;
    }

    public Boolean getDeviceEnabled() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getDeviceEnabled();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getDeviceServiceDescription() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getDeviceServiceDescription();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public UposVersion getDeviceServiceVersion() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            UposVersion res = new UposVersion();
            int version = device.getDeviceServiceVersion();
            res.setMajor(version / 1000000 % 1000);
            res.setMinor(version / 1000 % 1000);
            res.setBuild(version % 1000);
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getFlagWhenIdle() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getFlagWhenIdle();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getFreezeEvents() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getFreezeEvents();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public BigDecimal getMediumFreeSpace() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return BigDecimal.valueOf(device.getMediumFreeSpace());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getMediumID() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getMediumID();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getMediumIsAvailable() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getMediumIsAvailable();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public BigDecimal getMediumSize() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return BigDecimal.valueOf(device.getMediumSize());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getOutputID() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getOutputID();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getPhysicalDeviceDescription() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getPhysicalDeviceDescription();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getPhysicalDeviceName() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getPhysicalDeviceName();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public PowerNotification getPowerNotify() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return powerNotification.get(device.getPowerNotify());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public PowerState getPowerState() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return powerState.get(device.getPowerState());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public ControlState getState() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        return controlState.get(device.getState());
    }

    public Integer getStation() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getStation();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getStorageEnabled() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getStorageEnabled();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getSuspended() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getSuspended();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getWaterMark() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getWaterMark();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void initializeMedium(String mediumID) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.initializeMedium(mediumID);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void open(String endpointAddress) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.open(deviceName);
            if (endpointAddress != null)
            {
                try {
                    Service service = Service.create(
                            new URL(endpointAddress + "?wsdl"),
                            new QName("http://www.nrf-arts.org/UnifiedPOS/ElectronicJournalEvents/", "ElectronicJournalEventService"));
                    deviceEvent = service.getPort(org.nrf_arts.unifiedpos.electronicjournalevents.ElectronicJournalEvent.class);
                    device.addDataListener(this);
                    device.addDirectIOListener(this);
                    device.addErrorListener(this);
                    device.addOutputCompleteListener(this);
                    device.addStatusUpdateListener(this);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void printContent(String fromMarker, String toMarker) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.printContent(fromMarker, toMarker);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void printContentFile(String fileName) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.printContentFile(fileName);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void queryContent(String fileName, String fromMarker, String toMarker) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.queryContent(fileName, fromMarker, toMarker);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void release() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.release();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void resetStatistics(StatisticList statisticsBuffer) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            String param = null;
            List<Statistic> list = statisticsBuffer.getStatistic();
            switch (list.size()) {
                case 0:
                    param = "";
                    break;
                case 1:
                    String name = list.get(0).getName();
                    if (name.equals(StatisticCategories.ALL)) {
                        param = "";
                    }
                    else if (name.equals(StatisticCategories.MANUFACTURER)) {
                        param = "M_";
                    }
                    else if (name.equals(StatisticCategories.UPOS)) {
                        param = "U_";
                    }
                    else {
                        param = name;
                    }
                    break;
                default:
                    StringBuffer buffer = new StringBuffer();
                    for (Statistic statistic : statisticsBuffer.getStatistic()) {
                        buffer.append(",").append(statistic.getName());
                    }
                    param = buffer.substring(1);
                    break;
            }
            device.resetStatistics(param);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void resumePrintContent() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.resumePrintContent();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void resumeQueryContent() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.resumeQueryContent();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String retrieveCurrentMarker(MarkerType markerType) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            String[] res = new String[1];
            device.retrieveCurrentMarker(jposConst.get(markerType), res);
            return res[0];
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String retrieveMarker(MarkerType markerType, Integer sessionNumber, Integer documentNumber) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            String[] res = new String[1];
            device.retrieveMarker(jposConst.get(markerType), sessionNumber, documentNumber, res);
            return res[0];
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String retrieveMarkerByDateTime(MarkerType markerType, String dateTime, String markerNumber) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            String[] res = new String[1];
            device.retrieveMarkerByDateTime(jposConst.get(markerType), dateTime, markerNumber, res);
            return res[0];
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String retrieveMarkersDateTime(String marker) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            String[] res = new String[1];
            device.retrieveMarkersDateTime(marker, res);
            return res[0];
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String retrieveStatistics(StatisticList statisticsBuffer) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            String[] param = new String[1];
            List<Statistic> list = statisticsBuffer.getStatistic();
            switch (list.size()) {
                case 0:
                    param[0] = "";
                    break;
                case 1:
                    String name = list.get(0).getName();
                    if (name.equals(StatisticCategories.ALL)) {
                        param[0] = "";
                    }
                    else if (name.equals(StatisticCategories.MANUFACTURER)) {
                        param[0] = "M_";
                    }
                    else if (name.equals(StatisticCategories.UPOS)) {
                        param[0] = "U_";
                    }
                    else {
                        param[0] = name;
                    }
                    break;
                default:
                    StringBuffer buffer = new StringBuffer();
                    for (Statistic statistic : statisticsBuffer.getStatistic()) {
                        buffer.append(",").append(statistic.getName());
                    }
                    param[0] = buffer.substring(1);
                    break;
            }
            device.retrieveStatistics(param);
            return param[0];
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setAsyncMode(Boolean asyncMode) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setAsyncMode(asyncMode);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setAutoDisable(Boolean autoDisable) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setAutoDisable(autoDisable);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setDataEventEnabled(Boolean dataEventEnabled) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setDataEventEnabled(dataEventEnabled);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setDeviceEnabled(Boolean deviceEnabled) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setDeviceEnabled(deviceEnabled);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setFlagWhenIdle(Boolean flagWhenIdle) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setFlagWhenIdle(flagWhenIdle);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setFreezeEvents(Boolean freezeEvents) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setFreezeEvents(freezeEvents);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setPowerNotify(PowerNotification powerNotify) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setPowerNotify(jposConst.get(powerNotify));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setStation(Integer station) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setStation(station);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setStorageEnabled(Boolean storageEnabled) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setStorageEnabled(storageEnabled);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setWaterMark(Boolean waterMark) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setWaterMark(waterMark);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void suspendPrintContent() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.suspendPrintContent();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void suspendQueryContent() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.suspendQueryContent();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void updateFirmware(String firmwareFileName) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.updateFirmware(firmwareFileName);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void updateStatistics(StatisticList statisticsBuffer) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            String param = null;
            List<Statistic> list = statisticsBuffer.getStatistic();
            switch (list.size()) {
                case 0:
                    param = "";
                    break;
                case 1:
                    Statistic s = list.get(0);
                    String name = s.getName();
                    String value = s.getValue();
                    if (name.equals(StatisticCategories.ALL)) {
                        param = "=" + value;
                    }
                    else if (name.equals(StatisticCategories.MANUFACTURER)) {
                        param = "M_=" + value;
                    }
                    else if (name.equals(StatisticCategories.UPOS)) {
                        param = "U_=" + value;
                    }
                    else {
                        param = name + "=" + value;
                    }
                    break;
                default:
                    StringBuffer buffer = new StringBuffer();
                    for (Statistic statistic : statisticsBuffer.getStatistic()) {
                        buffer.append(",").append(statistic.getName()).append("=").append(statistic.getValue());
                    }
                    param = buffer.substring(1);
                    break;
            }
            device.updateStatistics(param);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    //
    // ElectronicJournalEvent Member
    //

    public void dataOccurred(DataEvent de) {
        //throw new UnsupportedOperationException("Not supported yet.");
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(new Date(de.getWhen()));
        deviceEvent.dataEvent(
                de.getSource().toString(),
                (int)de.getSequenceNumber(),
                datatypeFactory.newXMLGregorianCalendar(cal),
                de.getStatus());
    }

    public void directIOOccurred(DirectIOEvent dioe) {
        //throw new UnsupportedOperationException("Not supported yet.");
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(new Date(dioe.getWhen()));
        org.nrf_arts.unifiedpos.electronicjournalevents.DirectIOData value = deviceEvent.directIOEvent(
                dioe.getSource().toString(),
                (int)dioe.getSequenceNumber(),
                datatypeFactory.newXMLGregorianCalendar(cal),
                dioe.getEventNumber(),
                dioe.getData(),
                dioe.getObject());
        dioe.setData(value.getData());
        dioe.setObject(value.getObj());
    }

    public void errorOccurred(ErrorEvent ee) {
        //throw new UnsupportedOperationException("Not supported yet.");
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(new Date(ee.getWhen()));
        org.nrf_arts.unifiedpos.electronicjournalevents.ErrorResponse value = deviceEvent.errorEvent(
                ee.getSource().toString(),
                (int)ee.getSequenceNumber(),
                datatypeFactory.newXMLGregorianCalendar(cal),
                eventErrorCode.get(ee.getErrorCode()),
                ee.getErrorCodeExtended(),
                eventErrorLocus.get(ee.getErrorLocus()),
                eventErrorResponse.get(ee.getErrorResponse()));
        ee.setErrorResponse(jposEventConst.get(value));
    }

    public void outputCompleteOccurred(OutputCompleteEvent oce) {
        //throw new UnsupportedOperationException("Not supported yet.");
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(new Date(oce.getWhen()));
        deviceEvent.statusUpdateEvent(
                oce.getSource().toString(),
                (int)oce.getSequenceNumber(),
                datatypeFactory.newXMLGregorianCalendar(cal),
                oce.getOutputID());
    }

    public void statusUpdateOccurred(StatusUpdateEvent sue) {
        //throw new UnsupportedOperationException("Not supported yet.");
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(new Date(sue.getWhen()));
        deviceEvent.statusUpdateEvent(
                sue.getSource().toString(),
                (int)sue.getSequenceNumber(),
                datatypeFactory.newXMLGregorianCalendar(cal),
                sue.getStatus());
    }

}
