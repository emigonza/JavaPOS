﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace UnifiedPOS.BillAcceptorEvents
{
    [ServiceContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptorEvents/")]
    public interface BillAcceptorEvent
    {

        //
        // Events
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptorEvents/DataEvent", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptorEvents/DataEventResponse")]
        void DataEvent(string Source, int EventID, DateTime TimeStamp, int Status);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptorEvents/DirectIOEvent", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptorEvents/DirectIOEventResponse")]
        DirectIOData DirectIOEvent(string Source, int EventID, DateTime TimeStamp, int EventNumber, int Data, object Obj);

        /* NOT SUPPORTED
        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptorEvents/ErrorEvent", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptorEvents/ErrorEventResponse")]
        ErrorResponse ErrorEvent(string Source, int EventID, DateTime TimeStamp, ErrorCode ErrorCode, int ErrorCodeExtended, ErrorLocus ErrorLocus, ErrorResponse ErrorResponse);
        */

        /* NOT SUPPORTED
        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptorEvents/OutputCompleteEvent", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptorEvents/OutputCompleteEventResponse")]
        void OutputCompleteEvent(string Source, int EventID, DateTime TimeStamp, int OutputID);
        */

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptorEvents/StatusUpdateEvent", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptorEvents/StatusUpdateEventResponse")]
        void StatusUpdateEvent(string Source, int EventID, DateTime TimeStamp, int Status);
    }

    //
    // Common Data Types
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptorEvents/")]
    public class DirectIOData
    {
        [DataMember]
        public int Data { get; set; }
        [DataMember]
        public object Obj { get; set; }
    }

    //
    // Common Enumerations
    //

    /* NOT SUPPORTED
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptorEvents/")]
    public enum ErrorCode
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Claimed,
        [EnumMember]
        Closed,
        [EnumMember]
        Deprecated,
        [EnumMember]
        Disabled,
        [EnumMember]
        Exists,
        [EnumMember]
        Extended,
        [EnumMember]
        Failure,
        [EnumMember]
        Illegal,
        [EnumMember]
        NoExist,
        [EnumMember]
        NoHardware,
        [EnumMember]
        NoService,
        [EnumMember]
        NotClaimed,
        [EnumMember]
        Offline,
        [EnumMember]
        Success,
        [EnumMember]
        Timeout,
    } 
    */

    /* NOT SUPPORTED
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptorEvents/")]
    public enum ErrorLocus
    {
        [EnumMember]
        Input,
        [EnumMember]
        InputData,
        [EnumMember]
        Output,
    }
    */

    /* NOT SUPPORTED
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptorEvents/")]
    public enum ErrorResponse
    {
        [EnumMember]
        Clear,
        [EnumMember]
        ContinueInput,
        [EnumMember]
        Retry,
    }
    */

    //
    // Specific Data Types
    //

    //
    // Specific Enumerations
    //

    //
    // Constants
    //

    public class Status
    {
        public const int Full = 21;
        public const int FullOk = 23;
        public const int Jam = 31;
        public const int JamOk = 32;
        public const int NearFull = 22;
        public const int PowerOff = 2002;
        public const int PowerOffline = 2003;
        public const int PowerOffOffline = 2004;
        public const int PowerOnline = 2001;
        public const int UpdateFirmwareComplete = 2200;
        public const int UpdateFirmwareCompleteDeviceNotRestored = 2205;
        public const int UpdateFirmwareFailedDeviceNeedsFirmware = 2203;
        public const int UpdateFirmwareFailedDeviceOk = 2201;
        public const int UpdateFirmwareFailedDeviceUnknown = 2204;
        public const int UpdateFirmwareFailedDeviceUnrecoverable = 2202;
        public const int UpdateFirmwareProgress = 2100;
    }
}
