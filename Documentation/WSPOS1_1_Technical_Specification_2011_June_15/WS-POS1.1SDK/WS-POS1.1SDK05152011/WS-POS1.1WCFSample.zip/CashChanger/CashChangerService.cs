﻿using UnifiedPOS.CashChanger;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace Wspos
{
    [ServiceBehavior(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/", InstanceContextMode = InstanceContextMode.Single)]
    public class CashChangerService : CashChanger, IDisposable
    {
        #region CashChanger Enumration Converter

        private static Dictionary<Enum, Enum> Convert = new Dictionary<Enum, Enum>()
            {
                { Microsoft.PointOfService.PowerReporting.Advanced, PowerReporting.Advanced },
                { Microsoft.PointOfService.PowerReporting.None, PowerReporting.None },
                { Microsoft.PointOfService.PowerReporting.Standard, PowerReporting.Standard },
                { PowerReporting.Advanced, Microsoft.PointOfService.PowerReporting.Advanced },
                { PowerReporting.None, Microsoft.PointOfService.PowerReporting.None },
                { PowerReporting.Standard, Microsoft.PointOfService.PowerReporting.Standard },

                { Microsoft.PointOfService.PowerNotification.Disabled, PowerNotification.Disabled },
                { Microsoft.PointOfService.PowerNotification.Enabled, PowerNotification.Enabled },
                { PowerNotification.Disabled, Microsoft.PointOfService.PowerNotification.Disabled },
                { PowerNotification.Enabled, Microsoft.PointOfService.PowerNotification.Enabled },

                { Microsoft.PointOfService.PowerState.Off, PowerState.Off },
                { Microsoft.PointOfService.PowerState.Offline, PowerState.Offline },
                { Microsoft.PointOfService.PowerState.OffOffline, PowerState.OffOffline },
                { Microsoft.PointOfService.PowerState.Online, PowerState.Online },
                { Microsoft.PointOfService.PowerState.Unknown, PowerState.Unknown },
                { PowerState.Off, Microsoft.PointOfService.PowerState.Off },
                { PowerState.Offline, Microsoft.PointOfService.PowerState.Offline },
                { PowerState.OffOffline, Microsoft.PointOfService.PowerState.OffOffline },
                { PowerState.Online, Microsoft.PointOfService.PowerState.Online },
                { PowerState.Unknown, Microsoft.PointOfService.PowerState.Unknown },

                { Microsoft.PointOfService.ControlState.Busy, ControlState.Busy },
                { Microsoft.PointOfService.ControlState.Closed, ControlState.Closed },
                { Microsoft.PointOfService.ControlState.Error, ControlState.Error },
                { Microsoft.PointOfService.ControlState.Idle, ControlState.Idle },
                { ControlState.Busy, Microsoft.PointOfService.ControlState.Busy },
                { ControlState.Closed, Microsoft.PointOfService.ControlState.Closed },
                { ControlState.Error, Microsoft.PointOfService.ControlState.Error },
                { ControlState.Idle, Microsoft.PointOfService.ControlState.Idle },

                { Microsoft.PointOfService.HealthCheckLevel.External, HealthCheckLevel.External },
                { Microsoft.PointOfService.HealthCheckLevel.Interactive, HealthCheckLevel.Interactive },
                { Microsoft.PointOfService.HealthCheckLevel.Internal, HealthCheckLevel.Internal },
                { HealthCheckLevel.External, Microsoft.PointOfService.HealthCheckLevel.External },
                { HealthCheckLevel.Interactive, Microsoft.PointOfService.HealthCheckLevel.Interactive },
                { HealthCheckLevel.Internal, Microsoft.PointOfService.HealthCheckLevel.Internal },

                { Microsoft.PointOfService.CompareFirmwareResult.Different, CompareFirmwareResult.Different },
                { Microsoft.PointOfService.CompareFirmwareResult.Newer, CompareFirmwareResult.Newer },
                { Microsoft.PointOfService.CompareFirmwareResult.Older, CompareFirmwareResult.Older },
                { Microsoft.PointOfService.CompareFirmwareResult.Same, CompareFirmwareResult.Same },
                { Microsoft.PointOfService.CompareFirmwareResult.Unknown, CompareFirmwareResult.Unknown },
                { CompareFirmwareResult.Different, Microsoft.PointOfService.CompareFirmwareResult.Different },
                { CompareFirmwareResult.Newer, Microsoft.PointOfService.CompareFirmwareResult.Newer },
                { CompareFirmwareResult.Older, Microsoft.PointOfService.CompareFirmwareResult.Older },
                { CompareFirmwareResult.Same, Microsoft.PointOfService.CompareFirmwareResult.Same },
                { CompareFirmwareResult.Unknown, Microsoft.PointOfService.CompareFirmwareResult.Unknown },

                { Microsoft.PointOfService.ErrorCode.Busy, UnifiedPOS.CashChanger.ErrorCode.Busy },
                { Microsoft.PointOfService.ErrorCode.Claimed, UnifiedPOS.CashChanger.ErrorCode.Claimed },
                { Microsoft.PointOfService.ErrorCode.Closed, UnifiedPOS.CashChanger.ErrorCode.Closed },
                { Microsoft.PointOfService.ErrorCode.Deprecated, UnifiedPOS.CashChanger.ErrorCode.Deprecated },
                { Microsoft.PointOfService.ErrorCode.Disabled, UnifiedPOS.CashChanger.ErrorCode.Disabled },
                { Microsoft.PointOfService.ErrorCode.Exists, UnifiedPOS.CashChanger.ErrorCode.Exists },
                { Microsoft.PointOfService.ErrorCode.Extended, UnifiedPOS.CashChanger.ErrorCode.Extended },
                { Microsoft.PointOfService.ErrorCode.Failure, UnifiedPOS.CashChanger.ErrorCode.Failure },
                { Microsoft.PointOfService.ErrorCode.Illegal, UnifiedPOS.CashChanger.ErrorCode.Illegal },
                { Microsoft.PointOfService.ErrorCode.NoExist, UnifiedPOS.CashChanger.ErrorCode.NoExist },
                { Microsoft.PointOfService.ErrorCode.NoHardware, UnifiedPOS.CashChanger.ErrorCode.NoHardware },
                { Microsoft.PointOfService.ErrorCode.NoService, UnifiedPOS.CashChanger.ErrorCode.NoService },
                { Microsoft.PointOfService.ErrorCode.NotClaimed, UnifiedPOS.CashChanger.ErrorCode.NotClaimed },
                { Microsoft.PointOfService.ErrorCode.Offline, UnifiedPOS.CashChanger.ErrorCode.Offline },
                { Microsoft.PointOfService.ErrorCode.Success, UnifiedPOS.CashChanger.ErrorCode.Success },
                { Microsoft.PointOfService.ErrorCode.Timeout, UnifiedPOS.CashChanger.ErrorCode.Timeout },
                { UnifiedPOS.CashChanger.ErrorCode.Busy, Microsoft.PointOfService.ErrorCode.Busy },
                { UnifiedPOS.CashChanger.ErrorCode.Claimed, Microsoft.PointOfService.ErrorCode.Claimed },
                { UnifiedPOS.CashChanger.ErrorCode.Closed, Microsoft.PointOfService.ErrorCode.Closed },
                { UnifiedPOS.CashChanger.ErrorCode.Deprecated, Microsoft.PointOfService.ErrorCode.Deprecated },
                { UnifiedPOS.CashChanger.ErrorCode.Disabled, Microsoft.PointOfService.ErrorCode.Disabled },
                { UnifiedPOS.CashChanger.ErrorCode.Exists, Microsoft.PointOfService.ErrorCode.Exists },
                { UnifiedPOS.CashChanger.ErrorCode.Extended, Microsoft.PointOfService.ErrorCode.Extended },
                { UnifiedPOS.CashChanger.ErrorCode.Failure, Microsoft.PointOfService.ErrorCode.Failure },
                { UnifiedPOS.CashChanger.ErrorCode.Illegal, Microsoft.PointOfService.ErrorCode.Illegal },
                { UnifiedPOS.CashChanger.ErrorCode.NoExist, Microsoft.PointOfService.ErrorCode.NoExist },
                { UnifiedPOS.CashChanger.ErrorCode.NoHardware, Microsoft.PointOfService.ErrorCode.NoHardware },
                { UnifiedPOS.CashChanger.ErrorCode.NoService, Microsoft.PointOfService.ErrorCode.NoService },
                { UnifiedPOS.CashChanger.ErrorCode.NotClaimed, Microsoft.PointOfService.ErrorCode.NotClaimed },
                { UnifiedPOS.CashChanger.ErrorCode.Offline, Microsoft.PointOfService.ErrorCode.Offline },
                { UnifiedPOS.CashChanger.ErrorCode.Success, Microsoft.PointOfService.ErrorCode.Success },
                { UnifiedPOS.CashChanger.ErrorCode.Timeout, Microsoft.PointOfService.ErrorCode.Timeout },

                { Microsoft.PointOfService.CashCountType.Bill, CashCountType.Bill },
                { Microsoft.PointOfService.CashCountType.Coin, CashCountType.Coin },
                { CashCountType.Bill, Microsoft.PointOfService.CashCountType.Bill },
                { CashCountType.Coin, Microsoft.PointOfService.CashCountType.Coin },

                { Microsoft.PointOfService.CashDepositStatus.Count, CashDepositStatus.Count },
                { Microsoft.PointOfService.CashDepositStatus.End, CashDepositStatus.End },
                { Microsoft.PointOfService.CashDepositStatus.Jam, CashDepositStatus.Jam },
                { Microsoft.PointOfService.CashDepositStatus.None, CashDepositStatus.None },
                { Microsoft.PointOfService.CashDepositStatus.Start, CashDepositStatus.Start },
                { CashDepositStatus.Count, Microsoft.PointOfService.CashDepositStatus.Count },
                { CashDepositStatus.End, Microsoft.PointOfService.CashDepositStatus.End },
                { CashDepositStatus.Jam, Microsoft.PointOfService.CashDepositStatus.Jam },
                { CashDepositStatus.None, Microsoft.PointOfService.CashDepositStatus.None },
                { CashDepositStatus.Start, Microsoft.PointOfService.CashDepositStatus.Start },

                { Microsoft.PointOfService.CashChangerStatus.Empty, CashChangerStatus.Empty },
                { Microsoft.PointOfService.CashChangerStatus.Jam, CashChangerStatus.Jam },
                { Microsoft.PointOfService.CashChangerStatus.NearEmpty, CashChangerStatus.NearEmpty },
                { Microsoft.PointOfService.CashChangerStatus.OK, CashChangerStatus.OK },
                { CashChangerStatus.Empty, Microsoft.PointOfService.CashChangerStatus.Empty },
                { CashChangerStatus.Jam, Microsoft.PointOfService.CashChangerStatus.Jam },
                { CashChangerStatus.NearEmpty, Microsoft.PointOfService.CashChangerStatus.NearEmpty },
                { CashChangerStatus.OK, Microsoft.PointOfService.CashChangerStatus.OK },

                { Microsoft.PointOfService.CashChangerFullStatus.Full, CashChangerFullStatus.Full },
                { Microsoft.PointOfService.CashChangerFullStatus.NearFull, CashChangerFullStatus.NearFull },
                { Microsoft.PointOfService.CashChangerFullStatus.OK, CashChangerFullStatus.OK },
                { CashChangerFullStatus.Full, Microsoft.PointOfService.CashChangerFullStatus.Full },
                { CashChangerFullStatus.NearFull, Microsoft.PointOfService.CashChangerFullStatus.NearFull },
                { CashChangerFullStatus.OK, Microsoft.PointOfService.CashChangerFullStatus.OK },

                { Microsoft.PointOfService.CashDepositAction.Change, CashDepositAction.Change },
                { Microsoft.PointOfService.CashDepositAction.NoChange, CashDepositAction.NoChange },
                { Microsoft.PointOfService.CashDepositAction.Repay, CashDepositAction.Repay },
                { CashDepositAction.Change, Microsoft.PointOfService.CashDepositAction.Change },
                { CashDepositAction.NoChange, Microsoft.PointOfService.CashDepositAction.NoChange },
                { CashDepositAction.Repay, Microsoft.PointOfService.CashDepositAction.Repay },

                { Microsoft.PointOfService.CashDepositPause.Pause, CashDepositPause.Pause },
                { Microsoft.PointOfService.CashDepositPause.Restart, CashDepositPause.Restart },
                { CashDepositPause.Pause, Microsoft.PointOfService.CashDepositPause.Pause },
                { CashDepositPause.Restart, Microsoft.PointOfService.CashDepositPause.Restart },
            };

        #endregion

        private string deviceControlDescription = "";
        private UposVersion deviceControlVersion = new UposVersion() { Major = 1, Minor = 13, Build = 1 };
        private UnifiedPOS.CashChangerEvents.CashChangerEvent deviceEvent;
        private Microsoft.PointOfService.CashChanger device;

        #region Constructor

        public CashChangerService()
        {
            try
            {
                Microsoft.PointOfService.PosExplorer posExplorer = new Microsoft.PointOfService.PosExplorer();
                Microsoft.PointOfService.DeviceCollection deviceCollection = posExplorer.GetDevices("CashChanger");
                if (deviceCollection.Count > 0)
                {
                    device = (Microsoft.PointOfService.CashChanger)posExplorer.CreateInstance(deviceCollection[0]);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        #endregion

        #region CashChanger Member

        public bool GetCapCompareFirmwareVersion()
        {
            //throw new NotImplementedException();
            return device.CapCompareFirmwareVersion;
        }

        public PowerReporting GetCapPowerReporting()
        {
            //throw new NotImplementedException();
            return (PowerReporting)Convert[device.CapPowerReporting];
        }

        public bool GetCapStatisticsReporting()
        {
            //throw new NotImplementedException();
            return device.CapStatisticsReporting;
        }

        public bool GetCapUpdateFirmware()
        {
            //throw new NotImplementedException();
            return device.CapUpdateFirmware;
        }

        public bool GetCapUpdateStatistics()
        {
            //throw new NotImplementedException();
            return device.CapUpdateStatistics;
        }

        public string GetCheckHealthText()
        {
            //throw new NotImplementedException();
            return device.CheckHealthText;
        }

        public bool GetClaimed()
        {
            //throw new NotImplementedException();
            return device.Claimed;
        }

        public int GetDataCount()
        {
            //throw new NotImplementedException();
            return device.DataCount;
        }

        public bool GetDataEventEnabled()
        {
            //throw new NotImplementedException();
            return device.DataEventEnabled;
        }

        public void SetDataEventEnabled(bool DataEventEnabled)
        {
            //throw new NotImplementedException();
            device.DataEventEnabled = DataEventEnabled;
        }

        public bool GetDeviceEnabled()
        {
            //throw new NotImplementedException();
            return device.DeviceEnabled;
        }

        public void SetDeviceEnabled(bool DeviceEnabled)
        {
            //throw new NotImplementedException();
            device.DeviceEnabled = DeviceEnabled;
        }

        public bool GetFreezeEvents()
        {
            //throw new NotImplementedException();
            return device.FreezeEvents;
        }

        public void SetFreezeEvents(bool FreezeEvents)
        {
            //throw new NotImplementedException();
            device.FreezeEvents = FreezeEvents;
        }

        public PowerNotification GetPowerNotify()
        {
            //throw new NotImplementedException();
            return (PowerNotification)Convert[device.PowerNotify];
        }

        public void SetPowerNotify(PowerNotification PowerNotify)
        {
            //throw new NotImplementedException();
            device.PowerNotify = (Microsoft.PointOfService.PowerNotification)Convert[PowerNotify];
        }

        public PowerState GetPowerState()
        {
            //throw new NotImplementedException();
            return (PowerState)Convert[device.PowerState];
        }

        public ControlState GetState()
        {
            //throw new NotImplementedException();
            return (ControlState)Convert[device.State];
        }

        public string GetDeviceControlDescription()
        {
            //throw new NotImplementedException();
            return deviceControlDescription;
        }

        public UposVersion GetDeviceControlVersion()
        {
            //throw new NotImplementedException();
            return deviceControlVersion;
        }

        public string GetDeviceServiceDescription()
        {
            //throw new NotImplementedException();
            return device.ServiceObjectDescription;
        }

        public UposVersion GetDeviceServiceVersion()
        {
            //throw new NotImplementedException();
            Version value = device.ServiceObjectVersion;
            return new UposVersion() { Build = value.Build, Major = value.Major, Minor = value.Minor };
        }

        public string GetPhysicalDeviceDescription()
        {
            //throw new NotImplementedException();
            return device.DeviceDescription;
        }

        public string GetPhysicalDeviceName()
        {
            //throw new NotImplementedException();
            return device.DeviceName;
        }

        public bool GetCapDeposit()
        {
            //throw new NotImplementedException();
            return device.CapDeposit;
        }

        public bool GetCapDepositDataEvent()
        {
            //throw new NotImplementedException();
            return device.CapDepositDataEvent;
        }

        public bool GetCapDiscrepancy()
        {
            //throw new NotImplementedException();
            return device.CapDiscrepancy;
        }

        public bool GetCapEmptySensor()
        {
            //throw new NotImplementedException();
            return device.CapEmptySensor;
        }

        public bool GetCapFullSensor()
        {
            //throw new NotImplementedException();
            return device.CapFullSensor;
        }

        public bool GetCapJamSensor()
        {
            //throw new NotImplementedException();
            return device.CapJamSensor;
        }

        public bool GetCapNearEmptySensor()
        {
            //throw new NotImplementedException();
            return device.CapNearEmptySensor;
        }

        public bool GetCapNearFullSensor()
        {
            //throw new NotImplementedException();
            return device.CapNearFullSensor;
        }

        public bool GetCapPauseDeposit()
        {
            //throw new NotImplementedException();
            return device.CapPauseDeposit;
        }

        public bool GetCapRealTimeData()
        {
            //throw new NotImplementedException();
            return device.CapRealTimeData;
        }

        public bool GetCapRepayDeposit()
        {
            //throw new NotImplementedException();
            return device.CapRepayDeposit;
        }

        public bool GetAsyncMode()
        {
            //throw new NotImplementedException();
            return device.AsyncMode;
        }

        public void SetAsyncMode(bool AsyncMode)
        {
            //throw new NotImplementedException();
            device.AsyncMode = AsyncMode;
        }

        public int GetAsyncResultCode()
        {
            //throw new NotImplementedException();
            return device.AsyncResultCode;
        }

        public int GetAsyncResultCodeExtended()
        {
            //throw new NotImplementedException();
            return device.AsyncResultCodeExtended;
        }

        public CashUnits GetCurrencyCashList()
        {
            //throw new NotImplementedException();
            Microsoft.PointOfService.CashUnits c = device.CurrencyCashList;
            CashUnits value = new CashUnits() { Bills = new BillList(), Coins = new CoinList() };
            value.Bills.AddRange(c.Bills);
            value.Coins.AddRange(c.Coins);
            return value;
        }

        public string GetCurrencyCode()
        {
            //throw new NotImplementedException();
            return device.CurrencyCode;
        }

        public void SetCurrencyCode(string CurrencyCode)
        {
            //throw new NotImplementedException();
            device.CurrencyCode = CurrencyCode;
        }

        public CurrencyCodeList GetCurrencyCodeList()
        {
            //throw new NotImplementedException();
            CurrencyCodeList value = new CurrencyCodeList();
            value.AddRange(device.CurrencyCodeList);
            return value;
        }

        public int GetCurrentExit()
        {
            //throw new NotImplementedException();
            return device.CurrentExit;
        }

        public void SetCurrentExit(int CurrentExit)
        {
            //throw new NotImplementedException();
            device.CurrentExit = CurrentExit;
        }

        public int GetCurrentService()
        {
            //throw new NotImplementedException();
            return device.CurrentService;
        }

        public void SetCurrentService(int CurrentService)
        {
            //throw new NotImplementedException();
            device.CurrentService = CurrentService;
        }

        public int GetDepositAmount()
        {
            //throw new NotImplementedException();
            return device.DepositAmount;
        }

        public CashUnits GetDepositCashList()
        {
            //throw new NotImplementedException();
            Microsoft.PointOfService.CashUnits c = device.DepositCashList;
            CashUnits value = new CashUnits() { Bills = new BillList(), Coins = new CoinList() };
            value.Bills.AddRange(c.Bills);
            value.Coins.AddRange(c.Coins);
            return value;
        }

        public DepositCodeList GetDepositCodeList()
        {
            //throw new NotImplementedException();
            DepositCodeList value = new DepositCodeList();
            value.AddRange(device.DepositCodeList);
            return value;
        }

        public CashCountList GetDepositCounts()
        {
            //throw new NotImplementedException();
            CashCountList value = new CashCountList();
            value.AddRange(from el in device.DepositCounts select new CashCount() { Count = el.Count, NominalValue = el.NominalValue, Type = (CashCountType)Convert[el.Type] });
            return value;
        }

        public CashDepositStatus GetDepositStatus()
        {
            //throw new NotImplementedException();
            return (CashDepositStatus)Convert[device.DepositStatus];
        }

        public int GetDeviceExits()
        {
            //throw new NotImplementedException();
            return device.DeviceExits;
        }

        public CashChangerStatus GetDeviceStatus()
        {
            //throw new NotImplementedException();
            return (CashChangerStatus)Convert[device.DeviceStatus];
        }

        public CashUnits GetExitCashList()
        {
            //throw new NotImplementedException();
            Microsoft.PointOfService.CashUnits c = device.ExitCashList;
            CashUnits value = new CashUnits() { Bills = new BillList(), Coins = new CoinList() };
            value.Bills.AddRange(c.Bills);
            value.Coins.AddRange(c.Coins);
            return value;
        }

        public CashChangerFullStatus GetFullStatus()
        {
            //throw new NotImplementedException();
            return (CashChangerFullStatus)Convert[device.FullStatus];
        }

        public bool GetRealTimeDataEnabled()
        {
            //throw new NotImplementedException();
            return device.RealTimeDataEnabled;
        }

        public void SetRealTimeDataEnabled(bool RealTimeDataEnabled)
        {
            //throw new NotImplementedException();
            device.RealTimeDataEnabled = RealTimeDataEnabled;
        }

        public int GetServiceCount()
        {
            //throw new NotImplementedException();
            return device.ServiceCount;
        }

        public ServiceIndex GetServiceIndex()
        {
            //throw new NotImplementedException();
            Microsoft.PointOfService.ServiceIndex value = device.ServiceIndex;
            return new ServiceIndex() { BillAcceptor = value.IndexOfBillAcceptor, BillDispenser = value.IndexOfBillDispenser, CoinAcceptor = value.IndexOfCoinAcceptor, CoinDispenser = value.IndexOfCoinDispenser };
        }

        public void Open(string EndpointAddress)
        {
            //throw new NotImplementedException();
            device.Open();
            if (EndpointAddress != null)
            {
                ChannelFactory<UnifiedPOS.CashChangerEvents.CashChangerEvent> factory =
                    new ChannelFactory<UnifiedPOS.CashChangerEvents.CashChangerEvent>("CashChangerEventPort", new EndpointAddress(EndpointAddress));
                deviceEvent = factory.CreateChannel();

                device.DataEvent += new Microsoft.PointOfService.DataEventHandler(device_DataEvent);
                device.DirectIOEvent += new Microsoft.PointOfService.DirectIOEventHandler(device_DirectIOEvent);
                device.StatusUpdateEvent += new Microsoft.PointOfService.StatusUpdateEventHandler(device_StatusUpdateEvent);
            }
        }

        public void Close(string EndpointAddress)
        {
            //throw new NotImplementedException();
            device.Close();
            if (deviceEvent != null)
            {
                device.DataEvent -= device_DataEvent;
                device.DirectIOEvent -= device_DirectIOEvent;
                device.StatusUpdateEvent -= device_StatusUpdateEvent;

                ((IClientChannel)deviceEvent).Close();
                deviceEvent = null;
            }
        }

        public void Claim(int Timeout)
        {
            //throw new NotImplementedException();
            device.Claim(Timeout);
        }

        public void Release()
        {
            //throw new NotImplementedException();
            device.Release();
        }

        public void CheckHealth(HealthCheckLevel Level)
        {
            //throw new NotImplementedException();
            device.CheckHealth((Microsoft.PointOfService.HealthCheckLevel)Convert[Level]);
        }

        public void ClearInput()
        {
            //throw new NotImplementedException();
            device.ClearInput();
        }

        public DirectIOData DirectIO(int Command, int Data, object Obj)
        {
            //throw new NotImplementedException();
            Microsoft.PointOfService.DirectIOData value = device.DirectIO(Command, Data, Obj);
            return new DirectIOData() { Data = value.Data, Obj = value.Object };
        }

        public CompareFirmwareResult CompareFirmwareVersion(string FirmwareFileName)
        {
            //throw new NotImplementedException();
            return (CompareFirmwareResult)Convert[device.CompareFirmwareVersion(FirmwareFileName)];
        }

        public void ResetStatistics(StatisticList StatisticsBuffer)
        {
            //throw new NotImplementedException();
            var value = from el in StatisticsBuffer select el.Name;
            switch (value.Count())
            {
                case 0:
                    device.ResetStatistics();
                    break;
                case 1:
                    string name = value.First();
                    switch (name)
                    {
                        case StatisticCategories.All:
                            device.ResetStatistics(Microsoft.PointOfService.StatisticCategories.All);
                            break;
                        case StatisticCategories.Manufacturer:
                            device.ResetStatistics(Microsoft.PointOfService.StatisticCategories.Manufacturer);
                            break;
                        case StatisticCategories.Upos:
                            device.ResetStatistics(Microsoft.PointOfService.StatisticCategories.Upos);
                            break;
                        default:
                            device.ResetStatistic(name);
                            break;
                    }
                    break;
                default:
                    device.ResetStatistics(value.ToArray());
                    break;
            }
        }

        public string RetrieveStatistics(StatisticList StatisticsBuffer)
        {
            //throw new NotImplementedException();
            string res = null;
            var value = from el in StatisticsBuffer select el.Name;
            switch (value.Count())
            {
                case 0:
                    res = device.RetrieveStatistics();
                    break;
                case 1:
                    string name = value.First();
                    switch (name)
                    {
                        case StatisticCategories.All:
                            res = device.RetrieveStatistics(Microsoft.PointOfService.StatisticCategories.All);
                            break;
                        case StatisticCategories.Manufacturer:
                            res = device.RetrieveStatistics(Microsoft.PointOfService.StatisticCategories.Manufacturer);
                            break;
                        case StatisticCategories.Upos:
                            res = device.RetrieveStatistics(Microsoft.PointOfService.StatisticCategories.Upos);
                            break;
                        default:
                            res = device.RetrieveStatistic(name);
                            break;
                    }
                    break;
                default:
                    res = device.RetrieveStatistics(value.ToArray());
                    break;
            }
            return res;
        }

        public void UpdateFirmware(string FirmwareFileName)
        {
            //throw new NotImplementedException();
            device.UpdateFirmware(FirmwareFileName);
        }

        public void UpdateStatistics(StatisticList StatisticsBuffer)
        {
            //throw new NotImplementedException();
            var value = from el in StatisticsBuffer select new Microsoft.PointOfService.Statistic(el.Name, el.Value);
            switch (value.Count())
            {
                case 0:
                    device.UpdateStatistics(value.ToArray());
                    break;
                case 1:
                    Microsoft.PointOfService.Statistic statistic = value.First();
                    switch (statistic.Name)
                    {
                        case StatisticCategories.All:
                            device.UpdateStatistics(Microsoft.PointOfService.StatisticCategories.All, statistic.Value);
                            break;
                        case StatisticCategories.Manufacturer:
                            device.UpdateStatistics(Microsoft.PointOfService.StatisticCategories.Manufacturer, statistic.Value);
                            break;
                        case StatisticCategories.Upos:
                            device.UpdateStatistics(Microsoft.PointOfService.StatisticCategories.Upos, statistic.Value);
                            break;
                        default:
                            device.UpdateStatistic(statistic.Name, statistic.Value);
                            break;
                    }
                    break;
                default:
                    device.UpdateStatistics(value.ToArray());
                    break;
            }
        }

        public void AdjustCashCounts(CashCountList CashCounts)
        {
            //throw new NotImplementedException();
            device.AdjustCashCounts(from el in CashCounts select new Microsoft.PointOfService.CashCount((Microsoft.PointOfService.CashCountType)Convert[el.Type], el.NominalValue, el.Count));
        }

        public void BeginDeposit()
        {
            //throw new NotImplementedException();
            device.BeginDeposit();
        }

        public void DispenseCash(CashCountList CashCounts)
        {
            //throw new NotImplementedException();
            var value = from el in CashCounts select new Microsoft.PointOfService.CashCount((Microsoft.PointOfService.CashCountType)Convert[el.Type], el.NominalValue, el.Count);
            device.DispenseCash(value.ToArray());
        }

        public void DispenseChange(int Amount)
        {
            //throw new NotImplementedException();
            device.DispenseChange(Amount);
        }

        public void EndDeposit(CashDepositAction Success)
        {
            //throw new NotImplementedException();
            device.EndDeposit((Microsoft.PointOfService.CashDepositAction)Convert[Success]);
        }

        public void FixDeposit()
        {
            //throw new NotImplementedException();
            device.FixDeposit();
        }

        public void PauseDeposit(CashDepositPause Control)
        {
            //throw new NotImplementedException();
            device.PauseDeposit((Microsoft.PointOfService.CashDepositPause)Convert[Control]);
        }

        public CashCounts ReadCashCounts()
        {
            //throw new NotImplementedException();
            Microsoft.PointOfService.CashCounts c = device.ReadCashCounts();
            CashCounts value = new CashCounts() { Counts = new CashCountList(), Discrepancy = c.Discrepancy };
            value.Counts.AddRange(from el in c.Counts select new CashCount() { Count = el.Count, NominalValue = el.NominalValue, Type = (CashCountType)Convert[el.Type] });
            return value;
        }

        #endregion

        #region CashChangerEvent Member

        private void device_DataEvent(object sender, Microsoft.PointOfService.DataEventArgs e)
        {
            //throw new NotImplementedException();
            if (deviceEvent != null)
            {
                deviceEvent.DataEvent(sender.ToString(), e.EventId, e.TimeStamp, e.Status);
            }
        }

        private void device_DirectIOEvent(object sender, Microsoft.PointOfService.DirectIOEventArgs e)
        {
            //throw new NotImplementedException();
            if (deviceEvent != null)
            {
                UnifiedPOS.CashChangerEvents.DirectIOData value = deviceEvent.DirectIOEvent(sender.ToString(), e.EventId, e.TimeStamp, e.EventNumber, e.Data, e.Object);
                e.Data = value.Data;
                e.Object = value.Obj;
            }
        }

        private void device_StatusUpdateEvent(object sender, Microsoft.PointOfService.StatusUpdateEventArgs e)
        {
            //throw new NotImplementedException();
            if (deviceEvent != null)
            {
                deviceEvent.StatusUpdateEvent(sender.ToString(), e.EventId, e.TimeStamp, e.Status);
            }
        }

        #endregion

        #region IDisposable Member

        public void Dispose()
        {
            //throw new NotImplementedException();
            if (device != null)
            {
                try
                {
                    device.Close();
                }
                catch
                {
                }
                finally
                {
                    device = null;
                }
            }
            if (deviceEvent != null)
            {
                try
                {
                    ((IClientChannel)deviceEvent).Close();
                }
                catch
                {
                }
                finally
                {
                    deviceEvent = null;
                }
            }
        }

        #endregion
    }
}
