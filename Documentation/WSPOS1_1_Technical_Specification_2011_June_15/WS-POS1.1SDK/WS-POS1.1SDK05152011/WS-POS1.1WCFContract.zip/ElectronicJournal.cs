﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace UnifiedPOS.ElectronicJournal
{
    [ServiceContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/")]
    public interface ElectronicJournal
    {

        //
        // Common Properties
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetAutoDisableResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        bool GetAutoDisable();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/SetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/SetAutoDisableResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        void SetAutoDisable(bool AutoDisable);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetCapCompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetCapCompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        bool GetCapCompareFirmwareVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetCapPowerReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetCapPowerReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        PowerReporting GetCapPowerReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetCapStatisticsReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetCapStatisticsReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        bool GetCapStatisticsReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetCapUpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetCapUpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        bool GetCapUpdateFirmware();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetCapUpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetCapUpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        bool GetCapUpdateStatistics();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetCheckHealthText", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetCheckHealthTextResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        string GetCheckHealthText();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetClaimed", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetClaimedResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        bool GetClaimed();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetDataCount", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetDataCountResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        int GetDataCount();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetDataEventEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        bool GetDataEventEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/SetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/SetDataEventEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        void SetDataEventEnabled(bool DataEventEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        bool GetDeviceEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/SetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/SetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        void SetDeviceEnabled(bool DeviceEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        bool GetFreezeEvents();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/SetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/SetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        void SetFreezeEvents(bool FreezeEvents);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetOutputID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetOutputIDResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        int GetOutputID();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        PowerNotification GetPowerNotify();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/SetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/SetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        void SetPowerNotify(PowerNotification PowerNotify);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetPowerState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetPowerStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        PowerState GetPowerState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        ControlState GetState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetDeviceControlDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetDeviceControlDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        string GetDeviceControlDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetDeviceControlVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetDeviceControlVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        UposVersion GetDeviceControlVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetDeviceServiceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetDeviceServiceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        string GetDeviceServiceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetDeviceServiceVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetDeviceServiceVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        UposVersion GetDeviceServiceVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetPhysicalDeviceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetPhysicalDeviceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        string GetPhysicalDeviceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetPhysicalDeviceName", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetPhysicalDeviceNameResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        string GetPhysicalDeviceName();

        //
        // Specific Properties
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetAsyncMode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetAsyncModeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        bool GetAsyncMode();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/SetAsyncMode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/SetAsyncModeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        void SetAsyncMode(bool AsyncMode);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetCapAddMarker", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetCapAddMarkerResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        bool GetCapAddMarker();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetCapErasableMedium", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetCapErasableMediumResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        bool GetCapErasableMedium();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetCapInitializeMedium", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetCapInitializeMediumResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        bool GetCapInitializeMedium();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetCapMediumIsAvailable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetCapMediumIsAvailableResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        bool GetCapMediumIsAvailable();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetCapPrintContent", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetCapPrintContentResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        bool GetCapPrintContent();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetCapPrintContentFile", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetCapPrintContentFileResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        bool GetCapPrintContentFile();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetCapRetrieveCurrentMarker", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetCapRetrieveCurrentMarkerResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        bool GetCapRetrieveCurrentMarker();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetCapRetrieveMarker", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetCapRetrieveMarkerResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        bool GetCapRetrieveMarker();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetCapRetrieveMarkerByDateTime", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetCapRetrieveMarkerByDateTimeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        bool GetCapRetrieveMarkerByDateTime();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetCapRetrieveMarkersDateTime", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetCapRetrieveMarkersDateTimeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        bool GetCapRetrieveMarkersDateTime();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetCapStation", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetCapStationResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        int GetCapStation();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetCapStorageEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetCapStorageEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        bool GetCapStorageEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetCapSuspendPrintContent", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetCapSuspendPrintContentResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        bool GetCapSuspendPrintContent();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetCapSuspendQueryContent", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetCapSuspendQueryContentResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        bool GetCapSuspendQueryContent();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetCapWaterMark", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetCapWaterMarkResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        bool GetCapWaterMark();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetFlagWhenIdle", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetFlagWhenIdleResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        bool GetFlagWhenIdle();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/SetFlagWhenIdle", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/SetFlagWhenIdleResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        void SetFlagWhenIdle(bool FlagWhenIdle);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetMediumFreeSpace", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetMediumFreeSpaceResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        decimal GetMediumFreeSpace();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetMediumID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetMediumIDResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        string GetMediumID();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetMediumIsAvailable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetMediumIsAvailableResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        bool GetMediumIsAvailable();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetMediumSize", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetMediumSizeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        decimal GetMediumSize();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetStation", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetStationResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        int GetStation();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/SetStation", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/SetStationResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        void SetStation(int Station);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetStorageEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetStorageEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        bool GetStorageEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/SetStorageEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/SetStorageEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        void SetStorageEnabled(bool StorageEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetSuspended", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetSuspendedResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        bool GetSuspended();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetWaterMark", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/GetWaterMarkResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        bool GetWaterMark();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/SetWaterMark", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/SetWaterMarkResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        void SetWaterMark(bool WaterMark);

        //
        // Common Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/Open", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/OpenResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        void Open(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/Close", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/CloseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        void Close(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/Claim", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/ClaimResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        void Claim(int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/Release", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/ReleaseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        void Release();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/CheckHealth", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/CheckHealthResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        void CheckHealth(HealthCheckLevel Level);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/ClearInput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/ClearInputResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        void ClearInput();

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/ClearInputProperties", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/ClearInputPropertiesResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        // void ClearInputProperties();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/ClearOutput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/ClearOutputResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        void ClearOutput();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/DirectIO", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/DirectIOResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        DirectIOData DirectIO(int Command, int Data, object Obj);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/CompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/CompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        CompareFirmwareResult CompareFirmwareVersion(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/ResetStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/ResetStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        void ResetStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/RetrieveStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/RetrieveStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        string RetrieveStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        void UpdateFirmware(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        void UpdateStatistics(StatisticList StatisticsBuffer);

        //
        // Specific Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/AddMarker", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/AddMarkerResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        void AddMarker(string Marker);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/CancelPrintContent", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/CancelPrintContentResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        void CancelPrintContent();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/CancelQueryContent", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/CancelQueryContentResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        void CancelQueryContent();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/EraseMedium", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/EraseMediumResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        void EraseMedium();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/InitializeMedium", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/InitializeMediumResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        void InitializeMedium(string MediumID);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/PrintContent", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/PrintContentResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        void PrintContent(string FromMarker, string ToMarker);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/PrintContentFile", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/PrintContentFileResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        void PrintContentFile(string FileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/QueryContent", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/QueryContentResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        void QueryContent(string FileName, string FromMarker, string ToMarker);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/ResumePrintContent", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/ResumePrintContentResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        void ResumePrintContent();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/ResumeQueryContent", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/ResumeQueryContentResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        void ResumeQueryContent();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/RetrieveCurrentMarker", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/RetrieveCurrentMarkerResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        string RetrieveCurrentMarker(MarkerType MarkerType);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/RetrieveMarker", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/RetrieveMarkerResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        string RetrieveMarker(MarkerType MarkerType, int SessionNumber, int DocumentNumber);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/RetrieveMarkerByDateTime", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/RetrieveMarkerByDateTimeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        string RetrieveMarkerByDateTime(MarkerType MarkerType, string DateTime, string MarkerNumber);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/RetrieveMarkersDateTime", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/RetrieveMarkersDateTimeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        string RetrieveMarkersDateTime(string Marker);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/SuspendPrintContent", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/SuspendPrintContentResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        void SuspendPrintContent();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/SuspendQueryContent", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/SuspendQueryContentResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/UposException", Name = "UposException")]
        void SuspendQueryContent();

    }

    //
    // Common Data Types
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/")]
    public class DirectIOData
    {
        [DataMember]
        public int Data { get; set; }
        [DataMember]
        public object Obj { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/")]
    public class UposException
    {
        [DataMember]
        public ErrorCode ErrorCode { get; set; }
        [DataMember]
        public int ErrorCodeExtended { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/")]
    public class UposVersion
    {
        [DataMember]
        public int Major { get; set; }
        [DataMember]
        public int Minor { get; set; }
        [DataMember]
        public int Build { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/")]
    public class Statistic
    {
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public string Value { get; set; }
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/", ItemName = "Statistic")]
    public class StatisticList : List<Statistic>
    {
    }

    //
    // Common Enumerations
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/")]
    public enum CompareFirmwareResult
    {
        [EnumMember]
        Different,
        [EnumMember]
        Newer,
        [EnumMember]
        Older,
        [EnumMember]
        Same,
        [EnumMember]
        Unknown,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/")]
    public enum ControlState
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Closed,
        [EnumMember]
        Error,
        [EnumMember]
        Idle,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/")]
    public enum ErrorCode
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Claimed,
        [EnumMember]
        Closed,
        [EnumMember]
        Deprecated,
        [EnumMember]
        Disabled,
        [EnumMember]
        Exists,
        [EnumMember]
        Extended,
        [EnumMember]
        Failure,
        [EnumMember]
        Illegal,
        [EnumMember]
        NoExist,
        [EnumMember]
        NoHardware,
        [EnumMember]
        NoService,
        [EnumMember]
        NotClaimed,
        [EnumMember]
        Offline,
        [EnumMember]
        Success,
        [EnumMember]
        Timeout,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/")]
    public enum HealthCheckLevel
    {
        [EnumMember]
        External,
        [EnumMember]
        Interactive,
        [EnumMember]
        Internal,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/")]
    public enum PowerNotification
    {
        [EnumMember]
        Disabled,
        [EnumMember]
        Enabled,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/")]
    public enum PowerReporting
    {
        [EnumMember]
        Advanced,
        [EnumMember]
        None,
        [EnumMember]
        Standard,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/")]
    public enum PowerState
    {
        [EnumMember]
        Off,
        [EnumMember]
        Offline,
        [EnumMember]
        OffOffline,
        [EnumMember]
        Online,
        [EnumMember]
        Unknown,
    }

    /*
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/")]
    public enum StatisticCategories
    {
        [EnumMember]
        All,
        [EnumMember]
        Manufacturer,
        [EnumMember]
        Upos,
    }
    */
    public class StatisticCategories
    {
        public const string All = "";
        public const string Manufacturer = "M_";
        public const string Upos = "U_";
    }

    //
    // Specific Data Types
    //

    //
    // Specific Enumerations
    //

    /*
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/")]
    public enum ElectronicJournalStations
    {
        [EnumMember]
        Journal,
        [EnumMember]
        Receipt,
        [EnumMember]
        Slip,
    }
    */
    public class ElectronicJournalStations
    {
        public const int Journal = 4;
        public const int Receipt = 1;
        public const int Slip = 2;
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ElectronicJournal/")]
    public enum MarkerType
    {
        [EnumMember]
        Document,
        [EnumMember]
        Head,
        [EnumMember]
        SessionBegin,
        [EnumMember]
        SessionEnd,
        [EnumMember]
        Tail,
    }

    //
    // Constants
    //

    /*
    public class Constants
    {
        public const int ExtendedErrorCorruptedMedium = 205;
        public const int ExtendedErrorExisting = 201;
        public const int ExtendedErrorFirmwareBadFile = 281;
        public const int ExtendedErrorMediumFull = 202;
        public const int ExtendedErrorMultipleMarker = 203;
        public const int ExtendedErrorMultipleMarkers = 208;
        public const int ExtendedErrorNotEnoughSpace = 207;
        public const int ExtendedErrorStatistics = 280;
        public const int ExtendedErrorStatisticsDependency = 282;
        public const int ExtendedErrorUninitializedMedium = 204;
        public const int ExtendedErrorUnknownDataFormat = 206;
        public const string StatisticCommunicationErrorCount = "CommunicationErrorCount";
        public const string StatisticDeviceCategory = "DeviceCategory";
        public const string StatisticEraseCount = "EraseCount";
        public const string StatisticFailedWriteCount = "FailedWriteCount";
        public const string StatisticFirmwareRevision = "FirmwareRevision";
        public const string StatisticHoursPoweredCount = "HoursPoweredCount";
        public const string StatisticInstallationDate = "InstallationDate";
        public const string StatisticInterface = "Interface";
        public const string StatisticManufactureDate = "ManufactureDate";
        public const string StatisticManufacturerName = "ManufacturerName";
        public const string StatisticMechanicalRevision = "MechanicalRevision";
        public const string StatisticMediumFreeSpace = "MediumFreeSpace";
        public const string StatisticMediumRemovedCount = "MediumRemovedCount";
        public const string StatisticMediumSize = "MediumSize";
        public const string StatisticModelName = "ModelName";
        public const string StatisticSerialNumber = "SerialNumber";
        public const string StatisticUnifiedPOSVersion = "UnifiedPOSVersion";
        public const string StatisticWriteCount = "WriteCount";
        public const int StatusIdle = 6;
        public const int StatusMediumFull = 2;
        public const int StatusMediumInserted = 4;
        public const int StatusMediumNearFull = 1;
        public const int StatusMediumRemoved = 3;
        public const int StatusMediumSuspended = 5;
        public const int StatusPowerOff = 2002;
        public const int StatusPowerOffline = 2003;
        public const int StatusPowerOffOffline = 2004;
        public const int StatusPowerOnline = 2001;
        public const int StatusUpdateFirmwareComplete = 2200;
        public const int StatusUpdateFirmwareCompleteDeviceNotRestored = 2205;
        public const int StatusUpdateFirmwareFailedDeviceNeedsFirmware = 2203;
        public const int StatusUpdateFirmwareFailedDeviceOk = 2201;
        public const int StatusUpdateFirmwareFailedDeviceUnknown = 2204;
        public const int StatusUpdateFirmwareFailedDeviceUnrecoverable = 2202;
        public const int StatusUpdateFirmwareProgress = 2100;
        public const int WaitForever = -1;
    }
    */

    public class ExtendedError
    {
        public const int CorruptedMedium = 205;
        public const int Existing = 201;
        public const int FirmwareBadFile = 281;
        public const int MediumFull = 202;
        public const int MultipleMarker = 203;
        public const int MultipleMarkers = 208;
        public const int NotEnoughSpace = 207;
        public const int Statistics = 280;
        public const int StatisticsDependency = 282;
        public const int UninitializedMedium = 204;
        public const int UnknownDataFormat = 206;
    }

    public class StatisticProperties
    {
        public const string CommunicationErrorCount = "CommunicationErrorCount";
        public const string DeviceCategory = "DeviceCategory";
        public const string EraseCount = "EraseCount";
        public const string FailedWriteCount = "FailedWriteCount";
        public const string FirmwareRevision = "FirmwareRevision";
        public const string HoursPoweredCount = "HoursPoweredCount";
        public const string InstallationDate = "InstallationDate";
        public const string Interface = "Interface";
        public const string ManufactureDate = "ManufactureDate";
        public const string ManufacturerName = "ManufacturerName";
        public const string MechanicalRevision = "MechanicalRevision";
        public const string MediumFreeSpace = "MediumFreeSpace";
        public const string MediumRemovedCount = "MediumRemovedCount";
        public const string MediumSize = "MediumSize";
        public const string ModelName = "ModelName";
        public const string SerialNumber = "SerialNumber";
        public const string UnifiedPOSVersion = "UnifiedPOSVersion";
        public const string WriteCount = "WriteCount";
    }

    public class Wait
    {
        public const int Forever = -1;
    }
}
