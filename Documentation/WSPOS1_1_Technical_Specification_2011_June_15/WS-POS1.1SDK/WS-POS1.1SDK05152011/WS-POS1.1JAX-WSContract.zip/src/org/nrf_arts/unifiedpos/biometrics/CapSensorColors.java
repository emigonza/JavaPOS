/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.nrf_arts.unifiedpos.biometrics;

/**
 *
 * @author 
 */
public class CapSensorColors {
        public static final int NONE = 0;
        public static final int MONO = 1;
        public static final int GRAYSCALE = 2;
        public static final int COLOR16 = 4;
        public static final int COLOR256 = 8;
        public static final int FULL = 16;

}
