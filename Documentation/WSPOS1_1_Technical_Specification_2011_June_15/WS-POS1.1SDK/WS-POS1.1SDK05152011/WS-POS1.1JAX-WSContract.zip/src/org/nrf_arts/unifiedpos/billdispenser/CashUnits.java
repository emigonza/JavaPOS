
package org.nrf_arts.unifiedpos.billdispenser;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for CashUnits complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CashUnits">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Bills" type="{http://www.nrf-arts.org/UnifiedPOS/BillDispenser/}BillList" minOccurs="0"/>
 *         &lt;element name="Coins" type="{http://www.nrf-arts.org/UnifiedPOS/BillDispenser/}CoinList" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CashUnits", propOrder = {
    "bills",
    "coins"
})
public class CashUnits {

    @XmlElement(name = "Bills", nillable = true)
    protected BillList bills;
    @XmlElement(name = "Coins", nillable = true)
    protected CoinList coins;

    /**
     * Gets the value of the bills property.
     * 
     * @return
     *     possible object is
     *     {@link BillList }
     *     
     */
    public BillList getBills() {
        return bills;
    }

    /**
     * Sets the value of the bills property.
     * 
     * @param value
     *     allowed object is
     *     {@link BillList }
     *     
     */
    public void setBills(BillList value) {
        this.bills = value;
    }

    /**
     * Gets the value of the coins property.
     * 
     * @return
     *     possible object is
     *     {@link CoinList }
     *     
     */
    public CoinList getCoins() {
        return coins;
    }

    /**
     * Sets the value of the coins property.
     * 
     * @param value
     *     allowed object is
     *     {@link CoinList }
     *     
     */
    public void setCoins(CoinList value) {
        this.coins = value;
    }

}
