/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package wspos;

import java.net.URL;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import jpos.events.DirectIOEvent;
import jpos.events.StatusUpdateEvent;
import org.nrf_arts.unifiedpos.linedisplay.*;
import javax.jws.WebService;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.namespace.QName;
import javax.xml.ws.Service;

/**
 *
 * @author hideon
 */
@WebService(serviceName = "LineDisplayService", endpointInterface = "org.nrf_arts.unifiedpos.linedisplay.LineDisplay", targetNamespace = "http://www.nrf-arts.org/UnifiedPOS/LineDisplay/")
public class LineDisplayService implements LineDisplay, jpos.events.DirectIOListener, jpos.events.StatusUpdateListener {

    //
    // LineDisplay Enumration Converter
    //

    private static HashMap<Enum, Integer> jposConst;
    private static HashMap<Integer, PowerReporting> powerReporting;
    private static HashMap<Integer, PowerNotification> powerNotification;
    private static HashMap<Integer, PowerState> powerState;
    private static HashMap<Integer, ControlState> controlState;
    private static HashMap<Integer, HealthCheckLevel> healthCheckLevel;
    private static HashMap<Integer, CompareFirmwareResult> compareFirmwareResult;
    private static HashMap<Integer, ErrorCode> errorCode;
    private static HashMap<Integer, DisplayBlink> displayBlink;
    private static HashMap<Integer, CharacterSetCapability> characterSetCapability;
    private static HashMap<Integer, DisplayReadBack> displayReadBack;
    private static HashMap<Integer, DisplayReverse> displayReverse;
    private static HashMap<Integer, DisplayMarqueeFormat> displayMarqueeFormat;
    private static HashMap<Integer, DisplayMarqueeType> displayMarqueeType;
    private static HashMap<Integer, DisplayTextMode> displayTextMode;
    private static HashMap<Integer, DisplayScrollText> displayScrollText;
    private static HashMap<Integer, DisplaySetDescriptor> displaySetDescriptor;

    static {
        jposConst = new HashMap<Enum, Integer>();
        jposConst.put(PowerReporting.ADVANCED, jpos.LineDisplay.JPOS_PR_ADVANCED);
        jposConst.put(PowerReporting.NONE, jpos.LineDisplay.JPOS_PR_NONE);
        jposConst.put(PowerReporting.STANDARD, jpos.LineDisplay.JPOS_PR_STANDARD);
        jposConst.put(PowerNotification.DISABLED, jpos.LineDisplay.JPOS_PN_DISABLED);
        jposConst.put(PowerNotification.ENABLED, jpos.LineDisplay.JPOS_PN_ENABLED);
        jposConst.put(PowerState.OFF, jpos.LineDisplay.JPOS_PS_OFF);
        jposConst.put(PowerState.OFFLINE, jpos.LineDisplay.JPOS_PS_OFFLINE);
        jposConst.put(PowerState.OFF_OFFLINE, jpos.LineDisplay.JPOS_PS_OFF_OFFLINE);
        jposConst.put(PowerState.ONLINE, jpos.LineDisplay.JPOS_PS_ONLINE);
        jposConst.put(PowerState.UNKNOWN, jpos.LineDisplay.JPOS_PS_UNKNOWN);
        jposConst.put(ControlState.BUSY, jpos.LineDisplay.JPOS_S_BUSY);
        jposConst.put(ControlState.CLOSED, jpos.LineDisplay.JPOS_S_CLOSED);
        jposConst.put(ControlState.ERROR, jpos.LineDisplay.JPOS_S_ERROR);
        jposConst.put(ControlState.IDLE, jpos.LineDisplay.JPOS_S_IDLE);
        jposConst.put(HealthCheckLevel.EXTERNAL, jpos.LineDisplay.JPOS_CH_EXTERNAL);
        jposConst.put(HealthCheckLevel.INTERACTIVE, jpos.LineDisplay.JPOS_CH_INTERACTIVE);
        jposConst.put(HealthCheckLevel.INTERNAL, jpos.LineDisplay.JPOS_CH_INTERNAL);
        jposConst.put(CompareFirmwareResult.DIFFERENT, jpos.LineDisplay.JPOS_CFV_FIRMWARE_DIFFERENT);
        jposConst.put(CompareFirmwareResult.NEWER, jpos.LineDisplay.JPOS_CFV_FIRMWARE_NEWER);
        jposConst.put(CompareFirmwareResult.OLDER, jpos.LineDisplay.JPOS_CFV_FIRMWARE_OLDER);
        jposConst.put(CompareFirmwareResult.SAME, jpos.LineDisplay.JPOS_CFV_FIRMWARE_SAME);
        jposConst.put(CompareFirmwareResult.UNKNOWN, jpos.LineDisplay.JPOS_CFV_FIRMWARE_UNKNOWN);
        jposConst.put(ErrorCode.BUSY, jpos.LineDisplay.JPOS_E_BUSY);
        jposConst.put(ErrorCode.CLAIMED, jpos.LineDisplay.JPOS_E_CLAIMED);
        jposConst.put(ErrorCode.CLOSED, jpos.LineDisplay.JPOS_E_CLOSED);
        jposConst.put(ErrorCode.DEPRECATED, jpos.LineDisplay.JPOS_E_DEPRECATED);
        jposConst.put(ErrorCode.DISABLED, jpos.LineDisplay.JPOS_E_DISABLED);
        jposConst.put(ErrorCode.EXISTS, jpos.LineDisplay.JPOS_E_EXISTS);
        jposConst.put(ErrorCode.EXTENDED, jpos.LineDisplay.JPOS_E_EXTENDED);
        jposConst.put(ErrorCode.FAILURE, jpos.LineDisplay.JPOS_E_FAILURE);
        jposConst.put(ErrorCode.ILLEGAL, jpos.LineDisplay.JPOS_E_ILLEGAL);
        jposConst.put(ErrorCode.NO_EXIST, jpos.LineDisplay.JPOS_E_NOEXIST);
        jposConst.put(ErrorCode.NO_HARDWARE, jpos.LineDisplay.JPOS_E_NOHARDWARE);
        jposConst.put(ErrorCode.NO_SERVICE, jpos.LineDisplay.JPOS_E_NOSERVICE);
        jposConst.put(ErrorCode.NOT_CLAIMED, jpos.LineDisplay.JPOS_E_NOTCLAIMED);
        jposConst.put(ErrorCode.OFFLINE, jpos.LineDisplay.JPOS_E_OFFLINE);
        jposConst.put(ErrorCode.SUCCESS, 0);
        jposConst.put(ErrorCode.TIMEOUT, jpos.LineDisplay.JPOS_E_TIMEOUT);
        jposConst.put(DisplayBlink.ALL, jpos.LineDisplayConst.DISP_CB_BLINKALL);
        jposConst.put(DisplayBlink.EACH, jpos.LineDisplayConst.DISP_CB_BLINKEACH);
        jposConst.put(DisplayBlink.NONE, jpos.LineDisplayConst.DISP_CB_NOBLINK);
        jposConst.put(CharacterSetCapability.ALPHA, jpos.LineDisplayConst.DISP_CCS_ALPHA);
        jposConst.put(CharacterSetCapability.ASCII, jpos.LineDisplayConst.DISP_CCS_ASCII);
        jposConst.put(CharacterSetCapability.KANA, jpos.LineDisplayConst.DISP_CCS_KANA);
        jposConst.put(CharacterSetCapability.KANJI, jpos.LineDisplayConst.DISP_CCS_KANJI);
        jposConst.put(CharacterSetCapability.NUMERIC, jpos.LineDisplayConst.DISP_CCS_NUMERIC);
        jposConst.put(CharacterSetCapability.UNICODE, jpos.LineDisplayConst.DISP_CCS_UNICODE);
        jposConst.put(DisplayReadBack.NONE, jpos.LineDisplayConst.DISP_CRB_NONE);
        jposConst.put(DisplayReadBack.SINGLE, jpos.LineDisplayConst.DISP_CRB_SINGLE);
        jposConst.put(DisplayReverse.ALL, jpos.LineDisplayConst.DISP_CR_REVERSEALL);
        jposConst.put(DisplayReverse.EACH, jpos.LineDisplayConst.DISP_CR_REVERSEEACH);
        jposConst.put(DisplayReverse.NONE, jpos.LineDisplayConst.DISP_CR_NONE);
        jposConst.put(DisplayMarqueeFormat.PLACE, jpos.LineDisplayConst.DISP_MF_PLACE);
        jposConst.put(DisplayMarqueeFormat.WALK, jpos.LineDisplayConst.DISP_MF_WALK);
        jposConst.put(DisplayMarqueeType.DOWN, jpos.LineDisplayConst.DISP_MT_DOWN);
        jposConst.put(DisplayMarqueeType.INIT, jpos.LineDisplayConst.DISP_MT_INIT);
        jposConst.put(DisplayMarqueeType.LEFT, jpos.LineDisplayConst.DISP_MT_LEFT);
        jposConst.put(DisplayMarqueeType.NONE, jpos.LineDisplayConst.DISP_MT_NONE);
        jposConst.put(DisplayMarqueeType.RIGHT, jpos.LineDisplayConst.DISP_MT_RIGHT);
        jposConst.put(DisplayMarqueeType.UP, jpos.LineDisplayConst.DISP_MT_UP);
        jposConst.put(DisplayTextMode.BLINK, jpos.LineDisplayConst.DISP_DT_BLINK);
        jposConst.put(DisplayTextMode.BLINK_REVERSE, jpos.LineDisplayConst.DISP_DT_BLINK_REVERSE);
        jposConst.put(DisplayTextMode.NORMAL, jpos.LineDisplayConst.DISP_DT_NORMAL);
        jposConst.put(DisplayTextMode.REVERSE, jpos.LineDisplayConst.DISP_DT_REVERSE);
        jposConst.put(DisplayScrollText.DOWN, jpos.LineDisplayConst.DISP_ST_DOWN);
        jposConst.put(DisplayScrollText.LEFT, jpos.LineDisplayConst.DISP_ST_LEFT);
        jposConst.put(DisplayScrollText.RIGHT, jpos.LineDisplayConst.DISP_ST_RIGHT);
        jposConst.put(DisplayScrollText.UP, jpos.LineDisplayConst.DISP_ST_UP);
        jposConst.put(DisplaySetDescriptor.BLINK, jpos.LineDisplayConst.DISP_SD_BLINK);
        jposConst.put(DisplaySetDescriptor.OFF, jpos.LineDisplayConst.DISP_SD_OFF);
        jposConst.put(DisplaySetDescriptor.ON, jpos.LineDisplayConst.DISP_SD_ON);

        powerReporting = new HashMap<Integer, PowerReporting>();
        powerReporting.put(jpos.LineDisplay.JPOS_PR_ADVANCED, PowerReporting.ADVANCED);
        powerReporting.put(jpos.LineDisplay.JPOS_PR_NONE, PowerReporting.NONE);
        powerReporting.put(jpos.LineDisplay.JPOS_PR_STANDARD, PowerReporting.STANDARD);

        powerNotification = new HashMap<Integer, PowerNotification>();
        powerNotification.put(jpos.LineDisplay.JPOS_PN_DISABLED, PowerNotification.DISABLED);
        powerNotification.put(jpos.LineDisplay.JPOS_PN_ENABLED, PowerNotification.ENABLED);

        powerState = new HashMap<Integer, PowerState>();
        powerState.put(jpos.LineDisplay.JPOS_PS_OFF, PowerState.OFF);
        powerState.put(jpos.LineDisplay.JPOS_PS_OFFLINE, PowerState.OFFLINE);
        powerState.put(jpos.LineDisplay.JPOS_PS_OFF_OFFLINE, PowerState.OFF_OFFLINE);
        powerState.put(jpos.LineDisplay.JPOS_PS_ONLINE, PowerState.ONLINE);
        powerState.put(jpos.LineDisplay.JPOS_PS_UNKNOWN, PowerState.UNKNOWN);

        controlState = new HashMap<Integer, ControlState>();
        controlState.put(jpos.LineDisplay.JPOS_S_BUSY, ControlState.BUSY);
        controlState.put(jpos.LineDisplay.JPOS_S_CLOSED, ControlState.CLOSED);
        controlState.put(jpos.LineDisplay.JPOS_S_ERROR, ControlState.ERROR);
        controlState.put(jpos.LineDisplay.JPOS_S_IDLE, ControlState.IDLE);

        healthCheckLevel = new HashMap<Integer, HealthCheckLevel>();
        healthCheckLevel.put(jpos.LineDisplay.JPOS_CH_EXTERNAL, HealthCheckLevel.EXTERNAL);
        healthCheckLevel.put(jpos.LineDisplay.JPOS_CH_INTERACTIVE, HealthCheckLevel.INTERACTIVE);
        healthCheckLevel.put(jpos.LineDisplay.JPOS_CH_INTERNAL, HealthCheckLevel.INTERNAL);

        compareFirmwareResult = new HashMap<Integer, CompareFirmwareResult>();
        compareFirmwareResult.put(jpos.LineDisplay.JPOS_CFV_FIRMWARE_DIFFERENT, CompareFirmwareResult.DIFFERENT);
        compareFirmwareResult.put(jpos.LineDisplay.JPOS_CFV_FIRMWARE_NEWER, CompareFirmwareResult.NEWER);
        compareFirmwareResult.put(jpos.LineDisplay.JPOS_CFV_FIRMWARE_OLDER, CompareFirmwareResult.OLDER);
        compareFirmwareResult.put(jpos.LineDisplay.JPOS_CFV_FIRMWARE_SAME, CompareFirmwareResult.SAME);
        compareFirmwareResult.put(jpos.LineDisplay.JPOS_CFV_FIRMWARE_UNKNOWN, CompareFirmwareResult.UNKNOWN);

        errorCode = new HashMap<Integer, ErrorCode>();
        errorCode.put(jpos.LineDisplay.JPOS_E_BUSY, ErrorCode.BUSY);
        errorCode.put(jpos.LineDisplay.JPOS_E_CLAIMED, ErrorCode.CLAIMED);
        errorCode.put(jpos.LineDisplay.JPOS_E_CLOSED, ErrorCode.CLOSED);
        errorCode.put(jpos.LineDisplay.JPOS_E_DEPRECATED, ErrorCode.DEPRECATED);
        errorCode.put(jpos.LineDisplay.JPOS_E_DISABLED, ErrorCode.DISABLED);
        errorCode.put(jpos.LineDisplay.JPOS_E_EXISTS, ErrorCode.EXISTS);
        errorCode.put(jpos.LineDisplay.JPOS_E_EXTENDED, ErrorCode.EXTENDED);
        errorCode.put(jpos.LineDisplay.JPOS_E_FAILURE, ErrorCode.FAILURE);
        errorCode.put(jpos.LineDisplay.JPOS_E_ILLEGAL, ErrorCode.ILLEGAL);
        errorCode.put(jpos.LineDisplay.JPOS_E_NOEXIST, ErrorCode.NO_EXIST);
        errorCode.put(jpos.LineDisplay.JPOS_E_NOHARDWARE, ErrorCode.NO_HARDWARE);
        errorCode.put(jpos.LineDisplay.JPOS_E_NOSERVICE, ErrorCode.NO_SERVICE);
        errorCode.put(jpos.LineDisplay.JPOS_E_NOTCLAIMED, ErrorCode.NOT_CLAIMED);
        errorCode.put(jpos.LineDisplay.JPOS_E_OFFLINE, ErrorCode.OFFLINE);
        errorCode.put(0, ErrorCode.SUCCESS);
        errorCode.put(jpos.LineDisplay.JPOS_E_TIMEOUT, ErrorCode.TIMEOUT);

        displayBlink = new HashMap<Integer, DisplayBlink>();
        displayBlink.put(jpos.LineDisplayConst.DISP_CB_BLINKALL, DisplayBlink.ALL);
        displayBlink.put(jpos.LineDisplayConst.DISP_CB_BLINKEACH, DisplayBlink.EACH);
        displayBlink.put(jpos.LineDisplayConst.DISP_CB_NOBLINK, DisplayBlink.NONE);

        characterSetCapability = new HashMap<Integer, CharacterSetCapability>();
        characterSetCapability.put(jpos.LineDisplayConst.DISP_CCS_ALPHA, CharacterSetCapability.ALPHA);
        characterSetCapability.put(jpos.LineDisplayConst.DISP_CCS_ASCII, CharacterSetCapability.ASCII);
        characterSetCapability.put(jpos.LineDisplayConst.DISP_CCS_KANA, CharacterSetCapability.KANA);
        characterSetCapability.put(jpos.LineDisplayConst.DISP_CCS_KANJI, CharacterSetCapability.KANJI);
        characterSetCapability.put(jpos.LineDisplayConst.DISP_CCS_NUMERIC, CharacterSetCapability.NUMERIC);
        characterSetCapability.put( jpos.LineDisplayConst.DISP_CCS_UNICODE, CharacterSetCapability.UNICODE);

        displayReadBack = new HashMap<Integer, DisplayReadBack>();
        displayReadBack.put(jpos.LineDisplayConst.DISP_CRB_NONE, DisplayReadBack.NONE);
        displayReadBack.put(jpos.LineDisplayConst.DISP_CRB_SINGLE, DisplayReadBack.SINGLE);

        displayReverse = new HashMap<Integer, DisplayReverse>();
        displayReverse.put(jpos.LineDisplayConst.DISP_CR_REVERSEALL, DisplayReverse.ALL);
        displayReverse.put(jpos.LineDisplayConst.DISP_CR_REVERSEEACH, DisplayReverse.EACH);
        displayReverse.put(jpos.LineDisplayConst.DISP_CR_NONE, DisplayReverse.NONE);

        displayMarqueeFormat = new HashMap<Integer, DisplayMarqueeFormat>();
        displayMarqueeFormat.put(jpos.LineDisplayConst.DISP_MF_PLACE, DisplayMarqueeFormat.PLACE);
        displayMarqueeFormat.put(jpos.LineDisplayConst.DISP_MF_WALK, DisplayMarqueeFormat.WALK);

        displayMarqueeType = new HashMap<Integer, DisplayMarqueeType>();
        displayMarqueeType.put(jpos.LineDisplayConst.DISP_MT_DOWN, DisplayMarqueeType.DOWN);
        displayMarqueeType.put(jpos.LineDisplayConst.DISP_MT_INIT, DisplayMarqueeType.INIT);
        displayMarqueeType.put(jpos.LineDisplayConst.DISP_MT_LEFT, DisplayMarqueeType.LEFT);
        displayMarqueeType.put(jpos.LineDisplayConst.DISP_MT_NONE, DisplayMarqueeType.NONE);
        displayMarqueeType.put(jpos.LineDisplayConst.DISP_MT_RIGHT, DisplayMarqueeType.RIGHT);
        displayMarqueeType.put(jpos.LineDisplayConst.DISP_MT_UP, DisplayMarqueeType.UP);

        displayTextMode = new HashMap<Integer, DisplayTextMode>();
        displayTextMode.put(jpos.LineDisplayConst.DISP_DT_BLINK, DisplayTextMode.BLINK);
        displayTextMode.put(jpos.LineDisplayConst.DISP_DT_BLINK_REVERSE, DisplayTextMode.BLINK_REVERSE);
        displayTextMode.put(jpos.LineDisplayConst.DISP_DT_NORMAL, DisplayTextMode.NORMAL);
        displayTextMode.put(jpos.LineDisplayConst.DISP_DT_REVERSE, DisplayTextMode.REVERSE);

        displayScrollText = new HashMap<Integer, DisplayScrollText>();
        displayScrollText.put(jpos.LineDisplayConst.DISP_ST_DOWN, DisplayScrollText.DOWN);
        displayScrollText.put(jpos.LineDisplayConst.DISP_ST_LEFT, DisplayScrollText.LEFT);
        displayScrollText.put(jpos.LineDisplayConst.DISP_ST_RIGHT, DisplayScrollText.RIGHT);
        displayScrollText.put(jpos.LineDisplayConst.DISP_ST_UP, DisplayScrollText.UP);

        displaySetDescriptor = new HashMap<Integer, DisplaySetDescriptor>();
        displaySetDescriptor.put(jpos.LineDisplayConst.DISP_SD_BLINK, DisplaySetDescriptor.BLINK);
        displaySetDescriptor.put(jpos.LineDisplayConst.DISP_SD_OFF, DisplaySetDescriptor.OFF);
        displaySetDescriptor.put(jpos.LineDisplayConst.DISP_SD_ON, DisplaySetDescriptor.ON);
    }

    private String deviceName;
    private UposVersion deviceControlVersion;
    private org.nrf_arts.unifiedpos.linedisplayevents.LineDisplayEvent deviceEvent;
    private jpos.LineDisplay device = new jpos.LineDisplay();
    private DatatypeFactory datatypeFactory;
    private Pattern pattern = Pattern.compile("\\\\u([0-9a-fA-F]{4})|(\\\\\\\\)|(\\\\n)|(\\\\r)|(\\\\t)|(\\\\f)|(\\\\b)");

    private String processEscapeSequence(String data) {
        Matcher m = pattern.matcher(data);
        StringBuffer s = new StringBuffer();
        while (m.find()) {
            if (m.group(1) != null) {
                m.appendReplacement(s, String.valueOf((char)Integer.parseInt(m.group(1), 16)));
            }
            else if (m.group(2) != null) {
                m.appendReplacement(s, "\\\\");
            }
            else if (m.group(3) != null) {
                m.appendReplacement(s, "\n");
            }
            else if (m.group(4) != null) {
                m.appendReplacement(s, "\r");
            }
            else if (m.group(5) != null) {
                m.appendReplacement(s, "\t");
            }
            else if (m.group(6) != null) {
                m.appendReplacement(s, "\f");
            }
            else if (m.group(7) != null) {
                m.appendReplacement(s, "\b");
            }
        }
        m.appendTail(s);
        return s.toString();
    }

    public LineDisplayService(String logicalDeviceName) {
        deviceName = logicalDeviceName;
        deviceControlVersion = new UposVersion();
        deviceControlVersion.setMajor(1);
        deviceControlVersion.setMinor(13);
        deviceControlVersion.setBuild(1);
        try {
            datatypeFactory = DatatypeFactory.newInstance();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    //
    // LineDisplay Member
    //

    public void checkHealth(HealthCheckLevel level) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.checkHealth(jposConst.get(level));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void claim(Integer timeout) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.claim(timeout);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void clearDescriptors() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.clearDescriptors();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void clearText() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.clearText();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void close(String endpointAddress) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            if (deviceEvent != null)
            {
                device.removeDirectIOListener(this);
                device.removeStatusUpdateListener(this);
                deviceEvent = null;
            }
            device.close();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public CompareFirmwareResult compareFirmwareVersion(String firmwareFileName) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            int[] param = new int[1];
            device.compareFirmwareVersion(firmwareFileName, param);
            return compareFirmwareResult.get(param[0]);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void createWindow(Integer viewportRow, Integer viewportColumn, Integer viewportHeight, Integer viewportWidth, Integer windowHeight, Integer windowWidth) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.createWindow(viewportRow, viewportColumn, viewportHeight, viewportWidth, windowHeight, windowWidth);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void defineGlyph(Integer glyphCode, byte[] glyph) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.defineGlyph(glyphCode, glyph);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void destroyWindow() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.destroyWindow();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public DirectIOData directIO(Integer command, Integer data, Object obj) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            DirectIOData res = new DirectIOData();
            int[] param = new int[] { data };
            device.directIO(command, param, obj);
            res.setData(param[0]);
            res.setObj(obj);
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void displayBitmap(String fileName, Integer width, Integer alignmentX, Integer alignmentY) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.displayBitmap(fileName, width, alignmentX, alignmentY);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void displayText(String data, DisplayTextMode attribute) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.displayText(processEscapeSequence(data), jposConst.get(attribute));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void displayTextAt(Integer row, Integer column, String data, DisplayTextMode attribute) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.displayTextAt(row, column, processEscapeSequence(data), jposConst.get(attribute));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getBlinkRate() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getBlinkRate();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapBitmap() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapBitmap();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public DisplayBlink getCapBlink() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return displayBlink.get(device.getCapBlink());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapBlinkRate() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapBlinkRate();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapBrightness() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapBrightness();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public CharacterSetCapability getCapCharacterSet() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return characterSetCapability.get(device.getCapCharacterSet());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapCompareFirmwareVersion() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapCompareFirmwareVersion();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getCapCursorType() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCursorType();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapCustomGlyph() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapCustomGlyph();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapDescriptors() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapDescriptors();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapHMarquee() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapHMarquee();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapICharWait() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapICharWait();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapMapCharacterSet() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapMapCharacterSet();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public PowerReporting getCapPowerReporting() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return powerReporting.get(device.getCapPowerReporting());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public DisplayReadBack getCapReadBack() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return displayReadBack.get(device.getCapReadBack());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public DisplayReverse getCapReverse() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return displayReverse.get(device.getCapReverse());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapScreenMode() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapScreenMode();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapStatisticsReporting() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapStatisticsReporting();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapUpdateFirmware() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapUpdateFirmware();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapUpdateStatistics() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapUpdateStatistics();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapVMarquee() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapVMarquee();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getCharacterSet() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCharacterSet();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public CharacterSetList getCharacterSetList() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            CharacterSetList res = new CharacterSetList();
            List<Integer> list = res.getCharacterSet();
            for (String s : device.getCharacterSetList().split(",")) {
                list.add(Integer.valueOf(s));
            }
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getCheckHealthText() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCheckHealthText();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getClaimed() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getClaimed();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getColumns() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getColumns();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getCurrentWindow() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCurrentWindow();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getCursorColumn() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCursorColumn();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getCursorRow() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCursorRow();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getCursorType() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCursorType();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCursorUpdate() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCursorUpdate();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public CustomGlyphList getCustomGlyphList() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            CustomGlyphList res = new CustomGlyphList();
            List<RangeOfCharacters> list = res.getCustomGlyph();
            for (String range : device.getCustomGlyphList().split(",")) {
                String[] s = range.split("-");
                if (s.length > 0) {
                    RangeOfCharacters r = new RangeOfCharacters();
                    r.setFrom(Integer.valueOf(s[0], 16));
                    r.setTo(Integer.valueOf(s.length > 1 ? s[1] : s[0], 16));
                    list.add(r);
                }
            }
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getDeviceBrightness() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getDeviceBrightness();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getDeviceColumns() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getDeviceColumns();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getDeviceControlDescription() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        return device.getDeviceControlDescription();
    }

    public UposVersion getDeviceControlVersion() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        UposVersion res = new UposVersion();
        int version = device.getDeviceControlVersion();
        res.setMajor(version / 1000000 % 1000);
        res.setMinor(version / 1000 % 1000);
        res.setBuild(version % 1000);
        return res;
    }

    public Integer getDeviceDescriptors() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getDeviceDescriptors();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getDeviceEnabled() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getDeviceEnabled();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getDeviceRows() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getDeviceRows();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getDeviceServiceDescription() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getDeviceServiceDescription();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public UposVersion getDeviceServiceVersion() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            UposVersion res = new UposVersion();
            int version = device.getDeviceServiceVersion();
            res.setMajor(version / 1000000 % 1000);
            res.setMinor(version / 1000 % 1000);
            res.setBuild(version % 1000);
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getDeviceWindows() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getDeviceWindows();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getFreezeEvents() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getFreezeEvents();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getGlyphHeight() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getGlyphHeight();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getGlyphWidth() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getGlyphWidth();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getInterCharacterWait() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getInterCharacterWait();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getMapCharacterSet() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getMapCharacterSet();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public DisplayMarqueeFormat getMarqueeFormat() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return displayMarqueeFormat.get(device.getMarqueeFormat());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getMarqueeRepeatWait() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getMarqueeRepeatWait();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public DisplayMarqueeType getMarqueeType() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return displayMarqueeType.get(device.getMarqueeType());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getMarqueeUnitWait() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getMarqueeUnitWait();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getMaximumX() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getMaximumX();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getMaximumY() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getMaximumY();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getPhysicalDeviceDescription() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getPhysicalDeviceDescription();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getPhysicalDeviceName() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getPhysicalDeviceName();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public PowerNotification getPowerNotify() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return powerNotification.get(device.getPowerNotify());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public PowerState getPowerState() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return powerState.get(device.getPowerState());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getRows() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getRows();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getScreenMode() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getScreenMode();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public DisplayScreenModeList getScreenModeList() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            DisplayScreenModeList res = new DisplayScreenModeList();
            List<DisplayScreenMode> list = res.getDisplayScreenMode();
            for (String mode : device.getScreenModeList().split(",")) {
                String[] s = mode.split("x");
                if (s.length > 1) {
                    DisplayScreenMode m = new DisplayScreenMode();
                    m.setRows(Integer.valueOf(s[0]));
                    m.setColumns(Integer.valueOf(s[1]));
                    list.add(m);
                }
            }
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public ControlState getState() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        return controlState.get(device.getState());
    }

    public void open(String endpointAddress) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.open(deviceName);
            if (endpointAddress != null)
            {
                try {
                    Service service = Service.create(
                            new URL(endpointAddress + "?wsdl"),
                            new QName("http://www.nrf-arts.org/UnifiedPOS/LineDisplayEvents/", "LineDisplayEventService"));
                    deviceEvent = service.getPort(org.nrf_arts.unifiedpos.linedisplayevents.LineDisplayEvent.class);
                    device.addDirectIOListener(this);
                    device.addStatusUpdateListener(this);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer readCharacterAtCursor() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            int[] param = new int[1];
            device.readCharacterAtCursor(param);
            return param[0];
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void refreshWindow(Integer window) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.refreshWindow(window);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void release() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.release();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void resetStatistics(StatisticList statisticsBuffer) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            String param = null;
            List<Statistic> list = statisticsBuffer.getStatistic();
            switch (list.size()) {
                case 0:
                    param = "";
                    break;
                case 1:
                    String name = list.get(0).getName();
                    if (name.equals(StatisticCategories.ALL)) {
                        param = "";
                    }
                    else if (name.equals(StatisticCategories.MANUFACTURER)) {
                        param = "M_";
                    }
                    else if (name.equals(StatisticCategories.UPOS)) {
                        param = "U_";
                    }
                    else {
                        param = name;
                    }
                    break;
                default:
                    StringBuffer buffer = new StringBuffer();
                    for (Statistic statistic : statisticsBuffer.getStatistic()) {
                        buffer.append(",").append(statistic.getName());
                    }
                    param = buffer.substring(1);
                    break;
            }
            device.resetStatistics(param);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String retrieveStatistics(StatisticList statisticsBuffer) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            String[] param = new String[1];
            List<Statistic> list = statisticsBuffer.getStatistic();
            switch (list.size()) {
                case 0:
                    param[0] = "";
                    break;
                case 1:
                    String name = list.get(0).getName();
                    if (name.equals(StatisticCategories.ALL)) {
                        param[0] = "";
                    }
                    else if (name.equals(StatisticCategories.MANUFACTURER)) {
                        param[0] = "M_";
                    }
                    else if (name.equals(StatisticCategories.UPOS)) {
                        param[0] = "U_";
                    }
                    else {
                        param[0] = name;
                    }
                    break;
                default:
                    StringBuffer buffer = new StringBuffer();
                    for (Statistic statistic : statisticsBuffer.getStatistic()) {
                        buffer.append(",").append(statistic.getName());
                    }
                    param[0] = buffer.substring(1);
                    break;
            }
            device.retrieveStatistics(param);
            return param[0];
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void scrollText(DisplayScrollText direction, Integer units) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.scrollText(jposConst.get(direction), units);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setBitmap(Integer bitmapNumber, String fileName, Integer width, Integer alignmentX, Integer alignmentY) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setBitmap(bitmapNumber, fileName, width, alignmentX, alignmentY);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setBlinkRate(Integer blinkRate) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setBlinkRate(blinkRate);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setCharacterSet(Integer characterSet) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setCharacterSet(characterSet);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setCurrentWindow(Integer currentWindow) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setCurrentWindow(currentWindow);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setCursorColumn(Integer cursorColumn) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setCursorColumn(cursorColumn);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setCursorRow(Integer cursorRow) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setCursorRow(cursorRow);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setCursorType(Integer cursorType) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setCursorType(cursorType);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setCursorUpdate(Boolean cursorUpdate) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setCursorUpdate(cursorUpdate);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setDescriptor(Integer descriptor, DisplaySetDescriptor attribute) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setDescriptor(descriptor, jposConst.get(attribute));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setDeviceBrightness(Integer deviceBrightness) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setDeviceBrightness(deviceBrightness);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setDeviceEnabled(Boolean deviceEnabled) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setDeviceEnabled(deviceEnabled);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setFreezeEvents(Boolean freezeEvents) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setFreezeEvents(freezeEvents);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setInterCharacterWait(Integer interCharacterWait) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setInterCharacterWait(interCharacterWait);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setMapCharacterSet(Boolean mapCharacterSet) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setMapCharacterSet(mapCharacterSet);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setMarqueeFormat(DisplayMarqueeFormat marqueeFormat) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setMarqueeFormat(jposConst.get(marqueeFormat));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setMarqueeRepeatWait(Integer marqueeRepeatWait) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setMarqueeRepeatWait(marqueeRepeatWait);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setMarqueeType(DisplayMarqueeType marqueeType) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setMarqueeType(jposConst.get(marqueeType));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setMarqueeUnitWait(Integer marqueeUnitWait) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setMarqueeUnitWait(marqueeUnitWait);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setPowerNotify(PowerNotification powerNotify) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setPowerNotify(jposConst.get(powerNotify));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setScreenMode(Integer screenMode) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setScreenMode(screenMode);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void updateFirmware(String firmwareFileName) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.updateFirmware(firmwareFileName);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void updateStatistics(StatisticList statisticsBuffer) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            String param = null;
            List<Statistic> list = statisticsBuffer.getStatistic();
            switch (list.size()) {
                case 0:
                    param = "";
                    break;
                case 1:
                    Statistic s = list.get(0);
                    String name = s.getName();
                    String value = s.getValue();
                    if (name.equals(StatisticCategories.ALL)) {
                        param = "=" + value;
                    }
                    else if (name.equals(StatisticCategories.MANUFACTURER)) {
                        param = "M_=" + value;
                    }
                    else if (name.equals(StatisticCategories.UPOS)) {
                        param = "U_=" + value;
                    }
                    else {
                        param = name + "=" + value;
                    }
                    break;
                default:
                    StringBuffer buffer = new StringBuffer();
                    for (Statistic statistic : statisticsBuffer.getStatistic()) {
                        buffer.append(",").append(statistic.getName()).append("=").append(statistic.getValue());
                    }
                    param = buffer.substring(1);
                    break;
            }
            device.updateStatistics(param);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    //
    // LineDisplayEvent Member
    //

    public void directIOOccurred(DirectIOEvent dioe) {
        //throw new UnsupportedOperationException("Not supported yet.");
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(new Date(dioe.getWhen()));
        org.nrf_arts.unifiedpos.linedisplayevents.DirectIOData value = deviceEvent.directIOEvent(
                dioe.getSource().toString(),
                (int)dioe.getSequenceNumber(),
                datatypeFactory.newXMLGregorianCalendar(cal),
                dioe.getEventNumber(),
                dioe.getData(),
                dioe.getObject());
        dioe.setData(value.getData());
        dioe.setObject(value.getObj());
    }

    public void statusUpdateOccurred(StatusUpdateEvent sue) {
        //throw new UnsupportedOperationException("Not supported yet.");
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(new Date(sue.getWhen()));
        deviceEvent.statusUpdateEvent(
                sue.getSource().toString(),
                (int)sue.getSequenceNumber(),
                datatypeFactory.newXMLGregorianCalendar(cal),
                sue.getStatus());
    }

}
