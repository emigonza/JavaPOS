
package org.nrf_arts.unifiedpos.billdispenser;

public class Wait {

    public static final int FOREVER = -1;

}
