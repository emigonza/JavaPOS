﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace UnifiedPOS.FiscalPrinter
{
    [ServiceContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/")]
    public interface FiscalPrinter
    {

        //
        // Common Properties
        //

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetAutoDisableResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        // bool GetAutoDisable();

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/SetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/SetAutoDisableResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        // void SetAutoDisable(bool AutoDisable);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapCompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapCompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCapCompareFirmwareVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapPowerReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapPowerReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        PowerReporting GetCapPowerReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapStatisticsReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapStatisticsReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCapStatisticsReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapUpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapUpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCapUpdateFirmware();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapUpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapUpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCapUpdateStatistics();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCheckHealthText", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCheckHealthTextResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        string GetCheckHealthText();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetClaimed", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetClaimedResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetClaimed();

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetDataCount", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetDataCountResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        // int GetDataCount();

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetDataEventEnabledResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        // bool GetDataEventEnabled();

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/SetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/SetDataEventEnabledResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        // void SetDataEventEnabled(bool DataEventEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetDeviceEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/SetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/SetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void SetDeviceEnabled(bool DeviceEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetFreezeEvents();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/SetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/SetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void SetFreezeEvents(bool FreezeEvents);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetOutputID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetOutputIDResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        int GetOutputID();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        PowerNotification GetPowerNotify();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/SetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/SetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void SetPowerNotify(PowerNotification PowerNotify);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetPowerState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetPowerStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        PowerState GetPowerState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        ControlState GetState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetDeviceControlDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetDeviceControlDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        string GetDeviceControlDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetDeviceControlVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetDeviceControlVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        UposVersion GetDeviceControlVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetDeviceServiceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetDeviceServiceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        string GetDeviceServiceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetDeviceServiceVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetDeviceServiceVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        UposVersion GetDeviceServiceVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetPhysicalDeviceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetPhysicalDeviceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        string GetPhysicalDeviceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetPhysicalDeviceName", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetPhysicalDeviceNameResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        string GetPhysicalDeviceName();

        //
        // Specific Properties
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapAdditionalHeader", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapAdditionalHeaderResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCapAdditionalHeader();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapAdditionalLines", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapAdditionalLinesResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCapAdditionalLines();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapAdditionalTrailer", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapAdditionalTrailerResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCapAdditionalTrailer();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapAmountAdjustment", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapAmountAdjustmentResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCapAmountAdjustment();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapChangeDue", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapChangeDueResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCapChangeDue();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapCheckTotal", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapCheckTotalResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCapCheckTotal();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapCoverSensor", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapCoverSensorResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCapCoverSensor();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapDoubleWidth", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapDoubleWidthResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCapDoubleWidth();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapDuplicateReceipt", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapDuplicateReceiptResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCapDuplicateReceipt();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapEmptyReceiptIsVoidable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapEmptyReceiptIsVoidableResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCapEmptyReceiptIsVoidable();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapFiscalReceiptStation", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapFiscalReceiptStationResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCapFiscalReceiptStation();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapFiscalReceiptType", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapFiscalReceiptTypeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCapFiscalReceiptType();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapFixedOutput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapFixedOutputResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCapFixedOutput();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapHasVatTable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapHasVatTableResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCapHasVatTable();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapIndependentHeader", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapIndependentHeaderResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCapIndependentHeader();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapItemList", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapItemListResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCapItemList();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapJrnEmptySensor", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapJrnEmptySensorResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCapJrnEmptySensor();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapJrnNearEndSensor", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapJrnNearEndSensorResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCapJrnNearEndSensor();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapJrnPresent", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapJrnPresentResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCapJrnPresent();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapMultiContractor", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapMultiContractorResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCapMultiContractor();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapNonFiscalMode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapNonFiscalModeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCapNonFiscalMode();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapOnlyVoidLastItem", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapOnlyVoidLastItemResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCapOnlyVoidLastItem();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapOrderAdjustmentFirst", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapOrderAdjustmentFirstResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCapOrderAdjustmentFirst();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapPackageAdjustment", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapPackageAdjustmentResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCapPackageAdjustment();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapPercentAdjustment", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapPercentAdjustmentResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCapPercentAdjustment();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapPositiveAdjustment", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapPositiveAdjustmentResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCapPositiveAdjustment();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapPositiveSubtotalAdjustment", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapPositiveSubtotalAdjustmentResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCapPositiveSubtotalAdjustment();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapPostPreLine", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapPostPreLineResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCapPostPreLine();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapPowerLossReport", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapPowerLossReportResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCapPowerLossReport();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapPredefinedPaymentLines", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapPredefinedPaymentLinesResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCapPredefinedPaymentLines();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapReceiptNotPaid", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapReceiptNotPaidResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCapReceiptNotPaid();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapRecEmptySensor", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapRecEmptySensorResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCapRecEmptySensor();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapRecNearEndSensor", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapRecNearEndSensorResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCapRecNearEndSensor();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapRecPresent", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapRecPresentResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCapRecPresent();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapRemainingFiscalMemory", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapRemainingFiscalMemoryResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCapRemainingFiscalMemory();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapReservedWord", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapReservedWordResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCapReservedWord();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapSetCurrency", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapSetCurrencyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCapSetCurrency();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapSetHeader", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapSetHeaderResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCapSetHeader();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapSetPOSID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapSetPOSIDResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCapSetPOSID();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapSetStoreFiscalID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapSetStoreFiscalIDResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCapSetStoreFiscalID();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapSetTrailer", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapSetTrailerResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCapSetTrailer();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapSetVatTable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapSetVatTableResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCapSetVatTable();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapSlpEmptySensor", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapSlpEmptySensorResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCapSlpEmptySensor();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapSlpFiscalDocument", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapSlpFiscalDocumentResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCapSlpFiscalDocument();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapSlpFullSlip", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapSlpFullSlipResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCapSlpFullSlip();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapSlpNearEndSensor", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapSlpNearEndSensorResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCapSlpNearEndSensor();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapSlpPresent", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapSlpPresentResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCapSlpPresent();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapSlpValidation", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapSlpValidationResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCapSlpValidation();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapSubAmountAdjustment", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapSubAmountAdjustmentResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCapSubAmountAdjustment();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapSubPercentAdjustment", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapSubPercentAdjustmentResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCapSubPercentAdjustment();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapSubtotal", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapSubtotalResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCapSubtotal();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapTotalizerType", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapTotalizerTypeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCapTotalizerType();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapTrainingMode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapTrainingModeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCapTrainingMode();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapValidateJournal", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapValidateJournalResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCapValidateJournal();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapXReport", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCapXReportResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCapXReport();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetActualCurrency", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetActualCurrencyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        FiscalCurrency GetActualCurrency();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetAdditionalHeader", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetAdditionalHeaderResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        string GetAdditionalHeader();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/SetAdditionalHeader", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/SetAdditionalHeaderResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void SetAdditionalHeader(string AdditionalHeader);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetAdditionalTrailer", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetAdditionalTrailerResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        string GetAdditionalTrailer();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/SetAdditionalTrailer", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/SetAdditionalTrailerResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void SetAdditionalTrailer(string AdditionalTrailer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetAmountDecimalPlaces", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetAmountDecimalPlacesResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        int GetAmountDecimalPlaces();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetAsyncMode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetAsyncModeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetAsyncMode();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/SetAsyncMode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/SetAsyncModeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void SetAsyncMode(bool AsyncMode);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetChangeDue", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetChangeDueResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        string GetChangeDue();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/SetChangeDue", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/SetChangeDueResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void SetChangeDue(string ChangeDue);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCheckTotal", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCheckTotalResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCheckTotal();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/SetCheckTotal", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/SetCheckTotalResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void SetCheckTotal(bool CheckTotal);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetContractorID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetContractorIDResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        FiscalContractorID GetContractorID();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/SetContractorID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/SetContractorIDResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void SetContractorID(FiscalContractorID ContractorID);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCountryCode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCountryCodeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        int GetCountryCode();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCoverOpen", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetCoverOpenResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetCoverOpen();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetDateType", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetDateTypeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        FiscalDateType GetDateType();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/SetDateType", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/SetDateTypeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void SetDateType(FiscalDateType DateType);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetDayOpened", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetDayOpenedResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetDayOpened();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetDescriptionLength", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetDescriptionLengthResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        int GetDescriptionLength();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetDuplicateReceipt", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetDuplicateReceiptResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetDuplicateReceipt();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/SetDuplicateReceipt", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/SetDuplicateReceiptResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void SetDuplicateReceipt(bool DuplicateReceipt);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetErrorLevel", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetErrorLevelResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        FiscalErrorLevel GetErrorLevel();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetErrorOutID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetErrorOutIDResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        int GetErrorOutID();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetErrorState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetErrorStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        FiscalPrinterState GetErrorState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetErrorStation", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetErrorStationResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        FiscalPrinterStations GetErrorStation();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetErrorString", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetErrorStringResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        string GetErrorString();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetFiscalReceiptStation", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetFiscalReceiptStationResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        FiscalReceiptStation GetFiscalReceiptStation();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/SetFiscalReceiptStation", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/SetFiscalReceiptStationResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void SetFiscalReceiptStation(FiscalReceiptStation FiscalReceiptStation);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetFiscalReceiptType", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetFiscalReceiptTypeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        FiscalReceiptType GetFiscalReceiptType();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/SetFiscalReceiptType", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/SetFiscalReceiptTypeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void SetFiscalReceiptType(FiscalReceiptType FiscalReceiptType);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetFlagWhenIdle", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetFlagWhenIdleResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetFlagWhenIdle();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/SetFlagWhenIdle", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/SetFlagWhenIdleResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void SetFlagWhenIdle(bool FlagWhenIdle);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetJrnEmpty", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetJrnEmptyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetJrnEmpty();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetJrnNearEnd", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetJrnNearEndResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetJrnNearEnd();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetMessageLength", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetMessageLengthResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        int GetMessageLength();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetMessageType", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetMessageTypeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        FiscalMessageType GetMessageType();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/SetMessageType", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/SetMessageTypeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void SetMessageType(FiscalMessageType MessageType);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetNumHeaderLines", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetNumHeaderLinesResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        int GetNumHeaderLines();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetNumTrailerLines", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetNumTrailerLinesResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        int GetNumTrailerLines();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetNumVatRates", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetNumVatRatesResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        int GetNumVatRates();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetPostLine", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetPostLineResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        string GetPostLine();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/SetPostLine", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/SetPostLineResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void SetPostLine(string PostLine);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetPredefinedPaymentLines", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetPredefinedPaymentLinesResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        PaymentLinesList GetPredefinedPaymentLines();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetPreLine", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetPreLineResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        string GetPreLine();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/SetPreLine", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/SetPreLineResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void SetPreLine(string PreLine);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetPrinterState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetPrinterStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        FiscalPrinterState GetPrinterState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetQuantityDecimalPlaces", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetQuantityDecimalPlacesResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        int GetQuantityDecimalPlaces();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetQuantityLength", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetQuantityLengthResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        int GetQuantityLength();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetRecEmpty", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetRecEmptyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetRecEmpty();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetRecNearEnd", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetRecNearEndResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetRecNearEnd();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetRemainingFiscalMemory", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetRemainingFiscalMemoryResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        int GetRemainingFiscalMemory();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetReservedWord", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetReservedWordResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        string GetReservedWord();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetSlpEmpty", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetSlpEmptyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetSlpEmpty();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetSlpNearEnd", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetSlpNearEndResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetSlpNearEnd();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetSlipSelection", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetSlipSelectionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        FiscalSlipSelection GetSlipSelection();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/SetSlipSelection", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/SetSlipSelectionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void SetSlipSelection(FiscalSlipSelection SlipSelection);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetTotalizerType", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetTotalizerTypeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        FiscalTotalizerType GetTotalizerType();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/SetTotalizerType", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/SetTotalizerTypeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void SetTotalizerType(FiscalTotalizerType TotalizerType);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetTrainingModeActive", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetTrainingModeActiveResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        bool GetTrainingModeActive();

        //
        // Common Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/Open", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/OpenResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void Open(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/Close", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/CloseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void Close(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/Claim", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/ClaimResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void Claim(int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/Release", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/ReleaseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void Release();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/CheckHealth", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/CheckHealthResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void CheckHealth(HealthCheckLevel Level);

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/ClearInput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/ClearInputResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        // void ClearInput();

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/ClearInputProperties", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/ClearInputPropertiesResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        // void ClearInputProperties();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/ClearOutput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/ClearOutputResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void ClearOutput();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/DirectIO", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/DirectIOResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        DirectIOData DirectIO(int Command, int Data, object Obj);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/CompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/CompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        CompareFirmwareResult CompareFirmwareVersion(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/ResetStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/ResetStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void ResetStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/RetrieveStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/RetrieveStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        string RetrieveStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void UpdateFirmware(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void UpdateStatistics(StatisticList StatisticsBuffer);

        //
        // Specific Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/SetCurrency", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/SetCurrencyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void SetCurrency(FiscalCurrency NewCurrency);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/SetDate", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/SetDateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void SetDate(DateTime Date);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/SetHeaderLine", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/SetHeaderLineResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void SetHeaderLine(int LineNumber, string Text, bool DoubleWidth);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/SetPOSID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/SetPOSIDResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void SetPOSID(string POSID, string CashierID);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/SetStoreFiscalID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/SetStoreFiscalIDResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void SetStoreFiscalID(string ID);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/SetTrailerLine", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/SetTrailerLineResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void SetTrailerLine(int LineNumber, string Text, bool DoubleWidth);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/SetVatTable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/SetVatTableResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void SetVatTable();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/SetVatValue", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/SetVatValueResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void SetVatValue(int VatID, string VatValue);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/BeginFiscalReceipt", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/BeginFiscalReceiptResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void BeginFiscalReceipt(bool PrintHeader);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/EndFiscalReceipt", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/EndFiscalReceiptResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void EndFiscalReceipt(bool PrintHeader);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintDuplicateReceipt", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintDuplicateReceiptResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void PrintDuplicateReceipt();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintRecCash", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintRecCashResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void PrintRecCash(decimal Amount);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintRecItem", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintRecItemResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void PrintRecItem(string Description, decimal Price, int Quantity, int VatInfo, decimal UnitPrice, string UnitName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintRecItemVoid", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintRecItemVoidResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void PrintRecItemVoid(string Description, decimal Price, int Quantity, int VatInfo, decimal UnitPrice, string UnitName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintRecItemAdjustment", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintRecItemAdjustmentResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void PrintRecItemAdjustment(FiscalAdjustment AdjustmentType, string Description, decimal Amount, int VatInfo);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintRecItemAdjustmentVoid", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintRecItemAdjustmentVoidResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void PrintRecItemAdjustmentVoid(FiscalAdjustment AdjustmentType, string Description, decimal Amount, int VatInfo);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintRecItemFuel", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintRecItemFuelResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void PrintRecItemFuel(string Description, decimal Price, int Quantity, int VatInfo, decimal UnitPrice, string UnitName, decimal SpecialTax, string SpecialTaxName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintRecItemFuelVoid", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintRecItemFuelVoidResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void PrintRecItemFuelVoid(string Description, decimal Price, int VatInfo, decimal SpecialTax);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintRecItemRefund", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintRecItemRefundResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void PrintRecItemRefund(string Description, decimal Amount, int Quantity, int VatInfo, decimal UnitAmount, string UnitName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintRecItemRefundVoid", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintRecItemRefundVoidResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void PrintRecItemRefundVoid(string Description, decimal Amount, int Quantity, int VatInfo, decimal UnitAmount, string UnitName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintRecMessage", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintRecMessageResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void PrintRecMessage(string Message);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintRecNotPaid", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintRecNotPaidResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void PrintRecNotPaid(string Description, decimal Amount);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintRecPackageAdjustment", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintRecPackageAdjustmentResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void PrintRecPackageAdjustment(FiscalAdjustmentType AdjustmentType, string Description, VatInfoList VatAdjustments);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintRecPackageAdjustVoid", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintRecPackageAdjustVoidResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void PrintRecPackageAdjustVoid(FiscalAdjustmentType AdjustmentType, VatInfoList VatAdjustments);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintRecRefund", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintRecRefundResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void PrintRecRefund(string Description, decimal Amount, int VatInfo);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintRecRefundVoid", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintRecRefundVoidResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void PrintRecRefundVoid(string Description, decimal Amount, int VatInfo);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintRecSubtotal", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintRecSubtotalResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void PrintRecSubtotal(decimal Amount);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintRecSubtotalAdjustment", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintRecSubtotalAdjustmentResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void PrintRecSubtotalAdjustment(FiscalAdjustment AdjustmentType, string Description, decimal Amount);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintRecSubtotalAdjustVoid", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintRecSubtotalAdjustVoidResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void PrintRecSubtotalAdjustVoid(FiscalAdjustment AdjustmentType, decimal Amount);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintRecTaxID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintRecTaxIDResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void PrintRecTaxID(string TaxID);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintRecTotal", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintRecTotalResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void PrintRecTotal(decimal Total, decimal Payment, string Description);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintRecVoid", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintRecVoidResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void PrintRecVoid(string Description);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/BeginFiscalDocument", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/BeginFiscalDocumentResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void BeginFiscalDocument(int DocumentAmount);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/EndFiscalDocument", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/EndFiscalDocumentResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void EndFiscalDocument();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintFiscalDocumentLine", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintFiscalDocumentLineResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void PrintFiscalDocumentLine(string DocumentLine);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/BeginItemList", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/BeginItemListResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void BeginItemList(int VatID);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/EndItemList", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/EndItemListResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void EndItemList();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/VerifyItem", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/VerifyItemResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void VerifyItem(string ItemName, int VatID);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintPeriodicTotalsReport", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintPeriodicTotalsReportResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void PrintPeriodicTotalsReport(DateTime Date1, DateTime Date2);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintPowerLossReport", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintPowerLossReportResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void PrintPowerLossReport();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintReport", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintReportResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void PrintReport(ReportType ReportType, string StartNum, string EndNum);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintXReport", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintXReportResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void PrintXReport();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintZReport", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintZReportResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void PrintZReport();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/BeginInsertion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/BeginInsertionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void BeginInsertion(int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/BeginRemoval", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/BeginRemovalResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void BeginRemoval(int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/EndInsertion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/EndInsertionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void EndInsertion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/EndRemoval", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/EndRemovalResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void EndRemoval();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/BeginFixedOutput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/BeginFixedOutputResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void BeginFixedOutput(FiscalReceiptStation Station, int DocumentType);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/BeginNonFiscal", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/BeginNonFiscalResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void BeginNonFiscal();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/BeginTraining", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/BeginTrainingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void BeginTraining();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/EndFixedOutput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/EndFixedOutputResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void EndFixedOutput();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/EndNonFiscal", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/EndNonFiscalResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void EndNonFiscal();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/EndTraining", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/EndTrainingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void EndTraining();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintFixedOutput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintFixedOutputResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void PrintFixedOutput(int DocumentType, int LineNumber, string Data);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintNormal", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/PrintNormalResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void PrintNormal(FiscalPrinterStations Station, string Data);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetData", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetDataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        FiscalDataItem GetData(FiscalData DataItem, int OptArgs);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetDate", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetDateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        DateTime GetDate();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetTotalizer", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetTotalizerResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        string GetTotalizer(int VatID, FiscalTotalizer OptArgs);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetVatEntry", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/GetVatEntryResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        int GetVatEntry(int VatID, int OptArgs);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/ClearError", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/ClearErrorResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void ClearError();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/ResetPrinter", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/ResetPrinterResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/UposException", Name = "UposException")]
        void ResetPrinter();
    }

    //
    // Common Data Types
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/")]
    public class DirectIOData
    {
        [DataMember]
        public int Data { get; set; }
        [DataMember]
        public object Obj { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/")]
    public class UposException
    {
        [DataMember]
        public ErrorCode ErrorCode { get; set; }
        [DataMember]
        public int ErrorCodeExtended { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/")]
    public class UposVersion
    {
        [DataMember]
        public int Major { get; set; }
        [DataMember]
        public int Minor { get; set; }
        [DataMember]
        public int Build { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/")]
    public class Statistic
    {
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public string Value { get; set; }
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/", ItemName = "Statistic")]
    public class StatisticList : List<Statistic>
    {
    }

    //
    // Common Enumerations
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/")]
    public enum CompareFirmwareResult
    {
        [EnumMember]
        Different,
        [EnumMember]
        Newer,
        [EnumMember]
        Older,
        [EnumMember]
        Same,
        [EnumMember]
        Unknown,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/")]
    public enum ControlState
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Closed,
        [EnumMember]
        Error,
        [EnumMember]
        Idle,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/")]
    public enum ErrorCode
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Claimed,
        [EnumMember]
        Closed,
        [EnumMember]
        Deprecated,
        [EnumMember]
        Disabled,
        [EnumMember]
        Exists,
        [EnumMember]
        Extended,
        [EnumMember]
        Failure,
        [EnumMember]
        Illegal,
        [EnumMember]
        NoExist,
        [EnumMember]
        NoHardware,
        [EnumMember]
        NoService,
        [EnumMember]
        NotClaimed,
        [EnumMember]
        Offline,
        [EnumMember]
        Success,
        [EnumMember]
        Timeout,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/")]
    public enum HealthCheckLevel
    {
        [EnumMember]
        External,
        [EnumMember]
        Interactive,
        [EnumMember]
        Internal,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/")]
    public enum PowerNotification
    {
        [EnumMember]
        Disabled,
        [EnumMember]
        Enabled,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/")]
    public enum PowerReporting
    {
        [EnumMember]
        Advanced,
        [EnumMember]
        None,
        [EnumMember]
        Standard,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/")]
    public enum PowerState
    {
        [EnumMember]
        Off,
        [EnumMember]
        Offline,
        [EnumMember]
        OffOffline,
        [EnumMember]
        Online,
        [EnumMember]
        Unknown,
    }

    /*
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/")]
    public enum StatisticCategories
    {
        [EnumMember]
        All,
        [EnumMember]
        Manufacturer,
        [EnumMember]
        Upos,
    }
    */
    public class StatisticCategories
    {
        public const string All = "";
        public const string Manufacturer = "M_";
        public const string Upos = "U_";
    }

    //
    // Specific Data Types
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/")]
    public class FiscalDataItem
    {
        [DataMember]
        public string Data { get; set; }
        [DataMember]
        public int ItemOption { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/")]
    public class VatInfo
    {
        [DataMember]
        public decimal Amount { get; set; }
        [DataMember]
        public int ID { get; set; }
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/", ItemName = "PaymentLines")]
    public class PaymentLinesList : List<string>
    {
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/", ItemName = "VatInfo")]
    public class VatInfoList : List<VatInfo>
    {
    }

    //
    // Specific Enumerations
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/")]
    public enum FiscalCurrency
    {
        [EnumMember]
        BrazilianCruceiro,
        [EnumMember]
        BulgarianLev,
        [EnumMember]
        CzechianKoruna,
        [EnumMember]
        Euro,
        [EnumMember]
        GreekDrachma,
        [EnumMember]
        HungarianForint,
        [EnumMember]
        ItalianLira,
        [EnumMember]
        Other,
        [EnumMember]
        PolishZloty,
        [EnumMember]
        RomanianLeu,
        [EnumMember]
        RussianRouble,
        [EnumMember]
        SwedishKrona,
        [EnumMember]
        TurkishLira,
        [EnumMember]
        UkrainianHryvnia,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/")]
    public enum FiscalContractorID
    {
        [EnumMember]
        First,
        [EnumMember]
        Second,
        [EnumMember]
        Single,
    }

    /*
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/")]
    public enum FiscalCountryCodes
    {
        [EnumMember]
        Brazil,
        [EnumMember]
        Bulgaria,
        [EnumMember]
        CzechRepublic,
        [EnumMember]
        Greece,
        [EnumMember]
        Hungary,
        [EnumMember]
        Italy,
        [EnumMember]
        Other,
        [EnumMember]
        Poland,
        [EnumMember]
        Romania,
        [EnumMember]
        Russia,
        [EnumMember]
        Sweden,
        [EnumMember]
        Turkey,
        [EnumMember]
        Ukraine,
    }
    */
    public class FiscalCountryCodes
    {
        public const int Brazil = 1;
        public const int Bulgaria = 128;
        public const int CzechRepublic = 512;
        public const int Greece = 2;
        public const int Hungary = 4;
        public const int Italy = 8;
        public const int Other = 1073741824;
        public const int Poland = 16;
        public const int Romania = 256;
        public const int Russia = 64;
        public const int Sweden = 2048;
        public const int Turkey = 32;
        public const int Ukraine = 1024;
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/")]
    public enum FiscalDateType
    {
        [EnumMember]
        Configuration,
        [EnumMember]
        EndOfDay,
        [EnumMember]
        RealTimeClock,
        [EnumMember]
        Reset,
        [EnumMember]
        Start,
        [EnumMember]
        VatChange,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/")]
    public enum FiscalErrorLevel
    {
        [EnumMember]
        Blocked,
        [EnumMember]
        Fatal,
        [EnumMember]
        None,
        [EnumMember]
        Recoverable,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/")]
    public enum FiscalPrinterState
    {
        [EnumMember]
        FiscalDocument,
        [EnumMember]
        FiscalReceipt,
        [EnumMember]
        FiscalReceiptEnding,
        [EnumMember]
        FiscalReceiptTotal,
        [EnumMember]
        FixedOutput,
        [EnumMember]
        ItemList,
        [EnumMember]
        Locked,
        [EnumMember]
        Monitor,
        [EnumMember]
        NonFiscal,
        [EnumMember]
        Report,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/")]
    public enum FiscalPrinterStations
    {
        [EnumMember]
        Journal,
        [EnumMember]
        JournalReceipt,
        [EnumMember]
        JournalSlip,
        [EnumMember]
        Receipt,
        [EnumMember]
        ReceiptSlip,
        [EnumMember]
        Slip,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/")]
    public enum FiscalReceiptStation
    {
        [EnumMember]
        Receipt,
        [EnumMember]
        Slip,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/")]
    public enum FiscalReceiptType
    {
        [EnumMember]
        CashIn,
        [EnumMember]
        CashOut,
        [EnumMember]
        Generic,
        [EnumMember]
        Refund,
        [EnumMember]
        Sales,
        [EnumMember]
        Service,
        [EnumMember]
        SimpleInvoice,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/")]
    public enum FiscalMessageType
    {
        [EnumMember]
        Advance,
        [EnumMember]
        AdvancePaid,
        [EnumMember]
        AmountToBePaid,
        [EnumMember]
        AmountToBePaidBack,
        [EnumMember]
        Card,
        [EnumMember]
        CardNumber,
        [EnumMember]
        CardType,
        [EnumMember]
        Cash,
        [EnumMember]
        Cashier,
        [EnumMember]
        CashRegisterNumber,
        [EnumMember]
        Change,
        [EnumMember]
        Cheque,
        [EnumMember]
        ClientNumber,
        [EnumMember]
        ClientSignature,
        [EnumMember]
        CounterState,
        [EnumMember]
        CreditCard,
        [EnumMember]
        Currency,
        [EnumMember]
        CurrencyValue,
        [EnumMember]
        Deposit,
        [EnumMember]
        DepositReturned,
        [EnumMember]
        DotLine,
        [EnumMember]
        DriverNumber,
        [EnumMember]
        EmptyLine,
        [EnumMember]
        FreeText,
        [EnumMember]
        FreeTextWithDayLimit,
        [EnumMember]
        GivenDiscount,
        [EnumMember]
        LocalCredit,
        [EnumMember]
        MileageKilometers,
        [EnumMember]
        Note,
        [EnumMember]
        Paid,
        [EnumMember]
        PayIn,
        [EnumMember]
        PointGranted,
        [EnumMember]
        PointsBonus,
        [EnumMember]
        PointsReceipt,
        [EnumMember]
        PointsTotal,
        [EnumMember]
        Profited,
        [EnumMember]
        Rate,
        [EnumMember]
        RegisterNumber,
        [EnumMember]
        ShiftNumber,
        [EnumMember]
        StateOfAnAccount,
        [EnumMember]
        Subscription,
        [EnumMember]
        Table,
        [EnumMember]
        ThankYouForLoyalty,
        [EnumMember]
        TransactionNumber,
        [EnumMember]
        ValidTo,
        [EnumMember]
        Voucher,
        [EnumMember]
        VoucherPaid,
        [EnumMember]
        VoucherValue,
        [EnumMember]
        WithDiscount,
        [EnumMember]
        WithoutUplift,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/")]
    public enum FiscalSlipSelection
    {
        [EnumMember]
        FullLength,
        [EnumMember]
        Validation,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/")]
    public enum FiscalTotalizerType
    {
        [EnumMember]
        Day,
        [EnumMember]
        Document,
        [EnumMember]
        Grand,
        [EnumMember]
        Receipt,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/")]
    public enum FiscalAdjustment
    {
        [EnumMember]
        AmountDiscount,
        [EnumMember]
        AmountSurcharge,
        [EnumMember]
        CouponAmountDiscount,
        [EnumMember]
        CouponPercentageDiscount,
        [EnumMember]
        PercentageDiscount,
        [EnumMember]
        PercentageSurcharge,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/")]
    public enum FiscalAdjustmentType
    {
        [EnumMember]
        Discount,
        [EnumMember]
        Surcharge,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/")]
    public enum ReportType
    {
        [EnumMember]
        Date,
        [EnumMember]
        EndOfDayOrdinal,
        [EnumMember]
        Ordinal,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/")]
    public enum FiscalData
    {
        [EnumMember]
        CurrentTotal,
        [EnumMember]
        DailyTotal,
        [EnumMember]
        DescriptionLength,
        [EnumMember]
        Firmware,
        [EnumMember]
        FiscalDocument,
        [EnumMember]
        FiscalDocumentVoid,
        [EnumMember]
        FiscalReceipt,
        [EnumMember]
        FiscalReceiptVoid,
        [EnumMember]
        GrandTotal,
        [EnumMember]
        LineCount,
        [EnumMember]
        NonFiscalDocument,
        [EnumMember]
        NonFiscalDocumentVoid,
        [EnumMember]
        NonFiscalReceipt,
        [EnumMember]
        NotPaid,
        [EnumMember]
        NumberOfConfigurationBlocks,
        [EnumMember]
        NumberOfCurrencyBlocks,
        [EnumMember]
        NumberOfHeaderBlocks,
        [EnumMember]
        NumberOfResetBlocks,
        [EnumMember]
        NumberOfVatBlocks,
        [EnumMember]
        NumberOfVoidedReceipts,
        [EnumMember]
        PrinterId,
        [EnumMember]
        ReceiptNumber,
        [EnumMember]
        Refund,
        [EnumMember]
        RefundVoid,
        [EnumMember]
        Restart,
        [EnumMember]
        SimplifiedInvoice,
        [EnumMember]
        Tender,
        [EnumMember]
        ZReport,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinter/")]
    public enum FiscalTotalizer
    {
        [EnumMember]
        Discount,
        [EnumMember]
        DiscountVoid,
        [EnumMember]
        Gross,
        [EnumMember]
        Item,
        [EnumMember]
        ItemVoid,
        [EnumMember]
        Net,
        [EnumMember]
        NotPaid,
        [EnumMember]
        Refund,
        [EnumMember]
        RefundVoid,
        [EnumMember]
        SubtotalDiscount,
        [EnumMember]
        SubtotalDiscountVoid,
        [EnumMember]
        SubtotalSurcharges,
        [EnumMember]
        SubtotalSurchargesVoid,
        [EnumMember]
        Surcharge,
        [EnumMember]
        SurchargeVoid,
        [EnumMember]
        Vat,
        [EnumMember]
        VatCategory,
    }

    //
    // Constants
    //

    /*
    public class Constants
    {
        public const int CurrencyEuro = 1;
        public const int DescriptionLengthItem = 1;
        public const int DescriptionLengthItemAdjustment = 2;
        public const int DescriptionLengthItemFuel = 3;
        public const int DescriptionLengthItemFuelVoid = 4;
        public const int DescriptionLengthNotPaid = 5;
        public const int DescriptionLengthPackageAdjustment = 6;
        public const int DescriptionLengthRefund = 7;
        public const int DescriptionLengthRefundVoid = 8;
        public const int DescriptionLengthSubtotalAdjustment = 9;
        public const int DescriptionLengthTotal = 10;
        public const int DescriptionLengthVoid = 11;
        public const int DescriptionLengthVoidItem = 12;
        public const int ExtendedErrorBadDate = 219;
        public const int ExtendedErrorBadItemAmount = 214;
        public const int ExtendedErrorBadItemDescription = 215;
        public const int ExtendedErrorBadItemQuantity = 213
        public const int ExtendedErrorBadLength = 222;
        public const int ExtendedErrorBadPrice = 218;
        public const int ExtendedErrorBadVat = 217;
        public const int ExtendedErrorClockError = 209;
        public const int ExtendedErrorCoverOpen = 201;
        public const int ExtendedErrorDayEndRequired = 224;
        public const int ExtendedErrorFirmwareBadFile = 281;
        public const int ExtendedErrorJournalEmpty = 202;
        public const int ExtendedErrorMemoryDisconnected = 211;
        public const int ExtendedErrorMemoryFull = 210;
        public const int ExtendedErrorMissingDevices = 206;
        public const int ExtendedErrorMissingSetCurrency = 223;
        public const int ExtendedErrorNegativeTotal = 220;
        public const int ExtendedErrorReceiptEmpty = 203;
        public const int ExtendedErrorReceiptTotalOverflow = 216;
        public const int ExtendedErrorSlipEmpty = 204;
        public const int ExtendedErrorSlipForm = 205;
        public const int ExtendedErrorStatistics = 280;
        public const int ExtendedErrorStatisticsDependency = 282;
        public const int ExtendedErrorTechnicalAssistance = 208;
        public const int ExtendedErrorTotalsError = 212;
        public const int ExtendedErrorWordNotAllowed = 221;
        public const int ExtendedErrorWrongState = 207;
        public const int LineCountComment = 13;
        public const int LineCountDiscount = 3;
        public const int LineCountDiscountVoid = 4;
        public const int LineCountItem = 1;
        public const int LineCountItemVoid = 2;
        public const int LineCountRefund = 7;
        public const int LineCountRefundVoid = 8;
        public const int LineCountSubtotal = 14;
        public const int LineCountSubtotalDiscount = 9;
        public const int LineCountSubtotalDiscountVoid = 10;
        public const int LineCountSubtotalSurcharge = 11;
        public const int LineCountSubtotalSurchargeVoid = 12;
        public const int LineCountSurcharge = 5;
        public const int LineCountSurchargeVoid = 6;
        public const int LineCountTotal = 15;
        public const int PaymentDescriptionCash = 1;
        public const int PaymentDescriptionCheque = 2;
        public const int PaymentDescriptionChitty = 3;
        public const int PaymentDescriptionCoupon = 4;
        public const int PaymentDescriptionCurrency = 5;
        public const int PaymentDescriptionDrivenOff = 6;
        public const int PaymentDescriptionEftImprinter = 7;
        public const int PaymentDescriptionEftTerminal = 8;
        public const int PaymentDescriptionFreeGift = 10;
        public const int PaymentDescriptionGiro = 11;
        public const int PaymentDescriptionHome = 12;
        public const int PaymentDescriptionImprinterWithIssuer = 13;
        public const int PaymentDescriptionLocalAccount = 14;
        public const int PaymentDescriptionLocalAccountCard = 15;
        public const int PaymentDescriptionPayCard = 16;
        public const int PaymentDescriptionPayCardManual = 17;
        public const int PaymentDescriptionPrepay = 18;
        public const int PaymentDescriptionPumpTest = 19;
        public const int PaymentDescriptionShortCredit = 20;
        public const int PaymentDescriptionStaff = 21;
        public const int PaymentDescriptionTerminalImprinter = 9;
        public const int PaymentDescriptionVoucher = 22;
        public const string StatisticCommunicationErrorCount = "CommunicationErrorCount";
        public const string StatisticDeviceCategory = "DeviceCategory";
        public const string StatisticFirmwareRevision = "FirmwareRevision";
        public const string StatisticHoursPoweredCount = "HoursPoweredCount";
        public const string StatisticInstallationDate = "InstallationDate";
        public const string StatisticInterface = "Interface";
        public const string StatisticManufactureDate = "ManufactureDate";
        public const string StatisticManufacturerName = "ManufacturerName";
        public const string StatisticMechanicalRevision = "MechanicalRevision";
        public const string StatisticModelName = "ModelName";
        public const string StatisticSerialNumber = "SerialNumber";
        public const string StatisticUnifiedPOSVersion = "UnifiedPOSVersion";
        public const int StatusCoverOK = 12;
        public const int StatusCoverOpen = 11;
        public const int StatusIdle = 1001;
        public const int StatusJournalCoverOK = 61;
        public const int StatusJournalCoverOpen = 60;
        public const int StatusJournalEmpty = 21;
        public const int StatusJournalNearEmpty = 22;
        public const int StatusJournalPaperOK = 23;
        public const int StatusPowerOff = 2002;
        public const int StatusPowerOffline = 2003;
        public const int StatusPowerOffOffline = 2004;
        public const int StatusPowerOnline = 2001;
        public const int StatusReceiptCoverOK = 63;
        public const int StatusReceiptCoverOpen = 62;
        public const int StatusReceiptEmpty = 24;
        public const int StatusReceiptNearEmpty = 25;
        public const int StatusReceiptPaperOK = 26;
        public const int StatusSlipCoverOK = 65;
        public const int StatusSlipCoverOpen = 64;
        public const int StatusSlipEmpty = 27;
        public const int StatusSlipNearEmpty = 28;
        public const int StatusSlipPaperOK = 29;
        public const int StatusUpdateFirmwareComplete = 2200;
        public const int StatusUpdateFirmwareCompleteDeviceNotRestored = 2205;
        public const int StatusUpdateFirmwareFailedDeviceNeedsFirmware = 2203;
        public const int StatusUpdateFirmwareFailedDeviceOk = 2201;
        public const int StatusUpdateFirmwareFailedDeviceUnknown = 2204;
        public const int StatusUpdateFirmwareFailedDeviceUnrecoverable = 2202;
        public const int StatusUpdateFirmwareProgress = 2100;
        public const int WaitForever = -1;
    }
    */

    public class Currency
    {
        public const int Euro = 1;
    }

    public class DescriptionLength
    {
        public const int Item = 1;
        public const int ItemAdjustment = 2;
        public const int ItemFuel = 3;
        public const int ItemFuelVoid = 4;
        public const int NotPaid = 5;
        public const int PackageAdjustment = 6;
        public const int Refund = 7;
        public const int RefundVoid = 8;
        public const int SubtotalAdjustment = 9;
        public const int Total = 10;
        public const int Void = 11;
        public const int VoidItem = 12;
    }

    public class ExtendedError
    {
        public const int BadDate = 219;
        public const int BadItemAmount = 214;
        public const int BadItemDescription = 215;
        public const int BadItemQuantity = 213;
        public const int BadLength = 222;
        public const int BadPrice = 218;
        public const int BadVat = 217;
        public const int ClockError = 209;
        public const int CoverOpen = 201;
        public const int DayEndRequired = 224;
        public const int FirmwareBadFile = 281;
        public const int JournalEmpty = 202;
        public const int MemoryDisconnected = 211;
        public const int MemoryFull = 210;
        public const int MissingDevices = 206;
        public const int MissingSetCurrency = 223;
        public const int NegativeTotal = 220;
        public const int ReceiptEmpty = 203;
        public const int ReceiptTotalOverflow = 216;
        public const int SlipEmpty = 204;
        public const int SlipForm = 205;
        public const int Statistics = 280;
        public const int StatisticsDependency = 282;
        public const int TechnicalAssistance = 208;
        public const int TotalsError = 212;
        public const int WordNotAllowed = 221;
        public const int WrongState = 207;
    }

    public class LineCount
    {
        public const int Comment = 13;
        public const int Discount = 3;
        public const int DiscountVoid = 4;
        public const int Item = 1;
        public const int ItemVoid = 2;
        public const int Refund = 7;
        public const int RefundVoid = 8;
        public const int Subtotal = 14;
        public const int SubtotalDiscount = 9;
        public const int SubtotalDiscountVoid = 10;
        public const int SubtotalSurcharge = 11;
        public const int SubtotalSurchargeVoid = 12;
        public const int Surcharge = 5;
        public const int SurchargeVoid = 6;
        public const int Total = 15;
    }

    public class PaymentDescription
    {
        public const int Cash = 1;
        public const int Cheque = 2;
        public const int Chitty = 3;
        public const int Coupon = 4;
        public const int Currency = 5;
        public const int DrivenOff = 6;
        public const int EftImprinter = 7;
        public const int EftTerminal = 8;
        public const int FreeGift = 10;
        public const int Giro = 11;
        public const int Home = 12;
        public const int ImprinterWithIssuer = 13;
        public const int LocalAccount = 14;
        public const int LocalAccountCard = 15;
        public const int PayCard = 16;
        public const int PayCardManual = 17;
        public const int Prepay = 18;
        public const int PumpTest = 19;
        public const int ShortCredit = 20;
        public const int Staff = 21;
        public const int TerminalImprinter = 9;
        public const int Voucher = 22;
    }

    public class StatisticProperties
    {
        public const string CommunicationErrorCount = "CommunicationErrorCount";
        public const string DeviceCategory = "DeviceCategory";
        public const string FirmwareRevision = "FirmwareRevision";
        public const string HoursPoweredCount = "HoursPoweredCount";
        public const string InstallationDate = "InstallationDate";
        public const string Interface = "Interface";
        public const string ManufactureDate = "ManufactureDate";
        public const string ManufacturerName = "ManufacturerName";
        public const string MechanicalRevision = "MechanicalRevision";
        public const string ModelName = "ModelName";
        public const string SerialNumber = "SerialNumber";
        public const string UnifiedPOSVersion = "UnifiedPOSVersion";
        public const string BarcodePrintedCount = "BarcodePrintedCount";
        public const string FailedPaperCutCount = "FailedPaperCutCount";
        public const string FailedPrintSideChangeCount = "FailedPrintSideChangeCount";
        public const string FormInsertionCount = "FormInsertionCount";
        public const string HomeErrorCount = "HomeErrorCount";
        public const string JournalCharacterPrintedCount = "JournalCharacterPrintedCount";
        public const string JournalCoverOpenCount = "JournalCoverOpenCount";
        public const string JournalLinePrintedCount = "JournalLinePrintedCount";
        public const string MaximumTempReachedCount = "MaximumTempReachedCount";
        public const string NVRAMWriteCount = "NVRAMWriteCount";
        public const string PaperCutCount = "PaperCutCount";
        public const string PrinterFaultCount = "PrinterFaultCount";
        public const string PrintSideChangeCount = "PrintSideChangeCount";
        public const string ReceiptCharacterPrintedCount = "ReceiptCharacterPrintedCount";
        public const string ReceiptCoverOpenCount = "ReceiptCoverOpenCount";
        public const string ReceiptLineFeedCount = "ReceiptLineFeedCount";
        public const string ReceiptLinePrintedCount = "ReceiptLinePrintedCount";
        public const string SlipCharacterPrintedCount = "SlipCharacterPrintedCount";
        public const string SlipCoverOpenCount = "SlipCoverOpenCount";
        public const string SlipLineFeedCount = "SlipLineFeedCount";
        public const string SlipLinePrintedCount = "SlipLinePrintedCount";
        public const string StampFiredCount = "StampFiredCount";
    }

    public class Wait
    {
        public const int Forever = -1;
    }
}
