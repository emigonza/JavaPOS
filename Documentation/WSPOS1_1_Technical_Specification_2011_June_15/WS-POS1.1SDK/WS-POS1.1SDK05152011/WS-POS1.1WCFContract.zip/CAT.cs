﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace UnifiedPOS.CAT
{
    [ServiceContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CAT/")]
    public interface CAT
    {

        //
        // Common Properties
        //

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetAutoDisableResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        // int GetAutoDisable();

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/SetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/SetAutoDisableResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        // void SetAutoDisable(int AutoDisable);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetCapCompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetCapCompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        bool GetCapCompareFirmwareVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetCapPowerReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetCapPowerReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        PowerReporting GetCapPowerReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetCapStatisticsReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetCapStatisticsReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        bool GetCapStatisticsReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetCapUpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetCapUpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        bool GetCapUpdateFirmware();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetCapUpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetCapUpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        bool GetCapUpdateStatistics();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetCheckHealthText", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetCheckHealthTextResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        string GetCheckHealthText();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetClaimed", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetClaimedResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        bool GetClaimed();

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetDataCount", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetDataCountResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        // int GetDataCount();

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetDataEventEnabledResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        // bool GetDataEventEnabled();

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/SetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/SetDataEventEnabledResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        // void SetDataEventEnabled(bool DataEventEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        bool GetDeviceEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/SetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/SetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        void SetDeviceEnabled(bool DeviceEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        bool GetFreezeEvents();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/SetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/SetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        void SetFreezeEvents(bool FreezeEvents);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetOutputID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetOutputIDResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        int GetOutputID();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        PowerNotification GetPowerNotify();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/SetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/SetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        void SetPowerNotify(PowerNotification PowerNotify);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetPowerState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetPowerStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        PowerState GetPowerState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        ControlState GetState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetDeviceControlDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetDeviceControlDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        string GetDeviceControlDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetDeviceControlVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetDeviceControlVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        UposVersion GetDeviceControlVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetDeviceServiceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetDeviceServiceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        string GetDeviceServiceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetDeviceServiceVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetDeviceServiceVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        UposVersion GetDeviceServiceVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetPhysicalDeviceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetPhysicalDeviceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        string GetPhysicalDeviceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetPhysicalDeviceName", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetPhysicalDeviceNameResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        string GetPhysicalDeviceName();

        //
        // Specific Properties
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetAccountNumber", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetAccountNumberResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        string GetAccountNumber();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetAdditionalSecurityInformation", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetAdditionalSecurityInformationResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        string GetAdditionalSecurityInformation();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/SetAdditionalSecurityInformation", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/SetAdditionalSecurityInformationResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        void SetAdditionalSecurityInformation(string AdditionalSecurityInformation);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetApprovalCode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetApprovalCodeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        string GetApprovalCode();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetAsyncMode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetAsyncModeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        bool GetAsyncMode();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/SetAsyncMode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/SetAsyncModeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        void SetAsyncMode(bool AsyncMode);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetBalance", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetBalanceResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        decimal GetBalance();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetCapAdditionalSecurityInformation", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetCapAdditionalSecurityInformationResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        bool GetCapAdditionalSecurityInformation();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetCapAuthorizeCompletion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetCapAuthorizeCompletionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        bool GetCapAuthorizeCompletion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetCapAuthorizePreSales", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetCapAuthorizePreSalesResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        bool GetCapAuthorizePreSales();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetCapAuthorizeRefund", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetCapAuthorizeRefundResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        bool GetCapAuthorizeRefund();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetCapAuthorizeVoid", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetCapAuthorizeVoidResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        bool GetCapAuthorizeVoid();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetCapAuthorizeVoidPreSales", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetCapAuthorizeVoidPreSalesResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        bool GetCapAuthorizeVoidPreSales();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetCapCashDeposit", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetCapCashDepositResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        bool GetCapCashDeposit();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetCapCenterResultCode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetCapCenterResultCodeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        bool GetCapCenterResultCode();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetCapCheckCard", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetCapCheckCardResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        bool GetCapCheckCard();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetCapDailyLog", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetCapDailyLogResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        CATLogs GetCapDailyLog();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetCapInstallments", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetCapInstallmentsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        bool GetCapInstallments();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetCapLockTerminal", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetCapLockTerminalResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        bool GetCapLockTerminal();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetCapLogStatus", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetCapLogStatusResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        bool GetCapLogStatus();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetCapPaymentDetail", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetCapPaymentDetailResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        bool GetCapPaymentDetail();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetCapTaxOthers", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetCapTaxOthersResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        bool GetCapTaxOthers();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetCapTransactionNumber", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetCapTransactionNumberResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        bool GetCapTransactionNumber();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetCapTrainingMode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetCapTrainingModeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        bool GetCapTrainingMode();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetCapUnlockTerminal", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetCapUnlockTerminalResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        bool GetCapUnlockTerminal();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetCardCompanyID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetCardCompanyIDResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        string GetCardCompanyID();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetCenterResultCode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetCenterResultCodeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        string GetCenterResultCode();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetDailyLog", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetDailyLogResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        string GetDailyLog();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetLogStatus", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetLogStatusResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        DealingLogStatus GetLogStatus();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetPaymentCondition", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetPaymentConditionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        PaymentCondition GetPaymentCondition();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetPaymentDetail", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetPaymentDetailResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        string GetPaymentDetail();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetPaymentMedia", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetPaymentMediaResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        PaymentMedia GetPaymentMedia();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/SetPaymentMedia", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/SetPaymentMediaResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        void SetPaymentMedia(PaymentMedia PaymentMedia);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetSequenceNumber", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetSequenceNumberResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        int GetSequenceNumber();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetSettledAmount", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetSettledAmountResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        decimal GetSettledAmount();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetSlipNumber", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetSlipNumberResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        string GetSlipNumber();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetTrainingMode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetTrainingModeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        bool GetTrainingMode();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/SetTrainingMode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/SetTrainingModeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        void SetTrainingMode(bool TrainingMode);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetTransactionNumber", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetTransactionNumberResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        string GetTransactionNumber();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetTransactionType", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/GetTransactionTypeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        CreditTransactionType GetTransactionType();

        //
        // Common Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/Open", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/OpenResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        void Open(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/Close", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/CloseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        void Close(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/Claim", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/ClaimResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        void Claim(int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/Release", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/ReleaseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        void Release();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/CheckHealth", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/CheckHealthResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        void CheckHealth(HealthCheckLevel Level);

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/ClearInput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/ClearInputResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        // void ClearInput();

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/ClearInputProperties", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/ClearInputPropertiesResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        // void ClearInputProperties();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/ClearOutput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/ClearOutputResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        void ClearOutput();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/DirectIO", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/DirectIOResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        DirectIOData DirectIO(int Command, int Data, object Obj);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/CompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/CompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        CompareFirmwareResult CompareFirmwareVersion(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/ResetStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/ResetStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        void ResetStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/RetrieveStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/RetrieveStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        string RetrieveStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/UpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        void UpdateFirmware(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/UpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        void UpdateStatistics(StatisticList StatisticsBuffer);

        //
        // Specific Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/AccessDailyLog", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/AccessDailyLogResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        void AccessDailyLog(int SequenceNumber, CATLogs Type, int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/AuthorizeCompletion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/AuthorizeCompletionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        void AuthorizeCompletion(int SequenceNumber, decimal Amount, decimal TaxOthers, int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/AuthorizePreSales", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/AuthorizePreSalesResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        void AuthorizePreSales(int SequenceNumber, decimal Amount, decimal TaxOthers, int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/AuthorizeRefund", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/AuthorizeRefundResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        void AuthorizeRefund(int SequenceNumber, decimal Amount, decimal TaxOthers, int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/AuthorizeSales", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/AuthorizeSalesResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        void AuthorizeSales(int SequenceNumber, decimal Amount, decimal TaxOthers, int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/AuthorizeVoid", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/AuthorizeVoidResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        void AuthorizeVoid(int SequenceNumber, decimal Amount, decimal TaxOthers, int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/AuthorizeVoidPreSales", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/AuthorizeVoidPreSalesResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        void AuthorizeVoidPreSales(int SequenceNumber, decimal Amount, decimal TaxOthers, int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/CashDeposit", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/CashDepositResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        void CashDeposit(int SequenceNumber, decimal Amount, int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/CheckCard", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/CheckCardResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        void CheckCard(int SequenceNumber, int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/LockTerminal", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/LockTerminalResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        void LockTerminal();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UnlockTerminal", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CAT/UnlockTerminalResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CAT/UposException", Name = "UposException")]
        void UnlockTerminal();
    }

    //
    // Common Data Types
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CAT/")]
    public class DirectIOData
    {
        [DataMember]
        public int Data { get; set; }
        [DataMember]
        public object Obj { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CAT/")]
    public class UposException
    {
        [DataMember]
        public ErrorCode ErrorCode { get; set; }
        [DataMember]
        public int ErrorCodeExtended { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CAT/")]
    public class UposVersion
    {
        [DataMember]
        public int Major { get; set; }
        [DataMember]
        public int Minor { get; set; }
        [DataMember]
        public int Build { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CAT/")]
    public class Statistic
    {
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public string Value { get; set; }
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CAT/", ItemName = "Statistic")]
    public class StatisticList : List<Statistic>
    {
    }

    //
    // Common Enumerations
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CAT/")]
    public enum CompareFirmwareResult
    {
        [EnumMember]
        Different,
        [EnumMember]
        Newer,
        [EnumMember]
        Older,
        [EnumMember]
        Same,
        [EnumMember]
        Unknown,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CAT/")]
    public enum ControlState
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Closed,
        [EnumMember]
        Error,
        [EnumMember]
        Idle,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CAT/")]
    public enum ErrorCode
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Claimed,
        [EnumMember]
        Closed,
        [EnumMember]
        Deprecated,
        [EnumMember]
        Disabled,
        [EnumMember]
        Exists,
        [EnumMember]
        Extended,
        [EnumMember]
        Failure,
        [EnumMember]
        Illegal,
        [EnumMember]
        NoExist,
        [EnumMember]
        NoHardware,
        [EnumMember]
        NoService,
        [EnumMember]
        NotClaimed,
        [EnumMember]
        Offline,
        [EnumMember]
        Success,
        [EnumMember]
        Timeout,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CAT/")]
    public enum HealthCheckLevel
    {
        [EnumMember]
        External,
        [EnumMember]
        Interactive,
        [EnumMember]
        Internal,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CAT/")]
    public enum PowerNotification
    {
        [EnumMember]
        Disabled,
        [EnumMember]
        Enabled,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CAT/")]
    public enum PowerReporting
    {
        [EnumMember]
        Advanced,
        [EnumMember]
        None,
        [EnumMember]
        Standard,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CAT/")]
    public enum PowerState
    {
        [EnumMember]
        Off,
        [EnumMember]
        Offline,
        [EnumMember]
        OffOffline,
        [EnumMember]
        Online,
        [EnumMember]
        Unknown,
    }

    /*
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CAT/")]
    public enum StatisticCategories
    {
        [EnumMember]
        All,
        [EnumMember]
        Manufacturer,
        [EnumMember]
        Upos,
    }
    */
    public class StatisticCategories
    {
        public const string All = "";
        public const string Manufacturer = "M_";
        public const string Upos = "U_";
    }

    //
    // Specific Data Types
    //

    //
    // Specific Enumerations
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CAT/")]
    public enum CATLogs
    {
        [EnumMember]
        None,
        [EnumMember]
        Reporting,
        [EnumMember]
        ReportingAndSettlement,
        [EnumMember]
        Settlement,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CAT/")]
    public enum CreditTransactionType
    {
        [EnumMember]
        CashDeposit,
        [EnumMember]
        CheckCard,
        [EnumMember]
        Completion,
        [EnumMember]
        PreSales,
        [EnumMember]
        Refund,
        [EnumMember]
        Sales,
        [EnumMember]
        Void,
        [EnumMember]
        VoidPreSales,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CAT/")]
    public enum DealingLogStatus
    {
        [EnumMember]
        Full,
        [EnumMember]
        NearFull,
        [EnumMember]
        Ok,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CAT/")]
    public enum PaymentCondition
    {
        [EnumMember]
        Bonus1,
        [EnumMember]
        Bonus2,
        [EnumMember]
        Bonus3,
        [EnumMember]
        Bonus4,
        [EnumMember]
        Bonus5,
        [EnumMember]
        BonusCombination1,
        [EnumMember]
        BonusCombination2,
        [EnumMember]
        BonusCombination3,
        [EnumMember]
        BonusCombination4,
        [EnumMember]
        Debit,
        [EnumMember]
        ElectronicMoney,
        [EnumMember]
        Installment1,
        [EnumMember]
        Installment2,
        [EnumMember]
        Installment3,
        [EnumMember]
        Lump,
        [EnumMember]
        Revolving,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CAT/")]
    public enum PaymentMedia
    {
        [EnumMember]
        Credit,
        [EnumMember]
        Debit,
        [EnumMember]
        ElectronicMoney,
        [EnumMember]
        Unspecified,
    }

    //
    // Constants
    //

    /*
    public class Constants
    {
        public const int ExtendedErrorCenterError = 1;
        public const int ExtendedErrorCommandError = 90;
        public const int ExtendedErrorCommunicationError = 92;
        public const int ExtendedErrorDailyLogOverflow = 200;
        public const int ExtendedErrorDeficient = 201;
        public const int ExtendedErrorFirmwareBadFile = 281;
        public const int ExtendedErrorOverDeposit = 202;
        public const int ExtendedErrorReset = 91;
        public const int ExtendedErrorStatistics = 280;
        public const int ExtendedErrorStatisticsDependency = 282;
        public const string StatisticCommunicationErrorCount = "CommunicationErrorCount";
        public const string StatisticDeviceCategory = "DeviceCategory";
        public const string StatisticFirmwareRevision = "FirmwareRevision";
        public const string StatisticHoursPoweredCount = "HoursPoweredCount";
        public const string StatisticInstallationDate = "InstallationDate";
        public const string StatisticInterface = "Interface";
        public const string StatisticManufactureDate = "ManufactureDate";
        public const string StatisticManufacturerName = "ManufacturerName";
        public const string StatisticMechanicalRevision = "MechanicalRevision";
        public const string StatisticModelName = "ModelName";
        public const string StatisticSerialNumber = "SerialNumber";
        public const string StatisticUnifiedPOSVersion = "UnifiedPOSVersion";
        public const int WaitForever = -1;
    }
    */

    public class ExtendedError
    {
        public const int CenterError = 1;
        public const int CommandError = 90;
        public const int CommunicationError = 92;
        public const int DailyLogOverflow = 200;
        public const int Deficient = 201;
        public const int FirmwareBadFile = 281;
        public const int OverDeposit = 202;
        public const int Reset = 91;
        public const int Statistics = 280;
        public const int StatisticsDependency = 282;
    }

    public class StatisticProperties
    {
        public const string CommunicationErrorCount = "CommunicationErrorCount";
        public const string DeviceCategory = "DeviceCategory";
        public const string FirmwareRevision = "FirmwareRevision";
        public const string HoursPoweredCount = "HoursPoweredCount";
        public const string InstallationDate = "InstallationDate";
        public const string Interface = "Interface";
        public const string ManufactureDate = "ManufactureDate";
        public const string ManufacturerName = "ManufacturerName";
        public const string MechanicalRevision = "MechanicalRevision";
        public const string ModelName = "ModelName";
        public const string SerialNumber = "SerialNumber";
        public const string UnifiedPOSVersion = "UnifiedPOSVersion";
    }
    
    public class Wait
    {
        public const int Forever = -1;
    }
}
