
package org.nrf_arts.unifiedpos.belt;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="GetDeviceServiceDescriptionResult" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "getDeviceServiceDescriptionResult"
})
@XmlRootElement(name = "GetDeviceServiceDescriptionResponse")
public class GetDeviceServiceDescriptionResponse {

    @XmlElement(name = "GetDeviceServiceDescriptionResult", nillable = true)
    protected String getDeviceServiceDescriptionResult;

    /**
     * Gets the value of the getDeviceServiceDescriptionResult property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGetDeviceServiceDescriptionResult() {
        return getDeviceServiceDescriptionResult;
    }

    /**
     * Sets the value of the getDeviceServiceDescriptionResult property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGetDeviceServiceDescriptionResult(String value) {
        this.getDeviceServiceDescriptionResult = value;
    }

}
