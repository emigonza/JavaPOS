﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace UnifiedPOS.SignatureCapture
{
    [ServiceContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/")]
    public interface SignatureCapture
    {

        //
        // Common Properties
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetAutoDisableResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/UposException", Name = "UposException")]
        bool GetAutoDisable();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/SetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/SetAutoDisableResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/UposException", Name = "UposException")]
        void SetAutoDisable(bool AutoDisable);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetCapCompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetCapCompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/UposException", Name = "UposException")]
        bool GetCapCompareFirmwareVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetCapPowerReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetCapPowerReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/UposException", Name = "UposException")]
        PowerReporting GetCapPowerReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetCapStatisticsReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetCapStatisticsReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/UposException", Name = "UposException")]
        bool GetCapStatisticsReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetCapUpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetCapUpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/UposException", Name = "UposException")]
        bool GetCapUpdateFirmware();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetCapUpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetCapUpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/UposException", Name = "UposException")]
        bool GetCapUpdateStatistics();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetCheckHealthText", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetCheckHealthTextResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/UposException", Name = "UposException")]
        string GetCheckHealthText();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetClaimed", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetClaimedResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/UposException", Name = "UposException")]
        bool GetClaimed();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetDataCount", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetDataCountResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/UposException", Name = "UposException")]
        int GetDataCount();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetDataEventEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/UposException", Name = "UposException")]
        bool GetDataEventEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/SetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/SetDataEventEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/UposException", Name = "UposException")]
        void SetDataEventEnabled(bool DataEventEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/UposException", Name = "UposException")]
        bool GetDeviceEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/SetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/SetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/UposException", Name = "UposException")]
        void SetDeviceEnabled(bool DeviceEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/UposException", Name = "UposException")]
        bool GetFreezeEvents();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/SetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/SetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/UposException", Name = "UposException")]
        void SetFreezeEvents(bool FreezeEvents);

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetOutputID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetOutputIDResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/UposException", Name = "UposException")]
        // int GetOutputID();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/UposException", Name = "UposException")]
        PowerNotification GetPowerNotify();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/SetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/SetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/UposException", Name = "UposException")]
        void SetPowerNotify(PowerNotification PowerNotify);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetPowerState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetPowerStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/UposException", Name = "UposException")]
        PowerState GetPowerState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/UposException", Name = "UposException")]
        ControlState GetState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetDeviceControlDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetDeviceControlDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/UposException", Name = "UposException")]
        string GetDeviceControlDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetDeviceControlVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetDeviceControlVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/UposException", Name = "UposException")]
        UposVersion GetDeviceControlVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetDeviceServiceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetDeviceServiceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/UposException", Name = "UposException")]
        string GetDeviceServiceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetDeviceServiceVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetDeviceServiceVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/UposException", Name = "UposException")]
        UposVersion GetDeviceServiceVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetPhysicalDeviceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetPhysicalDeviceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/UposException", Name = "UposException")]
        string GetPhysicalDeviceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetPhysicalDeviceName", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetPhysicalDeviceNameResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/UposException", Name = "UposException")]
        string GetPhysicalDeviceName();

        //
        // Specific Properties
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetCapDisplay", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetCapDisplayResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/UposException", Name = "UposException")]
        bool GetCapDisplay();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetCapRealTimeData", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetCapRealTimeDataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/UposException", Name = "UposException")]
        bool GetCapRealTimeData();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetCapUserTerminated", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetCapUserTerminatedResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/UposException", Name = "UposException")]
        bool GetCapUserTerminated();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetMaximumX", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetMaximumXResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/UposException", Name = "UposException")]
        int GetMaximumX();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetMaximumY", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetMaximumYResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/UposException", Name = "UposException")]
        int GetMaximumY();

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetPointArray", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetPointArrayResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/UposException", Name = "UposException")]
        // System.Drawing.Point[] GetPointArray();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetPointArray", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetPointArrayResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/UposException", Name = "UposException")]
        PointList GetPointArray();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetRawData", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetRawDataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/UposException", Name = "UposException")]
        byte[] GetRawData();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetRealTimeDataEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/GetRealTimeDataEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/UposException", Name = "UposException")]
        bool GetRealTimeDataEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/SetRealTimeDataEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/SetRealTimeDataEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/UposException", Name = "UposException")]
        void SetRealTimeDataEnabled(bool RealTimeDataEnabled);

        //
        // Common Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/Open", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/OpenResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/UposException", Name = "UposException")]
        void Open(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/Close", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/CloseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/UposException", Name = "UposException")]
        void Close(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/Claim", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/ClaimResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/UposException", Name = "UposException")]
        void Claim(int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/Release", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/ReleaseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/UposException", Name = "UposException")]
        void Release();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/CheckHealth", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/CheckHealthResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/UposException", Name = "UposException")]
        void CheckHealth(HealthCheckLevel Level);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/ClearInput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/ClearInputResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/UposException", Name = "UposException")]
        void ClearInput();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/ClearInputProperties", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/ClearInputPropertiesResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/UposException", Name = "UposException")]
        void ClearInputProperties();

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/ClearOutput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/ClearOutputResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/UposException", Name = "UposException")]
        // void ClearOutput();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/DirectIO", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/DirectIOResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/UposException", Name = "UposException")]
        DirectIOData DirectIO(int Command, int Data, object Obj);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/CompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/CompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/UposException", Name = "UposException")]
        CompareFirmwareResult CompareFirmwareVersion(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/ResetStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/ResetStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/UposException", Name = "UposException")]
        void ResetStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/RetrieveStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/RetrieveStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/UposException", Name = "UposException")]
        string RetrieveStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/UpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/UpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/UposException", Name = "UposException")]
        void UpdateFirmware(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/UpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/UpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/UposException", Name = "UposException")]
        void UpdateStatistics(StatisticList StatisticsBuffer);

        //
        // Specific Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/BeginCapture", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/BeginCaptureResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/UposException", Name = "UposException")]
        void BeginCapture(string FormName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/EndCapture", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/EndCaptureResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/UposException", Name = "UposException")]
        void EndCapture();

    }

    //
    // Common Data Types
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/")]
    public class DirectIOData
    {
        [DataMember]
        public int Data { get; set; }
        [DataMember]
        public object Obj { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/")]
    public class UposException
    {
        [DataMember]
        public ErrorCode ErrorCode { get; set; }
        [DataMember]
        public int ErrorCodeExtended { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/")]
    public class UposVersion
    {
        [DataMember]
        public int Major { get; set; }
        [DataMember]
        public int Minor { get; set; }
        [DataMember]
        public int Build { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/")]
    public class Statistic
    {
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public string Value { get; set; }
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/", ItemName = "Statistic")]
    public class StatisticList : List<Statistic>
    {
    }

    //
    // Common Enumerations
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/")]
    public enum CompareFirmwareResult
    {
        [EnumMember]
        Different,
        [EnumMember]
        Newer,
        [EnumMember]
        Older,
        [EnumMember]
        Same,
        [EnumMember]
        Unknown,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/")]
    public enum ControlState
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Closed,
        [EnumMember]
        Error,
        [EnumMember]
        Idle,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/")]
    public enum ErrorCode
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Claimed,
        [EnumMember]
        Closed,
        [EnumMember]
        Deprecated,
        [EnumMember]
        Disabled,
        [EnumMember]
        Exists,
        [EnumMember]
        Extended,
        [EnumMember]
        Failure,
        [EnumMember]
        Illegal,
        [EnumMember]
        NoExist,
        [EnumMember]
        NoHardware,
        [EnumMember]
        NoService,
        [EnumMember]
        NotClaimed,
        [EnumMember]
        Offline,
        [EnumMember]
        Success,
        [EnumMember]
        Timeout,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/")]
    public enum HealthCheckLevel
    {
        [EnumMember]
        External,
        [EnumMember]
        Interactive,
        [EnumMember]
        Internal,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/")]
    public enum PowerNotification
    {
        [EnumMember]
        Disabled,
        [EnumMember]
        Enabled,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/")]
    public enum PowerReporting
    {
        [EnumMember]
        Advanced,
        [EnumMember]
        None,
        [EnumMember]
        Standard,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/")]
    public enum PowerState
    {
        [EnumMember]
        Off,
        [EnumMember]
        Offline,
        [EnumMember]
        OffOffline,
        [EnumMember]
        Online,
        [EnumMember]
        Unknown,
    }

    // [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/")]
    // public enum StatisticCategories
    // {
    //     [EnumMember]
    //     All,
    //     [EnumMember]
    //     Manufacturer,
    //     [EnumMember]
    //     Upos,
    // }

    public class StatisticCategories
    {
        public const string All = "";
        public const string Manufacturer = "M_";
        public const string Upos = "U_";
    }

    //
    // Specific Data Types
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/")]
    public class Point
    {
        [DataMember]
        public int X { get; set; }
        [DataMember]
        public int Y { get; set; }
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/SignatureCapture/", ItemName = "Point")]
    public class PointList : List<Point>
    {
    }

    //
    // Specific Enumerations
    //

    //
    // Constants
    //

    public class ExtendedError
    {
        public const int FirmwareBadFile = 281;
        public const int Statistics = 280;
        public const int StatisticsDependency = 282;
    }

    public class StatisticProperties
    {
        public const string CommunicationErrorCount = "CommunicationErrorCount";
        public const string DeviceCategory = "DeviceCategory";
        public const string FailedSignatureReadCount = "FailedSignatureReadCount";
        public const string FirmwareRevision = "FirmwareRevision";
        public const string GoodSignatureReadCount = "GoodSignatureReadCount";
        public const string HoursPoweredCount = "HoursPoweredCount";
        public const string InstallationDate = "InstallationDate";
        public const string Interface = "Interface";
        public const string ManufactureDate = "ManufactureDate";
        public const string ManufacturerName = "ManufacturerName";
        public const string MechanicalRevision = "MechanicalRevision";
        public const string ModelName = "ModelName";
        public const string SerialNumber = "SerialNumber";
        public const string UnifiedPOSVersion = "UnifiedPOSVersion";
    }

    public class Wait
    {
        public const int Forever = -1;
    }
}
