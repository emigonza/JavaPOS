﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace UnifiedPOS.RFIDScanner
{
    [ServiceContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/")]
    public interface RFIDScanner
    {

        //
        // Common Properties
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetAutoDisableResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        bool GetAutoDisable();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/SetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/SetAutoDisableResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        void SetAutoDisable(bool AutoDisable);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetCapCompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetCapCompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        bool GetCapCompareFirmwareVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetCapPowerReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetCapPowerReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        PowerReporting GetCapPowerReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetCapStatisticsReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetCapStatisticsReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        bool GetCapStatisticsReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetCapUpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetCapUpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        bool GetCapUpdateFirmware();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetCapUpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetCapUpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        bool GetCapUpdateStatistics();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetCheckHealthText", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetCheckHealthTextResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        string GetCheckHealthText();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetClaimed", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetClaimedResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        bool GetClaimed();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetDataCount", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetDataCountResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        int GetDataCount();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetDataEventEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        bool GetDataEventEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/SetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/SetDataEventEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        void SetDataEventEnabled(bool DataEventEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        bool GetDeviceEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/SetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/SetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        void SetDeviceEnabled(bool DeviceEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        bool GetFreezeEvents();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/SetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/SetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        void SetFreezeEvents(bool FreezeEvents);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetOutputID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetOutputIDResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        int GetOutputID();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        PowerNotification GetPowerNotify();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/SetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/SetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        void SetPowerNotify(PowerNotification PowerNotify);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetPowerState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetPowerStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        PowerState GetPowerState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        ControlState GetState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetDeviceControlDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetDeviceControlDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        string GetDeviceControlDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetDeviceControlVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetDeviceControlVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        UposVersion GetDeviceControlVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetDeviceServiceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetDeviceServiceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        string GetDeviceServiceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetDeviceServiceVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetDeviceServiceVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        UposVersion GetDeviceServiceVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetPhysicalDeviceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetPhysicalDeviceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        string GetPhysicalDeviceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetPhysicalDeviceName", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetPhysicalDeviceNameResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        string GetPhysicalDeviceName();

        //
        // Specific Properties
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetCapContinuousRead", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetCapContinuousReadResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        bool GetCapContinuousRead();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetCapDisableTag", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetCapDisableTagResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        bool GetCapDisableTag();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetCapLockTag", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetCapLockTagResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        bool GetCapLockTag();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetCapMultipleProtocols", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetCapMultipleProtocolsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        int GetCapMultipleProtocols();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetCapReadTimer", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetCapReadTimerResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        bool GetCapReadTimer();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetCapWriteTag", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetCapWriteTagResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        WriteTagSections GetCapWriteTag();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetContinuousReadMode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetContinuousReadModeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        bool GetContinuousReadMode();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetCurrentTagID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetCurrentTagIDResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        byte[] GetCurrentTagID();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetCurrentTagProtocol", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetCurrentTagProtocolResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        int GetCurrentTagProtocol();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetCurrentTagUserData", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetCurrentTagUserDataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        byte[] GetCurrentTagUserData();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetProtocolMask", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetProtocolMaskResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        int GetProtocolMask();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/SetProtocolMask", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/SetProtocolMaskResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        void SetProtocolMask(int ProtocolMask);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetReadTimerInterval", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetReadTimerIntervalResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        int GetReadTimerInterval();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/SetReadTimerInterval", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/SetReadTimerIntervalResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        void SetReadTimerInterval(int ReadTimerInterval);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetTagCount", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/GetTagCountResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        int GetTagCount();

        //
        // Common Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/Open", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/OpenResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        void Open(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/Close", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/CloseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        void Close(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/Claim", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/ClaimResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        void Claim(int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/Release", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/ReleaseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        void Release();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/CheckHealth", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/CheckHealthResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        void CheckHealth(HealthCheckLevel Level);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/ClearInput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/ClearInputResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        void ClearInput();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/ClearInputProperties", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/ClearInputPropertiesResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        void ClearInputProperties();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/ClearOutput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/ClearOutputResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        void ClearOutput();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/DirectIO", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/DirectIOResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        DirectIOData DirectIO(int Command, int Data, object Obj);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/CompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/CompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        CompareFirmwareResult CompareFirmwareVersion(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/ResetStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/ResetStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        void ResetStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/RetrieveStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/RetrieveStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        string RetrieveStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        void UpdateFirmware(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        void UpdateStatistics(StatisticList StatisticsBuffer);

        //
        // Specific Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/DisableTag", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/DisableTagResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        void DisableTag(byte[] TagID, int Timeout, byte[] Password);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/FirstTag", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/FirstTagResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        void FirstTag();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/LockTag", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/LockTagResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        void LockTag(byte[] TagID, int Timeout, byte[] Password);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/NextTag", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/NextTagResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        void NextTag();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/PreviousTag", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/PreviousTagResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        void PreviousTag();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/ReadTags", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/ReadTagsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        void ReadTags(RFIDReadOptions Cmd, byte[] FilterID, byte[] FilterMask, int Start, int Length, int Timeout, byte[] Password);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/StartReadTags", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/StartReadTagsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        void StartReadTags(RFIDReadOptions Cmd, byte[] FilterID, byte[] FilterMask, int Start, int Length, byte[] Password);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/StopReadTags", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/StopReadTagsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        void StopReadTags(byte[] Password);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/WriteTagData", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/WriteTagDataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        void WriteTagData(byte[] TagID, byte[] UserData, int Start, int Timeout, byte[] Password);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/WriteTagID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/WriteTagIDResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/UposException", Name = "UposException")]
        void WriteTagID(byte[] SourceTagID, byte[] DestinationTagID, int Timeout, byte[] Password);

    }

    //
    // Common Data Types
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/")]
    public class DirectIOData
    {
        [DataMember]
        public int Data { get; set; }
        [DataMember]
        public object Obj { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/")]
    public class UposException
    {
        [DataMember]
        public ErrorCode ErrorCode { get; set; }
        [DataMember]
        public int ErrorCodeExtended { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/")]
    public class UposVersion
    {
        [DataMember]
        public int Major { get; set; }
        [DataMember]
        public int Minor { get; set; }
        [DataMember]
        public int Build { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/")]
    public class Statistic
    {
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public string Value { get; set; }
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/", ItemName = "Statistic")]
    public class StatisticList : List<Statistic>
    {
    }

    //
    // Common Enumerations
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/")]
    public enum CompareFirmwareResult
    {
        [EnumMember]
        Different,
        [EnumMember]
        Newer,
        [EnumMember]
        Older,
        [EnumMember]
        Same,
        [EnumMember]
        Unknown,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/")]
    public enum ControlState
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Closed,
        [EnumMember]
        Error,
        [EnumMember]
        Idle,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/")]
    public enum ErrorCode
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Claimed,
        [EnumMember]
        Closed,
        [EnumMember]
        Deprecated,
        [EnumMember]
        Disabled,
        [EnumMember]
        Exists,
        [EnumMember]
        Extended,
        [EnumMember]
        Failure,
        [EnumMember]
        Illegal,
        [EnumMember]
        NoExist,
        [EnumMember]
        NoHardware,
        [EnumMember]
        NoService,
        [EnumMember]
        NotClaimed,
        [EnumMember]
        Offline,
        [EnumMember]
        Success,
        [EnumMember]
        Timeout,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/")]
    public enum HealthCheckLevel
    {
        [EnumMember]
        External,
        [EnumMember]
        Interactive,
        [EnumMember]
        Internal,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/")]
    public enum PowerNotification
    {
        [EnumMember]
        Disabled,
        [EnumMember]
        Enabled,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/")]
    public enum PowerReporting
    {
        [EnumMember]
        Advanced,
        [EnumMember]
        None,
        [EnumMember]
        Standard,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/")]
    public enum PowerState
    {
        [EnumMember]
        Off,
        [EnumMember]
        Offline,
        [EnumMember]
        OffOffline,
        [EnumMember]
        Online,
        [EnumMember]
        Unknown,
    }

    /*
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/")]
    public enum StatisticCategories
    {
        [EnumMember]
        All,
        [EnumMember]
        Manufacturer,
        [EnumMember]
        Upos,
    }
    */
    public class StatisticCategories
    {
        public const string All = "";
        public const string Manufacturer = "M_";
        public const string Upos = "U_";
    }

    //
    // Specific Data Types
    //

    //
    // Specific Enumerations
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/")]
    public enum WriteTagSections
    {
        [EnumMember]
        None,
        [EnumMember]
        IdOnly,
        [EnumMember]
        UserData,
        [EnumMember]
        All,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/RFIDScanner/")]
    public enum RFIDReadOptions
    {
        [EnumMember]
        FullUserData,
        [EnumMember]
        PartialUserData,
        [EnumMember]
        TagId,
        [EnumMember]
        IdAndFullUserData,
        [EnumMember]
        IdAndPartialUserData,
    }

    //
    // Constants
    //

    public class ExtendedError
    {
        public const int FirmwareBadFile = 281;
        public const int Statistics = 280;
        public const int StatisticsDependency = 282;
    }

    public class StatisticProperties
    {
        public const string CommunicationErrorCount = "CommunicationErrorCount";
        public const string DeviceCategory = "DeviceCategory";
        public const string FirmwareRevision = "FirmwareRevision";
        public const string HoursPoweredCount = "HoursPoweredCount";
        public const string InstallationDate = "InstallationDate";
        public const string Interface = "Interface";
        public const string ManufactureDate = "ManufactureDate";
        public const string ManufacturerName = "ManufacturerName";
        public const string MechanicalRevision = "MechanicalRevision";
        public const string ModelName = "ModelName";
        public const string SerialNumber = "SerialNumber";
        public const string UnifiedPOSVersion = "UnifiedPOSVersion";
        public const string TagReadCount = "TagReadCount";
        public const string GoodTagWriteCount = "GoodTagWriteCount";
        public const string FailedTagWriteCount = "FailedTagWriteCount";
        public const string GoodTagLockCount = "GoodTagLockCount";
        public const string FailedTagLockCount = "FailedTagLockCount";
        public const string GoodTagDisableCount = "GoodTagDisableCount";
        public const string FailedTagDisableCount = "FailedTagDisableCount";
    }

    public class Wait
    {
        public const int Forever = -1;
    }

    public class RFIDProtocols
    {
        public const int EpcClass0 = 1;
        public const int RFIDSdt0Plus = 2;
        public const int EpcClass1 = 4;
        public const int EpcClass1Gen2 = 8;
        public const int EpcClass2 = 16;
        public const int Iso14443A = 4096;
        public const int Iso14443B = 8192;
        public const int Iso15693 = 12288;
        public const int Iso180006B = 16384;
        public const int Other = 16777216;
        public const int All = 1073741824;
    }

}
