/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package wspos;

import java.math.BigDecimal;
import java.net.URL;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import jpos.events.DataEvent;
import jpos.events.DirectIOEvent;
import jpos.events.ErrorEvent;
import jpos.events.StatusUpdateEvent;
import org.nrf_arts.unifiedpos.pinpad.*;
import javax.jws.WebService;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.namespace.QName;
import javax.xml.ws.Service;

/**
 *
 * @author hideon
 */
@WebService(serviceName = "PINPadService", endpointInterface = "org.nrf_arts.unifiedpos.pinpad.PINPad", targetNamespace = "http://www.nrf-arts.org/UnifiedPOS/PINPad/")
public class PINPadService implements PINPad, jpos.events.DataListener, jpos.events.DirectIOListener, jpos.events.ErrorListener, jpos.events.StatusUpdateListener {

    //
    // PINPad Enumration Converter
    //

    private static HashMap<Enum, Integer> jposConst;
    private static HashMap<Enum, String> jposString;
    private static HashMap<Integer, PowerReporting> powerReporting;
    private static HashMap<Integer, PowerNotification> powerNotification;
    private static HashMap<Integer, PowerState> powerState;
    private static HashMap<Integer, ControlState> controlState;
    private static HashMap<Integer, HealthCheckLevel> healthCheckLevel;
    private static HashMap<Integer, CompareFirmwareResult> compareFirmwareResult;
    private static HashMap<Integer, ErrorCode> errorCode;
    private static HashMap<Integer, PINPadDisplay> pinPadDisplay;
    private static HashMap<Integer, PINPadLanguage> pinPadLanguage;
    private static HashMap<Integer, EFTTransactionType> eftTransactionType;
    private static HashMap<String, PINPadSystem> pinPadSystem;
    private static HashMap<Integer, EFTTransactionCompletion> eftTransactionCompletion;

    private static HashMap<Enum, Integer> jposEventConst;
    private static HashMap<Integer, org.nrf_arts.unifiedpos.pinpadevents.ErrorCode> eventErrorCode;
    private static HashMap<Integer, org.nrf_arts.unifiedpos.pinpadevents.ErrorLocus> eventErrorLocus;
    private static HashMap<Integer, org.nrf_arts.unifiedpos.pinpadevents.ErrorResponse> eventErrorResponse;

    static {
        jposConst = new HashMap<Enum, Integer>();
        jposConst.put(PowerReporting.ADVANCED, jpos.PINPad.JPOS_PR_ADVANCED);
        jposConst.put(PowerReporting.NONE, jpos.PINPad.JPOS_PR_NONE);
        jposConst.put(PowerReporting.STANDARD, jpos.PINPad.JPOS_PR_STANDARD);
        jposConst.put(PowerNotification.DISABLED, jpos.PINPad.JPOS_PN_DISABLED);
        jposConst.put(PowerNotification.ENABLED, jpos.PINPad.JPOS_PN_ENABLED);
        jposConst.put(PowerState.OFF, jpos.PINPad.JPOS_PS_OFF);
        jposConst.put(PowerState.OFFLINE, jpos.PINPad.JPOS_PS_OFFLINE);
        jposConst.put(PowerState.OFF_OFFLINE, jpos.PINPad.JPOS_PS_OFF_OFFLINE);
        jposConst.put(PowerState.ONLINE, jpos.PINPad.JPOS_PS_ONLINE);
        jposConst.put(PowerState.UNKNOWN, jpos.PINPad.JPOS_PS_UNKNOWN);
        jposConst.put(ControlState.BUSY, jpos.PINPad.JPOS_S_BUSY);
        jposConst.put(ControlState.CLOSED, jpos.PINPad.JPOS_S_CLOSED);
        jposConst.put(ControlState.ERROR, jpos.PINPad.JPOS_S_ERROR);
        jposConst.put(ControlState.IDLE, jpos.PINPad.JPOS_S_IDLE);
        jposConst.put(HealthCheckLevel.EXTERNAL, jpos.PINPad.JPOS_CH_EXTERNAL);
        jposConst.put(HealthCheckLevel.INTERACTIVE, jpos.PINPad.JPOS_CH_INTERACTIVE);
        jposConst.put(HealthCheckLevel.INTERNAL, jpos.PINPad.JPOS_CH_INTERNAL);
        jposConst.put(CompareFirmwareResult.DIFFERENT, jpos.PINPad.JPOS_CFV_FIRMWARE_DIFFERENT);
        jposConst.put(CompareFirmwareResult.NEWER, jpos.PINPad.JPOS_CFV_FIRMWARE_NEWER);
        jposConst.put(CompareFirmwareResult.OLDER, jpos.PINPad.JPOS_CFV_FIRMWARE_OLDER);
        jposConst.put(CompareFirmwareResult.SAME, jpos.PINPad.JPOS_CFV_FIRMWARE_SAME);
        jposConst.put(CompareFirmwareResult.UNKNOWN, jpos.PINPad.JPOS_CFV_FIRMWARE_UNKNOWN);
        jposConst.put(ErrorCode.BUSY, jpos.PINPad.JPOS_E_BUSY);
        jposConst.put(ErrorCode.CLAIMED, jpos.PINPad.JPOS_E_CLAIMED);
        jposConst.put(ErrorCode.CLOSED, jpos.PINPad.JPOS_E_CLOSED);
        jposConst.put(ErrorCode.DEPRECATED, jpos.PINPad.JPOS_E_DEPRECATED);
        jposConst.put(ErrorCode.DISABLED, jpos.PINPad.JPOS_E_DISABLED);
        jposConst.put(ErrorCode.EXISTS, jpos.PINPad.JPOS_E_EXISTS);
        jposConst.put(ErrorCode.EXTENDED, jpos.PINPad.JPOS_E_EXTENDED);
        jposConst.put(ErrorCode.FAILURE, jpos.PINPad.JPOS_E_FAILURE);
        jposConst.put(ErrorCode.ILLEGAL, jpos.PINPad.JPOS_E_ILLEGAL);
        jposConst.put(ErrorCode.NO_EXIST, jpos.PINPad.JPOS_E_NOEXIST);
        jposConst.put(ErrorCode.NO_HARDWARE, jpos.PINPad.JPOS_E_NOHARDWARE);
        jposConst.put(ErrorCode.NO_SERVICE, jpos.PINPad.JPOS_E_NOSERVICE);
        jposConst.put(ErrorCode.NOT_CLAIMED, jpos.PINPad.JPOS_E_NOTCLAIMED);
        jposConst.put(ErrorCode.OFFLINE, jpos.PINPad.JPOS_E_OFFLINE);
        jposConst.put(ErrorCode.SUCCESS, 0);
        jposConst.put(ErrorCode.TIMEOUT, jpos.PINPad.JPOS_E_TIMEOUT);
        jposConst.put(PINPadDisplay.NONE, jpos.PINPadConst.PPAD_DISP_NONE);
        jposConst.put(PINPadDisplay.PIN_RESTRICTED, jpos.PINPadConst.PPAD_DISP_PINRESTRICTED);
        jposConst.put(PINPadDisplay.RESTRICTED_LIST, jpos.PINPadConst.PPAD_DISP_RESTRICTED_LIST);
        jposConst.put(PINPadDisplay.RESTRICTED_ORDER, jpos.PINPadConst.PPAD_DISP_RESTRICTED_ORDER);
        jposConst.put(PINPadDisplay.UNRESTRICTED, jpos.PINPadConst.PPAD_DISP_UNRESTRICTED);
        jposConst.put(PINPadLanguage.NONE, jpos.PINPadConst.PPAD_LANG_NONE);
        jposConst.put(PINPadLanguage.ONE, jpos.PINPadConst.PPAD_LANG_ONE);
        jposConst.put(PINPadLanguage.PIN_RESTRICTED, jpos.PINPadConst.PPAD_LANG_PINRESTRICTED);
        jposConst.put(PINPadLanguage.UNRESTRICTED, jpos.PINPadConst.PPAD_LANG_UNRESTRICTED);
        jposConst.put(EFTTransactionType.ADMIN, jpos.PINPadConst.PPAD_TRANS_ADMIN);
        jposConst.put(EFTTransactionType.CREDIT, jpos.PINPadConst.PPAD_TRANS_CREDIT);
        jposConst.put(EFTTransactionType.DEBIT, jpos.PINPadConst.PPAD_TRANS_DEBIT);
        jposConst.put(EFTTransactionType.INQUIRY, jpos.PINPadConst.PPAD_TRANS_INQ);
        jposConst.put(EFTTransactionType.RECONCILE, jpos.PINPadConst.PPAD_TRANS_RECONCILE);
        jposConst.put(EFTTransactionCompletion.ABNORMAL, jpos.PINPadConst.PPAD_EFT_ABNORMAL);
        jposConst.put(EFTTransactionCompletion.NORMAL, jpos.PINPadConst.PPAD_EFT_NORMAL);

        jposString = new HashMap<Enum, String>();
        jposString.put(PINPadSystem.APACS_40, "APACS40");
        jposString.put(PINPadSystem.AS_2805, "AS2805");
        jposString.put(PINPadSystem.DUKPT, "DUKPT");
        jposString.put(PINPadSystem.HGEPOS, "HGEPOS");
        jposString.put(PINPadSystem.JDEBIT_2, "JDEBIT2");
        jposString.put(PINPadSystem.MASTER_SESSION, "M/S");

        powerReporting = new HashMap<Integer, PowerReporting>();
        powerReporting.put(jpos.PINPad.JPOS_PR_ADVANCED, PowerReporting.ADVANCED);
        powerReporting.put(jpos.PINPad.JPOS_PR_NONE, PowerReporting.NONE);
        powerReporting.put(jpos.PINPad.JPOS_PR_STANDARD, PowerReporting.STANDARD);

        powerNotification = new HashMap<Integer, PowerNotification>();
        powerNotification.put(jpos.PINPad.JPOS_PN_DISABLED, PowerNotification.DISABLED);
        powerNotification.put(jpos.PINPad.JPOS_PN_ENABLED, PowerNotification.ENABLED);

        powerState = new HashMap<Integer, PowerState>();
        powerState.put(jpos.PINPad.JPOS_PS_OFF, PowerState.OFF);
        powerState.put(jpos.PINPad.JPOS_PS_OFFLINE, PowerState.OFFLINE);
        powerState.put(jpos.PINPad.JPOS_PS_OFF_OFFLINE, PowerState.OFF_OFFLINE);
        powerState.put(jpos.PINPad.JPOS_PS_ONLINE, PowerState.ONLINE);
        powerState.put(jpos.PINPad.JPOS_PS_UNKNOWN, PowerState.UNKNOWN);

        controlState = new HashMap<Integer, ControlState>();
        controlState.put(jpos.PINPad.JPOS_S_BUSY, ControlState.BUSY);
        controlState.put(jpos.PINPad.JPOS_S_CLOSED, ControlState.CLOSED);
        controlState.put(jpos.PINPad.JPOS_S_ERROR, ControlState.ERROR);
        controlState.put(jpos.PINPad.JPOS_S_IDLE, ControlState.IDLE);

        healthCheckLevel = new HashMap<Integer, HealthCheckLevel>();
        healthCheckLevel.put(jpos.PINPad.JPOS_CH_EXTERNAL, HealthCheckLevel.EXTERNAL);
        healthCheckLevel.put(jpos.PINPad.JPOS_CH_INTERACTIVE, HealthCheckLevel.INTERACTIVE);
        healthCheckLevel.put(jpos.PINPad.JPOS_CH_INTERNAL, HealthCheckLevel.INTERNAL);

        compareFirmwareResult = new HashMap<Integer, CompareFirmwareResult>();
        compareFirmwareResult.put(jpos.PINPad.JPOS_CFV_FIRMWARE_DIFFERENT, CompareFirmwareResult.DIFFERENT);
        compareFirmwareResult.put(jpos.PINPad.JPOS_CFV_FIRMWARE_NEWER, CompareFirmwareResult.NEWER);
        compareFirmwareResult.put(jpos.PINPad.JPOS_CFV_FIRMWARE_OLDER, CompareFirmwareResult.OLDER);
        compareFirmwareResult.put(jpos.PINPad.JPOS_CFV_FIRMWARE_SAME, CompareFirmwareResult.SAME);
        compareFirmwareResult.put(jpos.PINPad.JPOS_CFV_FIRMWARE_UNKNOWN, CompareFirmwareResult.UNKNOWN);

        errorCode = new HashMap<Integer, ErrorCode>();
        errorCode.put(jpos.PINPad.JPOS_E_BUSY, ErrorCode.BUSY);
        errorCode.put(jpos.PINPad.JPOS_E_CLAIMED, ErrorCode.CLAIMED);
        errorCode.put(jpos.PINPad.JPOS_E_CLOSED, ErrorCode.CLOSED);
        errorCode.put(jpos.PINPad.JPOS_E_DEPRECATED, ErrorCode.DEPRECATED);
        errorCode.put(jpos.PINPad.JPOS_E_DISABLED, ErrorCode.DISABLED);
        errorCode.put(jpos.PINPad.JPOS_E_EXISTS, ErrorCode.EXISTS);
        errorCode.put(jpos.PINPad.JPOS_E_EXTENDED, ErrorCode.EXTENDED);
        errorCode.put(jpos.PINPad.JPOS_E_FAILURE, ErrorCode.FAILURE);
        errorCode.put(jpos.PINPad.JPOS_E_ILLEGAL, ErrorCode.ILLEGAL);
        errorCode.put(jpos.PINPad.JPOS_E_NOEXIST, ErrorCode.NO_EXIST);
        errorCode.put(jpos.PINPad.JPOS_E_NOHARDWARE, ErrorCode.NO_HARDWARE);
        errorCode.put(jpos.PINPad.JPOS_E_NOSERVICE, ErrorCode.NO_SERVICE);
        errorCode.put(jpos.PINPad.JPOS_E_NOTCLAIMED, ErrorCode.NOT_CLAIMED);
        errorCode.put(jpos.PINPad.JPOS_E_OFFLINE, ErrorCode.OFFLINE);
        errorCode.put(0, ErrorCode.SUCCESS);
        errorCode.put(jpos.PINPad.JPOS_E_TIMEOUT, ErrorCode.TIMEOUT);

        pinPadDisplay = new HashMap<Integer, PINPadDisplay>();
        pinPadDisplay.put(jpos.PINPadConst.PPAD_DISP_NONE, PINPadDisplay.NONE);
        pinPadDisplay.put(jpos.PINPadConst.PPAD_DISP_PINRESTRICTED, PINPadDisplay.PIN_RESTRICTED);
        pinPadDisplay.put(jpos.PINPadConst.PPAD_DISP_RESTRICTED_LIST, PINPadDisplay.RESTRICTED_LIST);
        pinPadDisplay.put(jpos.PINPadConst.PPAD_DISP_RESTRICTED_ORDER, PINPadDisplay.RESTRICTED_ORDER);
        pinPadDisplay.put(jpos.PINPadConst.PPAD_DISP_UNRESTRICTED, PINPadDisplay.UNRESTRICTED);

        pinPadLanguage = new HashMap<Integer, PINPadLanguage>();
        pinPadLanguage.put(jpos.PINPadConst.PPAD_LANG_NONE, PINPadLanguage.NONE);
        pinPadLanguage.put(jpos.PINPadConst.PPAD_LANG_ONE, PINPadLanguage.ONE);
        pinPadLanguage.put(jpos.PINPadConst.PPAD_LANG_PINRESTRICTED, PINPadLanguage.PIN_RESTRICTED);
        pinPadLanguage.put(jpos.PINPadConst.PPAD_LANG_UNRESTRICTED, PINPadLanguage.UNRESTRICTED);

        eftTransactionType = new HashMap<Integer, EFTTransactionType>();
        eftTransactionType.put(jpos.PINPadConst.PPAD_TRANS_ADMIN, EFTTransactionType.ADMIN);
        eftTransactionType.put(jpos.PINPadConst.PPAD_TRANS_CREDIT, EFTTransactionType.CREDIT);
        eftTransactionType.put(jpos.PINPadConst.PPAD_TRANS_DEBIT, EFTTransactionType.DEBIT);
        eftTransactionType.put(jpos.PINPadConst.PPAD_TRANS_INQ, EFTTransactionType.INQUIRY);
        eftTransactionType.put(jpos.PINPadConst.PPAD_TRANS_RECONCILE, EFTTransactionType.RECONCILE);

        pinPadSystem = new HashMap<String, PINPadSystem>();
        pinPadSystem.put("APACS40", PINPadSystem.APACS_40);
        pinPadSystem.put("AS2805", PINPadSystem.AS_2805);
        pinPadSystem.put("DUKPT", PINPadSystem.DUKPT);
        pinPadSystem.put("HGEPOS", PINPadSystem.HGEPOS);
        pinPadSystem.put("JDEBIT2", PINPadSystem.JDEBIT_2);
        pinPadSystem.put("M/S", PINPadSystem.MASTER_SESSION);

        eftTransactionCompletion = new HashMap<Integer, EFTTransactionCompletion>();
        eftTransactionCompletion.put(jpos.PINPadConst.PPAD_EFT_ABNORMAL, EFTTransactionCompletion.ABNORMAL);
        eftTransactionCompletion.put(jpos.PINPadConst.PPAD_EFT_NORMAL, EFTTransactionCompletion.NORMAL);

        jposEventConst = new HashMap<Enum, Integer>();
        jposEventConst.put(org.nrf_arts.unifiedpos.pinpadevents.ErrorCode.BUSY, jpos.PINPad.JPOS_E_BUSY);
        jposEventConst.put(org.nrf_arts.unifiedpos.pinpadevents.ErrorCode.CLAIMED, jpos.PINPad.JPOS_E_CLAIMED);
        jposEventConst.put(org.nrf_arts.unifiedpos.pinpadevents.ErrorCode.CLOSED, jpos.PINPad.JPOS_E_CLOSED);
        jposEventConst.put(org.nrf_arts.unifiedpos.pinpadevents.ErrorCode.DEPRECATED, jpos.PINPad.JPOS_E_DEPRECATED);
        jposEventConst.put(org.nrf_arts.unifiedpos.pinpadevents.ErrorCode.DISABLED, jpos.PINPad.JPOS_E_DISABLED);
        jposEventConst.put(org.nrf_arts.unifiedpos.pinpadevents.ErrorCode.EXISTS, jpos.PINPad.JPOS_E_EXISTS);
        jposEventConst.put(org.nrf_arts.unifiedpos.pinpadevents.ErrorCode.EXTENDED, jpos.PINPad.JPOS_E_EXTENDED);
        jposEventConst.put(org.nrf_arts.unifiedpos.pinpadevents.ErrorCode.FAILURE, jpos.PINPad.JPOS_E_FAILURE);
        jposEventConst.put(org.nrf_arts.unifiedpos.pinpadevents.ErrorCode.ILLEGAL, jpos.PINPad.JPOS_E_ILLEGAL);
        jposEventConst.put(org.nrf_arts.unifiedpos.pinpadevents.ErrorCode.NO_EXIST, jpos.PINPad.JPOS_E_NOEXIST);
        jposEventConst.put(org.nrf_arts.unifiedpos.pinpadevents.ErrorCode.NO_HARDWARE, jpos.PINPad.JPOS_E_NOHARDWARE);
        jposEventConst.put(org.nrf_arts.unifiedpos.pinpadevents.ErrorCode.NO_SERVICE, jpos.PINPad.JPOS_E_NOSERVICE);
        jposEventConst.put(org.nrf_arts.unifiedpos.pinpadevents.ErrorCode.NOT_CLAIMED, jpos.PINPad.JPOS_E_NOTCLAIMED);
        jposEventConst.put(org.nrf_arts.unifiedpos.pinpadevents.ErrorCode.OFFLINE, jpos.PINPad.JPOS_E_OFFLINE);
        jposEventConst.put(org.nrf_arts.unifiedpos.pinpadevents.ErrorCode.SUCCESS, 0);
        jposEventConst.put(org.nrf_arts.unifiedpos.pinpadevents.ErrorCode.TIMEOUT, jpos.PINPad.JPOS_E_TIMEOUT);
        jposEventConst.put(org.nrf_arts.unifiedpos.pinpadevents.ErrorLocus.INPUT, jpos.PINPad.JPOS_EL_INPUT);
        jposEventConst.put(org.nrf_arts.unifiedpos.pinpadevents.ErrorLocus.INPUT_DATA, jpos.PINPad.JPOS_EL_INPUT_DATA);
        jposEventConst.put(org.nrf_arts.unifiedpos.pinpadevents.ErrorLocus.OUTPUT, jpos.PINPad.JPOS_EL_OUTPUT);
        jposEventConst.put(org.nrf_arts.unifiedpos.pinpadevents.ErrorResponse.CLEAR, jpos.PINPad.JPOS_ER_CLEAR);
        jposEventConst.put(org.nrf_arts.unifiedpos.pinpadevents.ErrorResponse.CONTINUE_INPUT, jpos.PINPad.JPOS_ER_CONTINUEINPUT);
        jposEventConst.put(org.nrf_arts.unifiedpos.pinpadevents.ErrorResponse.RETRY, jpos.PINPad.JPOS_ER_RETRY);

        eventErrorCode = new HashMap<Integer, org.nrf_arts.unifiedpos.pinpadevents.ErrorCode>();
        eventErrorCode.put(jpos.PINPad.JPOS_E_BUSY, org.nrf_arts.unifiedpos.pinpadevents.ErrorCode.BUSY);
        eventErrorCode.put(jpos.PINPad.JPOS_E_CLAIMED, org.nrf_arts.unifiedpos.pinpadevents.ErrorCode.CLAIMED);
        eventErrorCode.put(jpos.PINPad.JPOS_E_CLOSED, org.nrf_arts.unifiedpos.pinpadevents.ErrorCode.CLOSED);
        eventErrorCode.put(jpos.PINPad.JPOS_E_DEPRECATED, org.nrf_arts.unifiedpos.pinpadevents.ErrorCode.DEPRECATED);
        eventErrorCode.put(jpos.PINPad.JPOS_E_DISABLED, org.nrf_arts.unifiedpos.pinpadevents.ErrorCode.DISABLED);
        eventErrorCode.put(jpos.PINPad.JPOS_E_EXISTS, org.nrf_arts.unifiedpos.pinpadevents.ErrorCode.EXISTS);
        eventErrorCode.put(jpos.PINPad.JPOS_E_EXTENDED, org.nrf_arts.unifiedpos.pinpadevents.ErrorCode.EXTENDED);
        eventErrorCode.put(jpos.PINPad.JPOS_E_FAILURE, org.nrf_arts.unifiedpos.pinpadevents.ErrorCode.FAILURE);
        eventErrorCode.put(jpos.PINPad.JPOS_E_ILLEGAL, org.nrf_arts.unifiedpos.pinpadevents.ErrorCode.ILLEGAL);
        eventErrorCode.put(jpos.PINPad.JPOS_E_NOEXIST, org.nrf_arts.unifiedpos.pinpadevents.ErrorCode.NO_EXIST);
        eventErrorCode.put(jpos.PINPad.JPOS_E_NOHARDWARE, org.nrf_arts.unifiedpos.pinpadevents.ErrorCode.NO_HARDWARE);
        eventErrorCode.put(jpos.PINPad.JPOS_E_NOSERVICE, org.nrf_arts.unifiedpos.pinpadevents.ErrorCode.NO_SERVICE);
        eventErrorCode.put(jpos.PINPad.JPOS_E_NOTCLAIMED, org.nrf_arts.unifiedpos.pinpadevents.ErrorCode.NOT_CLAIMED);
        eventErrorCode.put(jpos.PINPad.JPOS_E_OFFLINE, org.nrf_arts.unifiedpos.pinpadevents.ErrorCode.OFFLINE);
        eventErrorCode.put(0, org.nrf_arts.unifiedpos.pinpadevents.ErrorCode.SUCCESS);
        eventErrorCode.put(jpos.PINPad.JPOS_E_TIMEOUT, org.nrf_arts.unifiedpos.pinpadevents.ErrorCode.TIMEOUT);

        eventErrorLocus = new HashMap<Integer, org.nrf_arts.unifiedpos.pinpadevents.ErrorLocus>();
        eventErrorLocus.put(jpos.PINPad.JPOS_EL_INPUT, org.nrf_arts.unifiedpos.pinpadevents.ErrorLocus.INPUT);
        eventErrorLocus.put(jpos.PINPad.JPOS_EL_INPUT_DATA, org.nrf_arts.unifiedpos.pinpadevents.ErrorLocus.INPUT_DATA);
        eventErrorLocus.put(jpos.PINPad.JPOS_EL_OUTPUT, org.nrf_arts.unifiedpos.pinpadevents.ErrorLocus.OUTPUT);

        eventErrorResponse = new HashMap<Integer, org.nrf_arts.unifiedpos.pinpadevents.ErrorResponse>();
        eventErrorResponse.put(jpos.PINPad.JPOS_ER_CLEAR, org.nrf_arts.unifiedpos.pinpadevents.ErrorResponse.CLEAR);
        eventErrorResponse.put(jpos.PINPad.JPOS_ER_CONTINUEINPUT, org.nrf_arts.unifiedpos.pinpadevents.ErrorResponse.CONTINUE_INPUT);
        eventErrorResponse.put(jpos.PINPad.JPOS_ER_RETRY, org.nrf_arts.unifiedpos.pinpadevents.ErrorResponse.RETRY);
    }

    private String deviceName;
    private UposVersion deviceControlVersion;
    private org.nrf_arts.unifiedpos.pinpadevents.PINPadEvent deviceEvent;
    private jpos.PINPad device = new jpos.PINPad();
    private DatatypeFactory datatypeFactory;

    public PINPadService(String logicalDeviceName) {
        deviceName = logicalDeviceName;
        deviceControlVersion = new UposVersion();
        deviceControlVersion.setMajor(1);
        deviceControlVersion.setMinor(13);
        deviceControlVersion.setBuild(1);
        try {
            datatypeFactory = DatatypeFactory.newInstance();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    //
    // PINPad Member
    //

    public void beginEFTTransaction(PINPadSystem pinPadSystem, Integer transactionHost) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.beginEFTTransaction(jposString.get(pinPadSystem), transactionHost);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void checkHealth(HealthCheckLevel level) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.checkHealth(jposConst.get(level));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void claim(Integer timeout) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.claim(timeout);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void clearInput() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.clearInput();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void clearInputProperties() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.clearInputProperties();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void close(String endpointAddress) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            if (deviceEvent != null)
            {
                device.removeDataListener(this);
                device.removeDirectIOListener(this);
                device.removeErrorListener(this);
                device.removeStatusUpdateListener(this);
                deviceEvent = null;
            }
            device.close();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public CompareFirmwareResult compareFirmwareVersion(String firmwareFileName) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            int[] param = new int[1];
            device.compareFirmwareVersion(firmwareFileName, param);
            return compareFirmwareResult.get(param[0]);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String computeMAC(String inMsg) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            String[] param = new String[1];
            device.computeMAC(inMsg, param);
            return param[0];
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public DirectIOData directIO(Integer command, Integer data, Object obj) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            DirectIOData res = new DirectIOData();
            int[] param = new int[] { data };
            device.directIO(command, param, obj);
            res.setData(param[0]);
            res.setObj(obj);
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void enablePINEntry() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.enablePINEntry();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void endEFTTransaction(EFTTransactionCompletion completionCode) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.endEFTTransaction(jposConst.get(completionCode));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getAccountNumber() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getAccountNumber();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getAdditionalSecurityInformation() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getAdditionalSecurityInformation();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public BigDecimal getAmount() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return BigDecimal.valueOf(device.getAmount()).scaleByPowerOfTen(-4);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public LanguageList getAvailableLanguagesList() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            LanguageList res = new LanguageList();
            List<String> list = res.getLanguage();
            for (String s : device.getAvailableLanguagesList().replace(',', '-').split(";")) {
                list.add(s);
            }
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public PINPadMessageList getAvailablePromptsList() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            PINPadMessageList res = new PINPadMessageList();
            List<Integer> list = res.getPINPadMessage();
            for (String s : device.getAvailablePromptsList().split(",")) {
                list.add(Integer.valueOf(s));
            }
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapCompareFirmwareVersion() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapCompareFirmwareVersion();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public PINPadDisplay getCapDisplay() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return pinPadDisplay.get(device.getCapDisplay());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapKeyboard() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapKeyboard();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public PINPadLanguage getCapLanguage() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return pinPadLanguage.get(device.getCapLanguage());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapMACCalculation() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapMACCalculation();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public PowerReporting getCapPowerReporting() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return powerReporting.get(device.getCapPowerReporting());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapStatisticsReporting() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapStatisticsReporting();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapTone() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapTone();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapUpdateFirmware() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapUpdateFirmware();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapUpdateStatistics() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapUpdateStatistics();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getCheckHealthText() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCheckHealthText();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getClaimed() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getClaimed();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getDataCount() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getDataCount();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getDataEventEnabled() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getDataEventEnabled();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getDeviceControlDescription() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        return device.getDeviceControlDescription();
    }

    public UposVersion getDeviceControlVersion() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        UposVersion res = new UposVersion();
        int version = device.getDeviceControlVersion();
        res.setMajor(version / 1000000 % 1000);
        res.setMinor(version / 1000 % 1000);
        res.setBuild(version % 1000);
        return res;
    }

    public Boolean getDeviceEnabled() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getDeviceEnabled();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getDeviceServiceDescription() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getDeviceServiceDescription();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public UposVersion getDeviceServiceVersion() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            UposVersion res = new UposVersion();
            int version = device.getDeviceServiceVersion();
            res.setMajor(version / 1000000 % 1000);
            res.setMinor(version / 1000 % 1000);
            res.setBuild(version % 1000);
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getEncryptedPIN() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getEncryptedPIN();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getFreezeEvents() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getFreezeEvents();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getMaximumPINLength() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getMaximumPINLength();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getMerchantID() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getMerchantID();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getMinimumPINLength() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getMinimumPINLength();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getPINEntryEnabled() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getPINEntryEnabled();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getPhysicalDeviceDescription() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getPhysicalDeviceDescription();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getPhysicalDeviceName() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getPhysicalDeviceName();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public PowerNotification getPowerNotify() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return powerNotification.get(device.getPowerNotify());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public PowerState getPowerState() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return powerState.get(device.getPowerState());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getPrompt() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getPrompt();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getPromptLanguage() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getPromptLanguage();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public ControlState getState() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        return controlState.get(device.getState());
    }

    public String getTerminalID() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getTerminalID();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public byte[] getTrack1Data() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getTrack1Data();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public byte[] getTrack2Data() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getTrack2Data();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public byte[] getTrack3Data() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getTrack3Data();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public byte[] getTrack4Data() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getTrack4Data();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public EFTTransactionType getTransactionType() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return eftTransactionType.get(device.getTransactionType());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void open(String endpointAddress) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.open(deviceName);
            if (endpointAddress != null)
            {
                try {
                    Service service = Service.create(
                            new URL(endpointAddress + "?wsdl"),
                            new QName("http://www.nrf-arts.org/UnifiedPOS/PINPadEvents/", "PINPadEventService"));
                    deviceEvent = service.getPort(org.nrf_arts.unifiedpos.pinpadevents.PINPadEvent.class);
                    device.addDataListener(this);
                    device.addDirectIOListener(this);
                    device.addErrorListener(this);
                    device.addStatusUpdateListener(this);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void release() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.release();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void resetStatistics(StatisticList statisticsBuffer) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            String param = null;
            List<Statistic> list = statisticsBuffer.getStatistic();
            switch (list.size()) {
                case 0:
                    param = "";
                    break;
                case 1:
                    String name = list.get(0).getName();
                    if (name.equals(StatisticCategories.ALL)) {
                        param = "";
                    }
                    else if (name.equals(StatisticCategories.MANUFACTURER)) {
                        param = "M_";
                    }
                    else if (name.equals(StatisticCategories.UPOS)) {
                        param = "U_";
                    }
                    else {
                        param = name;
                    }
                    break;
                default:
                    StringBuffer buffer = new StringBuffer();
                    for (Statistic statistic : statisticsBuffer.getStatistic()) {
                        buffer.append(",").append(statistic.getName());
                    }
                    param = buffer.substring(1);
                    break;
            }
            device.resetStatistics(param);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String retrieveStatistics(StatisticList statisticsBuffer) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            String[] param = new String[1];
            List<Statistic> list = statisticsBuffer.getStatistic();
            switch (list.size()) {
                case 0:
                    param[0] = "";
                    break;
                case 1:
                    String name = list.get(0).getName();
                    if (name.equals(StatisticCategories.ALL)) {
                        param[0] = "";
                    }
                    else if (name.equals(StatisticCategories.MANUFACTURER)) {
                        param[0] = "M_";
                    }
                    else if (name.equals(StatisticCategories.UPOS)) {
                        param[0] = "U_";
                    }
                    else {
                        param[0] = name;
                    }
                    break;
                default:
                    StringBuffer buffer = new StringBuffer();
                    for (Statistic statistic : statisticsBuffer.getStatistic()) {
                        buffer.append(",").append(statistic.getName());
                    }
                    param[0] = buffer.substring(1);
                    break;
            }
            device.retrieveStatistics(param);
            return param[0];
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setAccountNumber(String accountNumber) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setAccountNumber(accountNumber);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setAmount(BigDecimal amount) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setAmount(amount.scaleByPowerOfTen(4).longValue());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setDataEventEnabled(Boolean dataEventEnabled) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setDataEventEnabled(dataEventEnabled);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setDeviceEnabled(Boolean deviceEnabled) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setDeviceEnabled(deviceEnabled);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setFreezeEvents(Boolean freezeEvents) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setFreezeEvents(freezeEvents);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setMaximumPINLength(Integer maximumPINLength) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setMaximumPINLength(maximumPINLength);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setMerchantID(String merchantID) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setMerchantID(merchantID);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setMinimumPINLength(Integer minimumPINLength) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setMinimumPINLength(minimumPINLength);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setPowerNotify(PowerNotification powerNotify) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setPowerNotify(jposConst.get(powerNotify));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setPrompt(Integer prompt) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setPrompt(prompt);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setPromptLanguage(String promptLanguage) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setPromptLanguage(promptLanguage);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setTerminalID(String terminalID) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setTerminalID(terminalID);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setTrack1Data(byte[] track1Data) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setTrack1Data(track1Data);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setTrack2Data(byte[] track2Data) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setTrack2Data(track2Data);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setTrack3Data(byte[] track3Data) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setTrack3Data(track3Data);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setTrack4Data(byte[] track4Data) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setTrack4Data(track4Data);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setTransactionType(EFTTransactionType transactionType) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setTransactionType(jposConst.get(transactionType));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void updateFirmware(String firmwareFileName) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.updateFirmware(firmwareFileName);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void updateKey(Integer keyNum, String key) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.updateKey(keyNum, key);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void updateStatistics(StatisticList statisticsBuffer) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            String param = null;
            List<Statistic> list = statisticsBuffer.getStatistic();
            switch (list.size()) {
                case 0:
                    param = "";
                    break;
                case 1:
                    Statistic s = list.get(0);
                    String name = s.getName();
                    String value = s.getValue();
                    if (name.equals(StatisticCategories.ALL)) {
                        param = "=" + value;
                    }
                    else if (name.equals(StatisticCategories.MANUFACTURER)) {
                        param = "M_=" + value;
                    }
                    else if (name.equals(StatisticCategories.UPOS)) {
                        param = "U_=" + value;
                    }
                    else {
                        param = name + "=" + value;
                    }
                    break;
                default:
                    StringBuffer buffer = new StringBuffer();
                    for (Statistic statistic : statisticsBuffer.getStatistic()) {
                        buffer.append(",").append(statistic.getName()).append("=").append(statistic.getValue());
                    }
                    param = buffer.substring(1);
                    break;
            }
            device.updateStatistics(param);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void verifyMAC(String message) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.verifyMAC(message);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    //
    // PINPadEvent Member
    //

    public void dataOccurred(DataEvent de) {
        //throw new UnsupportedOperationException("Not supported yet.");
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(new Date(de.getWhen()));
        deviceEvent.dataEvent(
                de.getSource().toString(),
                (int)de.getSequenceNumber(),
                datatypeFactory.newXMLGregorianCalendar(cal),
                de.getStatus());
    }

    public void directIOOccurred(DirectIOEvent dioe) {
        //throw new UnsupportedOperationException("Not supported yet.");
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(new Date(dioe.getWhen()));
        org.nrf_arts.unifiedpos.pinpadevents.DirectIOData value = deviceEvent.directIOEvent(
                dioe.getSource().toString(),
                (int)dioe.getSequenceNumber(),
                datatypeFactory.newXMLGregorianCalendar(cal),
                dioe.getEventNumber(),
                dioe.getData(),
                dioe.getObject());
        dioe.setData(value.getData());
        dioe.setObject(value.getObj());
    }

    public void errorOccurred(ErrorEvent ee) {
        //throw new UnsupportedOperationException("Not supported yet.");
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(new Date(ee.getWhen()));
        org.nrf_arts.unifiedpos.pinpadevents.ErrorResponse value = deviceEvent.errorEvent(
                ee.getSource().toString(),
                (int)ee.getSequenceNumber(),
                datatypeFactory.newXMLGregorianCalendar(cal),
                eventErrorCode.get(ee.getErrorCode()),
                ee.getErrorCodeExtended(),
                eventErrorLocus.get(ee.getErrorLocus()),
                eventErrorResponse.get(ee.getErrorResponse()));
        ee.setErrorResponse(jposEventConst.get(value));
    }

    public void statusUpdateOccurred(StatusUpdateEvent sue) {
        //throw new UnsupportedOperationException("Not supported yet.");
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(new Date(sue.getWhen()));
        deviceEvent.statusUpdateEvent(
                sue.getSource().toString(),
                (int)sue.getSequenceNumber(),
                datatypeFactory.newXMLGregorianCalendar(cal),
                sue.getStatus());
    }

}
