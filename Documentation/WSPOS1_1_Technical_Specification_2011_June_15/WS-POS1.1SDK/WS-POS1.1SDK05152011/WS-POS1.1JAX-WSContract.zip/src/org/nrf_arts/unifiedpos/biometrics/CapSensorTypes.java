/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.nrf_arts.unifiedpos.biometrics;

/**
 *
 * @author 1127431970104
 */
public class CapSensorTypes {
        public static final int NONE = 0;
        public static final int FACIAL_FEATURES = 1;
        public static final int VOICE = 2;
        public static final int FINGERPRINT = 4;
        public static final int IRIS = 8;
        public static final int RETINA = 16;
        public static final int HAND_GEOMETRY = 32;
        public static final int SIGNATURE_DYNAMICS = 64;
        public static final int KEYSTROKE_DYNAMICS = 128;
        public static final int LIP_MOVEMENT = 256;
        public static final int THERMAL_FACE_IMAGE = 512;
        public static final int THERMAL_HAND_IMAGE = 1024;
        public static final int GAIT = 2048;
        public static final int PASSWORD = 4096;

}
