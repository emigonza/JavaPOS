﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace UnifiedPOS.Biometrics
{
    [ServiceContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/")]
    public interface Biometrics
    {

        //
        // Common Properties
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetAutoDisableResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        bool GetAutoDisable();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/SetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/SetAutoDisableResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        void SetAutoDisable(bool AutoDisable);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetCapCompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetCapCompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        bool GetCapCompareFirmwareVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetCapPowerReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetCapPowerReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        PowerReporting GetCapPowerReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetCapStatisticsReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetCapStatisticsReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        bool GetCapStatisticsReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetCapUpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetCapUpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        bool GetCapUpdateFirmware();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetCapUpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetCapUpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        bool GetCapUpdateStatistics();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetCheckHealthText", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetCheckHealthTextResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        string GetCheckHealthText();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetClaimed", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetClaimedResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        bool GetClaimed();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetDataCount", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetDataCountResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        int GetDataCount();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetDataEventEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        bool GetDataEventEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/SetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/SetDataEventEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        void SetDataEventEnabled(bool DataEventEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        bool GetDeviceEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/SetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/SetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        void SetDeviceEnabled(bool DeviceEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        bool GetFreezeEvents();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/SetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/SetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        void SetFreezeEvents(bool FreezeEvents);

        // Not Supported
        //[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetOutputID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetOutputIDResponse")]
        //[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        //int GetOutputID();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        PowerNotification GetPowerNotify();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/SetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/SetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        void SetPowerNotify(PowerNotification PowerNotify);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetPowerState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetPowerStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        PowerState GetPowerState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        ControlState GetState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetDeviceControlDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetDeviceControlDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        string GetDeviceControlDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetDeviceControlVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetDeviceControlVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        UposVersion GetDeviceControlVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetDeviceServiceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetDeviceServiceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        string GetDeviceServiceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetDeviceServiceVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetDeviceServiceVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        UposVersion GetDeviceServiceVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetPhysicalDeviceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetPhysicalDeviceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        string GetPhysicalDeviceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetPhysicalDeviceName", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetPhysicalDeviceNameResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        string GetPhysicalDeviceName();

        //
        // Specific Properties
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetAlgorithm", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetAlgorithmResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        int GetAlgorithm();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/SetAlgorithm", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/SetAlgorithmResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        void SetAlgorithm(int Algorithm);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetAlgorithmList", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetAlgorithmListResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        AlgorithmList GetAlgorithmList();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetBIR", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetBIRResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        BiometricsInformationRecord GetBIR();
        
        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetCapPrematchData", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetCapPrematchDataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        bool GetCapPrematchData();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetCapRawSensorData", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetGetCapRawSensorDataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        bool GetCapRawSensorData();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetCapRealTimeData", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetCapRealTimeDataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        bool GetCapRealTimeData();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetCapSensorColor", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetCapSensorColorResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        int GetCapSensorColor();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetCapSensorOrientation", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetCapSensorOrientationResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        int GetCapSensorOrientation();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetCapSensorType", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetCapSensorTypeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        int GetCapSensorType();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetCapTemplateAdaptation", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetCapTemplateAdaptationResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        bool GetCapTemplateAdaptation();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetRawSensorData", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetRawSensorDataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        byte[] GetRawSensorData();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetRealTimeDataEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetRealTimeDataEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        bool GetRealTimeDataEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/SetRealTimeDataEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/SetRealTimeDataEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        void SetRealTimeDataEnabled(bool RealTimeDataEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetSensorBPP", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetSensorBPPResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        int GetSensorBPP();
        
        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetSensorColor", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetSensorColorResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        SensorColor GetSensorColor();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/SetSensorColor", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/SetSensorColorResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        void SetSensorColor(SensorColor SensorColor);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetSensorHeight", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetSensorHeightResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        int GetSensorHeight();
        
        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetSensorOrientation", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetSensorOrientationResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        SensorOrientation GetSensorOrientation();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/SetSensorOrientation", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/SetSensorOrientationResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        void SetSensorOrientation(SensorOrientation SensorOrientation);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetSensorType", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetSensorTypeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        SensorType GetSensorType();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/SetSensorType", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/SetSensorTypeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        void SetSensorType(SensorType SensorType);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetSensorWidth", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/GetSensorWidth")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        int GetSensorWidth();
        
        //
        // Common Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/Open", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/OpenResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        void Open(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/Close", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/CloseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        void Close(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/Claim", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/ClaimResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        void Claim(int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/Release", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/ReleaseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        void Release();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/CheckHealth", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/CheckHealthResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        void CheckHealth(HealthCheckLevel Level);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/ClearInput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/ClearInputResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        void ClearInput();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/ClearInputProperties", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/ClearInputPropertiesResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        void ClearInputProperties();

        // Not Supported
        //[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/ClearOutput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/ClearOutputResponse")]
        //[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        //void ClearOutput();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/DirectIO", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/DirectIOResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        DirectIOData DirectIO(int Command, int Data, object Obj);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/CompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/CompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        CompareFirmwareResult CompareFirmwareVersion(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/ResetStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/ResetStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        void ResetStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/RetrieveStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/RetrieveStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        string RetrieveStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        void UpdateFirmware(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        void UpdateStatistics(StatisticList StatisticsBuffer);

        //
        // Specific Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/BeginEnrollCapture", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/BeginEnrollCaptureResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        void BeginEnrollCapture(BiometricsInformationRecord ReferenceBIR, byte[] Payload);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/BeginVerifyCapture", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/BeginVerifyCaptureResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        void BeginVerifyCapture();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/EndCapture", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/EndCaptureResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        void EndCapture();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/Identify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/IdentifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        IdentifyList Identify(int MaxFARRequested, int MaxFRRRequested, bool FARPrecedence, BiometricsInformationRecordList ReferenceBIRPopulation, int Timeout);
        
        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/IdentifyMatch", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/IdentifyMatchResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        IdentifyMatchList IdentifyMatch(int MaxFARRequested, int MaxFRRRequested, bool FARPrecedence, BiometricsInformationRecord SampleBIR, BiometricsInformationRecordList ReferenceBIRPopulation);
        
        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/ProcessPrematchData", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/ProcessPrematchDataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        BiometricsInformationRecord ProcessPrematchData(BiometricsInformationRecord SampleBIR, BiometricsInformationRecord PrematchDataBIR);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/Verify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/VerifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        BiometricsVerifyResult Verify(int MaxFARRequested, int MaxFRRRequested, bool FARPrecedence, BiometricsInformationRecord ReferenceBIR, bool AdaptBIR, int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/VerifyMatch", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/VerifyMatchResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/UposException", Name = "UposException")]
        BiometricsVerifyResult VerifyMatch(int MaxFARRequested, int MaxFRRRequested, bool FARPrecedence, BiometricsInformationRecord SampleBIR, BiometricsInformationRecord ReferenceBIR, bool AdaptBIR);


    }

    //
    // Common Data Types
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/")]
    public class DirectIOData
    {
        [DataMember]
        public int Data { get; set; }
        [DataMember]
        public object Obj { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/")]
    public class UposException
    {
        [DataMember]
        public ErrorCode ErrorCode { get; set; }
        [DataMember]
        public int ErrorCodeExtended { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/")]
    public class UposVersion
    {
        [DataMember]
        public int Major { get; set; }
        [DataMember]
        public int Minor { get; set; }
        [DataMember]
        public int Build { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/")]
    public class Statistic
    {
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public string Value { get; set; }
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/", ItemName = "Statistic")]
    public class StatisticList : List<Statistic>
    {
    }

    //
    // Common Enumerations
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/")]
    public enum CompareFirmwareResult
    {
        [EnumMember]
        Different,
        [EnumMember]
        Newer,
        [EnumMember]
        Older,
        [EnumMember]
        Same,
        [EnumMember]
        Unknown,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/")]
    public enum ControlState
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Closed,
        [EnumMember]
        Error,
        [EnumMember]
        Idle,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/")]
    public enum ErrorCode
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Claimed,
        [EnumMember]
        Closed,
        [EnumMember]
        Deprecated,
        [EnumMember]
        Disabled,
        [EnumMember]
        Exists,
        [EnumMember]
        Extended,
        [EnumMember]
        Failure,
        [EnumMember]
        Illegal,
        [EnumMember]
        NoExist,
        [EnumMember]
        NoHardware,
        [EnumMember]
        NoService,
        [EnumMember]
        NotClaimed,
        [EnumMember]
        Offline,
        [EnumMember]
        Success,
        [EnumMember]
        Timeout,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/")]
    public enum HealthCheckLevel
    {
        [EnumMember]
        External,
        [EnumMember]
        Interactive,
        [EnumMember]
        Internal,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/")]
    public enum PowerNotification
    {
        [EnumMember]
        Disabled,
        [EnumMember]
        Enabled,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/")]
    public enum PowerReporting
    {
        [EnumMember]
        Advanced,
        [EnumMember]
        None,
        [EnumMember]
        Standard,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/")]
    public enum PowerState
    {
        [EnumMember]
        Off,
        [EnumMember]
        Offline,
        [EnumMember]
        OffOffline,
        [EnumMember]
        Online,
        [EnumMember]
        Unknown,
    }

    /*
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/")]
    public enum StatisticCategories
    {
        [EnumMember]
        All,
        [EnumMember]
        Manufacturer,
        [EnumMember]
        Upos,
    }
    */
    public class StatisticCategories
    {
        public const string All = "";
        public const string Manufacturer = "M_";
        public const string Upos = "U_";
    }

    //
    // Specific Data Types
    //

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/", ItemName = "Identify")]
    public class IdentifyList : List<int>
    {
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/", ItemName = "IdentifyMatch")]
    public class IdentifyMatchList : List<int>
    {
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/", ItemName = "Algorithm")]
    public class AlgorithmList : List<string>
    {
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/", ItemName = "CandidateRanking")]
    public class CandidateRankingList : List<int>
    {
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/", ItemName = "BiometricsInformationRecord")]
    public class BiometricsInformationRecordList : List<BiometricsInformationRecord>
    {
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/")]
    public class BiometricsInformationRecord
    {
        [DataMember]
        public int BiometricDataBlockSize { get; set; }
        [DataMember]
        public DateTime CreatedTime { get; set; }
        [DataMember]
        public int DataType { get; set; }
        [DataMember]
        public int FormatId { get; set; }
        [DataMember]
        public int FormatOwner { get; set; }
        [DataMember]
        public BIRPurpose Purpose { get; set; }
        [DataMember]
        public SensorType SensorType { get; set; }
        [DataMember]
        public UposVersion Version { get; set; }
        [DataMember]
        public byte[] BiometricDataBlock { get; set; }

    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/")]
    public class BiometricsVerifyResult
    {
        [DataMember]
        public BiometricsInformationRecord AdaptedBIR { get; set; }
        [DataMember]
        public int FARAchieved { get; set; }
        [DataMember]
        public int FRRAchieved { get; set; }
        [DataMember]
        public bool Result { get; set; }
        [DataMember]
        public byte[] Payload { get; set; }
    }

    //
    // Specific Enumerations
    //

    //[DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/")]
    //public enum CapSensorColors
    //{
    //    [EnumMember]
    //    Color16,
    //    [EnumMember]
    //    Color256,
    //    [EnumMember]
    //    Full,
    //    [EnumMember]
    //    Grayscale,
    //    [EnumMember]
    //    Mono,
    //    [EnumMember]
    //    None,
    //}
    //[DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/")]
    public class CapSensorColors
    {
        public const int None = 0;
        public const int Mono = 1;
        public const int Grayscale = 2;
        public const int Color16 = 4;
        public const int Color256 = 8;
        public const int Full = 16;
    }


    //[DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/")]
    //public enum CapSensorOrientations
    //{
    //    [EnumMember]
    //    Inverted,
    //    [EnumMember]
    //    Left,
    //    [EnumMember]
    //    None,
    //    [EnumMember]
    //    Normal,
    //    [EnumMember]
    //    Right,
    //}
    //[DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/")]
    public class CapSensorOrientations
    {
        public const int None = 0;
        public const int Normal = 1;
        public const int Right = 2;
        public const int Inverted = 4;
        public const int Left = 8;
    }

    //[DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/")]
    //public enum CapSensorTypes
    //{
    //    [EnumMember]
    //    FacialFeatures,
    //    [EnumMember]
    //    Fingerprint,
    //    [EnumMember]
    //    Gait,
    //    [EnumMember]
    //    HandGeometry,
    //    [EnumMember]
    //    Iris,
    //    [EnumMember]
    //    KeystrokeDynamics,
    //    [EnumMember]
    //    LipMovement,
    //    [EnumMember]
    //    None,
    //    [EnumMember]
    //    Password,
    //    [EnumMember]
    //    Retina,
    //    [EnumMember]
    //    SignatureDynamics,
    //    [EnumMember]
    //    ThermalFaceImage,
    //    [EnumMember]
    //    ThermalHandImage,
    //    [EnumMember]
    //    Voice,
    //}
    //[DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/")]
    public class CapSensorTypes
    {
        public const int None = 0;
        public const int FacialFeatures = 1;
        public const int Voice = 2;
        public const int Fingerprint = 4;
        public const int Iris = 8;
        public const int Retina = 16;
        public const int HandGeometry = 32;
        public const int SignatureDynamics = 64;
        public const int KeystrokeDynamics = 128;
        public const int LipMovement = 256;
        public const int ThermalFaceImage = 512;
        public const int ThermalHandImage = 1024;
        public const int Gait = 2048;
        public const int Password = 4096;
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/")]
    public enum SensorColor
    {
        [EnumMember]
        None,
        [EnumMember]
        Mono,
        [EnumMember]
        Grayscale,
        [EnumMember]
        Color16,
        [EnumMember]
        Color256,
        [EnumMember]
        Full,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/")]
    public enum SensorOrientation
    {
        [EnumMember]
        None,
        [EnumMember]
        Normal,
        [EnumMember]
        Right,
        [EnumMember]
        Inverted,
        [EnumMember]
        Left,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/")]
    public enum SensorType
    {
        [EnumMember]
        Unspecified,
        [EnumMember]
        FacialFeatures,
        [EnumMember]
        Voice,
        [EnumMember]
        Fingerprint,
        [EnumMember]
        Iris,
        [EnumMember]
        Retina,
        [EnumMember]
        HandGeometry,
        [EnumMember]
        SignatureDynamics,
        [EnumMember]
        KeystrokeDynamics,
        [EnumMember]
        LipMovement,
        [EnumMember]
        ThermalFaceImage,
        [EnumMember]
        ThermalHandImage,
        [EnumMember]
        Gait,
        [EnumMember]
        Password,
    }

    /*
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/")]
    public enum BIRDataTypes
    {
        [EnumMember]
        Encrypted,
        [EnumMember]
        Intermediate,
        [EnumMember]
        Processed,
        [EnumMember]
        Raw,
        [EnumMember]
        Signed,
    }
    */
    public class BIRDataTypes
    {
        public const int Encrypted = 8;
        public const int Intermediate = 2;
        public const int Processed = 4;
        public const int Raw = 1;
        public const int Signed = 16;
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Biometrics/")]
    public enum BIRPurpose
    {
        [EnumMember]
        Unspecified,
        [EnumMember]
        Verify,
        [EnumMember]
        Identify,
        [EnumMember]
        Enroll,
        [EnumMember]
        EnrollForVerificationOnly,
        [EnumMember]
        EnrollForIdentificationOnly,
        [EnumMember]
        Audit,
    }


    //
    // Constants
    //

    public class ExtendedError
    {
        public const int FirmwareBadFile = 281;
        public const int Statistics = 280;
        public const int StatisticsDependency = 282;
    }

    public class StatisticProperties
    {
        public const string AverageFalseAcceptRate = "AverageFAR";
        public const string AverageFalseRejectRate = "AverageFRR";
        public const string SuccessfulMatchCount = "SuccessfulMatchCount";
        public const string UnsuccessfulMatchCount = "UnsuccessfulMatchCount";
        public const string CommunicationErrorCount = "CommunicationErrorCount";
        public const string DeviceCategory = "DeviceCategory";
        public const string FirmwareRevision = "FirmwareRevision";
        public const string HoursPoweredCount = "HoursPoweredCount";
        public const string InstallationDate = "InstallationDate";
        public const string Interface = "Interface";
        public const string ManufactureDate = "ManufactureDate";
        public const string ManufacturerName = "ManufacturerName";
        public const string MechanicalRevision = "MechanicalRevision";
        public const string ModelName = "ModelName";
        public const string SerialNumber = "SerialNumber";
        public const string UnifiedPOSVersion = "UnifiedPOSVersion";
    }

    public class Wait
    {
        public const int Forever = -1;
    }
}
