﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace UnifiedPOS.BumpBar
{
    [ServiceContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/")]
    public interface BumpBar
    {

        //
        // Common Properties
        //

        /* Not Supported
        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetAutoDisableResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/UposException", Name = "UposException")]
        bool GetAutoDisable();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/SetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/SetAutoDisableResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/UposException", Name = "UposException")]
        void SetAutoDisable(bool AutoDisable);
        */


        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetCapCompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetCapCompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/UposException", Name = "UposException")]
        bool GetCapCompareFirmwareVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetCapPowerReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetCapPowerReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/UposException", Name = "UposException")]
        PowerReporting GetCapPowerReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetCapStatisticsReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetCapStatisticsReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/UposException", Name = "UposException")]
        bool GetCapStatisticsReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetCapUpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetCapUpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/UposException", Name = "UposException")]
        bool GetCapUpdateFirmware();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetCapUpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetCapUpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/UposException", Name = "UposException")]
        bool GetCapUpdateStatistics();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetCheckHealthText", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetCheckHealthTextResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/UposException", Name = "UposException")]
        string GetCheckHealthText();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetClaimed", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetClaimedResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/UposException", Name = "UposException")]
        bool GetClaimed();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetDataCount", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetDataCountResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/UposException", Name = "UposException")]
        int GetDataCount();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetDataEventEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/UposException", Name = "UposException")]
        bool GetDataEventEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/SetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/SetDataEventEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/UposException", Name = "UposException")]
        void SetDataEventEnabled(bool DataEventEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/UposException", Name = "UposException")]
        bool GetDeviceEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/SetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/SetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/UposException", Name = "UposException")]
        void SetDeviceEnabled(bool DeviceEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/UposException", Name = "UposException")]
        bool GetFreezeEvents();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/SetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/SetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/UposException", Name = "UposException")]
        void SetFreezeEvents(bool FreezeEvents);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetOutputID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetOutputIDResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/UposException", Name = "UposException")]
        int GetOutputID();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/UposException", Name = "UposException")]
        PowerNotification GetPowerNotify();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/SetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/SetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/UposException", Name = "UposException")]
        void SetPowerNotify(PowerNotification PowerNotify);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetPowerState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetPowerStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/UposException", Name = "UposException")]
        PowerState GetPowerState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/UposException", Name = "UposException")]
        ControlState GetState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetDeviceControlDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetDeviceControlDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/UposException", Name = "UposException")]
        string GetDeviceControlDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetDeviceControlVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetDeviceControlVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/UposException", Name = "UposException")]
        UposVersion GetDeviceControlVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetDeviceServiceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetDeviceServiceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/UposException", Name = "UposException")]
        string GetDeviceServiceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetDeviceServiceVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetDeviceServiceVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/UposException", Name = "UposException")]
        UposVersion GetDeviceServiceVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetPhysicalDeviceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetPhysicalDeviceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/UposException", Name = "UposException")]
        string GetPhysicalDeviceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetPhysicalDeviceName", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetPhysicalDeviceNameResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/UposException", Name = "UposException")]
        string GetPhysicalDeviceName();

        //
        // Specific Properties
        //
        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetAsyncMode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetAsyncModeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        bool GetAsyncMode();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/SetAsyncMode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/SetAsyncModeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        void SetAsyncMode(bool AsyncMode);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetAutoToneDuration", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetAutoToneDurationResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        int GetAutoToneDuration();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/SetAutoToneDuration", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/SetAutoToneDurationResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        void SetAutoToneDuration(int AutoToneDuration);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetAutoToneFrequency", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetAutoToneFrequencyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        int GetAutoToneFrequency();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/SetAutoToneFrequency", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/SetAutoToneFrequencyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        void SetAutoToneFrequency(int AutoToneFrequency);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetBumpBarDataCount", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetBumpBarDataCountResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        int GetBumpBarDataCount();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetCapTone", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetCapToneResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        bool GetCapTone();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetCurrentUnitID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetCurrentUnitIDResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        int GetCurrentUnitID();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/SetCurrentUnitID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/SetCurrentUnitIDResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        void SetCurrentUnitID(int CurrentUnitID);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetErrorString", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetErrorStringResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        string GetErrorString();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetErrorUnits", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetErrorUnitsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        int GetErrorUnits();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetEventString", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetEventStringResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        string GetEventString();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetEventUnitID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetEventUnitIDResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        int GetEventUnitID();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetEventUnits", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetEventUnitsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        int GetEventUnits();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetKeys", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetKeysResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        int GetKeys();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetTimeout", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetTimeoutResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        int GetTimeout();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/SetTimeout", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/SetTimeoutResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        void SetTimeout(int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetUnitsOnline", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/GetUnitsOnlineResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        int GetUnitsOnline();

        //
        // Common Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/Open", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/OpenResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/UposException", Name = "UposException")]
        void Open(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/Close", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/CloseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/UposException", Name = "UposException")]
        void Close(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/Claim", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/ClaimResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/UposException", Name = "UposException")]
        void Claim(int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/Release", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/ReleaseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/UposException", Name = "UposException")]
        void Release();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/CheckHealth", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/CheckHealthResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/UposException", Name = "UposException")]
        void CheckHealth(HealthCheckLevel Level);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/ClearInput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/ClearInputResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/UposException", Name = "UposException")]
        void ClearInput();

        /* Not Supported
        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/ClearInputProperties", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/ClearInputPropertiesResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/UposException", Name = "UposException")]
        void ClearInputProperties();
        */

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/ClearOutput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/ClearOutputResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/UposException", Name = "UposException")]
        void ClearOutput();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/DirectIO", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/DirectIOResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/UposException", Name = "UposException")]
        DirectIOData DirectIO(int Command, int Data, object Obj);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/CompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/CompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/UposException", Name = "UposException")]
        CompareFirmwareResult CompareFirmwareVersion(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/ResetStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/ResetStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/UposException", Name = "UposException")]
        void ResetStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/RetrieveStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/RetrieveStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/UposException", Name = "UposException")]
        string RetrieveStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/UpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/UpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/UposException", Name = "UposException")]
        void UpdateFirmware(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/UpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/UpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/UposException", Name = "UposException")]
        void UpdateStatistics(StatisticList StatisticsBuffer);

        //
        // Specific Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/BumpBarSound", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/BumpBarSoundResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        void BumpBarSound(int Units, int Frequency, int Duration, int NumberOfCycles, int InterSoundWait);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/SetKeyTranslation", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/SetKeyTranslationResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Belt/UposException", Name = "UposException")]
        void SetKeyTranslation(int Units, int ScanCode, int LogicalKey);

    }

    //
    // Common Data Types
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/")]
    public class DirectIOData
    {
        [DataMember]
        public int Data { get; set; }
        [DataMember]
        public object Obj { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/")]
    public class UposException
    {
        [DataMember]
        public ErrorCode ErrorCode { get; set; }
        [DataMember]
        public int ErrorCodeExtended { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/")]
    public class UposVersion
    {
        [DataMember]
        public int Major { get; set; }
        [DataMember]
        public int Minor { get; set; }
        [DataMember]
        public int Build { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/")]
    public class Statistic
    {
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public string Value { get; set; }
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/", ItemName = "Statistic")]
    public class StatisticList : List<Statistic>
    {
    }

    //
    // Common Enumerations
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/")]
    public enum CompareFirmwareResult
    {
        [EnumMember]
        Different,
        [EnumMember]
        Newer,
        [EnumMember]
        Older,
        [EnumMember]
        Same,
        [EnumMember]
        Unknown,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/")]
    public enum ControlState
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Closed,
        [EnumMember]
        Error,
        [EnumMember]
        Idle,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/")]
    public enum ErrorCode
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Claimed,
        [EnumMember]
        Closed,
        [EnumMember]
        Deprecated,
        [EnumMember]
        Disabled,
        [EnumMember]
        Exists,
        [EnumMember]
        Extended,
        [EnumMember]
        Failure,
        [EnumMember]
        Illegal,
        [EnumMember]
        NoExist,
        [EnumMember]
        NoHardware,
        [EnumMember]
        NoService,
        [EnumMember]
        NotClaimed,
        [EnumMember]
        Offline,
        [EnumMember]
        Success,
        [EnumMember]
        Timeout,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/")]
    public enum HealthCheckLevel
    {
        [EnumMember]
        External,
        [EnumMember]
        Interactive,
        [EnumMember]
        Internal,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/")]
    public enum PowerNotification
    {
        [EnumMember]
        Disabled,
        [EnumMember]
        Enabled,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/")]
    public enum PowerReporting
    {
        [EnumMember]
        Advanced,
        [EnumMember]
        None,
        [EnumMember]
        Standard,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/")]
    public enum PowerState
    {
        [EnumMember]
        Off,
        [EnumMember]
        Offline,
        [EnumMember]
        OffOffline,
        [EnumMember]
        Online,
        [EnumMember]
        Unknown,
    }

    /*
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BumpBar/")]
    public enum StatisticCategories
    {
        [EnumMember]
        All,
        [EnumMember]
        Manufacturer,
        [EnumMember]
        Upos,
    }
    */
    public class StatisticCategories
    {
        public const string All = "";
        public const string Manufacturer = "M_";
        public const string Upos = "U_";
    }

    //
    // Specific Data Types
    //

    //
    // Specific Enumerations
    //
    public class DeviceUnits
    {
        public const int Unit1 = 1;
        public const int Unit2 = 2;
        public const int Unit3 = 4;
        public const int Unit4 = 8;
        public const int Unit5 = 16;
        public const int Unit6 = 32;
        public const int Unit7 = 64;
        public const int Unit8 = 128;
        public const int Unit9 = 256;
        public const int Unit10 = 512;
        public const int Unit11 = 1024;
        public const int Unit12 = 2048;
        public const int Unit13 = 4096;
        public const int Unit14 = 8192;
        public const int Unit15 = 16384;
        public const int Unit16 = 32768;
        public const int Unit17 = 65536;
        public const int Unit18 = 131072;
        public const int Unit19 = 262144;
        public const int Unit20 = 524288;
        public const int Unit21 = 1048576;
        public const int Unit22 = 2097152;
        public const int Unit23 = 4194304;
        public const int Unit24 = 8388608;
        public const int Unit25 = 16777216;
        public const int Unit26 = 33554432;
        public const int Unit27 = 67108864;
        public const int Unit28 = 134217728;
        public const int Unit29 = 268435456;
        public const int Unit30 = 536870912;
        public const int Unit31 = 1073741824;
        public const int Unit32 = -2147483648;
    }

    //
    // Constants
    //

    public class ExtendedError
    {
        public const int FirmwareBadFile = 281;
        public const int Statistics = 280;
        public const int StatisticsDependency = 282;
    }

    public class StatisticProperties
    {
        public const string BumpCount = "BumpCount";
        public const string CommunicationErrorCount = "CommunicationErrorCount";
        public const string DeviceCategory = "DeviceCategory";
        public const string FirmwareRevision = "FirmwareRevision";
        public const string HoursPoweredCount = "HoursPoweredCount";
        public const string InstallationDate = "InstallationDate";
        public const string Interface = "Interface";
        public const string ManufactureDate = "ManufactureDate";
        public const string ManufacturerName = "ManufacturerName";
        public const string MechanicalRevision = "MechanicalRevision";
        public const string ModelName = "ModelName";
        public const string SerialNumber = "SerialNumber";
        public const string UnifiedPOSVersion = "UnifiedPOSVersion";
    }

    public class Wait
    {
        public const int Forever = -1;
    }

}
