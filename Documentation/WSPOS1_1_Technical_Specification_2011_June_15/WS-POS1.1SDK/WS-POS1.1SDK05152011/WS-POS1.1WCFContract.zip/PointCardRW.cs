﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace UnifiedPOS.PointCardRW
{
    [ServiceContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/")]
    public interface PointCardRW
    {

        //
        // Common Properties
        //

        //[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetAutoDisableResponse")]
        //[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        //bool GetAutoDisable();

        //[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/SetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/SetAutoDisableResponse")]
        //[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        //void SetAutoDisable(bool AutoDisable);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetCapCompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetCapCompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        bool GetCapCompareFirmwareVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetCapPowerReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetCapPowerReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        PowerReporting GetCapPowerReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetCapStatisticsReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetCapStatisticsReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        bool GetCapStatisticsReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetCapUpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetCapUpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        bool GetCapUpdateFirmware();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetCapUpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetCapUpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        bool GetCapUpdateStatistics();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetCheckHealthText", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetCheckHealthTextResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        string GetCheckHealthText();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetClaimed", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetClaimedResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        bool GetClaimed();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetDataCount", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetDataCountResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        int GetDataCount();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetDataEventEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        bool GetDataEventEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/SetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/SetDataEventEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        void SetDataEventEnabled(bool DataEventEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        bool GetDeviceEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/SetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/SetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        void SetDeviceEnabled(bool DeviceEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        bool GetFreezeEvents();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/SetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/SetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        void SetFreezeEvents(bool FreezeEvents);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetOutputID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetOutputIDResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        int GetOutputID();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        PowerNotification GetPowerNotify();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/SetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/SetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        void SetPowerNotify(PowerNotification PowerNotify);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetPowerState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetPowerStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        PowerState GetPowerState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        ControlState GetState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetDeviceControlDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetDeviceControlDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        string GetDeviceControlDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetDeviceControlVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetDeviceControlVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        UposVersion GetDeviceControlVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetDeviceServiceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetDeviceServiceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        string GetDeviceServiceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetDeviceServiceVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetDeviceServiceVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        UposVersion GetDeviceServiceVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetPhysicalDeviceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetPhysicalDeviceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        string GetPhysicalDeviceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetPhysicalDeviceName", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetPhysicalDeviceNameResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        string GetPhysicalDeviceName();


        //
        // Specific Properties
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetCapBold", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetCapBoldResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        bool GetCapBold();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetCapCardEntranceSensor", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetCapCardEntranceSensorResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        bool GetCapCardEntranceSensor();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetCapCharacterSet", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetCapCharacterSetResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        int GetCapCharacterSet();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetCapCleanCard", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetCapCleanCardResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        bool GetCapCleanCard();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetCapClearPrint", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetCapClearPrintResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        bool GetCapClearPrint();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetCapDHigh", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetCapDHighResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        bool GetCapDHigh();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetCapDWide", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetCapDWideResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        bool GetCapDWide();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetCapDWideDHigh", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetCapDWideDHighResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        bool GetCapDWideDHigh();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetCapItalic", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetCapItalicResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        bool GetCapItalic();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetCapLeft90", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetCapLeft90Response")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        bool GetCapLeft90();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetCapMapCharacterSet", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetCapMapCharacterSetResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        bool GetCapMapCharacterSet();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetCapPrint", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetCapPrintResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        bool GetCapPrint();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetCapPrintMode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetCapPrintModeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        bool GetCapPrintMode();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetCapRight90", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetCapRight90Response")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        bool GetCapRight90();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetCapRotate180", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetCapRotate180Response")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        bool GetCapRotate180();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetCapTracksToRead", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetCapTracksToReadResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        int GetCapTracksToRead();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetCapTracksToWrite", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetCapTracksToWriteResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        int GetCapTracksToWrite();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetCardState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetCardStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        PointCardState GetCardState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetCharacterSet", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetCharacterSetResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        int GetCharacterSet();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/SetCharacterSet", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/SetCharacterSetResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        void SetCharacterSet(int CharacterSet);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetCharacterSetList", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetCharacterSetListResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        CharacterSetList GetCharacterSetList();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetFontTypefaceList", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetFontTypefaceListResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        FontTypefaceList GetFontTypefaceList();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetLineChars", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetLineCharsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        int GetLineChars();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/SetLineChars", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/SetLineCharsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        void SetLineChars(int LineChars);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetLineCharsList", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetLineCharsListResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        LineCharsList GetLineCharsList();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetLineHeight", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetLineHeightResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        int GetLineHeight();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/SetLineHeight", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/SetLineHeightResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        void SetLineHeight(int LineHeight);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetLineSpacing", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetLineSpacingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        int GetLineSpacing();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/SetLineSpacing", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/SetLineSpacingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        void SetLineSpacing(int LineSpacing);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetLineWidth", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetLineWidthResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        int GetLineWidth();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetMapCharacterSet", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetMapCharacterSetResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        bool GetMapCharacterSet();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/SetMapCharacterSet", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/SetMapCharacterSetResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        void SetMapCharacterSet(bool MapCharacterSet);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetMapMode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetMapModeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        MapMode GetMapMode();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/SetMapMode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/SetMapModeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        void SetMapMode(MapMode MapMode);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetMaxLine", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetMaxLineResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        int GetMaxLine();


        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetPrintHeight", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetPrintHeightResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        int GetPrintHeight();



        //ReadState1とReadState2がClass1.csにない(POS for .netにない)。
        //PointCardReadWriteStates GetReadState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetReadState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetReadStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        PointCardReadWriteStates GetReadState();



        //RecvLength1とRecvLength2がClass1.csにない(POS for .netにない)。
        //PointCardReceiveLengths GetRecvLength();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetRecvLength", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetRecvLengthResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        PointCardReceiveLengths GetRecvLength();



        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetSidewaysMaxChars", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetSidewaysMaxCharsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        int GetSidewaysMaxChars();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetSidewaysMaxLines", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetSidewaysMaxLinesResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        int GetSidewaysMaxLines();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetTracksToRead", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetTracksToReadResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        int GetTracksToRead();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/SetTracksToRead", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/SetTracksToReadResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        void SetTracksToRead(int TracksToRead);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetTracksToWrite", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetTracksToWriteResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        int GetTracksToWrite();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/SetTracksToWrite", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/SetTracksToWriteResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        void SetTracksToWrite(int TracksToWrite);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetTrack1Data", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetTrack1DataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        byte[] GetTrack1Data();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetTrack2Data", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetTrack2DataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        byte[] GetTrack2Data();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetTrack3Data", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetTrack3DataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        byte[] GetTrack3Data();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetTrack4Data", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetTrack4DataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        byte[] GetTrack4Data();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetTrack5Data", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetTrack5DataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        byte[] GetTrack5Data();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetTrack6Data", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetTrack6DataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        byte[] GetTrack6Data();



        //WriteState1とWriteState2がClass1.csにない(POS for .netにない)。
        //PointCardReadWriteStates GetWriteState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetWriteState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetWriteStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        PointCardReadWriteStates GetWriteState();



        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetWrite1Data", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetWrite1DataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        byte[] GetWrite1Data();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/SetWrite1Data", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/SetWrite1DataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        void SetWrite1Data(byte[] Write1Data);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetWrite2Data", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetWrite2DataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        byte[] GetWrite2Data();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/SetWrite2Data", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/SetWrite2DataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        void SetWrite2Data(byte[] Write2Data);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetWrite3Data", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetWrite3DataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        byte[] GetWrite3Data();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/SetWrite3Data", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/SetWrite3DataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        void SetWrite3Data(byte[] Write3Data);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetWrite4Data", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetWrite4DataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        byte[] GetWrite4Data();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/SetWrite4Data", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/SetWrite4DataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        void SetWrite4Data(byte[] Write4Data);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetWrite5Data", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetWrite5DataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        byte[] GetWrite5Data();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/SetWrite5Data", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/SetWrite5DataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        void SetWrite5Data(byte[] Write5Data);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetWrite6Data", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/GetWrite6DataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        byte[] GetWrite6Data();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/SetWrite6Data", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/SetWrite6DataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]        
        void SetWrite6Data(byte[] Write6Data);



        //
        // Common Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/Open", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/OpenResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        void Open(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/Close", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/CloseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        void Close(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/Claim", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/ClaimResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        void Claim(int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/Release", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/ReleaseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        void Release();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/CheckHealth", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/CheckHealthResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        void CheckHealth(HealthCheckLevel Level);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/ClearInput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/ClearInputResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        void ClearInput();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/ClearInputProperties", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/ClearInputPropertiesResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        void ClearInputProperties();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/ClearOutput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/ClearOutputResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        void ClearOutput();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/DirectIO", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/DirectIOResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        DirectIOData DirectIO(int Command, int Data, object Obj);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/CompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/CompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        CompareFirmwareResult CompareFirmwareVersion(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/ResetStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/ResetStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        void ResetStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/RetrieveStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/RetrieveStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        string RetrieveStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        void UpdateFirmware(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        void UpdateStatistics(StatisticList StatisticsBuffer);

        //
        // Specific Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/BeginInsertion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/BeginInsertionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        void BeginInsertion(int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/BeginRemoval", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/BeginRemovalResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        void BeginRemoval(int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/CleanCard", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/CleanCardResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        void CleanCard();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/ClearPrintWrite", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/ClearPrintWriteResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        void ClearPrintWrite(PointCardAreas Kind, int HPosition, int VPosition, int Width, int Height);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/EndInsertion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/EndInsertionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        void EndInsertion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/EndRemoval", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/EndRemovalResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        void EndRemoval();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/PrintWrite", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/PrintWriteResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        void PrintWrite(PointCardAreas Kind, int HPosition, int VPosition, string Data);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/RotatePrint", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/RotatePrintResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        void RotatePrint(Rotation Rotation);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/ValidateData", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/ValidateDataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/UposException", Name = "UposException")]
        void ValidateData(string Data);


    }

    //
    // Common Data Types
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/")]
    public class DirectIOData
    {
        [DataMember]
        public int Data { get; set; }
        [DataMember]
        public object Obj { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/")]
    public class UposException
    {
        [DataMember]
        public ErrorCode ErrorCode { get; set; }
        [DataMember]
        public int ErrorCodeExtended { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/")]
    public class UposVersion
    {
        [DataMember]
        public int Major { get; set; }
        [DataMember]
        public int Minor { get; set; }
        [DataMember]
        public int Build { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/")]
    public class Statistic
    {
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public string Value { get; set; }
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/", ItemName = "Statistic")]
    public class StatisticList : List<Statistic>
    {
    }



    //
    // Common Enumerations
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/")]
    public enum CompareFirmwareResult
    {
        [EnumMember]
        Different,
        [EnumMember]
        Newer,
        [EnumMember]
        Older,
        [EnumMember]
        Same,
        [EnumMember]
        Unknown,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/")]
    public enum ControlState
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Closed,
        [EnumMember]
        Error,
        [EnumMember]
        Idle,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/")]
    public enum ErrorCode
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Claimed,
        [EnumMember]
        Closed,
        [EnumMember]
        Deprecated,
        [EnumMember]
        Disabled,
        [EnumMember]
        Exists,
        [EnumMember]
        Extended,
        [EnumMember]
        Failure,
        [EnumMember]
        Illegal,
        [EnumMember]
        NoExist,
        [EnumMember]
        NoHardware,
        [EnumMember]
        NoService,
        [EnumMember]
        NotClaimed,
        [EnumMember]
        Offline,
        [EnumMember]
        Success,
        [EnumMember]
        Timeout,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/")]
    public enum HealthCheckLevel
    {
        [EnumMember]
        External,
        [EnumMember]
        Interactive,
        [EnumMember]
        Internal,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/")]
    public enum PowerNotification
    {
        [EnumMember]
        Disabled,
        [EnumMember]
        Enabled,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/")]
    public enum PowerReporting
    {
        [EnumMember]
        Advanced,
        [EnumMember]
        None,
        [EnumMember]
        Standard,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/")]
    public enum PowerState
    {
        [EnumMember]
        Off,
        [EnumMember]
        Offline,
        [EnumMember]
        OffOffline,
        [EnumMember]
        Online,
        [EnumMember]
        Unknown,
    }

    /*
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/")]
    public enum StatisticCategories
    {
        [EnumMember]
        All,
        [EnumMember]
        Manufacturer,
        [EnumMember]
        Upos,
    }
    */
    public class StatisticCategories
    {
        public const string All = "";
        public const string Manufacturer = "M_";
        public const string Upos = "U_";
    }

    //
    // Specific Data Types
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/")]
    public class PointCardReadWriteStates
    {
        [DataMember]
        public PointCardReadWriteState Track1 { get; set; }
        [DataMember]
        public PointCardReadWriteState Track2 { get; set; }
        [DataMember]
        public PointCardReadWriteState Track3 { get; set; }
        [DataMember]
        public PointCardReadWriteState Track4 { get; set; }
        [DataMember]
        public PointCardReadWriteState Track5 { get; set; }
        [DataMember]
        public PointCardReadWriteState Track6 { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/")]
    public class PointCardReceiveLengths
    {
        [DataMember]
        public int Track1 { get; set; }
        [DataMember]
        public int Track2 { get; set; }
        [DataMember]
        public int Track3 { get; set; }
        [DataMember]
        public int Track4 { get; set; }
        [DataMember]
        public int Track5 { get; set; }
        [DataMember]
        public int Track6 { get; set; }
    }


    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/", ItemName = "CharacterSet")]
    public class CharacterSetList : List<int>
    {
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/", ItemName = "FontTypeface")]
    public class FontTypefaceList : List<string>
    {
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/", ItemName = "LineChars")]
    public class LineCharsList : List<int>
    {
    }



    //
    // Specific Enumerations
    //

 　 /*
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/")]
    public enum CharacterSetCapability
    {
        [EnumMember]
        Alpha,
        [EnumMember]
        Ansi,
        [EnumMember]
        Ascii,
        [EnumMember]
        Kana,
        [EnumMember]   
        Kanji,
        [EnumMember] 
        Numeric,
        [EnumMember]   
        Unicode,
        [EnumMember]   
        Windows,
    }
    */

    //[DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/")]
    public class CharacterSetCapability
    {
        public const int Alpha = 1;
        public const int Kana = 10;
        public const int Kanji = 11;
        public const int Unicode = 997;
        public const int Ascii = 998;
    }
    
    /*
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/")]
    public enum PointCardRWTracks
    {
        [EnumMember]
        Track1,
        [EnumMember]
        Track2,
        [EnumMember]
        Track3,
        [EnumMember]
        Track4,
        [EnumMember]
        Track5,
        [EnumMember]
        Track6,
    }
    */

    //[DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/")]
    public class PointCardRWTracks
    {
        public const int Track1 = 1;
        public const int Track2 = 2;
        public const int Track3 = 4;
        public const int Track4 = 8;
        public const int Track5 = 16;
        public const int Track6 = 32;
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/")]
    public enum PointCardState
    {
        [EnumMember]
        Inserted,
        [EnumMember]
        NoCard,
        [EnumMember]
        Remaining,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/")]
    public enum PointCardAreas
    {
        [EnumMember]
        MagneticTracks,
        [EnumMember]
        PrintingArea,
        [EnumMember]
        PrintingAreaAndMagneticTracks,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/")]
    public enum MapMode
    {
        [EnumMember]
        Dots,
        [EnumMember]
        English,
        [EnumMember]
        Metric,
        [EnumMember]
        Twips,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/")]
    public enum Rotation
    {
        [EnumMember]
        Left90,
        [EnumMember]
        Normal,
        [EnumMember]
        Right90,
        [EnumMember]
        Rotate180,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/PointCardRW/")]
    public enum PointCardReadWriteState
    {
        [EnumMember]
        Success,
        [EnumMember]
        Failure,
        [EnumMember]
        Start,
        [EnumMember]
        End,
        [EnumMember]
        Parity,
        [EnumMember]
        Encode,
        [EnumMember]
        LrcError,
        [EnumMember]
        Verify,
    }

    //
    // Constants
    //

    public class ExtendedError
    {
        public const int FirmwareBadFile = 281;
        public const int Statistics = 280;
        public const int StatisticsDependency = 282;
        public const int Cover = 205; 
        public const int Display = 208;
        public const int Jam = 203;
        public const int Motor = 204; 
        public const int NoCard = 209;
        public const int Printer = 206;
        public const int Read = 201; 
        public const int Release = 207;
        public const int Write = 202;
    }

    public class CharacterSet
    {
        public const int Ansi = 999;
        public const int Ascii = 998;
        public const int Unicode = 997;
    }

    public class StatisticProperties
    {
        public const string CommunicationErrorCount = "CommunicationErrorCount";
        public const string DeviceCategory = "DeviceCategory";
        public const string FirmwareRevision = "FirmwareRevision";
        public const string HoursPoweredCount = "HoursPoweredCount";
        public const string InstallationDate = "InstallationDate";
        public const string Interface = "Interface";
        public const string ManufactureDate = "ManufactureDate";
        public const string ManufacturerName = "ManufacturerName";
        public const string MechanicalRevision = "MechanicalRevision";
        public const string ModelName = "ModelName";
        public const string SerialNumber = "SerialNumber";
        public const string UnifiedPOSVersion = "UnifiedPOSVersion";
    }

    public class Wait
    {
        public const int Forever = -1;
    }
}
