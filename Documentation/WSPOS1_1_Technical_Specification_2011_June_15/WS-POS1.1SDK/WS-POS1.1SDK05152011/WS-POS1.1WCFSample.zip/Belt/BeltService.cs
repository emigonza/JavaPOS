﻿using UnifiedPOS.Belt;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace Wspos
{
    [ServiceBehavior(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Belt/", InstanceContextMode = InstanceContextMode.Single)]
    public class BeltService : Belt, IDisposable
    {
        #region Belt Enumration Converter

        private static Dictionary<Enum, Enum> Convert = new Dictionary<Enum, Enum>()
            {
                { Microsoft.PointOfService.PowerReporting.Advanced, PowerReporting.Advanced },
                { Microsoft.PointOfService.PowerReporting.None, PowerReporting.None },
                { Microsoft.PointOfService.PowerReporting.Standard, PowerReporting.Standard },
                { PowerReporting.Advanced, Microsoft.PointOfService.PowerReporting.Advanced },
                { PowerReporting.None, Microsoft.PointOfService.PowerReporting.None },
                { PowerReporting.Standard, Microsoft.PointOfService.PowerReporting.Standard },

                { Microsoft.PointOfService.PowerNotification.Disabled, PowerNotification.Disabled },
                { Microsoft.PointOfService.PowerNotification.Enabled, PowerNotification.Enabled },
                { PowerNotification.Disabled, Microsoft.PointOfService.PowerNotification.Disabled },
                { PowerNotification.Enabled, Microsoft.PointOfService.PowerNotification.Enabled },

                { Microsoft.PointOfService.PowerState.Off, PowerState.Off },
                { Microsoft.PointOfService.PowerState.Offline, PowerState.Offline },
                { Microsoft.PointOfService.PowerState.OffOffline, PowerState.OffOffline },
                { Microsoft.PointOfService.PowerState.Online, PowerState.Online },
                { Microsoft.PointOfService.PowerState.Unknown, PowerState.Unknown },
                { PowerState.Off, Microsoft.PointOfService.PowerState.Off },
                { PowerState.Offline, Microsoft.PointOfService.PowerState.Offline },
                { PowerState.OffOffline, Microsoft.PointOfService.PowerState.OffOffline },
                { PowerState.Online, Microsoft.PointOfService.PowerState.Online },
                { PowerState.Unknown, Microsoft.PointOfService.PowerState.Unknown },

                { Microsoft.PointOfService.ControlState.Busy, ControlState.Busy },
                { Microsoft.PointOfService.ControlState.Closed, ControlState.Closed },
                { Microsoft.PointOfService.ControlState.Error, ControlState.Error },
                { Microsoft.PointOfService.ControlState.Idle, ControlState.Idle },
                { ControlState.Busy, Microsoft.PointOfService.ControlState.Busy },
                { ControlState.Closed, Microsoft.PointOfService.ControlState.Closed },
                { ControlState.Error, Microsoft.PointOfService.ControlState.Error },
                { ControlState.Idle, Microsoft.PointOfService.ControlState.Idle },

                { Microsoft.PointOfService.HealthCheckLevel.External, HealthCheckLevel.External },
                { Microsoft.PointOfService.HealthCheckLevel.Interactive, HealthCheckLevel.Interactive },
                { Microsoft.PointOfService.HealthCheckLevel.Internal, HealthCheckLevel.Internal },
                { HealthCheckLevel.External, Microsoft.PointOfService.HealthCheckLevel.External },
                { HealthCheckLevel.Interactive, Microsoft.PointOfService.HealthCheckLevel.Interactive },
                { HealthCheckLevel.Internal, Microsoft.PointOfService.HealthCheckLevel.Internal },

                { Microsoft.PointOfService.CompareFirmwareResult.Different, CompareFirmwareResult.Different },
                { Microsoft.PointOfService.CompareFirmwareResult.Newer, CompareFirmwareResult.Newer },
                { Microsoft.PointOfService.CompareFirmwareResult.Older, CompareFirmwareResult.Older },
                { Microsoft.PointOfService.CompareFirmwareResult.Same, CompareFirmwareResult.Same },
                { Microsoft.PointOfService.CompareFirmwareResult.Unknown, CompareFirmwareResult.Unknown },
                { CompareFirmwareResult.Different, Microsoft.PointOfService.CompareFirmwareResult.Different },
                { CompareFirmwareResult.Newer, Microsoft.PointOfService.CompareFirmwareResult.Newer },
                { CompareFirmwareResult.Older, Microsoft.PointOfService.CompareFirmwareResult.Older },
                { CompareFirmwareResult.Same, Microsoft.PointOfService.CompareFirmwareResult.Same },
                { CompareFirmwareResult.Unknown, Microsoft.PointOfService.CompareFirmwareResult.Unknown },

                { Microsoft.PointOfService.ErrorCode.Busy, UnifiedPOS.Belt.ErrorCode.Busy },
                { Microsoft.PointOfService.ErrorCode.Claimed, UnifiedPOS.Belt.ErrorCode.Claimed },
                { Microsoft.PointOfService.ErrorCode.Closed, UnifiedPOS.Belt.ErrorCode.Closed },
                { Microsoft.PointOfService.ErrorCode.Deprecated, UnifiedPOS.Belt.ErrorCode.Deprecated },
                { Microsoft.PointOfService.ErrorCode.Disabled, UnifiedPOS.Belt.ErrorCode.Disabled },
                { Microsoft.PointOfService.ErrorCode.Exists, UnifiedPOS.Belt.ErrorCode.Exists },
                { Microsoft.PointOfService.ErrorCode.Extended, UnifiedPOS.Belt.ErrorCode.Extended },
                { Microsoft.PointOfService.ErrorCode.Failure, UnifiedPOS.Belt.ErrorCode.Failure },
                { Microsoft.PointOfService.ErrorCode.Illegal, UnifiedPOS.Belt.ErrorCode.Illegal },
                { Microsoft.PointOfService.ErrorCode.NoExist, UnifiedPOS.Belt.ErrorCode.NoExist },
                { Microsoft.PointOfService.ErrorCode.NoHardware, UnifiedPOS.Belt.ErrorCode.NoHardware },
                { Microsoft.PointOfService.ErrorCode.NoService, UnifiedPOS.Belt.ErrorCode.NoService },
                { Microsoft.PointOfService.ErrorCode.NotClaimed, UnifiedPOS.Belt.ErrorCode.NotClaimed },
                { Microsoft.PointOfService.ErrorCode.Offline, UnifiedPOS.Belt.ErrorCode.Offline },
                { Microsoft.PointOfService.ErrorCode.Success, UnifiedPOS.Belt.ErrorCode.Success },
                { Microsoft.PointOfService.ErrorCode.Timeout, UnifiedPOS.Belt.ErrorCode.Timeout },
                { UnifiedPOS.Belt.ErrorCode.Busy, Microsoft.PointOfService.ErrorCode.Busy },
                { UnifiedPOS.Belt.ErrorCode.Claimed, Microsoft.PointOfService.ErrorCode.Claimed },
                { UnifiedPOS.Belt.ErrorCode.Closed, Microsoft.PointOfService.ErrorCode.Closed },
                { UnifiedPOS.Belt.ErrorCode.Deprecated, Microsoft.PointOfService.ErrorCode.Deprecated },
                { UnifiedPOS.Belt.ErrorCode.Disabled, Microsoft.PointOfService.ErrorCode.Disabled },
                { UnifiedPOS.Belt.ErrorCode.Exists, Microsoft.PointOfService.ErrorCode.Exists },
                { UnifiedPOS.Belt.ErrorCode.Extended, Microsoft.PointOfService.ErrorCode.Extended },
                { UnifiedPOS.Belt.ErrorCode.Failure, Microsoft.PointOfService.ErrorCode.Failure },
                { UnifiedPOS.Belt.ErrorCode.Illegal, Microsoft.PointOfService.ErrorCode.Illegal },
                { UnifiedPOS.Belt.ErrorCode.NoExist, Microsoft.PointOfService.ErrorCode.NoExist },
                { UnifiedPOS.Belt.ErrorCode.NoHardware, Microsoft.PointOfService.ErrorCode.NoHardware },
                { UnifiedPOS.Belt.ErrorCode.NoService, Microsoft.PointOfService.ErrorCode.NoService },
                { UnifiedPOS.Belt.ErrorCode.NotClaimed, Microsoft.PointOfService.ErrorCode.NotClaimed },
                { UnifiedPOS.Belt.ErrorCode.Offline, Microsoft.PointOfService.ErrorCode.Offline },
                { UnifiedPOS.Belt.ErrorCode.Success, Microsoft.PointOfService.ErrorCode.Success },
                { UnifiedPOS.Belt.ErrorCode.Timeout, Microsoft.PointOfService.ErrorCode.Timeout },

                { Microsoft.PointOfService.BeltDirection.Backward, BeltDirection.Backward },
                { Microsoft.PointOfService.BeltDirection.Forward, BeltDirection.Forward },
                { BeltDirection.Backward, Microsoft.PointOfService.BeltDirection.Backward },
                { BeltDirection.Forward, Microsoft.PointOfService.BeltDirection.Forward },

                { Microsoft.PointOfService.BeltMotionStatus.Backward, BeltMotionStatus.Backward },
                { Microsoft.PointOfService.BeltMotionStatus.Emergency, BeltMotionStatus.Emergency },
                { Microsoft.PointOfService.BeltMotionStatus.Forward, BeltMotionStatus.Forward },
                { Microsoft.PointOfService.BeltMotionStatus.MotorFault, BeltMotionStatus.MotorFault },
                { Microsoft.PointOfService.BeltMotionStatus.Stopped, BeltMotionStatus.Stopped },
                { BeltMotionStatus.Backward, Microsoft.PointOfService.BeltMotionStatus.Backward },
                { BeltMotionStatus.Emergency, Microsoft.PointOfService.BeltMotionStatus.Emergency },
                { BeltMotionStatus.Forward, Microsoft.PointOfService.BeltMotionStatus.Forward },
                { BeltMotionStatus.MotorFault, Microsoft.PointOfService.BeltMotionStatus.MotorFault },
                { BeltMotionStatus.Stopped, Microsoft.PointOfService.BeltMotionStatus.Stopped },
            };

        #endregion

        private string deviceControlDescription = "";
        private UposVersion deviceControlVersion = new UposVersion() { Major = 1, Minor = 13, Build = 1 };
        private UnifiedPOS.BeltEvents.BeltEvent deviceEvent;
        private Microsoft.PointOfService.Belt device;

        #region Constructor

        public BeltService()
        {
            try
            {
                Microsoft.PointOfService.PosExplorer posExplorer = new Microsoft.PointOfService.PosExplorer();
                Microsoft.PointOfService.DeviceCollection deviceCollection = posExplorer.GetDevices("Belt");
                if (deviceCollection.Count > 0)
                {
                    device = (Microsoft.PointOfService.Belt)posExplorer.CreateInstance(deviceCollection[0]);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        #endregion

        #region Belt Member

        public bool GetCapCompareFirmwareVersion()
        {
            //throw new NotImplementedException();
            return device.CapCompareFirmwareVersion;
        }

        public PowerReporting GetCapPowerReporting()
        {
            //throw new NotImplementedException();
            return (PowerReporting)Convert[device.CapPowerReporting];
        }

        public bool GetCapStatisticsReporting()
        {
            //throw new NotImplementedException();
            return device.CapStatisticsReporting;
        }

        public bool GetCapUpdateFirmware()
        {
            //throw new NotImplementedException();
            return device.CapUpdateFirmware;
        }

        public bool GetCapUpdateStatistics()
        {
            //throw new NotImplementedException();
            return device.CapUpdateStatistics;
        }

        public string GetCheckHealthText()
        {
            //throw new NotImplementedException();
            return device.CheckHealthText;
        }

        public bool GetClaimed()
        {
            //throw new NotImplementedException();
            return device.Claimed;
        }

        public bool GetDeviceEnabled()
        {
            //throw new NotImplementedException();
            return device.DeviceEnabled;
        }

        public void SetDeviceEnabled(bool DeviceEnabled)
        {
            //throw new NotImplementedException();
            device.DeviceEnabled = DeviceEnabled;
        }

        public bool GetFreezeEvents()
        {
            //throw new NotImplementedException();
            return device.FreezeEvents;
        }

        public void SetFreezeEvents(bool FreezeEvents)
        {
            //throw new NotImplementedException();
            device.FreezeEvents = FreezeEvents;
        }

        public PowerNotification GetPowerNotify()
        {
            //throw new NotImplementedException();
            return (PowerNotification)Convert[device.PowerNotify];
        }

        public void SetPowerNotify(PowerNotification PowerNotify)
        {
            //throw new NotImplementedException();
            device.PowerNotify = (Microsoft.PointOfService.PowerNotification)Convert[PowerNotify];
        }

        public PowerState GetPowerState()
        {
            //throw new NotImplementedException();
            return (PowerState)Convert[device.PowerState];
        }

        public ControlState GetState()
        {
            //throw new NotImplementedException();
            return (ControlState)Convert[device.State];
        }

        public string GetDeviceControlDescription()
        {
            //throw new NotImplementedException();
            return deviceControlDescription;
        }

        public UposVersion GetDeviceControlVersion()
        {
            //throw new NotImplementedException();
            return deviceControlVersion;
        }

        public string GetDeviceServiceDescription()
        {
            //throw new NotImplementedException();
            return device.ServiceObjectDescription;
        }

        public UposVersion GetDeviceServiceVersion()
        {
            //throw new NotImplementedException();
            Version value = device.ServiceObjectVersion;
            return new UposVersion() { Build = value.Build, Major = value.Major, Minor = value.Minor };
        }

        public string GetPhysicalDeviceDescription()
        {
            //throw new NotImplementedException();
            return device.DeviceDescription;
        }

        public string GetPhysicalDeviceName()
        {
            //throw new NotImplementedException();
            return device.DeviceName;
        }

        public bool GetCapAutoStopBackward()
        {
            //throw new NotImplementedException();
            return device.CapAutoStopBackward;
        }

        public bool GetCapAutoStopBackwardItemCount()
        {
            //throw new NotImplementedException();
            return device.CapAutoStopBackwardItemCount;
        }

        public bool GetCapAutoStopForward()
        {
            //throw new NotImplementedException();
            return device.CapAutoStopForward;
        }

        public bool GetCapAutoStopForwardItemCount()
        {
            //throw new NotImplementedException();
            return device.CapAutoStopForwardItemCount;
        }

        public bool GetCapLightBarrierBackward()
        {
            //throw new NotImplementedException();
            return device.CapLightBarrierBackward;
        }

        public bool GetCapLightBarrierForward()
        {
            //throw new NotImplementedException();
            return device.CapLightBarrierForward;
        }

        public bool GetCapMoveBackward()
        {
            //throw new NotImplementedException();
            return device.CapMoveBackward;
        }

        public bool GetCapSecurityFlapBackward()
        {
            //throw new NotImplementedException();
            return device.CapSecurityFlapBackward;
        }

        public bool GetCapSecurityFlapForward()
        {
            //throw new NotImplementedException();
            return device.CapSecurityFlapForward;
        }

        public int GetCapSpeedStepsBackward()
        {
            //throw new NotImplementedException();
            return device.CapSpeedStepsBackward;
        }

        public int GetCapSpeedStepsForward()
        {
            //throw new NotImplementedException();
            return device.CapSpeedStepsForward;
        }

        public bool GetAutoStopBackward()
        {
            //throw new NotImplementedException();
            return device.AutoStopBackward;
        }

        public void SetAutoStopBackward(bool AutoStopBackward)
        {
            //throw new NotImplementedException();
            device.AutoStopBackward = AutoStopBackward;
        }

        public int GetAutoStopBackwardDelayTime()
        {
            //throw new NotImplementedException();
            return device.AutoStopBackwardDelayTime;
        }

        public void SetAutoStopBackwardDelayTime(int AutoStopBackwardDelayTime)
        {
            //throw new NotImplementedException();
            device.AutoStopBackwardDelayTime = AutoStopBackwardDelayTime;
        }

        public int GetAutoStopBackwardItemCount()
        {
            //throw new NotImplementedException();
            return device.AutoStopBackwardItemCount;
        }

        public bool GetAutoStopForward()
        {
            //throw new NotImplementedException();
            return device.AutoStopForward;
        }

        public void SetAutoStopForward(bool AutoStopForward)
        {
            //throw new NotImplementedException();
            device.AutoStopForward = AutoStopForward;
        }

        public int GetAutoStopForwardDelayTime()
        {
            //throw new NotImplementedException();
            return device.AutoStopForwardDelayTime;
        }

        public void SetAutoStopForwardDelayTime(int AutoStopForwardDelayTime)
        {
            //throw new NotImplementedException();
            device.AutoStopForwardDelayTime = AutoStopForwardDelayTime;
        }

        public int GetAutoStopForwardItemCount()
        {
            //throw new NotImplementedException();
            return device.AutoStopForwardItemCount;
        }

        public bool GetLightBarrierBackwardInterrupted()
        {
            //throw new NotImplementedException();
            return device.LightBarrierBackwardInterrupted;
        }

        public bool GetLightBarrierForwardInterrupted()
        {
            //throw new NotImplementedException();
            return device.LightBarrierForwardInterrupted;
        }

        public BeltMotionStatus GetMotionStatus()
        {
            //throw new NotImplementedException();
            return (BeltMotionStatus)Convert[device.MotionStatus];
        }

        public bool GetSecurityFlapBackwardOpened()
        {
            //throw new NotImplementedException();
            return device.SecurityFlapBackwardOpened;
        }

        public bool GetSecurityFlapForwardOpened()
        {
            //throw new NotImplementedException();
            return device.SecurityFlapForwardOpened;
        }

        public void Open(string EndpointAddress)
        {
            //throw new NotImplementedException();
            device.Open();
            if (EndpointAddress != null)
            {
                ChannelFactory<UnifiedPOS.BeltEvents.BeltEvent> factory =
                    new ChannelFactory<UnifiedPOS.BeltEvents.BeltEvent>("BeltEventPort", new EndpointAddress(EndpointAddress));
                deviceEvent = factory.CreateChannel();

                device.DirectIOEvent += new Microsoft.PointOfService.DirectIOEventHandler(device_DirectIOEvent);
                device.StatusUpdateEvent += new Microsoft.PointOfService.StatusUpdateEventHandler(device_StatusUpdateEvent);
            }
        }

        public void Close(string EndpointAddress)
        {
            //throw new NotImplementedException();
            device.Close();
            if (deviceEvent != null)
            {
                device.DirectIOEvent -= device_DirectIOEvent;
                device.StatusUpdateEvent -= device_StatusUpdateEvent;

                ((IClientChannel)deviceEvent).Close();
                deviceEvent = null;
            }
        }

        public void Claim(int Timeout)
        {
            //throw new NotImplementedException();
            device.Claim(Timeout);
        }

        public void Release()
        {
            //throw new NotImplementedException();
            device.Release();
        }

        public void CheckHealth(HealthCheckLevel Level)
        {
            //throw new NotImplementedException();
            device.CheckHealth((Microsoft.PointOfService.HealthCheckLevel)Convert[Level]);
        }

        public DirectIOData DirectIO(int Command, int Data, object Obj)
        {
            //throw new NotImplementedException();
            Microsoft.PointOfService.DirectIOData value = device.DirectIO(Command, Data, Obj);
            return new DirectIOData() { Data = value.Data, Obj = value.Object };
        }

        public CompareFirmwareResult CompareFirmwareVersion(string FirmwareFileName)
        {
            //throw new NotImplementedException();
            return (CompareFirmwareResult)Convert[device.CompareFirmwareVersion(FirmwareFileName)];
        }

        public void ResetStatistics(StatisticList StatisticsBuffer)
        {
            //throw new NotImplementedException();
            var value = from el in StatisticsBuffer select el.Name;
            switch (value.Count())
            {
                case 0:
                    device.ResetStatistics();
                    break;
                case 1:
                    string name = value.First();
                    switch (name)
                    {
                        case StatisticCategories.All:
                            device.ResetStatistics(Microsoft.PointOfService.StatisticCategories.All);
                            break;
                        case StatisticCategories.Manufacturer:
                            device.ResetStatistics(Microsoft.PointOfService.StatisticCategories.Manufacturer);
                            break;
                        case StatisticCategories.Upos:
                            device.ResetStatistics(Microsoft.PointOfService.StatisticCategories.Upos);
                            break;
                        default:
                            device.ResetStatistic(name);
                            break;
                    }
                    break;
                default:
                    device.ResetStatistics(value.ToArray());
                    break;
            }
        }

        public string RetrieveStatistics(StatisticList StatisticsBuffer)
        {
            //throw new NotImplementedException();
            string res = null;
            var value = from el in StatisticsBuffer select el.Name;
            switch (value.Count())
            {
                case 0:
                    res = device.RetrieveStatistics();
                    break;
                case 1:
                    string name = value.First();
                    switch (name)
                    {
                        case StatisticCategories.All:
                            res = device.RetrieveStatistics(Microsoft.PointOfService.StatisticCategories.All);
                            break;
                        case StatisticCategories.Manufacturer:
                            res = device.RetrieveStatistics(Microsoft.PointOfService.StatisticCategories.Manufacturer);
                            break;
                        case StatisticCategories.Upos:
                            res = device.RetrieveStatistics(Microsoft.PointOfService.StatisticCategories.Upos);
                            break;
                        default:
                            res = device.RetrieveStatistic(name);
                            break;
                    }
                    break;
                default:
                    res = device.RetrieveStatistics(value.ToArray());
                    break;
            }
            return res;
        }

        public void UpdateFirmware(string FirmwareFileName)
        {
            //throw new NotImplementedException();
            device.UpdateFirmware(FirmwareFileName);
        }

        public void UpdateStatistics(StatisticList StatisticsBuffer)
        {
            //throw new NotImplementedException();
            var value = from el in StatisticsBuffer select new Microsoft.PointOfService.Statistic(el.Name, el.Value);
            switch (value.Count())
            {
                case 0:
                    device.UpdateStatistics(value.ToArray());
                    break;
                case 1:
                    Microsoft.PointOfService.Statistic statistic = value.First();
                    switch (statistic.Name)
                    {
                        case StatisticCategories.All:
                            device.UpdateStatistics(Microsoft.PointOfService.StatisticCategories.All, statistic.Value);
                            break;
                        case StatisticCategories.Manufacturer:
                            device.UpdateStatistics(Microsoft.PointOfService.StatisticCategories.Manufacturer, statistic.Value);
                            break;
                        case StatisticCategories.Upos:
                            device.UpdateStatistics(Microsoft.PointOfService.StatisticCategories.Upos, statistic.Value);
                            break;
                        default:
                            device.UpdateStatistic(statistic.Name, statistic.Value);
                            break;
                    }
                    break;
                default:
                    device.UpdateStatistics(value.ToArray());
                    break;
            }
        }

        public void AdjustItemCount(BeltDirection Direction, int Count)
        {
            //throw new NotImplementedException();
            device.AdjustItemCount((Microsoft.PointOfService.BeltDirection)Convert[Direction], Count);
        }

        public void MoveBackward(int Speed)
        {
            //throw new NotImplementedException();
            device.MoveBackward(Speed);
        }

        public void MoveForward(int Speed)
        {
            //throw new NotImplementedException();
            device.MoveForward(Speed);
        }

        public void ResetBelt()
        {
            //throw new NotImplementedException();
            device.ResetBelt();
        }

        public void ResetItemCount(BeltDirection Direction)
        {
            //throw new NotImplementedException();
            device.ResetItemCount((Microsoft.PointOfService.BeltDirection)Convert[Direction]);
        }

        public void StopBelt()
        {
            //throw new NotImplementedException();
            device.StopBelt();
        }

        #endregion

        #region BeltEvent Member

        private void device_DirectIOEvent(object sender, Microsoft.PointOfService.DirectIOEventArgs e)
        {
            //throw new NotImplementedException();
            if (deviceEvent != null)
            {
                UnifiedPOS.BeltEvents.DirectIOData value = deviceEvent.DirectIOEvent(sender.ToString(), e.EventId, e.TimeStamp, e.EventNumber, e.Data, e.Object);
                e.Data = value.Data;
                e.Object = value.Obj;
            }
        }

        private void device_StatusUpdateEvent(object sender, Microsoft.PointOfService.StatusUpdateEventArgs e)
        {
            //throw new NotImplementedException();
            if (deviceEvent != null)
            {
                deviceEvent.StatusUpdateEvent(sender.ToString(), e.EventId, e.TimeStamp, e.Status);
            }
        }

        #endregion

        #region IDisposable Member

        public void  Dispose()
        {
            //throw new NotImplementedException();
            if (device != null)
            {
                try
                {
                    device.Close();
                }
                catch
                {
                }
                finally
                {
                    device = null;
                }
            }
            if (deviceEvent != null)
            {
                try
                {
                    ((IClientChannel)deviceEvent).Close();
                }
                catch
                {
                }
                finally
                {
                    deviceEvent = null;
                }
            }
        }

        #endregion

    }
}
