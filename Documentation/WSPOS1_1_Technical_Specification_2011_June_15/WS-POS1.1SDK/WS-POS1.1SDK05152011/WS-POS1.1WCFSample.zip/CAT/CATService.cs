﻿using UnifiedPOS.CAT;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace Wspos
{
    [ServiceBehavior(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CAT/", InstanceContextMode = InstanceContextMode.Single)]
    public class CATService : CAT, IDisposable
    {
        #region CAT Enumration Converter

        private static Dictionary<Enum, Enum> Convert = new Dictionary<Enum, Enum>()
            {
                { Microsoft.PointOfService.PowerReporting.Advanced, PowerReporting.Advanced },
                { Microsoft.PointOfService.PowerReporting.None, PowerReporting.None },
                { Microsoft.PointOfService.PowerReporting.Standard, PowerReporting.Standard },
                { PowerReporting.Advanced, Microsoft.PointOfService.PowerReporting.Advanced },
                { PowerReporting.None, Microsoft.PointOfService.PowerReporting.None },
                { PowerReporting.Standard, Microsoft.PointOfService.PowerReporting.Standard },

                { Microsoft.PointOfService.PowerNotification.Disabled, PowerNotification.Disabled },
                { Microsoft.PointOfService.PowerNotification.Enabled, PowerNotification.Enabled },
                { PowerNotification.Disabled, Microsoft.PointOfService.PowerNotification.Disabled },
                { PowerNotification.Enabled, Microsoft.PointOfService.PowerNotification.Enabled },

                { Microsoft.PointOfService.PowerState.Off, PowerState.Off },
                { Microsoft.PointOfService.PowerState.Offline, PowerState.Offline },
                { Microsoft.PointOfService.PowerState.OffOffline, PowerState.OffOffline },
                { Microsoft.PointOfService.PowerState.Online, PowerState.Online },
                { Microsoft.PointOfService.PowerState.Unknown, PowerState.Unknown },
                { PowerState.Off, Microsoft.PointOfService.PowerState.Off },
                { PowerState.Offline, Microsoft.PointOfService.PowerState.Offline },
                { PowerState.OffOffline, Microsoft.PointOfService.PowerState.OffOffline },
                { PowerState.Online, Microsoft.PointOfService.PowerState.Online },
                { PowerState.Unknown, Microsoft.PointOfService.PowerState.Unknown },

                { Microsoft.PointOfService.ControlState.Busy, ControlState.Busy },
                { Microsoft.PointOfService.ControlState.Closed, ControlState.Closed },
                { Microsoft.PointOfService.ControlState.Error, ControlState.Error },
                { Microsoft.PointOfService.ControlState.Idle, ControlState.Idle },
                { ControlState.Busy, Microsoft.PointOfService.ControlState.Busy },
                { ControlState.Closed, Microsoft.PointOfService.ControlState.Closed },
                { ControlState.Error, Microsoft.PointOfService.ControlState.Error },
                { ControlState.Idle, Microsoft.PointOfService.ControlState.Idle },

                { Microsoft.PointOfService.HealthCheckLevel.External, HealthCheckLevel.External },
                { Microsoft.PointOfService.HealthCheckLevel.Interactive, HealthCheckLevel.Interactive },
                { Microsoft.PointOfService.HealthCheckLevel.Internal, HealthCheckLevel.Internal },
                { HealthCheckLevel.External, Microsoft.PointOfService.HealthCheckLevel.External },
                { HealthCheckLevel.Interactive, Microsoft.PointOfService.HealthCheckLevel.Interactive },
                { HealthCheckLevel.Internal, Microsoft.PointOfService.HealthCheckLevel.Internal },

                { Microsoft.PointOfService.CompareFirmwareResult.Different, CompareFirmwareResult.Different },
                { Microsoft.PointOfService.CompareFirmwareResult.Newer, CompareFirmwareResult.Newer },
                { Microsoft.PointOfService.CompareFirmwareResult.Older, CompareFirmwareResult.Older },
                { Microsoft.PointOfService.CompareFirmwareResult.Same, CompareFirmwareResult.Same },
                { Microsoft.PointOfService.CompareFirmwareResult.Unknown, CompareFirmwareResult.Unknown },
                { CompareFirmwareResult.Different, Microsoft.PointOfService.CompareFirmwareResult.Different },
                { CompareFirmwareResult.Newer, Microsoft.PointOfService.CompareFirmwareResult.Newer },
                { CompareFirmwareResult.Older, Microsoft.PointOfService.CompareFirmwareResult.Older },
                { CompareFirmwareResult.Same, Microsoft.PointOfService.CompareFirmwareResult.Same },
                { CompareFirmwareResult.Unknown, Microsoft.PointOfService.CompareFirmwareResult.Unknown },

                { Microsoft.PointOfService.ErrorCode.Busy, UnifiedPOS.CAT.ErrorCode.Busy },
                { Microsoft.PointOfService.ErrorCode.Claimed, UnifiedPOS.CAT.ErrorCode.Claimed },
                { Microsoft.PointOfService.ErrorCode.Closed, UnifiedPOS.CAT.ErrorCode.Closed },
                { Microsoft.PointOfService.ErrorCode.Deprecated, UnifiedPOS.CAT.ErrorCode.Deprecated },
                { Microsoft.PointOfService.ErrorCode.Disabled, UnifiedPOS.CAT.ErrorCode.Disabled },
                { Microsoft.PointOfService.ErrorCode.Exists, UnifiedPOS.CAT.ErrorCode.Exists },
                { Microsoft.PointOfService.ErrorCode.Extended, UnifiedPOS.CAT.ErrorCode.Extended },
                { Microsoft.PointOfService.ErrorCode.Failure, UnifiedPOS.CAT.ErrorCode.Failure },
                { Microsoft.PointOfService.ErrorCode.Illegal, UnifiedPOS.CAT.ErrorCode.Illegal },
                { Microsoft.PointOfService.ErrorCode.NoExist, UnifiedPOS.CAT.ErrorCode.NoExist },
                { Microsoft.PointOfService.ErrorCode.NoHardware, UnifiedPOS.CAT.ErrorCode.NoHardware },
                { Microsoft.PointOfService.ErrorCode.NoService, UnifiedPOS.CAT.ErrorCode.NoService },
                { Microsoft.PointOfService.ErrorCode.NotClaimed, UnifiedPOS.CAT.ErrorCode.NotClaimed },
                { Microsoft.PointOfService.ErrorCode.Offline, UnifiedPOS.CAT.ErrorCode.Offline },
                { Microsoft.PointOfService.ErrorCode.Success, UnifiedPOS.CAT.ErrorCode.Success },
                { Microsoft.PointOfService.ErrorCode.Timeout, UnifiedPOS.CAT.ErrorCode.Timeout },
                { UnifiedPOS.CAT.ErrorCode.Busy, Microsoft.PointOfService.ErrorCode.Busy },
                { UnifiedPOS.CAT.ErrorCode.Claimed, Microsoft.PointOfService.ErrorCode.Claimed },
                { UnifiedPOS.CAT.ErrorCode.Closed, Microsoft.PointOfService.ErrorCode.Closed },
                { UnifiedPOS.CAT.ErrorCode.Deprecated, Microsoft.PointOfService.ErrorCode.Deprecated },
                { UnifiedPOS.CAT.ErrorCode.Disabled, Microsoft.PointOfService.ErrorCode.Disabled },
                { UnifiedPOS.CAT.ErrorCode.Exists, Microsoft.PointOfService.ErrorCode.Exists },
                { UnifiedPOS.CAT.ErrorCode.Extended, Microsoft.PointOfService.ErrorCode.Extended },
                { UnifiedPOS.CAT.ErrorCode.Failure, Microsoft.PointOfService.ErrorCode.Failure },
                { UnifiedPOS.CAT.ErrorCode.Illegal, Microsoft.PointOfService.ErrorCode.Illegal },
                { UnifiedPOS.CAT.ErrorCode.NoExist, Microsoft.PointOfService.ErrorCode.NoExist },
                { UnifiedPOS.CAT.ErrorCode.NoHardware, Microsoft.PointOfService.ErrorCode.NoHardware },
                { UnifiedPOS.CAT.ErrorCode.NoService, Microsoft.PointOfService.ErrorCode.NoService },
                { UnifiedPOS.CAT.ErrorCode.NotClaimed, Microsoft.PointOfService.ErrorCode.NotClaimed },
                { UnifiedPOS.CAT.ErrorCode.Offline, Microsoft.PointOfService.ErrorCode.Offline },
                { UnifiedPOS.CAT.ErrorCode.Success, Microsoft.PointOfService.ErrorCode.Success },
                { UnifiedPOS.CAT.ErrorCode.Timeout, Microsoft.PointOfService.ErrorCode.Timeout },

                { Microsoft.PointOfService.CatLogs.None, CATLogs.None },
                { Microsoft.PointOfService.CatLogs.Reporting, CATLogs.Reporting },
                { Microsoft.PointOfService.CatLogs.ReportingAndSettlement, CATLogs.ReportingAndSettlement },
                { Microsoft.PointOfService.CatLogs.Settlement, CATLogs.Settlement },
                { CATLogs.None, Microsoft.PointOfService.CatLogs.None },
                { CATLogs.Reporting, Microsoft.PointOfService.CatLogs.Reporting },
                { CATLogs.ReportingAndSettlement, Microsoft.PointOfService.CatLogs.ReportingAndSettlement },
                { CATLogs.Settlement, Microsoft.PointOfService.CatLogs.Settlement },

                { Microsoft.PointOfService.DealingLogStatus.Full, DealingLogStatus.Full },
                { Microsoft.PointOfService.DealingLogStatus.NearFull, DealingLogStatus.NearFull },
                { Microsoft.PointOfService.DealingLogStatus.Ok, DealingLogStatus.Ok },
                { DealingLogStatus.Full, Microsoft.PointOfService.DealingLogStatus.Full },
                { DealingLogStatus.NearFull, Microsoft.PointOfService.DealingLogStatus.NearFull },
                { DealingLogStatus.Ok, Microsoft.PointOfService.DealingLogStatus.Ok },

                { Microsoft.PointOfService.PaymentCondition.Bonus1, PaymentCondition.Bonus1 },
                { Microsoft.PointOfService.PaymentCondition.Bonus2, PaymentCondition.Bonus2 },
                { Microsoft.PointOfService.PaymentCondition.Bonus3, PaymentCondition.Bonus3 },
                { Microsoft.PointOfService.PaymentCondition.Bonus4, PaymentCondition.Bonus4 },
                { Microsoft.PointOfService.PaymentCondition.Bonus5, PaymentCondition.Bonus5 },
                { Microsoft.PointOfService.PaymentCondition.BonusCombination1, PaymentCondition.BonusCombination1 },
                { Microsoft.PointOfService.PaymentCondition.BonusCombination2, PaymentCondition.BonusCombination2 },
                { Microsoft.PointOfService.PaymentCondition.BonusCombination3, PaymentCondition.BonusCombination3 },
                { Microsoft.PointOfService.PaymentCondition.BonusCombination4, PaymentCondition.BonusCombination4 },
                { Microsoft.PointOfService.PaymentCondition.Debit, PaymentCondition.Debit },
                { Microsoft.PointOfService.PaymentCondition.ElectronicMoney, PaymentCondition.ElectronicMoney },
                { Microsoft.PointOfService.PaymentCondition.Installment1, PaymentCondition.Installment1 },
                { Microsoft.PointOfService.PaymentCondition.Installment2, PaymentCondition.Installment2 },
                { Microsoft.PointOfService.PaymentCondition.Installment3, PaymentCondition.Installment3 },
                { Microsoft.PointOfService.PaymentCondition.Lump, PaymentCondition.Lump },
                { Microsoft.PointOfService.PaymentCondition.Revolving, PaymentCondition.Revolving },
                { PaymentCondition.Bonus1, Microsoft.PointOfService.PaymentCondition.Bonus1 },
                { PaymentCondition.Bonus2, Microsoft.PointOfService.PaymentCondition.Bonus2 },
                { PaymentCondition.Bonus3, Microsoft.PointOfService.PaymentCondition.Bonus3 },
                { PaymentCondition.Bonus4, Microsoft.PointOfService.PaymentCondition.Bonus4 },
                { PaymentCondition.Bonus5, Microsoft.PointOfService.PaymentCondition.Bonus5 },
                { PaymentCondition.BonusCombination1, Microsoft.PointOfService.PaymentCondition.BonusCombination1 },
                { PaymentCondition.BonusCombination2, Microsoft.PointOfService.PaymentCondition.BonusCombination2 },
                { PaymentCondition.BonusCombination3, Microsoft.PointOfService.PaymentCondition.BonusCombination3 },
                { PaymentCondition.BonusCombination4, Microsoft.PointOfService.PaymentCondition.BonusCombination4 },
                { PaymentCondition.Debit, Microsoft.PointOfService.PaymentCondition.Debit },
                { PaymentCondition.ElectronicMoney, Microsoft.PointOfService.PaymentCondition.ElectronicMoney },
                { PaymentCondition.Installment1, Microsoft.PointOfService.PaymentCondition.Installment1 },
                { PaymentCondition.Installment2, Microsoft.PointOfService.PaymentCondition.Installment2 },
                { PaymentCondition.Installment3, Microsoft.PointOfService.PaymentCondition.Installment3 },
                { PaymentCondition.Lump, Microsoft.PointOfService.PaymentCondition.Lump },
                { PaymentCondition.Revolving, Microsoft.PointOfService.PaymentCondition.Revolving },

                { Microsoft.PointOfService.PaymentMedia.Credit, PaymentMedia.Credit },
                { Microsoft.PointOfService.PaymentMedia.Debit, PaymentMedia.Debit },
                { Microsoft.PointOfService.PaymentMedia.ElectronicMoney, PaymentMedia.ElectronicMoney },
                { Microsoft.PointOfService.PaymentMedia.Unspecified, PaymentMedia.Unspecified },
                { PaymentMedia.Credit, Microsoft.PointOfService.PaymentMedia.Credit },
                { PaymentMedia.Debit, Microsoft.PointOfService.PaymentMedia.Debit },
                { PaymentMedia.ElectronicMoney, Microsoft.PointOfService.PaymentMedia.ElectronicMoney },
                { PaymentMedia.Unspecified, Microsoft.PointOfService.PaymentMedia.Unspecified },

                { Microsoft.PointOfService.CreditTransactionType.CashDeposit, CreditTransactionType.CashDeposit },
                { Microsoft.PointOfService.CreditTransactionType.CheckCard, CreditTransactionType.CheckCard },
                { Microsoft.PointOfService.CreditTransactionType.Completion, CreditTransactionType.Completion },
                { Microsoft.PointOfService.CreditTransactionType.PreSales, CreditTransactionType.PreSales },
                { Microsoft.PointOfService.CreditTransactionType.Refund, CreditTransactionType.Refund },
                { Microsoft.PointOfService.CreditTransactionType.Sales, CreditTransactionType.Sales },
                { Microsoft.PointOfService.CreditTransactionType.Void, CreditTransactionType.Void },
                { Microsoft.PointOfService.CreditTransactionType.VoidPreSales, CreditTransactionType.VoidPreSales },
                { CreditTransactionType.CashDeposit, Microsoft.PointOfService.CreditTransactionType.CashDeposit },
                { CreditTransactionType.CheckCard, Microsoft.PointOfService.CreditTransactionType.CheckCard },
                { CreditTransactionType.Completion, Microsoft.PointOfService.CreditTransactionType.Completion },
                { CreditTransactionType.PreSales, Microsoft.PointOfService.CreditTransactionType.PreSales },
                { CreditTransactionType.Refund, Microsoft.PointOfService.CreditTransactionType.Refund },
                { CreditTransactionType.Sales, Microsoft.PointOfService.CreditTransactionType.Sales },
                { CreditTransactionType.Void, Microsoft.PointOfService.CreditTransactionType.Void },
                { CreditTransactionType.VoidPreSales, Microsoft.PointOfService.CreditTransactionType.VoidPreSales },
            };

        private static Dictionary<Enum, Enum> EventConvert = new Dictionary<Enum, Enum>()
            {
                { Microsoft.PointOfService.ErrorCode.Busy, UnifiedPOS.CATEvents.ErrorCode.Busy },
                { Microsoft.PointOfService.ErrorCode.Claimed, UnifiedPOS.CATEvents.ErrorCode.Claimed },
                { Microsoft.PointOfService.ErrorCode.Closed, UnifiedPOS.CATEvents.ErrorCode.Closed },
                { Microsoft.PointOfService.ErrorCode.Deprecated, UnifiedPOS.CATEvents.ErrorCode.Deprecated },
                { Microsoft.PointOfService.ErrorCode.Disabled, UnifiedPOS.CATEvents.ErrorCode.Disabled },
                { Microsoft.PointOfService.ErrorCode.Exists, UnifiedPOS.CATEvents.ErrorCode.Exists },
                { Microsoft.PointOfService.ErrorCode.Extended, UnifiedPOS.CATEvents.ErrorCode.Extended },
                { Microsoft.PointOfService.ErrorCode.Failure, UnifiedPOS.CATEvents.ErrorCode.Failure },
                { Microsoft.PointOfService.ErrorCode.Illegal, UnifiedPOS.CATEvents.ErrorCode.Illegal },
                { Microsoft.PointOfService.ErrorCode.NoExist, UnifiedPOS.CATEvents.ErrorCode.NoExist },
                { Microsoft.PointOfService.ErrorCode.NoHardware, UnifiedPOS.CATEvents.ErrorCode.NoHardware },
                { Microsoft.PointOfService.ErrorCode.NoService, UnifiedPOS.CATEvents.ErrorCode.NoService },
                { Microsoft.PointOfService.ErrorCode.NotClaimed, UnifiedPOS.CATEvents.ErrorCode.NotClaimed },
                { Microsoft.PointOfService.ErrorCode.Offline, UnifiedPOS.CATEvents.ErrorCode.Offline },
                { Microsoft.PointOfService.ErrorCode.Success, UnifiedPOS.CATEvents.ErrorCode.Success },
                { Microsoft.PointOfService.ErrorCode.Timeout, UnifiedPOS.CATEvents.ErrorCode.Timeout },
                { UnifiedPOS.CATEvents.ErrorCode.Busy, Microsoft.PointOfService.ErrorCode.Busy },
                { UnifiedPOS.CATEvents.ErrorCode.Claimed, Microsoft.PointOfService.ErrorCode.Claimed },
                { UnifiedPOS.CATEvents.ErrorCode.Closed, Microsoft.PointOfService.ErrorCode.Closed },
                { UnifiedPOS.CATEvents.ErrorCode.Deprecated, Microsoft.PointOfService.ErrorCode.Deprecated },
                { UnifiedPOS.CATEvents.ErrorCode.Disabled, Microsoft.PointOfService.ErrorCode.Disabled },
                { UnifiedPOS.CATEvents.ErrorCode.Exists, Microsoft.PointOfService.ErrorCode.Exists },
                { UnifiedPOS.CATEvents.ErrorCode.Extended, Microsoft.PointOfService.ErrorCode.Extended },
                { UnifiedPOS.CATEvents.ErrorCode.Failure, Microsoft.PointOfService.ErrorCode.Failure },
                { UnifiedPOS.CATEvents.ErrorCode.Illegal, Microsoft.PointOfService.ErrorCode.Illegal },
                { UnifiedPOS.CATEvents.ErrorCode.NoExist, Microsoft.PointOfService.ErrorCode.NoExist },
                { UnifiedPOS.CATEvents.ErrorCode.NoHardware, Microsoft.PointOfService.ErrorCode.NoHardware },
                { UnifiedPOS.CATEvents.ErrorCode.NoService, Microsoft.PointOfService.ErrorCode.NoService },
                { UnifiedPOS.CATEvents.ErrorCode.NotClaimed, Microsoft.PointOfService.ErrorCode.NotClaimed },
                { UnifiedPOS.CATEvents.ErrorCode.Offline, Microsoft.PointOfService.ErrorCode.Offline },
                { UnifiedPOS.CATEvents.ErrorCode.Success, Microsoft.PointOfService.ErrorCode.Success },
                { UnifiedPOS.CATEvents.ErrorCode.Timeout, Microsoft.PointOfService.ErrorCode.Timeout },

                { Microsoft.PointOfService.ErrorLocus.Input, UnifiedPOS.CATEvents.ErrorLocus.Input },
                { Microsoft.PointOfService.ErrorLocus.InputData, UnifiedPOS.CATEvents.ErrorLocus.InputData },
                { Microsoft.PointOfService.ErrorLocus.Output, UnifiedPOS.CATEvents.ErrorLocus.Output },
                { UnifiedPOS.CATEvents.ErrorLocus.Input, Microsoft.PointOfService.ErrorLocus.Input },
                { UnifiedPOS.CATEvents.ErrorLocus.InputData, Microsoft.PointOfService.ErrorLocus.InputData },
                { UnifiedPOS.CATEvents.ErrorLocus.Output, Microsoft.PointOfService.ErrorLocus.Output },

                { Microsoft.PointOfService.ErrorResponse.Clear, UnifiedPOS.CATEvents.ErrorResponse.Clear },
                { Microsoft.PointOfService.ErrorResponse.ContinueInput, UnifiedPOS.CATEvents.ErrorResponse.ContinueInput },
                { Microsoft.PointOfService.ErrorResponse.Retry, UnifiedPOS.CATEvents.ErrorResponse.Retry },
                { UnifiedPOS.CATEvents.ErrorResponse.Clear, Microsoft.PointOfService.ErrorResponse.Clear },
                { UnifiedPOS.CATEvents.ErrorResponse.ContinueInput, Microsoft.PointOfService.ErrorResponse.ContinueInput },
                { UnifiedPOS.CATEvents.ErrorResponse.Retry, Microsoft.PointOfService.ErrorResponse.Retry },
            };

        #endregion

        private string deviceControlDescription = "";
        private UposVersion deviceControlVersion = new UposVersion() { Major = 1, Minor = 13, Build = 1 };
        private UnifiedPOS.CATEvents.CATEvent deviceEvent;
        private Microsoft.PointOfService.Cat device;

        #region Constructor

        public CATService()
        {
            try
            {
                Microsoft.PointOfService.PosExplorer posExplorer = new Microsoft.PointOfService.PosExplorer();
                Microsoft.PointOfService.DeviceCollection deviceCollection = posExplorer.GetDevices("Cat");
                if (deviceCollection.Count > 0)
                {
                    device = (Microsoft.PointOfService.Cat)posExplorer.CreateInstance(deviceCollection[0]);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        #endregion

        #region CAT Member

        public bool GetCapCompareFirmwareVersion()
        {
            //throw new NotImplementedException();
            return device.CapCompareFirmwareVersion;
        }

        public PowerReporting GetCapPowerReporting()
        {
            //throw new NotImplementedException();
            return (PowerReporting)Convert[device.CapPowerReporting];
        }

        public bool GetCapStatisticsReporting()
        {
            //throw new NotImplementedException();
            return device.CapStatisticsReporting;
        }

        public bool GetCapUpdateFirmware()
        {
            //throw new NotImplementedException();
            return device.CapUpdateFirmware;
        }

        public bool GetCapUpdateStatistics()
        {
            //throw new NotImplementedException();
            return device.CapUpdateStatistics;
        }

        public string GetCheckHealthText()
        {
            //throw new NotImplementedException();
            return device.CheckHealthText;
        }

        public bool GetClaimed()
        {
            //throw new NotImplementedException();
            return device.Claimed;
        }

        public bool GetDeviceEnabled()
        {
            //throw new NotImplementedException();
            return device.DeviceEnabled;
        }

        public void SetDeviceEnabled(bool DeviceEnabled)
        {
            //throw new NotImplementedException();
            device.DeviceEnabled = DeviceEnabled;
        }

        public bool GetFreezeEvents()
        {
            //throw new NotImplementedException();
            return device.FreezeEvents;
        }

        public void SetFreezeEvents(bool FreezeEvents)
        {
            //throw new NotImplementedException();
            device.FreezeEvents = FreezeEvents;
        }

        public int GetOutputID()
        {
            //throw new NotImplementedException();
            return device.OutputId;
        }

        public PowerNotification GetPowerNotify()
        {
            //throw new NotImplementedException();
            return (PowerNotification)Convert[device.PowerNotify];
        }

        public void SetPowerNotify(PowerNotification PowerNotify)
        {
            //throw new NotImplementedException();
            device.PowerNotify = (Microsoft.PointOfService.PowerNotification)Convert[PowerNotify];
        }

        public PowerState GetPowerState()
        {
            //throw new NotImplementedException();
            return (PowerState)Convert[device.PowerState];
        }

        public ControlState GetState()
        {
            //throw new NotImplementedException();
            return (ControlState)Convert[device.State];
        }

        public string GetDeviceControlDescription()
        {
            //throw new NotImplementedException();
            return deviceControlDescription;
        }

        public UposVersion GetDeviceControlVersion()
        {
            //throw new NotImplementedException();
            return deviceControlVersion;
        }

        public string GetDeviceServiceDescription()
        {
            //throw new NotImplementedException();
            return device.ServiceObjectDescription;
        }

        public UposVersion GetDeviceServiceVersion()
        {
            //throw new NotImplementedException();
            Version value = device.ServiceObjectVersion;
            return new UposVersion() { Build = value.Build, Major = value.Major, Minor = value.Minor };
        }

        public string GetPhysicalDeviceDescription()
        {
            //throw new NotImplementedException();
            return device.DeviceDescription;
        }

        public string GetPhysicalDeviceName()
        {
            //throw new NotImplementedException();
            return device.DeviceName;
        }

        public string GetAccountNumber()
        {
            //throw new NotImplementedException();
            return device.AccountNumber;
        }

        public string GetAdditionalSecurityInformation()
        {
            //throw new NotImplementedException();
            return device.AdditionalSecurityInformation;
        }

        public void SetAdditionalSecurityInformation(string AdditionalSecurityInformation)
        {
            //throw new NotImplementedException();
            device.AdditionalSecurityInformation = AdditionalSecurityInformation;
        }

        public string GetApprovalCode()
        {
            //throw new NotImplementedException();
            return device.ApprovalCode;
        }

        public bool GetAsyncMode()
        {
            //throw new NotImplementedException();
            return device.AsyncMode;
        }

        public void SetAsyncMode(bool AsyncMode)
        {
            //throw new NotImplementedException();
            device.AsyncMode = AsyncMode;
        }

        public decimal GetBalance()
        {
            //throw new NotImplementedException();
            return device.Balance;
        }

        public bool GetCapAdditionalSecurityInformation()
        {
            //throw new NotImplementedException();
            return device.CapAdditionalSecurityInformation;
        }

        public bool GetCapAuthorizeCompletion()
        {
            //throw new NotImplementedException();
            return device.CapAuthorizeCompletion;
        }

        public bool GetCapAuthorizePreSales()
        {
            //throw new NotImplementedException();
            return device.CapAuthorizePreSales;
        }

        public bool GetCapAuthorizeRefund()
        {
            //throw new NotImplementedException();
            return device.CapAuthorizeRefund;
        }

        public bool GetCapAuthorizeVoid()
        {
            //throw new NotImplementedException();
            return device.CapAuthorizeVoid;
        }

        public bool GetCapAuthorizeVoidPreSales()
        {
            //throw new NotImplementedException();
            return device.CapAuthorizeVoidPreSales;
        }

        public bool GetCapCashDeposit()
        {
            //throw new NotImplementedException();
            return device.CapCashDeposit;
        }

        public bool GetCapCenterResultCode()
        {
            //throw new NotImplementedException();
            return device.CapCenterResultCode;
        }

        public bool GetCapCheckCard()
        {
            //throw new NotImplementedException();
            return device.CapCheckCard;
        }

        public CATLogs GetCapDailyLog()
        {
            //throw new NotImplementedException();
            return (CATLogs)Convert[device.CapDailyLog];
        }

        public bool GetCapInstallments()
        {
            //throw new NotImplementedException();
            return device.CapInstallments;
        }

        public bool GetCapLockTerminal()
        {
            //throw new NotImplementedException();
            return device.CapLockTerminal;
        }

        public bool GetCapLogStatus()
        {
            //throw new NotImplementedException();
            return device.CapLogStatus;
        }

        public bool GetCapPaymentDetail()
        {
            //throw new NotImplementedException();
            return device.CapPaymentDetail;
        }

        public bool GetCapTaxOthers()
        {
            //throw new NotImplementedException();
            return device.CapTaxOthers;
        }

        public bool GetCapTransactionNumber()
        {
            //throw new NotImplementedException();
            return device.CapTransactionNumber;
        }

        public bool GetCapTrainingMode()
        {
            //throw new NotImplementedException();
            return device.CapTrainingMode;
        }

        public bool GetCapUnlockTerminal()
        {
            //throw new NotImplementedException();
            return device.CapUnlockTerminal;
        }

        public string GetCardCompanyID()
        {
            //throw new NotImplementedException();
            return device.CardCompanyId;
        }

        public string GetCenterResultCode()
        {
            //throw new NotImplementedException();
            return device.CenterResultCode;
        }

        public string GetDailyLog()
        {
            //throw new NotImplementedException();
            return device.DailyLog;
        }

        public DealingLogStatus GetLogStatus()
        {
            //throw new NotImplementedException();
            return (DealingLogStatus)Convert[device.LogStatus];
        }

        public PaymentCondition GetPaymentCondition()
        {
            //throw new NotImplementedException();
            return (PaymentCondition)Convert[device.PaymentCondition];
        }

        public string GetPaymentDetail()
        {
            //throw new NotImplementedException();
            return device.PaymentDetail;
        }

        public PaymentMedia GetPaymentMedia()
        {
            //throw new NotImplementedException();
            return (PaymentMedia)Convert[device.PaymentMedia];
        }

        public void SetPaymentMedia(PaymentMedia PaymentMedia)
        {
            //throw new NotImplementedException();
            device.PaymentMedia = (Microsoft.PointOfService.PaymentMedia)Convert[PaymentMedia];
        }

        public int GetSequenceNumber()
        {
            //throw new NotImplementedException();
            return device.SequenceNumber;
        }

        public decimal GetSettledAmount()
        {
            //throw new NotImplementedException();
            return device.SettledAmount;
        }

        public string GetSlipNumber()
        {
            //throw new NotImplementedException();
            return device.SlipNumber;
        }

        public bool GetTrainingMode()
        {
            //throw new NotImplementedException();
            return device.TrainingMode;
        }

        public void SetTrainingMode(bool TrainingMode)
        {
            //throw new NotImplementedException();
            device.TrainingMode = TrainingMode;
        }

        public string GetTransactionNumber()
        {
            //throw new NotImplementedException();
            return device.TransactionNumber;
        }

        public CreditTransactionType GetTransactionType()
        {
            //throw new NotImplementedException();
            return (CreditTransactionType)Convert[device.TransactionType];
        }

        public void Open(string EndpointAddress)
        {
            //throw new NotImplementedException();
            device.Open();
            if (EndpointAddress != null)
            {
                ChannelFactory<UnifiedPOS.CATEvents.CATEvent> factory =
                    new ChannelFactory<UnifiedPOS.CATEvents.CATEvent>("CATEventPort", new EndpointAddress(EndpointAddress));
                deviceEvent = factory.CreateChannel();

                device.DirectIOEvent += new Microsoft.PointOfService.DirectIOEventHandler(device_DirectIOEvent);
                device.ErrorEvent += new Microsoft.PointOfService.DeviceErrorEventHandler(device_ErrorEvent);
                device.OutputCompleteEvent += new Microsoft.PointOfService.OutputCompleteEventHandler(device_OutputCompleteEvent);
                device.StatusUpdateEvent += new Microsoft.PointOfService.StatusUpdateEventHandler(device_StatusUpdateEvent);
            }
        }

        public void Close(string EndpointAddress)
        {
            //throw new NotImplementedException();
            device.Close();
            if (deviceEvent != null)
            {
                device.DirectIOEvent -= device_DirectIOEvent;
                device.ErrorEvent -= device_ErrorEvent;
                device.OutputCompleteEvent -= device_OutputCompleteEvent;
                device.StatusUpdateEvent -= device_StatusUpdateEvent;

                ((IClientChannel)deviceEvent).Close();
                deviceEvent = null;
            }
        }

        public void Claim(int Timeout)
        {
            //throw new NotImplementedException();
            device.Claim(Timeout);
        }

        public void Release()
        {
            //throw new NotImplementedException();
            device.Release();
        }

        public void CheckHealth(HealthCheckLevel Level)
        {
            //throw new NotImplementedException();
            device.CheckHealth((Microsoft.PointOfService.HealthCheckLevel)Convert[Level]);
        }

        public void ClearOutput()
        {
            //throw new NotImplementedException();
            device.ClearOutput();
        }

        public DirectIOData DirectIO(int Command, int Data, object Obj)
        {
            //throw new NotImplementedException();
            Microsoft.PointOfService.DirectIOData value = device.DirectIO(Command, Data, Obj);
            return new DirectIOData() { Data = value.Data, Obj = value.Object };
        }

        public CompareFirmwareResult CompareFirmwareVersion(string FirmwareFileName)
        {
            //throw new NotImplementedException();
            return (CompareFirmwareResult)Convert[device.CompareFirmwareVersion(FirmwareFileName)];
        }

        public void ResetStatistics(StatisticList StatisticsBuffer)
        {
            //throw new NotImplementedException();
            var value = from el in StatisticsBuffer select el.Name;
            switch (value.Count())
            {
                case 0:
                    device.ResetStatistics();
                    break;
                case 1:
                    string name = value.First();
                    switch (name)
                    {
                        case StatisticCategories.All:
                            device.ResetStatistics(Microsoft.PointOfService.StatisticCategories.All);
                            break;
                        case StatisticCategories.Manufacturer:
                            device.ResetStatistics(Microsoft.PointOfService.StatisticCategories.Manufacturer);
                            break;
                        case StatisticCategories.Upos:
                            device.ResetStatistics(Microsoft.PointOfService.StatisticCategories.Upos);
                            break;
                        default:
                            device.ResetStatistic(name);
                            break;
                    }
                    break;
                default:
                    device.ResetStatistics(value.ToArray());
                    break;
            }
        }

        public string RetrieveStatistics(StatisticList StatisticsBuffer)
        {
            //throw new NotImplementedException();
            string res = null;
            var value = from el in StatisticsBuffer select el.Name;
            switch (value.Count())
            {
                case 0:
                    res = device.RetrieveStatistics();
                    break;
                case 1:
                    string name = value.First();
                    switch (name)
                    {
                        case StatisticCategories.All:
                            res = device.RetrieveStatistics(Microsoft.PointOfService.StatisticCategories.All);
                            break;
                        case StatisticCategories.Manufacturer:
                            res = device.RetrieveStatistics(Microsoft.PointOfService.StatisticCategories.Manufacturer);
                            break;
                        case StatisticCategories.Upos:
                            res = device.RetrieveStatistics(Microsoft.PointOfService.StatisticCategories.Upos);
                            break;
                        default:
                            res = device.RetrieveStatistic(name);
                            break;
                    }
                    break;
                default:
                    res = device.RetrieveStatistics(value.ToArray());
                    break;
            }
            return res;
        }

        public void UpdateFirmware(string FirmwareFileName)
        {
            //throw new NotImplementedException();
            device.UpdateFirmware(FirmwareFileName);
        }

        public void UpdateStatistics(StatisticList StatisticsBuffer)
        {
            //throw new NotImplementedException();
            var value = from el in StatisticsBuffer select new Microsoft.PointOfService.Statistic(el.Name, el.Value);
            switch (value.Count())
            {
                case 0:
                    device.UpdateStatistics(value.ToArray());
                    break;
                case 1:
                    Microsoft.PointOfService.Statistic statistic = value.First();
                    switch (statistic.Name)
                    {
                        case StatisticCategories.All:
                            device.UpdateStatistics(Microsoft.PointOfService.StatisticCategories.All, statistic.Value);
                            break;
                        case StatisticCategories.Manufacturer:
                            device.UpdateStatistics(Microsoft.PointOfService.StatisticCategories.Manufacturer, statistic.Value);
                            break;
                        case StatisticCategories.Upos:
                            device.UpdateStatistics(Microsoft.PointOfService.StatisticCategories.Upos, statistic.Value);
                            break;
                        default:
                            device.UpdateStatistic(statistic.Name, statistic.Value);
                            break;
                    }
                    break;
                default:
                    device.UpdateStatistics(value.ToArray());
                    break;
            }
        }

        public void AccessDailyLog(int SequenceNumber, CATLogs Type, int Timeout)
        {
            //throw new NotImplementedException();
            device.AccessDailyLog(SequenceNumber, (Microsoft.PointOfService.CatLogs)Convert[Type], Timeout);
        }

        public void AuthorizeCompletion(int SequenceNumber, decimal Amount, decimal TaxOthers, int Timeout)
        {
            //throw new NotImplementedException();
            device.AuthorizeCompletion(SequenceNumber, Amount, TaxOthers, Timeout);
        }

        public void AuthorizePreSales(int SequenceNumber, decimal Amount, decimal TaxOthers, int Timeout)
        {
            //throw new NotImplementedException();
            device.AuthorizePreSales(SequenceNumber, Amount, TaxOthers, Timeout);
        }

        public void AuthorizeRefund(int SequenceNumber, decimal Amount, decimal TaxOthers, int Timeout)
        {
            //throw new NotImplementedException();
            device.AuthorizeRefund(SequenceNumber, Amount, TaxOthers, Timeout);
        }

        public void AuthorizeSales(int SequenceNumber, decimal Amount, decimal TaxOthers, int Timeout)
        {
            //throw new NotImplementedException();
            device.AuthorizeSales(SequenceNumber, Amount, TaxOthers, Timeout);
        }

        public void AuthorizeVoid(int SequenceNumber, decimal Amount, decimal TaxOthers, int Timeout)
        {
            //throw new NotImplementedException();
            device.AuthorizeVoid(SequenceNumber, Amount, TaxOthers, Timeout);
        }

        public void AuthorizeVoidPreSales(int SequenceNumber, decimal Amount, decimal TaxOthers, int Timeout)
        {
            //throw new NotImplementedException();
            device.AuthorizeVoidPreSales(SequenceNumber, Amount, TaxOthers, Timeout);
        }

        public void CashDeposit(int SequenceNumber, decimal Amount, int Timeout)
        {
            //throw new NotImplementedException();
            device.CashDeposit(SequenceNumber, Amount, Timeout);
        }

        public void CheckCard(int SequenceNumber, int Timeout)
        {
            //throw new NotImplementedException();
            device.CheckCard(SequenceNumber, Timeout);
        }

        public void LockTerminal()
        {
            //throw new NotImplementedException();
            device.LockTerminal();
        }

        public void UnlockTerminal()
        {
            //throw new NotImplementedException();
            device.UnlockTerminal();
        }

        #endregion

        #region CATEvent Member

        private void device_DirectIOEvent(object sender, Microsoft.PointOfService.DirectIOEventArgs e)
        {
            //throw new NotImplementedException();
            if (deviceEvent != null)
            {
                UnifiedPOS.CATEvents.DirectIOData value = deviceEvent.DirectIOEvent(sender.ToString(), e.EventId, e.TimeStamp, e.EventNumber, e.Data, e.Object);
                e.Data = value.Data;
                e.Object = value.Obj;
            }
        }

        private void device_ErrorEvent(object sender, Microsoft.PointOfService.DeviceErrorEventArgs e)
        {
            //throw new NotImplementedException();
            if (deviceEvent != null)
            {
                UnifiedPOS.CATEvents.ErrorResponse value = deviceEvent.ErrorEvent(sender.ToString(), e.EventId, e.TimeStamp, (UnifiedPOS.CATEvents.ErrorCode)EventConvert[e.ErrorCode], e.ErrorCodeExtended, (UnifiedPOS.CATEvents.ErrorLocus)EventConvert[e.ErrorLocus], (UnifiedPOS.CATEvents.ErrorResponse)EventConvert[e.ErrorResponse]);
                e.ErrorResponse = (Microsoft.PointOfService.ErrorResponse)EventConvert[value];
            }
        }

        private void device_OutputCompleteEvent(object sender, Microsoft.PointOfService.OutputCompleteEventArgs e)
        {
            //throw new NotImplementedException();
            if (deviceEvent != null)
            {
                deviceEvent.OutputCompleteEvent(sender.ToString(), e.EventId, e.TimeStamp, e.OutputId);
            }
        }

        private void device_StatusUpdateEvent(object sender, Microsoft.PointOfService.StatusUpdateEventArgs e)
        {
            //throw new NotImplementedException();
            if (deviceEvent != null)
            {
                deviceEvent.StatusUpdateEvent(sender.ToString(), e.EventId, e.TimeStamp, e.Status);
            }
        }

        #endregion

        #region IDisposable Member

        public void Dispose()
        {
            //throw new NotImplementedException();
            if (device != null)
            {
                try
                {
                    device.Close();
                }
                catch
                {
                }
                finally
                {
                    device = null;
                }
            }
            if (deviceEvent != null)
            {
                try
                {
                    ((IClientChannel)deviceEvent).Close();
                }
                catch
                {
                }
                finally
                {
                    deviceEvent = null;
                }
            }
        }

        #endregion
    }
}
