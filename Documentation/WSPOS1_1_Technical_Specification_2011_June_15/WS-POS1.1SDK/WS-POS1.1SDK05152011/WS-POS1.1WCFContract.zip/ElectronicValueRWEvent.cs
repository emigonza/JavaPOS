﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace UnifiedPOS.ElectronicValueRWEvents
{
    [ServiceContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRWEvents/")]
    public interface ElectronicValueRWEvent
    {

        //
        // Events
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRWEvents/DataEvent", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRWEvents/DataEventResponse")]
        void DataEvent(string Source, int EventID, DateTime TimeStamp, int Status);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRWEvents/DirectIOEvent", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRWEvents/DirectIOEventResponse")]
        DirectIOData DirectIOEvent(string Source, int EventID, DateTime TimeStamp, int EventNumber, int Data, object Obj);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRWEvents/ErrorEvent", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRWEvents/ErrorEventResponse")]
        ErrorResponse ErrorEvent(string Source, int EventID, DateTime TimeStamp, ErrorCode ErrorCode, int ErrorCodeExtended, ErrorLocus ErrorLocus, ErrorResponse ErrorResponse);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRWEvents/OutputCompleteEvent", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRWEvents/OutputCompleteEventResponse")]
        void OutputCompleteEvent(string Source, int EventID, DateTime TimeStamp, int OutputID);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRWEvents/StatusUpdateEvent", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRWEvents/StatusUpdateEventResponse")]
        void StatusUpdateEvent(string Source, int EventID, DateTime TimeStamp, int Status);
    }

    //
    // Common Data Types
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRWEvents/")]
    public class DirectIOData
    {
        [DataMember]
        public int Data { get; set; }
        [DataMember]
        public object Obj { get; set; }
    }

    //
    // Common Enumerations
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRWEvents/")]
    public enum ErrorCode
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Claimed,
        [EnumMember]
        Closed,
        [EnumMember]
        Deprecated,
        [EnumMember]
        Disabled,
        [EnumMember]
        Exists,
        [EnumMember]
        Extended,
        [EnumMember]
        Failure,
        [EnumMember]
        Illegal,
        [EnumMember]
        NoExist,
        [EnumMember]
        NoHardware,
        [EnumMember]
        NoService,
        [EnumMember]
        NotClaimed,
        [EnumMember]
        Offline,
        [EnumMember]
        Success,
        [EnumMember]
        Timeout,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRWEvents/")]
    public enum ErrorLocus
    {
        [EnumMember]
        Input,
        [EnumMember]
        InputData,
        [EnumMember]
        Output,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ElectronicValueRWEvents/")]
    public enum ErrorResponse
    {
        [EnumMember]
        Clear,
        [EnumMember]
        ContinueInput,
        [EnumMember]
        Retry,
    }

    //
    // Specific Data Types
    //

    //
    // Specific Enumerations
    //

    //
    // Constants
    //

    /*
    public class Constants
    {
        public const int ExtendedErrorCenterError = 203;
        public const int ExtendedErrorCommandError = 204;
        public const int ExtendedErrorCommunicationError = 206;
        public const int ExtendedErrorDailyLogOverflow = 208;
        public const int ExtendedErrorDeficient = 209;
        public const int ExtendedErrorFirmwareBadFile = 281;
        public const int ExtendedErrorLogOverflow = 207;
        public const int ExtendedErrorNoCard = 201;
        public const int ExtendedErrorOverdeposit = 210;
        public const int ExtendedErrorRelease = 202;
        public const int ExtendedErrorReset = 205;
        public const int ExtendedErrorStatistics = 280;
        public const int ExtendedErrorStatisticsDependency = 282;
        public const int StatusCardCaptured = 24;
        public const int StatusCardDetected = 22;
        public const int StatusCardEntered = 23;
        public const int StatusLogFull = 13;
        public const int StatusLogNearFull = 12;
        public const int StatusLogOk = 11;
        public const int StatusNoCard = 21;
        public const int StatusPowerOff = 2002;
        public const int StatusPowerOffline = 2003;
        public const int StatusPowerOffOffline = 2004;
        public const int StatusPowerOnline = 2001;
        public const int StatusUpdateFirmwareComplete = 2200;
        public const int StatusUpdateFirmwareCompleteDeviceNotRestored = 2205;
        public const int StatusUpdateFirmwareFailedDeviceNeedsFirmware = 2203;
        public const int StatusUpdateFirmwareFailedDeviceOk = 2201;
        public const int StatusUpdateFirmwareFailedDeviceUnknown = 2204;
        public const int StatusUpdateFirmwareFailedDeviceUnrecoverable = 2202;
        public const int StatusUpdateFirmwareProgress = 2100;
    }
    */

    public class ExtendedError
    {
        public const int CenterError = 203;
        public const int CommandError = 204;
        public const int CommunicationError = 206;
        public const int DailyLogOverflow = 208;
        public const int Deficient = 209;
        public const int FirmwareBadFile = 281;
        public const int LogOverflow = 207;
        public const int NoCard = 201;
        public const int Overdeposit = 210;
        public const int Release = 202;
        public const int Reset = 205;
        public const int Statistics = 280;
        public const int StatisticsDependency = 282;
    }

    public class Status
    {
        public const int CardCaptured = 24;
        public const int CardDetected = 22;
        public const int CardEntered = 23;
        public const int LogFull = 13;
        public const int LogNearFull = 12;
        public const int LogOk = 11;
        public const int NoCard = 21;
        public const int PowerOff = 2002;
        public const int PowerOffline = 2003;
        public const int PowerOffOffline = 2004;
        public const int PowerOnline = 2001;
        public const int UpdateFirmwareComplete = 2200;
        public const int UpdateFirmwareCompleteDeviceNotRestored = 2205;
        public const int UpdateFirmwareFailedDeviceNeedsFirmware = 2203;
        public const int UpdateFirmwareFailedDeviceOk = 2201;
        public const int UpdateFirmwareFailedDeviceUnknown = 2204;
        public const int UpdateFirmwareFailedDeviceUnrecoverable = 2202;
        public const int UpdateFirmwareProgress = 2100;
    }
}
