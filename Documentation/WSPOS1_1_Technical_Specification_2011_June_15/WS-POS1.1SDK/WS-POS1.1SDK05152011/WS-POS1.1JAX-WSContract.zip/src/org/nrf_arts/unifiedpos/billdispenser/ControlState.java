
package org.nrf_arts.unifiedpos.billdispenser;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ControlState.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="ControlState">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="Busy"/>
 *     &lt;enumeration value="Closed"/>
 *     &lt;enumeration value="Error"/>
 *     &lt;enumeration value="Idle"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "ControlState")
@XmlEnum
public enum ControlState {

    @XmlEnumValue("Busy")
    BUSY("Busy"),
    @XmlEnumValue("Closed")
    CLOSED("Closed"),
    @XmlEnumValue("Error")
    ERROR("Error"),
    @XmlEnumValue("Idle")
    IDLE("Idle");
    private final String value;

    ControlState(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ControlState fromValue(String v) {
        for (ControlState c: ControlState.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
