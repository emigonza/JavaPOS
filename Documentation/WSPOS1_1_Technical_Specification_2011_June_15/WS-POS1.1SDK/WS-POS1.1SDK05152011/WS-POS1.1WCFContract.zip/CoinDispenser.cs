﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace UnifiedPOS.CoinDispenser
{
    [ServiceContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/")]
    public interface CoinDispenser
    {

        //
        // Common Properties
        //

//        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/GetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/GetAutoDisableResponse")]
//        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/UposException", Name = "UposException")]
//        bool GetAutoDisable();

//        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/SetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/SetAutoDisableResponse")]
//        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/UposException", Name = "UposException")]
//        void SetAutoDisable(bool AutoDisable);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/GetCapCompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/GetCapCompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/UposException", Name = "UposException")]
        bool GetCapCompareFirmwareVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/GetCapPowerReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/GetCapPowerReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/UposException", Name = "UposException")]
        PowerReporting GetCapPowerReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/GetCapStatisticsReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/GetCapStatisticsReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/UposException", Name = "UposException")]
        bool GetCapStatisticsReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/GetCapUpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/GetCapUpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/UposException", Name = "UposException")]
        bool GetCapUpdateFirmware();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/GetCapUpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/GetCapUpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/UposException", Name = "UposException")]
        bool GetCapUpdateStatistics();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/GetCheckHealthText", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/GetCheckHealthTextResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/UposException", Name = "UposException")]
        string GetCheckHealthText();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/GetClaimed", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/GetClaimedResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/UposException", Name = "UposException")]
        bool GetClaimed();

//        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/GetDataCount", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/GetDataCountResponse")]
//        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/UposException", Name = "UposException")]
//        int GetDataCount();

//        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/GetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/GetDataEventEnabledResponse")]
//        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/UposException", Name = "UposException")]
//        bool GetDataEventEnabled();

//        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/SetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/SetDataEventEnabledResponse")]
//        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/UposException", Name = "UposException")]
//        void SetDataEventEnabled(bool DataEventEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/GetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/GetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/UposException", Name = "UposException")]
        bool GetDeviceEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/SetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/SetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/UposException", Name = "UposException")]
        void SetDeviceEnabled(bool DeviceEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/GetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/GetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/UposException", Name = "UposException")]
        bool GetFreezeEvents();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/SetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/SetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/UposException", Name = "UposException")]
        void SetFreezeEvents(bool FreezeEvents);

//        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/GetOutputID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/GetOutputIDResponse")]
//        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/UposException", Name = "UposException")]
//        int GetOutputID();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/GetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/GetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/UposException", Name = "UposException")]
        PowerNotification GetPowerNotify();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/SetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/SetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/UposException", Name = "UposException")]
        void SetPowerNotify(PowerNotification PowerNotify);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/GetPowerState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/GetPowerStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/UposException", Name = "UposException")]
        PowerState GetPowerState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/GetState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/GetStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/UposException", Name = "UposException")]
        ControlState GetState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/GetDeviceControlDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/GetDeviceControlDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/UposException", Name = "UposException")]
        string GetDeviceControlDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/GetDeviceControlVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/GetDeviceControlVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/UposException", Name = "UposException")]
        UposVersion GetDeviceControlVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/GetDeviceServiceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/GetDeviceServiceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/UposException", Name = "UposException")]
        string GetDeviceServiceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/GetDeviceServiceVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/GetDeviceServiceVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/UposException", Name = "UposException")]
        UposVersion GetDeviceServiceVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/GetPhysicalDeviceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/GetPhysicalDeviceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/UposException", Name = "UposException")]
        string GetPhysicalDeviceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/GetPhysicalDeviceName", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/GetPhysicalDeviceNameResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/UposException", Name = "UposException")]
        string GetPhysicalDeviceName();

        //
        // Specific Properties
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/GetCapEmptySensor", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/GetCapEmptySensorResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/UposException", Name = "UposException")]
        bool GetCapEmptySensor();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/GetCapJamSensor", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/GetCapJamSensorResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/UposException", Name = "UposException")]
        bool GetCapJamSensor();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/GetCapNearEmptySensor", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/GetCapNearEmptySensorResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/UposException", Name = "UposException")]
        bool GetCapNearEmptySensor();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/GetDispenserStatus", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/GetDispenserStatusResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/UposException", Name = "UposException")]
        CoinDispenserStatus GetDispenserStatus();

        //
        // Common Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/Open", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/OpenResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/UposException", Name = "UposException")]
        void Open(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/Close", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/CloseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/UposException", Name = "UposException")]
        void Close(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/Claim", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/ClaimResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/UposException", Name = "UposException")]
        void Claim(int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/Release", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/ReleaseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/UposException", Name = "UposException")]
        void Release();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/CheckHealth", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/CheckHealthResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/UposException", Name = "UposException")]
        void CheckHealth(HealthCheckLevel Level);

//        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/ClearInput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/ClearInputResponse")]
//        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/UposException", Name = "UposException")]
//        void ClearInput();

//        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/ClearInputProperties", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/ClearInputPropertiesResponse")]
//        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/UposException", Name = "UposException")]
//        void ClearInputProperties();

//        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/ClearOutput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/ClearOutputResponse")]
//        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/UposException", Name = "UposException")]
//        void ClearOutput();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/DirectIO", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/DirectIOResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/UposException", Name = "UposException")]
        DirectIOData DirectIO(int Command, int Data, object Obj);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/CompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/CompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/UposException", Name = "UposException")]
        CompareFirmwareResult CompareFirmwareVersion(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/ResetStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/ResetStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/UposException", Name = "UposException")]
        void ResetStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/RetrieveStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/RetrieveStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/UposException", Name = "UposException")]
        string RetrieveStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/UpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/UpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/UposException", Name = "UposException")]
        void UpdateFirmware(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/UpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/UpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/UposException", Name = "UposException")]
        void UpdateStatistics(StatisticList StatisticsBuffer);

        //
        // Specific Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/AdjustCashCounts", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/AdjustCashCountsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/UposException", Name = "UposException")]
//        public virtual void AdjustCashCounts(IEnumerable<CashCount> cashCounts);
//        void AdjustCashCounts(IEnumerable<CashCount> cashCounts);
        void AdjustCashCounts(CashCountList CashCounts);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/DispenseChange", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/DispenseChangeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/UposException", Name = "UposException")]
        void DispenseChange(int Amount);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/ReadCashCounts", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/ReadCashCountsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/UposException", Name = "UposException")]
//        public virtual CashCounts ReadCashCounts();
        CashCounts ReadCashCounts();
    }

    //
    // Common Data Types
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/")]
    public class DirectIOData
    {
        [DataMember]
        public int Data { get; set; }
        [DataMember]
        public object Obj { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/")]
    public class UposException
    {
        [DataMember]
        public ErrorCode ErrorCode { get; set; }
        [DataMember]
        public int ErrorCodeExtended { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/")]
    public class UposVersion
    {
        [DataMember]
        public int Major { get; set; }
        [DataMember]
        public int Minor { get; set; }
        [DataMember]
        public int Build { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/")]
    public class Statistic
    {
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public string Value { get; set; }
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/", ItemName = "Statistic")]
    public class StatisticList : List<Statistic>
    {
    }

    //
    // Common Enumerations
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/")]
    public enum CompareFirmwareResult
    {
        [EnumMember]
        Different,
        [EnumMember]
        Newer,
        [EnumMember]
        Older,
        [EnumMember]
        Same,
        [EnumMember]
        Unknown,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/")]
    public enum ControlState
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Closed,
        [EnumMember]
        Error,
        [EnumMember]
        Idle,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/")]
    public enum ErrorCode
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Claimed,
        [EnumMember]
        Closed,
        [EnumMember]
        Deprecated,
        [EnumMember]
        Disabled,
        [EnumMember]
        Exists,
        [EnumMember]
        Extended,
        [EnumMember]
        Failure,
        [EnumMember]
        Illegal,
        [EnumMember]
        NoExist,
        [EnumMember]
        NoHardware,
        [EnumMember]
        NoService,
        [EnumMember]
        NotClaimed,
        [EnumMember]
        Offline,
        [EnumMember]
        Success,
        [EnumMember]
        Timeout,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/")]
    public enum HealthCheckLevel
    {
        [EnumMember]
        External,
        [EnumMember]
        Interactive,
        [EnumMember]
        Internal,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/")]
    public enum PowerNotification
    {
        [EnumMember]
        Disabled,
        [EnumMember]
        Enabled,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/")]
    public enum PowerReporting
    {
        [EnumMember]
        Advanced,
        [EnumMember]
        None,
        [EnumMember]
        Standard,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/")]
    public enum PowerState
    {
        [EnumMember]
        Off,
        [EnumMember]
        Offline,
        [EnumMember]
        OffOffline,
        [EnumMember]
        Online,
        [EnumMember]
        Unknown,
    }

    /*
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/")]
    public enum StatisticCategories
    {
        [EnumMember]
        All,
        [EnumMember]
        Manufacturer,
        [EnumMember]
        Upos,
    }
    */
    public class StatisticCategories
    {
        public const string All = "";
        public const string Manufacturer = "M_";
        public const string Upos = "U_";
    }

    //
    // Specific Data Types
    //

    /*
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/")]
    public class Statistic
    {
        [DataMember]
        public string Name { get; }
        [DataMember]
        public object Value { get; set; }
    }
    */

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/")]
    public class CashCount
    {
        [DataMember]
        public int Count { get; set; }
        [DataMember]
        public int NominalValue { get; set; }
        [DataMember]
        public CashCountType Type { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/")]
    public class CashCounts
    {
        [DataMember]
        public CashCountList Counts { get; set; }
        [DataMember]
        public bool Discrepancy { get; set; }
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/", ItemName = "CashCount")]
    public class CashCountList : List<CashCount>
    {
    }

    //
    // Specific Enumerations
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/")]
    public enum CoinDispenserStatus
    {
        [EnumMember]
        Empty,
        [EnumMember]
        Jam,
        [EnumMember]
        NearEmpty,
        [EnumMember]
        OK,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CoinDispenser/")]
    public enum CashCountType
    {
        [EnumMember]
        Bill,
        [EnumMember]
        Coin,
    }
    
    //
    // Constants
    //

    public class ExtendedError
    {
        public const int FirmwareBadFile = 281;
        public const int Statistics = 280;
        public const int StatisticsDependency = 282;
    }

    public class StatisticProperties
    {
        public const string CommunicationErrorCount = "CommunicationErrorCount";
        public const string DeviceCategory = "DeviceCategory";
        public const string FirmwareRevision = "FirmwareRevision";
        public const string HoursPoweredCount = "HoursPoweredCount";
        public const string InstallationDate = "InstallationDate";
        public const string Interface = "Interface";
        public const string ManufactureDate = "ManufactureDate";
        public const string ManufacturerName = "ManufacturerName";
        public const string MechanicalRevision = "MechanicalRevision";
        public const string ModelName = "ModelName";
        public const string SerialNumber = "SerialNumber";
        public const string UnifiedPOSVersion = "UnifiedPOSVersion";
    }

    public class Wait
    {
        public const int Forever = -1;
    }
}
