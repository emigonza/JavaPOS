﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace UnifiedPOS.FiscalPrinterEvents
{
    [ServiceContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinterEvents/")]
    public interface FiscalPrinterEvent
    {

        //
        // Events
        //

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinterEvents/DataEvent", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinterEvents/DataEventResponse")]
        // void DataEvent(string Source, int EventID, DateTime TimeStamp, int Status);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinterEvents/DirectIOEvent", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinterEvents/DirectIOEventResponse")]
        DirectIOData DirectIOEvent(string Source, int EventID, DateTime TimeStamp, int EventNumber, int Data, object Obj);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinterEvents/ErrorEvent", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinterEvents/ErrorEventResponse")]
        ErrorResponse ErrorEvent(string Source, int EventID, DateTime TimeStamp, ErrorCode ErrorCode, int ErrorCodeExtended, ErrorLocus ErrorLocus, ErrorResponse ErrorResponse);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinterEvents/OutputCompleteEvent", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinterEvents/OutputCompleteEventResponse")]
        void OutputCompleteEvent(string Source, int EventID, DateTime TimeStamp, int OutputID);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinterEvents/StatusUpdateEvent", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinterEvents/StatusUpdateEventResponse")]
        void StatusUpdateEvent(string Source, int EventID, DateTime TimeStamp, int Status);
    }

    //
    // Common Data Types
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinterEvents/")]
    public class DirectIOData
    {
        [DataMember]
        public int Data { get; set; }
        [DataMember]
        public object Obj { get; set; }
    }

    //
    // Common Enumerations
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinterEvents/")]
    public enum ErrorCode
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Claimed,
        [EnumMember]
        Closed,
        [EnumMember]
        Deprecated,
        [EnumMember]
        Disabled,
        [EnumMember]
        Exists,
        [EnumMember]
        Extended,
        [EnumMember]
        Failure,
        [EnumMember]
        Illegal,
        [EnumMember]
        NoExist,
        [EnumMember]
        NoHardware,
        [EnumMember]
        NoService,
        [EnumMember]
        NotClaimed,
        [EnumMember]
        Offline,
        [EnumMember]
        Success,
        [EnumMember]
        Timeout,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinterEvents/")]
    public enum ErrorLocus
    {
        [EnumMember]
        Input,
        [EnumMember]
        InputData,
        [EnumMember]
        Output,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/FiscalPrinterEvents/")]
    public enum ErrorResponse
    {
        [EnumMember]
        Clear,
        [EnumMember]
        ContinueInput,
        [EnumMember]
        Retry,
    }

    //
    // Specific Data Types
    //

    //
    // Specific Enumerations
    //

    //
    // Constants
    //

    public class ExtendedError
    {
        public const int BadDate = 219;
        public const int BadItemAmount = 214;
        public const int BadItemDescription = 215;
        public const int BadItemQuantity = 213;
        public const int BadLength = 222;
        public const int BadPrice = 218;
        public const int BadVat = 217;
        public const int ClockError = 209;
        public const int CoverOpen = 201;
        public const int DayEndRequired = 224;
        public const int FirmwareBadFile = 281;
        public const int JournalEmpty = 202;
        public const int MemoryDisconnected = 211;
        public const int MemoryFull = 210;
        public const int MissingDevices = 206;
        public const int MissingSetCurrency = 223;
        public const int NegativeTotal = 220;
        public const int ReceiptEmpty = 203;
        public const int ReceiptTotalOverflow = 216;
        public const int SlipEmpty = 204;
        public const int SlipForm = 205;
        public const int Statistics = 280;
        public const int StatisticsDependency = 282;
        public const int TechnicalAssistance = 208;
        public const int TotalsError = 212;
        public const int WordNotAllowed = 221;
        public const int WrongState = 207;
    }

    public class Status
    {
        public const int CoverOK = 12;
        public const int CoverOpen = 11;
        public const int Idle = 1001;
        public const int JournalCoverOK = 61;
        public const int JournalCoverOpen = 60;
        public const int JournalEmpty = 21;
        public const int JournalNearEmpty = 22;
        public const int JournalPaperOK = 23;
        public const int PowerOff = 2002;
        public const int PowerOffline = 2003;
        public const int PowerOffOffline = 2004;
        public const int PowerOnline = 2001;
        public const int ReceiptCoverOK = 63;
        public const int ReceiptCoverOpen = 62;
        public const int ReceiptEmpty = 24;
        public const int ReceiptNearEmpty = 25;
        public const int ReceiptPaperOK = 26;
        public const int SlipCoverOK = 65;
        public const int SlipCoverOpen = 64;
        public const int SlipEmpty = 27;
        public const int SlipNearEmpty = 28;
        public const int SlipPaperOK = 29;
        public const int UpdateFirmwareComplete = 2200;
        public const int UpdateFirmwareCompleteDeviceNotRestored = 2205;
        public const int UpdateFirmwareFailedDeviceNeedsFirmware = 2203;
        public const int UpdateFirmwareFailedDeviceOk = 2201;
        public const int UpdateFirmwareFailedDeviceUnknown = 2204;
        public const int UpdateFirmwareFailedDeviceUnrecoverable = 2202;
        public const int UpdateFirmwareProgress = 2100;
    }
}
