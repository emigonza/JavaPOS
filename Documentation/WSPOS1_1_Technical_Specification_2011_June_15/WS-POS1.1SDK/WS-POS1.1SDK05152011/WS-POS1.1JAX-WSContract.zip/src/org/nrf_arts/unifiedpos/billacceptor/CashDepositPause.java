
package org.nrf_arts.unifiedpos.billacceptor;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for CashDepositPause.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="CashDepositPause">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="Pause"/>
 *     &lt;enumeration value="Restart"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "CashDepositPause")
@XmlEnum
public enum CashDepositPause {

    @XmlEnumValue("Pause")
    PAUSE("Pause"),
    @XmlEnumValue("Restart")
    RESTART("Restart");
    private final String value;

    CashDepositPause(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static CashDepositPause fromValue(String v) {
        for (CashDepositPause c: CashDepositPause.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
