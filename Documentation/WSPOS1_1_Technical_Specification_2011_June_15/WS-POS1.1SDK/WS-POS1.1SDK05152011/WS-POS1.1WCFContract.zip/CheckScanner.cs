﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace UnifiedPOS.CheckScanner
{
    [ServiceContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/")]
    public interface CheckScanner
    {

        //
        // Common Properties
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetAutoDisableResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        bool GetAutoDisable();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/SetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/SetAutoDisableResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        void SetAutoDisable(bool AutoDisable);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetCapCompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetCapCompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        bool GetCapCompareFirmwareVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetCapPowerReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetCapPowerReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        PowerReporting GetCapPowerReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetCapStatisticsReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetCapStatisticsReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        bool GetCapStatisticsReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetCapUpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetCapUpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        bool GetCapUpdateFirmware();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetCapUpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetCapUpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        bool GetCapUpdateStatistics();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetCheckHealthText", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetCheckHealthTextResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        string GetCheckHealthText();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetClaimed", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetClaimedResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        bool GetClaimed();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetDataCount", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetDataCountResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        int GetDataCount();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetDataEventEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        bool GetDataEventEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/SetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/SetDataEventEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        void SetDataEventEnabled(bool DataEventEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        bool GetDeviceEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/SetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/SetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        void SetDeviceEnabled(bool DeviceEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        bool GetFreezeEvents();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/SetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/SetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        void SetFreezeEvents(bool FreezeEvents);

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetOutputID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetOutputIDResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        // int GetOutputID();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        PowerNotification GetPowerNotify();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/SetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/SetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        void SetPowerNotify(PowerNotification PowerNotify);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetPowerState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetPowerStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        PowerState GetPowerState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        ControlState GetState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetDeviceControlDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetDeviceControlDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        string GetDeviceControlDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetDeviceControlVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetDeviceControlVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        UposVersion GetDeviceControlVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetDeviceServiceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetDeviceServiceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        string GetDeviceServiceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetDeviceServiceVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetDeviceServiceVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        UposVersion GetDeviceServiceVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetPhysicalDeviceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetPhysicalDeviceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        string GetPhysicalDeviceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetPhysicalDeviceName", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetPhysicalDeviceNameResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        string GetPhysicalDeviceName();

        //
        // Specific Properties
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetCapAutoContrast", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetCapAutoContrastResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        bool GetCapAutoContrast();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetCapAutoGenerateFileID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetCapAutoGenerateFileIDResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        bool GetCapAutoGenerateFileID();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetCapAutoGenerateImageTagData", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetCapAutoGenerateImageTagDataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        bool GetCapAutoGenerateImageTagData();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetCapAutoSize", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetCapAutoSizeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        bool GetCapAutoSize();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetCapColor", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetCapColorResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        int GetCapColor();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetCapConcurrentMICR", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetCapConcurrentMICRResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        bool GetCapConcurrentMICR();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetCapContrast", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetCapContrastResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        bool GetCapContrast();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetCapDefineCropArea", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetCapDefineCropAreaResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        bool GetCapDefineCropArea();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetCapImageFormat", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetCapImageFormatResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        int GetCapImageFormat();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetCapImageTagData", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetCapImageTagDataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        bool GetCapImageTagData();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetCapMICRDevice", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetCapMICRDeviceResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        bool GetCapMICRDevice();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetCapStoreImageFiles", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetCapStoreImageFilesResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        bool GetCapStoreImageFiles();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetCapValidationDevice", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetCapValidationDeviceResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        bool GetCapValidationDevice();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetColor", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetColorResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        int GetColor();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/SetColor", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/SetColorResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        void SetColor(int Color);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetConcurrentMICR", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetConcurrentMICRResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        bool GetConcurrentMICR();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/SetConcurrentMICR", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/SetConcurrentMICRResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        void SetConcurrentMICR(bool ConcurrentMICR);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetContrast", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetContrastResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        int GetContrast();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/SetContrast", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/SetContrastResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        void SetContrast(int Contrast);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetCropAreaCount", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetCropAreaCountResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        int GetCropAreaCount();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetDocumentHeight", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetDocumentHeightResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        int GetDocumentHeight();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/SetDocumentHeight", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/SetDocumentHeightResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        void SetDocumentHeight(int DocumentHeight);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetDocumentWidth", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetDocumentWidthResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        int GetDocumentWidth();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/SetDocumentWidth", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/SetDocumentWidthResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        void SetDocumentWidth(int DocumentWidth);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetFileID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetFileIDResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        string GetFileID();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/SetFileID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/SetFileIDResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        void SetFileID(string FileID);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetFileIndex", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetFileIndexResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        int GetFileIndex();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/SetFileIndex", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/SetFileIndexResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        void SetFileIndex(int FileIndex);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetImageData", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetImageDataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        byte[] GetImageData();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetImageFormat", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetImageFormatResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        int GetImageFormat();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/SetImageFormat", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/SetImageFormatResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        void SetImageFormat(int ImageFormat);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetImageMemoryStatus", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetImageMemoryStatusResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        ImageMemoryStatus GetImageMemoryStatus();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetImageTagData", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetImageTagDataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        string GetImageTagData();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/SetImageTagData", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/SetImageTagDataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        void SetImageTagData(string ImageTagData);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetMapMode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetMapModeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        MapMode GetMapMode();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/SetMapMode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/SetMapModeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        void SetMapMode(MapMode MapMode);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetMaxCropAreas", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetMaxCropAreasResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        int GetMaxCropAreas();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetQuality", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetQualityResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        int GetQuality();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/SetQuality", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/SetQualityResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        void SetQuality(int Quality);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetQualityList", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetQualityListResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        QualityList GetQualityList();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetRemainingImagesEstimate", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/GetRemainingImagesEstimateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        int GetRemainingImagesEstimate();

        //
        // Common Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/Open", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/OpenResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        void Open(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/Close", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/CloseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        void Close(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/Claim", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/ClaimResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        void Claim(int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/Release", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/ReleaseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        void Release();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/CheckHealth", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/CheckHealthResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        void CheckHealth(HealthCheckLevel Level);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/ClearInput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/ClearInputResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        void ClearInput();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/ClearInputProperties", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/ClearInputPropertiesResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        void ClearInputProperties();

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/ClearOutput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/ClearOutputResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        // void ClearOutput();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/DirectIO", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/DirectIOResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        DirectIOData DirectIO(int Command, int Data, object Obj);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/CompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/CompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        CompareFirmwareResult CompareFirmwareVersion(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/ResetStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/ResetStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        void ResetStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/RetrieveStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/RetrieveStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        string RetrieveStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        void UpdateFirmware(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        void UpdateStatistics(StatisticList StatisticsBuffer);

        //
        // Specific Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/BeginInsertion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/BeginInsertionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        void BeginInsertion(int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/BeginRemoval", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/BeginRemovalResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        void BeginRemoval(int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/ClearImage", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/ClearImageResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        void ClearImage(CheckImageClear By);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/DefineCropArea", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/DefineCropAreaResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        void DefineCropArea(int CropAreaID, int X, int Y, int CX, int CY);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/EndInsertion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/EndInsertionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        void EndInsertion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/EndRemoval", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/EndRemovalResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        void EndRemoval();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/RetrieveImage", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/RetrieveImageResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        void RetrieveImage(int CropAreaID);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/RetrieveMemory", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/RetrieveMemoryResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        void RetrieveMemory(CheckImageLocate By);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/StoreImage", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/StoreImageResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/UposException", Name = "UposException")]
        void StoreImage(int CropAreaID);
    }

    //
    // Common Data Types
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/")]
    public class DirectIOData
    {
        [DataMember]
        public int Data { get; set; }
        [DataMember]
        public object Obj { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/")]
    public class UposException
    {
        [DataMember]
        public ErrorCode ErrorCode { get; set; }
        [DataMember]
        public int ErrorCodeExtended { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/")]
    public class UposVersion
    {
        [DataMember]
        public int Major { get; set; }
        [DataMember]
        public int Minor { get; set; }
        [DataMember]
        public int Build { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/")]
    public class Statistic
    {
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public string Value { get; set; }
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/", ItemName = "Statistic")]
    public class StatisticList : List<Statistic>
    {
    }

    //
    // Common Enumerations
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/")]
    public enum CompareFirmwareResult
    {
        [EnumMember]
        Different,
        [EnumMember]
        Newer,
        [EnumMember]
        Older,
        [EnumMember]
        Same,
        [EnumMember]
        Unknown,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/")]
    public enum ControlState
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Closed,
        [EnumMember]
        Error,
        [EnumMember]
        Idle,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/")]
    public enum ErrorCode
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Claimed,
        [EnumMember]
        Closed,
        [EnumMember]
        Deprecated,
        [EnumMember]
        Disabled,
        [EnumMember]
        Exists,
        [EnumMember]
        Extended,
        [EnumMember]
        Failure,
        [EnumMember]
        Illegal,
        [EnumMember]
        NoExist,
        [EnumMember]
        NoHardware,
        [EnumMember]
        NoService,
        [EnumMember]
        NotClaimed,
        [EnumMember]
        Offline,
        [EnumMember]
        Success,
        [EnumMember]
        Timeout,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/")]
    public enum HealthCheckLevel
    {
        [EnumMember]
        External,
        [EnumMember]
        Interactive,
        [EnumMember]
        Internal,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/")]
    public enum PowerNotification
    {
        [EnumMember]
        Disabled,
        [EnumMember]
        Enabled,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/")]
    public enum PowerReporting
    {
        [EnumMember]
        Advanced,
        [EnumMember]
        None,
        [EnumMember]
        Standard,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/")]
    public enum PowerState
    {
        [EnumMember]
        Off,
        [EnumMember]
        Offline,
        [EnumMember]
        OffOffline,
        [EnumMember]
        Online,
        [EnumMember]
        Unknown,
    }

    /*
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/")]
    public enum StatisticCategories
    {
        [EnumMember]
        All,
        [EnumMember]
        Manufacturer,
        [EnumMember]
        Upos,
    }
    */
    public class StatisticCategories
    {
        public const string All = "";
        public const string Manufacturer = "M_";
        public const string Upos = "U_";
    }

    //
    // Specific Data Types
    //

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/", ItemName = "Quality")]
    public class QualityList : List<int>
    {
    }

    //
    // Specific Enumerations
    //

    /*
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/")]
    public enum CheckColors
    {
        [EnumMember]
        Color16,
        [EnumMember]
        Color256,
        [EnumMember]
        Full,
        [EnumMember]
        GrayScale,
        [EnumMember]
        Mono,
    }
    */
    public class CheckColors
    {
        public const int Color16 = 4;
        public const int Color256 = 8;
        public const int Full = 16;
        public const int GrayScale = 2;
        public const int Mono = 1;
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/")]
    public enum CheckImageClear
    {
        [EnumMember]
        All,
        [EnumMember]
        FileId,
        [EnumMember]
        FileIndex,
        [EnumMember]
        ImageTagData,
    }

    /*
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/")]
    public enum CheckImageFormats
    {
        [EnumMember]
        Bmp,
        [EnumMember]
        Gif,
        [EnumMember]
        Jpeg,
        [EnumMember]
        Native,
        [EnumMember]
        Tiff,
    }
    */
    public class CheckImageFormats
    {
        public const int Bmp = 4;
        public const int Gif = 16;
        public const int Jpeg = 8;
        public const int Native = 1;
        public const int Tiff = 2;
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/")]
    public enum CheckImageLocate
    {
        [EnumMember]
        FileId,
        [EnumMember]
        FileIndex,
        [EnumMember]
        ImageTagData,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/")]
    public enum ImageMemoryStatus
    {
        [EnumMember]
        Empty,
        [EnumMember]
        Full,
        [EnumMember]
        OK,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CheckScanner/")]
    public enum MapMode
    {
        [EnumMember]
        Dots,
        [EnumMember]
        English,
        [EnumMember]
        Metric,
        [EnumMember]
        Twips,
    }

    //
    // Constants
    //

    /*
    public class Constants
    {
        public const int AutomaticContrast = -1;
        public const int CropAreaBottom = -1;
        public const int CropAreaEntireImage = -1;
        public const int CropAreaResetAll = -2;
        public const int CropAreaRight = -1;
        public const int ExtendedErrorCheck = 202;
        public const int ExtendedErrorFirmwareBadFile = 281;
        public const int ExtendedErrorNoCheck = 201;
        public const int ExtendedErrorNoRoom = 203;
        public const int ExtendedErrorStatistics = 280;
        public const int ExtendedErrorStatisticsDependency = 282;
        public const int GetRawImageData = 1000;
        public const string StatisticChecksScannedCount = "ChecksScannedCount";
        public const string StatisticCommunicationErrorCount = "CommunicationErrorCount";
        public const string StatisticDeviceCategory = "DeviceCategory";
        public const string StatisticFirmwareRevision = "FirmwareRevision";
        public const string StatisticHoursPoweredCount = "HoursPoweredCount";
        public const string StatisticInstallationDate = "InstallationDate";
        public const string StatisticInterface = "Interface";
        public const string StatisticManufactureDate = "ManufactureDate";
        public const string StatisticManufacturerName = "ManufacturerName";
        public const string StatisticMechanicalRevision = "MechanicalRevision";
        public const string StatisticModelName = "ModelName";
        public const string StatisticSerialNumber = "SerialNumber";
        public const string StatisticUnifiedPOSVersion = "UnifiedPOSVersion";
        public const int StatusPowerOff = 2002;
        public const int StatusPowerOffline = 2003;
        public const int StatusPowerOffOffline = 2004;
        public const int StatusPowerOnline = 2001;
        public const int StatusScanComplete = 11;
        public const int StatusUpdateFirmwareComplete = 2200;
        public const int StatusUpdateFirmwareCompleteDeviceNotRestored = 2205;
        public const int StatusUpdateFirmwareFailedDeviceNeedsFirmware = 2203;
        public const int StatusUpdateFirmwareFailedDeviceOk = 2201;
        public const int StatusUpdateFirmwareFailedDeviceUnknown = 2204;
        public const int StatusUpdateFirmwareFailedDeviceUnrecoverable = 2202;
        public const int StatusUpdateFirmwareProgress = 2100;
        public const int WaitForever = -1;
    }
    */

    public class Command
    {
        public const int GetRawImageData = 1000;
    }

    public class Contrast
    {
        public const int Automatic = -1;
    }

    public class CropArea
    {
        public const int Bottom = -1;
        public const int EntireImage = -1;
        public const int ResetAll = -2;
        public const int Right = -1;
    }

    public class ExtendedError
    {
        public const int Check = 202;
        public const int FirmwareBadFile = 281;
        public const int NoCheck = 201;
        public const int NoRoom = 203;
        public const int Statistics = 280;
        public const int StatisticsDependency = 282;
    }

    public class StatisticProperties
    {
        public const string ChecksScannedCount = "ChecksScannedCount";
        public const string CommunicationErrorCount = "CommunicationErrorCount";
        public const string DeviceCategory = "DeviceCategory";
        public const string FirmwareRevision = "FirmwareRevision";
        public const string HoursPoweredCount = "HoursPoweredCount";
        public const string InstallationDate = "InstallationDate";
        public const string Interface = "Interface";
        public const string ManufactureDate = "ManufactureDate";
        public const string ManufacturerName = "ManufacturerName";
        public const string MechanicalRevision = "MechanicalRevision";
        public const string ModelName = "ModelName";
        public const string SerialNumber = "SerialNumber";
        public const string UnifiedPOSVersion = "UnifiedPOSVersion";
    }

    public class Wait
    {
        public const int Forever = -1;
    }
}
