
package org.nrf_arts.unifiedpos.biometrics;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ErrorCode.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="ErrorCode">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="Busy"/>
 *     &lt;enumeration value="Claimed"/>
 *     &lt;enumeration value="Closed"/>
 *     &lt;enumeration value="Deprecated"/>
 *     &lt;enumeration value="Disabled"/>
 *     &lt;enumeration value="Exists"/>
 *     &lt;enumeration value="Extended"/>
 *     &lt;enumeration value="Failure"/>
 *     &lt;enumeration value="Illegal"/>
 *     &lt;enumeration value="NoExist"/>
 *     &lt;enumeration value="NoHardware"/>
 *     &lt;enumeration value="NoService"/>
 *     &lt;enumeration value="NotClaimed"/>
 *     &lt;enumeration value="Offline"/>
 *     &lt;enumeration value="Success"/>
 *     &lt;enumeration value="Timeout"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "ErrorCode")
@XmlEnum
public enum ErrorCode {

    @XmlEnumValue("Busy")
    BUSY("Busy"),
    @XmlEnumValue("Claimed")
    CLAIMED("Claimed"),
    @XmlEnumValue("Closed")
    CLOSED("Closed"),
    @XmlEnumValue("Deprecated")
    DEPRECATED("Deprecated"),
    @XmlEnumValue("Disabled")
    DISABLED("Disabled"),
    @XmlEnumValue("Exists")
    EXISTS("Exists"),
    @XmlEnumValue("Extended")
    EXTENDED("Extended"),
    @XmlEnumValue("Failure")
    FAILURE("Failure"),
    @XmlEnumValue("Illegal")
    ILLEGAL("Illegal"),
    @XmlEnumValue("NoExist")
    NO_EXIST("NoExist"),
    @XmlEnumValue("NoHardware")
    NO_HARDWARE("NoHardware"),
    @XmlEnumValue("NoService")
    NO_SERVICE("NoService"),
    @XmlEnumValue("NotClaimed")
    NOT_CLAIMED("NotClaimed"),
    @XmlEnumValue("Offline")
    OFFLINE("Offline"),
    @XmlEnumValue("Success")
    SUCCESS("Success"),
    @XmlEnumValue("Timeout")
    TIMEOUT("Timeout");
    private final String value;

    ErrorCode(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ErrorCode fromValue(String v) {
        for (ErrorCode c: ErrorCode.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
