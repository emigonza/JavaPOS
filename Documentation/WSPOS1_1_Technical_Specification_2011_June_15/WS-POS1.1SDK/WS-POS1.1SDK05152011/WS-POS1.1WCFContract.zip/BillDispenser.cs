﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace UnifiedPOS.BillDispenser
{
    [ServiceContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/")]
    public interface BillDispenser
    {

        //
        // Common Properties
        //

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetAutoDisableResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        // bool GetAutoDisable();

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/SetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/SetAutoDisableResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        // void SetAutoDisable(bool AutoDisable);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetCapCompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetCapCompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        bool GetCapCompareFirmwareVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetCapPowerReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetCapPowerReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        PowerReporting GetCapPowerReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetCapStatisticsReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetCapStatisticsReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        bool GetCapStatisticsReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetCapUpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetCapUpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        bool GetCapUpdateFirmware();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetCapUpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetCapUpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        bool GetCapUpdateStatistics();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetCheckHealthText", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetCheckHealthTextResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        string GetCheckHealthText();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetClaimed", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetClaimedResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        bool GetClaimed();

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetDataCount", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetDataCountResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        // int GetDataCount();

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetDataEventEnabledResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        // bool GetDataEventEnabled();

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/SetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/SetDataEventEnabledResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        // void SetDataEventEnabled(bool DataEventEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        bool GetDeviceEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/SetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/SetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        void SetDeviceEnabled(bool DeviceEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        bool GetFreezeEvents();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/SetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/SetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        void SetFreezeEvents(bool FreezeEvents);

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetOutputID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetOutputIDResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        // int GetOutputID();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        PowerNotification GetPowerNotify();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/SetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/SetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        void SetPowerNotify(PowerNotification PowerNotify);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetPowerState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetPowerStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        PowerState GetPowerState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        ControlState GetState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetDeviceControlDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetDeviceControlDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        string GetDeviceControlDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetDeviceControlVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetDeviceControlVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        UposVersion GetDeviceControlVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetDeviceServiceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetDeviceServiceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        string GetDeviceServiceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetDeviceServiceVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetDeviceServiceVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        UposVersion GetDeviceServiceVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetPhysicalDeviceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetPhysicalDeviceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        string GetPhysicalDeviceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetPhysicalDeviceName", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetPhysicalDeviceNameResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        string GetPhysicalDeviceName();

        //
        // Specific Properties
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetCapDiscrepancy", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetCapDiscrepancyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        bool GetCapDiscrepancy();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetCapEmptySensor", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetCapEmptySensorResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        bool GetCapEmptySensor();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetCapJamSensor", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetCapJamSensorResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        bool GetCapJamSensor();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetCapNearEmptySensor", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetCapNearEmptySensorResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        bool GetCapNearEmptySensor();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetAsyncMode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetAsyncModeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        bool GetAsyncMode();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/SetAsyncMode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/SetAsyncModeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        void SetAsyncMode(bool AsyncMode);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetAsyncResultCode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetAsyncResultCodeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        int GetAsyncResultCode();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetAsyncResultCodeExtended", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetAsyncResultCodeExtendedResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        int GetAsyncResultCodeExtended();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetCurrencyCashList", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetCurrencyCashListResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        CashUnits GetCurrencyCashList();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetCurrencyCode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetCurrencyCodeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        string GetCurrencyCode();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/SetCurrencyCode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/SetCurrencyCodeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        void SetCurrencyCode(string CurrencyCode);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetCurrencyCodeList", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetCurrencyCodeListResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        CurrencyCodeList GetCurrencyCodeList();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetCurrentExit", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetCurrentExitResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        int GetCurrentExit();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/SetCurrentExit", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/SetCurrentExitResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        void SetCurrentExit(int CurrentExit);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetDeviceExits", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetDeviceExitsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        int GetDeviceExits();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetDeviceStatus", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetDeviceStatusResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        CashChangerStatus GetDeviceStatus();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetExitCashList", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/GetExitCashListResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        CashUnits GetExitCashList();


        //
        // Common Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/Open", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/OpenResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        void Open(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/Close", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/CloseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        void Close(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/Claim", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/ClaimResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        void Claim(int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/Release", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/ReleaseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        void Release();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/CheckHealth", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/CheckHealthResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        void CheckHealth(HealthCheckLevel Level);

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/ClearInput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/ClearInputResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        // void ClearInput();

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/ClearInputProperties", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/ClearInputPropertiesResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        // void ClearInputProperties();

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/ClearOutput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/ClearOutputResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        // void ClearOutput();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/DirectIO", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/DirectIOResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        DirectIOData DirectIO(int Command, int Data, object Obj);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/CompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/CompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        CompareFirmwareResult CompareFirmwareVersion(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/ResetStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/ResetStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        void ResetStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/RetrieveStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/RetrieveStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        string RetrieveStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        void UpdateFirmware(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        void UpdateStatistics(StatisticList StatisticsBuffer);

        //
        // Specific Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/AdjustCashCounts", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/AdjustCashCountsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        void AdjustCashCounts(CashCountList CashCounts);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/DispenseCash", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/DispenseCashResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        void DispenseCash(CashCountList CashCounts);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/ReadCashCounts", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/ReadCashCountsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/UposException", Name = "UposException")]
        CashCounts ReadCashCounts();


    }

    //
    // Common Data Types
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/")]
    public class DirectIOData
    {
        [DataMember]
        public int Data { get; set; }
        [DataMember]
        public object Obj { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/")]
    public class UposException
    {
        [DataMember]
        public ErrorCode ErrorCode { get; set; }
        [DataMember]
        public int ErrorCodeExtended { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/")]
    public class UposVersion
    {
        [DataMember]
        public int Major { get; set; }
        [DataMember]
        public int Minor { get; set; }
        [DataMember]
        public int Build { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/")]
    public class Statistic
    {
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public string Value { get; set; }
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/", ItemName = "Statistic")]
    public class StatisticList : List<Statistic>
    {
    }

    //
    // Common Enumerations
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/")]
    public enum CompareFirmwareResult
    {
        [EnumMember]
        Different,
        [EnumMember]
        Newer,
        [EnumMember]
        Older,
        [EnumMember]
        Same,
        [EnumMember]
        Unknown,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/")]
    public enum ControlState
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Closed,
        [EnumMember]
        Error,
        [EnumMember]
        Idle,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/")]
    public enum ErrorCode
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Claimed,
        [EnumMember]
        Closed,
        [EnumMember]
        Deprecated,
        [EnumMember]
        Disabled,
        [EnumMember]
        Exists,
        [EnumMember]
        Extended,
        [EnumMember]
        Failure,
        [EnumMember]
        Illegal,
        [EnumMember]
        NoExist,
        [EnumMember]
        NoHardware,
        [EnumMember]
        NoService,
        [EnumMember]
        NotClaimed,
        [EnumMember]
        Offline,
        [EnumMember]
        Success,
        [EnumMember]
        Timeout,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/")]
    public enum HealthCheckLevel
    {
        [EnumMember]
        External,
        [EnumMember]
        Interactive,
        [EnumMember]
        Internal,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/")]
    public enum PowerNotification
    {
        [EnumMember]
        Disabled,
        [EnumMember]
        Enabled,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/")]
    public enum PowerReporting
    {
        [EnumMember]
        Advanced,
        [EnumMember]
        None,
        [EnumMember]
        Standard,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/")]
    public enum PowerState
    {
        [EnumMember]
        Off,
        [EnumMember]
        Offline,
        [EnumMember]
        OffOffline,
        [EnumMember]
        Online,
        [EnumMember]
        Unknown,
    }

    /*
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/")]
    public enum StatisticCategories
    {
        [EnumMember]
        All,
        [EnumMember]
        Manufacturer,
        [EnumMember]
        Upos,
    }
    */
    public class StatisticCategories
    {
        public const string All = "";
        public const string Manufacturer = "M_";
        public const string Upos = "U_";
    }

    //
    // Specific Data Types
    //

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/", ItemName = "Bill")]
    public class BillList : List<int>
    {
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/")]
    public class CashCount
    {
        [DataMember]
        public int Count { get; set; }
        [DataMember]
        public int NominalValue { get; set; }
        [DataMember]
        public CashCountType Type { get; set; }
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/", ItemName = "CashCount")]
    public class CashCountList : List<CashCount>
    {
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/")]
    public class CashCounts
    {
        [DataMember]
        public CashCountList Counts { get; set; }
        [DataMember]
        public bool Discrepancy { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/")]
    public class CashUnits
    {
        [DataMember]
        public BillList Bills { get; set; }
        [DataMember]
        public CoinList Coins { get; set; }
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/", ItemName = "Coin")]
    public class CoinList : List<int>
    {
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/", ItemName = "CurrencyCode")]
    public class CurrencyCodeList : List<string>
    {
    }


    //
    // Specific Enumerations
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/")]
    public enum CashChangerStatus
    {
        [EnumMember]
        Empty,
        [EnumMember]
        Jam,
        [EnumMember]
        NearEmpty,
        [EnumMember]
        OK,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/BillDispenser/")]
    public enum CashCountType
    {
        [EnumMember]
        Bill,
        [EnumMember]
        Coin,
    }

    //
    // Constants
    //

    public class ExtendedError
    {
        public const int FirmwareBadFile = 281;
        public const int OverDispense = 201;
        public const int Statistics = 280;
        public const int StatisticsDependency = 282;
    }

    public class StatisticProperties
    {
        public const string CommunicationErrorCount = "CommunicationErrorCount";
        public const string DeviceCategory = "DeviceCategory";
        public const string FirmwareRevision = "FirmwareRevision";
        public const string HoursPoweredCount = "HoursPoweredCount";
        public const string InstallationDate = "InstallationDate";
        public const string Interface = "Interface";
        public const string ManufactureDate = "ManufactureDate";
        public const string ManufacturerName = "ManufacturerName";
        public const string MechanicalRevision = "MechanicalRevision";
        public const string ModelName = "ModelName";
        public const string SerialNumber = "SerialNumber";
        public const string UnifiedPOSVersion = "UnifiedPOSVersion";
    }

    public class Wait
    {
        public const int Forever = -1;
    }
}
