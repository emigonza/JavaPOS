/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package wspos;

import java.net.URL;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import jpos.events.DirectIOEvent;
import jpos.events.StatusUpdateEvent;
import org.nrf_arts.unifiedpos.belt.*;
import javax.jws.WebService;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.namespace.QName;
import javax.xml.ws.Service;

/**
 *
 * @author hideon
 */
@WebService(serviceName = "BeltService", endpointInterface = "org.nrf_arts.unifiedpos.belt.Belt", targetNamespace = "http://www.nrf-arts.org/UnifiedPOS/Belt/")
public class BeltService implements Belt, jpos.events.DirectIOListener, jpos.events.StatusUpdateListener {

    //
    // Belt Enumration Converter
    //

    private static HashMap<Enum, Integer> jposConst;
    private static HashMap<Integer, PowerReporting> powerReporting;
    private static HashMap<Integer, PowerNotification> powerNotification;
    private static HashMap<Integer, PowerState> powerState;
    private static HashMap<Integer, ControlState> controlState;
    private static HashMap<Integer, HealthCheckLevel> healthCheckLevel;
    private static HashMap<Integer, CompareFirmwareResult> compareFirmwareResult;
    private static HashMap<Integer, ErrorCode> errorCode;
    private static HashMap<Integer, BeltDirection> beltDirection;
    private static HashMap<Integer, BeltMotionStatus> beltMotionStatus;

    static {
        jposConst = new HashMap<Enum, Integer>();
        jposConst.put(PowerReporting.ADVANCED, jpos.Belt.JPOS_PR_ADVANCED);
        jposConst.put(PowerReporting.NONE, jpos.Belt.JPOS_PR_NONE);
        jposConst.put(PowerReporting.STANDARD, jpos.Belt.JPOS_PR_STANDARD);
        jposConst.put(PowerNotification.DISABLED, jpos.Belt.JPOS_PN_DISABLED);
        jposConst.put(PowerNotification.ENABLED, jpos.Belt.JPOS_PN_ENABLED);
        jposConst.put(PowerState.OFF, jpos.Belt.JPOS_PS_OFF);
        jposConst.put(PowerState.OFFLINE, jpos.Belt.JPOS_PS_OFFLINE);
        jposConst.put(PowerState.OFF_OFFLINE, jpos.Belt.JPOS_PS_OFF_OFFLINE);
        jposConst.put(PowerState.ONLINE, jpos.Belt.JPOS_PS_ONLINE);
        jposConst.put(PowerState.UNKNOWN, jpos.Belt.JPOS_PS_UNKNOWN);
        jposConst.put(ControlState.BUSY, jpos.Belt.JPOS_S_BUSY);
        jposConst.put(ControlState.CLOSED, jpos.Belt.JPOS_S_CLOSED);
        jposConst.put(ControlState.ERROR, jpos.Belt.JPOS_S_ERROR);
        jposConst.put(ControlState.IDLE, jpos.Belt.JPOS_S_IDLE);
        jposConst.put(HealthCheckLevel.EXTERNAL, jpos.Belt.JPOS_CH_EXTERNAL);
        jposConst.put(HealthCheckLevel.INTERACTIVE, jpos.Belt.JPOS_CH_INTERACTIVE);
        jposConst.put(HealthCheckLevel.INTERNAL, jpos.Belt.JPOS_CH_INTERNAL);
        jposConst.put(CompareFirmwareResult.DIFFERENT, jpos.Belt.JPOS_CFV_FIRMWARE_DIFFERENT);
        jposConst.put(CompareFirmwareResult.NEWER, jpos.Belt.JPOS_CFV_FIRMWARE_NEWER);
        jposConst.put(CompareFirmwareResult.OLDER, jpos.Belt.JPOS_CFV_FIRMWARE_OLDER);
        jposConst.put(CompareFirmwareResult.SAME, jpos.Belt.JPOS_CFV_FIRMWARE_SAME);
        jposConst.put(CompareFirmwareResult.UNKNOWN, jpos.Belt.JPOS_CFV_FIRMWARE_UNKNOWN);
        jposConst.put(ErrorCode.BUSY, jpos.Belt.JPOS_E_BUSY);
        jposConst.put(ErrorCode.CLAIMED, jpos.Belt.JPOS_E_CLAIMED);
        jposConst.put(ErrorCode.CLOSED, jpos.Belt.JPOS_E_CLOSED);
        jposConst.put(ErrorCode.DEPRECATED, jpos.Belt.JPOS_E_DEPRECATED);
        jposConst.put(ErrorCode.DISABLED, jpos.Belt.JPOS_E_DISABLED);
        jposConst.put(ErrorCode.EXISTS, jpos.Belt.JPOS_E_EXISTS);
        jposConst.put(ErrorCode.EXTENDED, jpos.Belt.JPOS_E_EXTENDED);
        jposConst.put(ErrorCode.FAILURE, jpos.Belt.JPOS_E_FAILURE);
        jposConst.put(ErrorCode.ILLEGAL, jpos.Belt.JPOS_E_ILLEGAL);
        jposConst.put(ErrorCode.NO_EXIST, jpos.Belt.JPOS_E_NOEXIST);
        jposConst.put(ErrorCode.NO_HARDWARE, jpos.Belt.JPOS_E_NOHARDWARE);
        jposConst.put(ErrorCode.NO_SERVICE, jpos.Belt.JPOS_E_NOSERVICE);
        jposConst.put(ErrorCode.NOT_CLAIMED, jpos.Belt.JPOS_E_NOTCLAIMED);
        jposConst.put(ErrorCode.OFFLINE, jpos.Belt.JPOS_E_OFFLINE);
        jposConst.put(ErrorCode.SUCCESS, 0);
        jposConst.put(ErrorCode.TIMEOUT, jpos.Belt.JPOS_E_TIMEOUT);
        jposConst.put(BeltDirection.BACKWARD, jpos.BeltConst.BELT_AIC_BACKWARD);
        jposConst.put(BeltDirection.FORWARD, jpos.BeltConst.BELT_AIC_FORWARD);
        //jposConst.put(BeltDirection.BACKWARD, jpos.BeltConst.BELT_RIC_BACKWARD);
        //jposConst.put(BeltDirection.FORWARD, jpos.BeltConst.BELT_RIC_FORWARD);
        jposConst.put(BeltMotionStatus.BACKWARD, jpos.BeltConst.BELT_MT_BACKWARD);
        jposConst.put(BeltMotionStatus.EMERGENCY, jpos.BeltConst.BELT_MT_EMERGENCY);
        jposConst.put(BeltMotionStatus.FORWARD, jpos.BeltConst.BELT_MT_FORWARD);
        jposConst.put(BeltMotionStatus.MOTOR_FAULT, jpos.BeltConst.BELT_MT_MOTOR_FAULT);
        jposConst.put(BeltMotionStatus.STOPPED, jpos.BeltConst.BELT_MT_STOPPED);

        powerReporting = new HashMap<Integer, PowerReporting>();
        powerReporting.put(jpos.Belt.JPOS_PR_ADVANCED, PowerReporting.ADVANCED);
        powerReporting.put(jpos.Belt.JPOS_PR_NONE, PowerReporting.NONE);
        powerReporting.put(jpos.Belt.JPOS_PR_STANDARD, PowerReporting.STANDARD);

        powerNotification = new HashMap<Integer, PowerNotification>();
        powerNotification.put(jpos.Belt.JPOS_PN_DISABLED, PowerNotification.DISABLED);
        powerNotification.put(jpos.Belt.JPOS_PN_ENABLED, PowerNotification.ENABLED);

        powerState = new HashMap<Integer, PowerState>();
        powerState.put(jpos.Belt.JPOS_PS_OFF, PowerState.OFF);
        powerState.put(jpos.Belt.JPOS_PS_OFFLINE, PowerState.OFFLINE);
        powerState.put(jpos.Belt.JPOS_PS_OFF_OFFLINE, PowerState.OFF_OFFLINE);
        powerState.put(jpos.Belt.JPOS_PS_ONLINE, PowerState.ONLINE);
        powerState.put(jpos.Belt.JPOS_PS_UNKNOWN, PowerState.UNKNOWN);

        controlState = new HashMap<Integer, ControlState>();
        controlState.put(jpos.Belt.JPOS_S_BUSY, ControlState.BUSY);
        controlState.put(jpos.Belt.JPOS_S_CLOSED, ControlState.CLOSED);
        controlState.put(jpos.Belt.JPOS_S_ERROR, ControlState.ERROR);
        controlState.put(jpos.Belt.JPOS_S_IDLE, ControlState.IDLE);

        healthCheckLevel = new HashMap<Integer, HealthCheckLevel>();
        healthCheckLevel.put(jpos.Belt.JPOS_CH_EXTERNAL, HealthCheckLevel.EXTERNAL);
        healthCheckLevel.put(jpos.Belt.JPOS_CH_INTERACTIVE, HealthCheckLevel.INTERACTIVE);
        healthCheckLevel.put(jpos.Belt.JPOS_CH_INTERNAL, HealthCheckLevel.INTERNAL);

        compareFirmwareResult = new HashMap<Integer, CompareFirmwareResult>();
        compareFirmwareResult.put(jpos.Belt.JPOS_CFV_FIRMWARE_DIFFERENT, CompareFirmwareResult.DIFFERENT);
        compareFirmwareResult.put(jpos.Belt.JPOS_CFV_FIRMWARE_NEWER, CompareFirmwareResult.NEWER);
        compareFirmwareResult.put(jpos.Belt.JPOS_CFV_FIRMWARE_OLDER, CompareFirmwareResult.OLDER);
        compareFirmwareResult.put(jpos.Belt.JPOS_CFV_FIRMWARE_SAME, CompareFirmwareResult.SAME);
        compareFirmwareResult.put(jpos.Belt.JPOS_CFV_FIRMWARE_UNKNOWN, CompareFirmwareResult.UNKNOWN);

        errorCode = new HashMap<Integer, ErrorCode>();
        errorCode.put(jpos.Belt.JPOS_E_BUSY, ErrorCode.BUSY);
        errorCode.put(jpos.Belt.JPOS_E_CLAIMED, ErrorCode.CLAIMED);
        errorCode.put(jpos.Belt.JPOS_E_CLOSED, ErrorCode.CLOSED);
        errorCode.put(jpos.Belt.JPOS_E_DEPRECATED, ErrorCode.DEPRECATED);
        errorCode.put(jpos.Belt.JPOS_E_DISABLED, ErrorCode.DISABLED);
        errorCode.put(jpos.Belt.JPOS_E_EXISTS, ErrorCode.EXISTS);
        errorCode.put(jpos.Belt.JPOS_E_EXTENDED, ErrorCode.EXTENDED);
        errorCode.put(jpos.Belt.JPOS_E_FAILURE, ErrorCode.FAILURE);
        errorCode.put(jpos.Belt.JPOS_E_ILLEGAL, ErrorCode.ILLEGAL);
        errorCode.put(jpos.Belt.JPOS_E_NOEXIST, ErrorCode.NO_EXIST);
        errorCode.put(jpos.Belt.JPOS_E_NOHARDWARE, ErrorCode.NO_HARDWARE);
        errorCode.put(jpos.Belt.JPOS_E_NOSERVICE, ErrorCode.NO_SERVICE);
        errorCode.put(jpos.Belt.JPOS_E_NOTCLAIMED, ErrorCode.NOT_CLAIMED);
        errorCode.put(jpos.Belt.JPOS_E_OFFLINE, ErrorCode.OFFLINE);
        errorCode.put(0, ErrorCode.SUCCESS);
        errorCode.put(jpos.Belt.JPOS_E_TIMEOUT, ErrorCode.TIMEOUT);

        beltDirection = new HashMap<Integer, BeltDirection>();
        beltDirection.put(jpos.BeltConst.BELT_AIC_BACKWARD, BeltDirection.BACKWARD);
        beltDirection.put(jpos.BeltConst.BELT_AIC_FORWARD, BeltDirection.FORWARD);
        //beltDirection.put(jpos.BeltConst.BELT_RIC_BACKWARD, BeltDirection.BACKWARD);
        //beltDirection.put(jpos.BeltConst.BELT_RIC_FORWARD, BeltDirection.FORWARD);

        beltMotionStatus = new HashMap<Integer, BeltMotionStatus>();
        beltMotionStatus.put(jpos.BeltConst.BELT_MT_BACKWARD, BeltMotionStatus.BACKWARD);
        beltMotionStatus.put(jpos.BeltConst.BELT_MT_EMERGENCY, BeltMotionStatus.EMERGENCY);
        beltMotionStatus.put(jpos.BeltConst.BELT_MT_FORWARD, BeltMotionStatus.FORWARD);
        beltMotionStatus.put(jpos.BeltConst.BELT_MT_MOTOR_FAULT, BeltMotionStatus.MOTOR_FAULT);
        beltMotionStatus.put(jpos.BeltConst.BELT_MT_STOPPED, BeltMotionStatus.STOPPED);
    }

    private String deviceName;
    private UposVersion deviceControlVersion;
    private org.nrf_arts.unifiedpos.beltevents.BeltEvent deviceEvent;
    private jpos.Belt device = new jpos.Belt();
    private DatatypeFactory datatypeFactory;

    public BeltService(String logicalDeviceName) {
        deviceName = logicalDeviceName;
        deviceControlVersion = new UposVersion();
        deviceControlVersion.setMajor(1);
        deviceControlVersion.setMinor(13);
        deviceControlVersion.setBuild(1);
        try {
            datatypeFactory = DatatypeFactory.newInstance();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    //
    // Belt Member
    //

    public void adjustItemCount(BeltDirection direction, Integer count) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.adjustItemCount(jposConst.get(direction), count);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void checkHealth(HealthCheckLevel level) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.checkHealth(jposConst.get(level));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void claim(Integer timeout) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.claim(timeout);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void close(String string) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            if (deviceEvent != null)
            {
                device.removeDirectIOListener(this);
                device.removeStatusUpdateListener(this);
                deviceEvent = null;
            }
            device.close();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public CompareFirmwareResult compareFirmwareVersion(String firmwareFileName) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            int[] param = new int[1];
            device.compareFirmwareVersion(firmwareFileName, param);
            return compareFirmwareResult.get(param[0]);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public DirectIOData directIO(Integer command, Integer data, Object obj) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            DirectIOData res = new DirectIOData();
            int[] param = new int[] { data };
            device.directIO(command, param, obj);
            res.setData(param[0]);
            res.setObj(obj);
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getAutoStopBackward() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getAutoStopBackward();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getAutoStopBackwardDelayTime() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getAutoStopBackwardDelayTime();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getAutoStopBackwardItemCount() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getAutoStopBackwardItemCount();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getAutoStopForward() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getAutoStopForward();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getAutoStopForwardDelayTime() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getAutoStopForwardDelayTime();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getAutoStopForwardItemCount() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getAutoStopForwardItemCount();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapAutoStopBackward() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapAutoStopBackward();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapAutoStopBackwardItemCount() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapAutoStopBackwardItemCount();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapAutoStopForward() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapAutoStopForward();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapAutoStopForwardItemCount() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapAutoStopForwardItemCount();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapCompareFirmwareVersion() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapCompareFirmwareVersion();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapLightBarrierBackward() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapLightBarrierBackward();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapLightBarrierForward() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapLightBarrierForward();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapMoveBackward() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapMoveBackward();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public PowerReporting getCapPowerReporting() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return powerReporting.get(device.getCapPowerReporting());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapSecurityFlapBackward() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapSecurityFlapBackward();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapSecurityFlapForward() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapSecurityFlapForward();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getCapSpeedStepsBackward() throws FaultException {
        throw new UnsupportedOperationException("Not supported yet.");
        /*
        try {
            return device.getCapSpeedStepsBackward();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
        */
    }

    public Integer getCapSpeedStepsForward() throws FaultException {
        throw new UnsupportedOperationException("Not supported yet.");
        /*
        try {
            return device.getCapSpeedStepsForward();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
        */
    }

    public Boolean getCapStatisticsReporting() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapStatisticsReporting();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapUpdateFirmware() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapUpdateFirmware();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapUpdateStatistics() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapUpdateStatistics();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getCheckHealthText() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCheckHealthText();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getClaimed() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getClaimed();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getDeviceControlDescription() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        return device.getDeviceControlDescription();
    }

    public UposVersion getDeviceControlVersion() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        UposVersion res = new UposVersion();
        int version = device.getDeviceControlVersion();
        res.setMajor(version / 1000000 % 1000);
        res.setMinor(version / 1000 % 1000);
        res.setBuild(version % 1000);
        return res;
    }

    public Boolean getDeviceEnabled() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getDeviceEnabled();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getDeviceServiceDescription() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getDeviceServiceDescription();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public UposVersion getDeviceServiceVersion() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            UposVersion res = new UposVersion();
            int version = device.getDeviceServiceVersion();
            res.setMajor(version / 1000000 % 1000);
            res.setMinor(version / 1000 % 1000);
            res.setBuild(version % 1000);
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getFreezeEvents() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getFreezeEvents();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getLightBarrierBackwardInterrupted() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getLightBarrierBackwardInterrupted();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getLightBarrierForwardInterrupted() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getLightBarrierForwardInterrupted();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public BeltMotionStatus getMotionStatus() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return beltMotionStatus.get(device.getMotionStatus());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getPhysicalDeviceDescription() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getPhysicalDeviceDescription();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getPhysicalDeviceName() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getPhysicalDeviceName();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public PowerNotification getPowerNotify() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return powerNotification.get(device.getPowerNotify());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public PowerState getPowerState() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return powerState.get(device.getPowerState());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getSecurityFlapBackwardOpened() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getSecurityFlapBackwardOpened();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getSecurityFlapForwardOpened() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getSecurityFlapForwardOpened();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public ControlState getState() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        return controlState.get(device.getState());
    }

    public void moveBackward(Integer speed) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.moveBackward(speed);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void moveForward(Integer speed) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.moveForward(speed);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void open(String endpointAddress) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.open(deviceName);
            if (endpointAddress != null)
            {
                try {
                    Service service = Service.create(
                            new URL(endpointAddress + "?wsdl"),
                            new QName("http://www.nrf-arts.org/UnifiedPOS/BeltEvents/", "BeltEventService"));
                    deviceEvent = service.getPort(org.nrf_arts.unifiedpos.beltevents.BeltEvent.class);
                    device.addDirectIOListener(this);
                    device.addStatusUpdateListener(this);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void release() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.release();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void resetBelt() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.resetBelt();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void resetItemCount(BeltDirection direction) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.resetItemCount(jposConst.get(direction));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void resetStatistics(StatisticList statisticsBuffer) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            String param = null;
            List<Statistic> list = statisticsBuffer.getStatistic();
            switch (list.size()) {
                case 0:
                    param = "";
                    break;
                case 1:
                    String name = list.get(0).getName();
                    if (name.equals(StatisticCategories.ALL)) {
                        param = "";
                    }
                    else if (name.equals(StatisticCategories.MANUFACTURER)) {
                        param = "M_";
                    }
                    else if (name.equals(StatisticCategories.UPOS)) {
                        param = "U_";
                    }
                    else {
                        param = name;
                    }
                    break;
                default:
                    StringBuffer buffer = new StringBuffer();
                    for (Statistic statistic : statisticsBuffer.getStatistic()) {
                        buffer.append(",").append(statistic.getName());
                    }
                    param = buffer.substring(1);
                    break;
            }
            device.resetStatistics(param);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String retrieveStatistics(StatisticList statisticsBuffer) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            String[] param = new String[1];
            List<Statistic> list = statisticsBuffer.getStatistic();
            switch (list.size()) {
                case 0:
                    param[0] = "";
                    break;
                case 1:
                    String name = list.get(0).getName();
                    if (name.equals(StatisticCategories.ALL)) {
                        param[0] = "";
                    }
                    else if (name.equals(StatisticCategories.MANUFACTURER)) {
                        param[0] = "M_";
                    }
                    else if (name.equals(StatisticCategories.UPOS)) {
                        param[0] = "U_";
                    }
                    else {
                        param[0] = name;
                    }
                    break;
                default:
                    StringBuffer buffer = new StringBuffer();
                    for (Statistic statistic : statisticsBuffer.getStatistic()) {
                        buffer.append(",").append(statistic.getName());
                    }
                    param[0] = buffer.substring(1);
                    break;
            }
            device.retrieveStatistics(param);
            return param[0];
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setAutoStopBackward(Boolean autoStopBackward) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setAutoStopBackward(autoStopBackward);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setAutoStopBackwardDelayTime(Integer autoStopBackwardDelayTime) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setAutoStopBackwardDelayTime(autoStopBackwardDelayTime);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setAutoStopForward(Boolean autoStopForward) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setAutoStopForward(autoStopForward);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setAutoStopForwardDelayTime(Integer autoStopForwardDelayTime) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setAutoStopForwardDelayTime(autoStopForwardDelayTime);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setDeviceEnabled(Boolean deviceEnabled) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setDeviceEnabled(deviceEnabled);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setFreezeEvents(Boolean freezeEvents) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setFreezeEvents(freezeEvents);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setPowerNotify(PowerNotification powerNotify) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setPowerNotify(jposConst.get(powerNotify));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void stopBelt() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.stopBelt();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void updateFirmware(String firmwareFileName) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.updateFirmware(firmwareFileName);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void updateStatistics(StatisticList statisticsBuffer) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            String param = null;
            List<Statistic> list = statisticsBuffer.getStatistic();
            switch (list.size()) {
                case 0:
                    param = "";
                    break;
                case 1:
                    Statistic s = list.get(0);
                    String name = s.getName();
                    String value = s.getValue();
                    if (name.equals(StatisticCategories.ALL)) {
                        param = "=" + value;
                    }
                    else if (name.equals(StatisticCategories.MANUFACTURER)) {
                        param = "M_=" + value;
                    }
                    else if (name.equals(StatisticCategories.UPOS)) {
                        param = "U_=" + value;
                    }
                    else {
                        param = name + "=" + value;
                    }
                    break;
                default:
                    StringBuffer buffer = new StringBuffer();
                    for (Statistic statistic : statisticsBuffer.getStatistic()) {
                        buffer.append(",").append(statistic.getName()).append("=").append(statistic.getValue());
                    }
                    param = buffer.substring(1);
                    break;
            }
            device.updateStatistics(param);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    //
    // BeltEvent Member
    //

    public void directIOOccurred(DirectIOEvent dioe) {
        //throw new UnsupportedOperationException("Not supported yet.");
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(new Date(dioe.getWhen()));
        org.nrf_arts.unifiedpos.beltevents.DirectIOData value = deviceEvent.directIOEvent(
                dioe.getSource().toString(),
                (int)dioe.getSequenceNumber(),
                datatypeFactory.newXMLGregorianCalendar(cal),
                dioe.getEventNumber(),
                dioe.getData(),
                dioe.getObject());
        dioe.setData(value.getData());
        dioe.setObject(value.getObj());
    }

    public void statusUpdateOccurred(StatusUpdateEvent sue) {
        //throw new UnsupportedOperationException("Not supported yet.");
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(new Date(sue.getWhen()));
        deviceEvent.statusUpdateEvent(
                sue.getSource().toString(),
                (int)sue.getSequenceNumber(),
                datatypeFactory.newXMLGregorianCalendar(cal),
                sue.getStatus());
    }

}
