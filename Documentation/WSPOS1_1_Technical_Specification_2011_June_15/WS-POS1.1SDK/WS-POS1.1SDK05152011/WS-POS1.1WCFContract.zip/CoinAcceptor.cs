﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace UnifiedPOS.CoinAcceptor
{
    [ServiceContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/")]
    public interface CoinAcceptor
    {

        //
        // Common Properties
        //

//        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetAutoDisableResponse")]
//        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
//        bool GetAutoDisable();

//        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/SetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/SetAutoDisableResponse")]
//        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
//        void SetAutoDisable(bool AutoDisable);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetCapCompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetCapCompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
        bool GetCapCompareFirmwareVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetCapPowerReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetCapPowerReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
        PowerReporting GetCapPowerReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetCapStatisticsReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetCapStatisticsReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
        bool GetCapStatisticsReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetCapUpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetCapUpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
        bool GetCapUpdateFirmware();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetCapUpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetCapUpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
        bool GetCapUpdateStatistics();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetCheckHealthText", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetCheckHealthTextResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
        string GetCheckHealthText();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetClaimed", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetClaimedResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
        bool GetClaimed();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetDataCount", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetDataCountResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
        int GetDataCount();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetDataEventEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
        bool GetDataEventEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/SetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/SetDataEventEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
        void SetDataEventEnabled(bool DataEventEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
        bool GetDeviceEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/SetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/SetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
        void SetDeviceEnabled(bool DeviceEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
        bool GetFreezeEvents();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/SetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/SetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
        void SetFreezeEvents(bool FreezeEvents);

//        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetOutputID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetOutputIDResponse")]
//        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
//        int GetOutputID();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
        PowerNotification GetPowerNotify();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/SetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/SetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
        void SetPowerNotify(PowerNotification PowerNotify);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetPowerState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetPowerStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
        PowerState GetPowerState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
        ControlState GetState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetDeviceControlDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetDeviceControlDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
        string GetDeviceControlDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetDeviceControlVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetDeviceControlVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
        UposVersion GetDeviceControlVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetDeviceServiceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetDeviceServiceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
        string GetDeviceServiceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetDeviceServiceVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetDeviceServiceVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
        UposVersion GetDeviceServiceVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetPhysicalDeviceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetPhysicalDeviceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
        string GetPhysicalDeviceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetPhysicalDeviceName", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetPhysicalDeviceNameResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
        string GetPhysicalDeviceName();

        //
        // Specific Properties
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetCapDiscrepancy", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetCapDiscrepancyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
        bool GetCapDiscrepancy();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetCapFullSensor", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetCapFullSensorResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
        bool GetCapFullSensor();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetCapJamSensor", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetCapJamSensorResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
        bool GetCapJamSensor();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetCapNearFullSensor", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetCapNearFullSensorResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
        bool GetCapNearFullSensor();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetCapPauseDeposit", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetCapPauseDepositResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
        bool GetCapPauseDeposit();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetCapRealTimeData", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetCapRealTimeDataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
        bool GetCapRealTimeData();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetCurrencyCode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetCurrencyCodeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
        string GetCurrencyCode();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/SetCurrencyCode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/SetCurrencyCodeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
        void SetCurrencyCode(string CurrencyCode);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetDepositAmount", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetDepositAmountResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
        int GetDepositAmount();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetDepositCashList", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetDepositCashListResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
        CashUnits GetDepositCashList();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetDepositCodeList", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetDepositCodeListResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
//        string[] GetDepositCodeList();
        DepositCodeList GetDepositCodeList();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetDepositCounts", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetDepositCountsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
//        CashCount[] GetDepositCounts();
        CashCountList GetDepositCounts();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetDepositStatus", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetDepositStatusResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
        DepositStatus GetDepositStatus();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetFullStatus", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetFullStatusResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
        CashChangerFullStatus GetFullStatus();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetRealTimeDataEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/GetRealTimeDataEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
        bool GetRealTimeDataEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/SetRealTimeDataEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/SetRealTimeDataEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
        void SetRealTimeDataEnabled(bool RealTimeDataEnabled);

        //
        // Common Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/Open", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/OpenResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
        void Open(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/Close", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/CloseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
        void Close(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/Claim", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/ClaimResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
        void Claim(int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/Release", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/ReleaseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
        void Release();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/CheckHealth", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/CheckHealthResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
        void CheckHealth(HealthCheckLevel Level);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/ClearInput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/ClearInputResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
        void ClearInput();

//        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/ClearInputProperties", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/ClearInputPropertiesResponse")]
//        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
//        void ClearInputProperties();

//        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/ClearOutput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/ClearOutputResponse")]
//        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
//        void ClearOutput();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/DirectIO", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/DirectIOResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
        DirectIOData DirectIO(int Command, int Data, object Obj);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/CompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/CompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
        CompareFirmwareResult CompareFirmwareVersion(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/ResetStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/ResetStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
        void ResetStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/RetrieveStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/RetrieveStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
        string RetrieveStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
        void UpdateFirmware(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
        void UpdateStatistics(StatisticList StatisticsBuffer);

        //
        // Specific Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/AdjustCashCounts", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/AdjustCashCountsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
//        void AdjustCashCounts(IEnumerable<CashCount> cashCounts);
        void AdjustCashCounts(CashCountList CashCounts);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/BeginDeposit", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/BeginDepositResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
        void BeginDeposit();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/EndDeposit", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/EndDepositResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
        void EndDeposit(EndDepositAction Success);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/FixDeposit", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/FixDepositResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
        void FixDeposit();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/PauseDeposit", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/PauseDepositResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
        void PauseDeposit(CashDepositPause Control);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/ReadCashCounts", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/ReadCashCountsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/UposException", Name = "UposException")]
        CashCounts ReadCashCounts();
    }

    //
    // Common Data Types
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/")]
    public class DirectIOData
    {
        [DataMember]
        public int Data { get; set; }
        [DataMember]
        public object Obj { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/")]
    public class UposException
    {
        [DataMember]
        public ErrorCode ErrorCode { get; set; }
        [DataMember]
        public int ErrorCodeExtended { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/")]
    public class UposVersion
    {
        [DataMember]
        public int Major { get; set; }
        [DataMember]
        public int Minor { get; set; }
        [DataMember]
        public int Build { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/")]
    public class Statistic
    {
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public string Value { get; set; }
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/", ItemName = "Statistic")]
    public class StatisticList : List<Statistic>
    {
    }

    //
    // Common Enumerations
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/")]
    public enum CompareFirmwareResult
    {
        [EnumMember]
        Different,
        [EnumMember]
        Newer,
        [EnumMember]
        Older,
        [EnumMember]
        Same,
        [EnumMember]
        Unknown,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/")]
    public enum ControlState
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Closed,
        [EnumMember]
        Error,
        [EnumMember]
        Idle,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/")]
    public enum ErrorCode
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Claimed,
        [EnumMember]
        Closed,
        [EnumMember]
        Deprecated,
        [EnumMember]
        Disabled,
        [EnumMember]
        Exists,
        [EnumMember]
        Extended,
        [EnumMember]
        Failure,
        [EnumMember]
        Illegal,
        [EnumMember]
        NoExist,
        [EnumMember]
        NoHardware,
        [EnumMember]
        NoService,
        [EnumMember]
        NotClaimed,
        [EnumMember]
        Offline,
        [EnumMember]
        Success,
        [EnumMember]
        Timeout,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/")]
    public enum HealthCheckLevel
    {
        [EnumMember]
        External,
        [EnumMember]
        Interactive,
        [EnumMember]
        Internal,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/")]
    public enum PowerNotification
    {
        [EnumMember]
        Disabled,
        [EnumMember]
        Enabled,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/")]
    public enum PowerReporting
    {
        [EnumMember]
        Advanced,
        [EnumMember]
        None,
        [EnumMember]
        Standard,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/")]
    public enum PowerState
    {
        [EnumMember]
        Off,
        [EnumMember]
        Offline,
        [EnumMember]
        OffOffline,
        [EnumMember]
        Online,
        [EnumMember]
        Unknown,
    }

    /*
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/")]
    public enum StatisticCategories
    {
        [EnumMember]
        All,
        [EnumMember]
        Manufacturer,
        [EnumMember]
        Upos,
    }
    */
    public class StatisticCategories
    {
        public const string All = "";
        public const string Manufacturer = "M_";
        public const string Upos = "U_";
    }

    //
    // Specific Data Types
    //

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/", ItemName = "Bill")]
    public class BillList : List<int>
    {
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/")]
    public class CashCount
    {
        [DataMember]
        public int Count { get; set; }
        [DataMember]
        public int NominalValue { get; set; }
        [DataMember]
        public CashCountType Type { get; set; }
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/", ItemName = "CashCount")]
    public class CashCountList : List<CashCount>
    {
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/")]
    public class CashCounts
    {
        [DataMember]
        public CashCountList Counts { get; set; }
        [DataMember]
        public bool Discrepancy { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/")]
    public class CashUnits
    {
        [DataMember]
        public BillList Bills { get; set; }
        [DataMember]
        public CoinList Coins { get; set; }
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/", ItemName = "Coin")]
    public class CoinList : List<int>
    {
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/", ItemName = "DepositCode")]
    public class DepositCodeList : List<string>
    {
    }

    //
    // Specific Enumerations
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/")]
    public enum DepositStatus
    {
        [EnumMember]
        Count,
        [EnumMember]
        End,
        [EnumMember]
        Jam,
        [EnumMember]
        Start,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/")]
    public enum EndDepositAction
    {
        [EnumMember]
        Complete,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/")]
    public enum CashChangerFullStatus
    {
        [EnumMember]
        Full,
        [EnumMember]
        NearFull,
        [EnumMember]
        OK,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/")]
    public enum CashDepositPause
    {
        [EnumMember]
        Pause,
        [EnumMember]
        Restart,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CoinAcceptor/")]
    public enum CashCountType
    {
        [EnumMember]
        Bill,
        [EnumMember]
        Coin,
    }

    //
    // Constants
    //

    public class ExtendedError
    {
        public const int FirmwareBadFile = 281;
        public const int Statistics = 280;
        public const int StatisticsDependency = 282;
    }

    public class StatisticProperties
    {
        public const string CommunicationErrorCount = "CommunicationErrorCount";
        public const string DeviceCategory = "DeviceCategory";
        public const string FirmwareRevision = "FirmwareRevision";
        public const string HoursPoweredCount = "HoursPoweredCount";
        public const string InstallationDate = "InstallationDate";
        public const string Interface = "Interface";
        public const string ManufactureDate = "ManufactureDate";
        public const string ManufacturerName = "ManufacturerName";
        public const string MechanicalRevision = "MechanicalRevision";
        public const string ModelName = "ModelName";
        public const string SerialNumber = "SerialNumber";
        public const string UnifiedPOSVersion = "UnifiedPOSVersion";
    }

    public class Wait
    {
        public const int Forever = -1;
    }
}
