
package org.nrf_arts.unifiedpos.billacceptor;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DepositStatus.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="DepositStatus">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="Start"/>
 *     &lt;enumeration value="End"/>
 *     &lt;enumeration value="Count"/>
 *     &lt;enumeration value="Jam"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "DepositStatus")
@XmlEnum
public enum DepositStatus {

    @XmlEnumValue("Start")
    START("Start"),
    @XmlEnumValue("End")
    END("End"),
    @XmlEnumValue("Count")
    COUNT("Count"),
    @XmlEnumValue("Jam")
    JAM("Jam");
    private final String value;

    DepositStatus(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static DepositStatus fromValue(String v) {
        for (DepositStatus c: DepositStatus.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
