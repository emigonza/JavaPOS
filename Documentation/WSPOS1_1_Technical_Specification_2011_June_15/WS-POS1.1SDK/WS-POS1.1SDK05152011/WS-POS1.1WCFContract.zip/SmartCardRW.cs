﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace UnifiedPOS.SmartCardRW
{
    [ServiceContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/")]
    public interface SmartCardRW
    {
        //
        // Common Properties
        //

		// Not Supported
		//[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetAutoDisableResponse")]
		//[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
		//bool GetAutoDisable();

		//Not Supported
		//[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/SetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/SetAutoDisableResponse")]
		//[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
		//void SetAutoDisable(bool AutoDisable);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetCapCompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetCapCompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
        bool GetCapCompareFirmwareVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetCapPowerReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetCapPowerReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
        PowerReporting GetCapPowerReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetCapStatisticsReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetCapStatisticsReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
        bool GetCapStatisticsReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetCapUpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetCapUpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
        bool GetCapUpdateFirmware();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetCapUpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetCapUpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
        bool GetCapUpdateStatistics();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetCheckHealthText", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetCheckHealthTextResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
        string GetCheckHealthText();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetClaimed", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetClaimedResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
        bool GetClaimed();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetDataCount", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetDataCountResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
        int GetDataCount();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetDataEventEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
        bool GetDataEventEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/SetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/SetDataEventEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
        void SetDataEventEnabled(bool DataEventEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
        bool GetDeviceEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/SetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/SetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
        void SetDeviceEnabled(bool DeviceEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
        bool GetFreezeEvents();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/SetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/SetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
        void SetFreezeEvents(bool FreezeEvents);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetOutputID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetOutputIDResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
        int GetOutputID();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
        PowerNotification GetPowerNotify();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/SetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/SetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
        void SetPowerNotify(PowerNotification PowerNotify);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetPowerState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetPowerStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
        PowerState GetPowerState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
        ControlState GetState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetDeviceControlDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetDeviceControlDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
        string GetDeviceControlDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetDeviceControlVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetDeviceControlVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
        UposVersion GetDeviceControlVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetDeviceServiceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetDeviceServiceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
        string GetDeviceServiceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetDeviceServiceVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetDeviceServiceVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
        UposVersion GetDeviceServiceVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetPhysicalDeviceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetPhysicalDeviceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
        string GetPhysicalDeviceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetPhysicalDeviceName", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetPhysicalDeviceNameResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
        string GetPhysicalDeviceName();

        //
        // Specific Properties
		//


		[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetCapCardErrorDetection", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetCapCardErrorDetectionResponse")]
		[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
		bool GetCapCardErrorDetection();

		[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetCapInterfaceMode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetCapInterfaceModeResponse")]
		[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
		//SmartCardInterfaceModes GetCapInterfaceMode();
		int GetCapInterfaceMode();

		[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetCapIsoEmvMode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetCapIsoEmvModeResponse")]
		[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
		//SmartCardIsoEmvModes GetCapIsoEmvMode();
		int GetCapIsoEmvMode();

		[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetCapSCPresentSensor", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetCapSCPresentSensorResponse")]
		[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
		int GetCapSCPresentSensor();

		[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetCapSCSlots", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetCapSCSlotsResponse")]
		[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
		int GetCapSCSlots();

		[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetCapTransmissionProtocol", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetCapTransmissionProtocolResponse")]
		[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
		//SmartCardTransmissionProtocols GetCapTransmissionProtocol();
		int GetCapTransmissionProtocol();

		[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetInterfaceMode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetInterfaceModeResponse")]
		[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
		//SmartCardInterfaceModes 
		int GetInterfaceMode();

		[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/SetInterfaceMode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/SetInterfaceModeResponse")]
		[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
		//void SetInterfaceMode(SmartCardInterfaceModes InterfaceMode);
		void SetInterfaceMode(int InterfaceMode);

		[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetIsoEmvMode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetIsoEmvModeResponse")]
		[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
		//SmartCardIsoEmvModes GetIsoEmvMode();
		int GetIsoEmvMode();

		[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/SetIsoEmvMode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/SetIsoEmvModeResponse")]
		[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
		//void SetIsoEmvMode(SmartCardIsoEmvModes IsoEmvMode);
		void SetIsoEmvMode(int IsoEmvMode);

		[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetSCPresentSensor", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetSCPresentSensorResponse")]
		[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
		int GetSCPresentSensor();

		[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetSCSlot", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetSCSlotResponse")]
		[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
		int GetSCSlot();

		[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/SetSCSlot", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/SetSCSlotResponse")]
		[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
		void SetSCSlot(int SCSlot);

		[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetTransactionInProgress", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetTransactionInProgressResponse")]
		[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
		bool GetTransactionInProgress();

		[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetTransmissionProtocol", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/GetTransmissionProtocolResponse")]
		[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
		//SmartCardTransmissionProtocols GetTransmissionProtocol();
		int GetTransmissionProtocol();

        //
        // Common Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/Open", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/OpenResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
        void Open(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/Close", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/CloseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
        void Close(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/Claim", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/ClaimResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
        void Claim(int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/Release", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/ReleaseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
        void Release();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/CheckHealth", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/CheckHealthResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
        void CheckHealth(HealthCheckLevel Level);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/ClearInput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/ClearInputResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
        void ClearInput();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/ClearInputProperties", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/ClearInputPropertiesResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
        void ClearInputProperties();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/ClearOutput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/ClearOutputResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
        void ClearOutput();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/DirectIO", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/DirectIOResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
        DirectIOData DirectIO(int Command, int Data, object Obj);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/CompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/CompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
        CompareFirmwareResult CompareFirmwareVersion(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/ResetStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/ResetStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
        void ResetStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/RetrieveStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/RetrieveStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
        string RetrieveStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
        void UpdateFirmware(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
        void UpdateStatistics(StatisticList StatisticsBuffer);

        //
        // Specific Methods
        //

		[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/BeginInsertion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/BeginInsertionResponse")]
		[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
		void BeginInsertion(int Timeout);

		[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/BeginRemoval", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/BeginRemovalResponse")]
		[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
		void BeginRemoval(int Timeout);

		[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/EndInsertion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/EndInsertionResponse")]
		[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
		void EndInsertion();

		[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/EndRemoval", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/EndRemovalResponse")]
		[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
		void EndRemoval();

		[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/ReadData", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/ReadDataResponse")]
		[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
		byte[] ReadData(SmartCardReadAction Action, byte[] Data);

		[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/WriteData", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/WriteDataResponse")]
		[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/UposException", Name = "UposException")]
		void WriteData(SmartCardWriteAction Action, byte[] Data);
	}

    //
    // Common Data Types
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/")]
    public class DirectIOData
    {
        [DataMember]
        public int Data { get; set; }
        [DataMember]
        public object Obj { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/")]
    public class UposException
    {
        [DataMember]
        public ErrorCode ErrorCode { get; set; }
        [DataMember]
        public int ErrorCodeExtended { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/")]
    public class UposVersion
    {
        [DataMember]
        public int Major { get; set; }
        [DataMember]
        public int Minor { get; set; }
        [DataMember]
        public int Build { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/")]
    public class Statistic
    {
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public string Value { get; set; }
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/", ItemName = "Statistic")]
    public class StatisticList : List<Statistic>
    {
    }

    //
    // Common Enumerations
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/")]
    public enum CompareFirmwareResult
    {
        [EnumMember]
        Different,
        [EnumMember]
        Newer,
        [EnumMember]
        Older,
        [EnumMember]
        Same,
        [EnumMember]
        Unknown,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/")]
    public enum ControlState
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Closed,
        [EnumMember]
        Error,
        [EnumMember]
        Idle,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/")]
    public enum ErrorCode
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Claimed,
        [EnumMember]
        Closed,
        [EnumMember]
        Deprecated,
        [EnumMember]
        Disabled,
        [EnumMember]
        Exists,
        [EnumMember]
        Extended,
        [EnumMember]
        Failure,
        [EnumMember]
        Illegal,
        [EnumMember]
        NoExist,
        [EnumMember]
        NoHardware,
        [EnumMember]
        NoService,
        [EnumMember]
        NotClaimed,
        [EnumMember]
        Offline,
        [EnumMember]
        Success,
        [EnumMember]
        Timeout,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/")]
    public enum HealthCheckLevel
    {
        [EnumMember]
        External,
        [EnumMember]
        Interactive,
        [EnumMember]
        Internal,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/")]
    public enum PowerNotification
    {
        [EnumMember]
        Disabled,
        [EnumMember]
        Enabled,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/")]
    public enum PowerReporting
    {
        [EnumMember]
        Advanced,
        [EnumMember]
        None,
        [EnumMember]
        Standard,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/")]
    public enum PowerState
    {
        [EnumMember]
        Off,
        [EnumMember]
        Offline,
        [EnumMember]
        OffOffline,
        [EnumMember]
        Online,
        [EnumMember]
        Unknown,
    }

    /*
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/")]
    public enum StatisticCategories
    {
        [EnumMember]
        All,
        [EnumMember]
        Manufacturer,
        [EnumMember]
        Upos,
    }
    */
    public class StatisticCategories
    {
        public const string All = "";
        public const string Manufacturer = "M_";
        public const string Upos = "U_";
    }

    //
    // Specific Data Types
    //

    //
    // Specific Enumerations
    //

	// 削除理由：定数化
	//[DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/")]
	//public enum SmartCardInterfaceModes
	//{
	//    [EnumMember]
	//    Apdu,
	//    [EnumMember]
	//    Block,
	//    [EnumMember]
	//    Transaction,
	//    [EnumMember]
	//    Xml,
	//}

	// 削除理由：定数化
	//[DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/")]
	//public enum SmartCardIsoEmvModes
	//{
	//    [EnumMember]
	//    Emv,
	//    [EnumMember]
	//    Iso,
	//}


	[DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/")]
	public enum SmartCardReadAction
	{
		[EnumMember]
		ReadData,
		[EnumMember]
		ReadProgram,
		[EnumMember]
		ExecuteAndReadData,
		[EnumMember]
		XmlReadBlockData,
	}

	// 削除理由：定数化
	//[DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/")]
	//public enum SmartCardTransmissionProtocols
	//{
	//    [EnumMember]
	//    T0,
	//    [EnumMember]
	//    T1,
	//}

	[DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/SmartCardRW/")]
	public enum SmartCardWriteAction
	{
		[EnumMember]
		StoreData,
		[EnumMember]
		StoreProgram,
		[EnumMember]
		ExecuteData,
		[EnumMember]
		XmlBlockData,
		[EnumMember]
		SecurityFuse,
		[EnumMember]
		Reset,
	}

    //
    // Constants
    //

    public class ExtendedError
    {
        public const int FirmwareBadFile = 281;
        public const int Statistics = 280;
        public const int StatisticsDependency = 282;

		//
		// Specific Constants
		//
		public const int Read = 201;
		public const int Write = 202;
		public const int Torn = 203;
		public const int NoCard = 204;

	}

    public class StatisticProperties
    {
        public const string CommunicationErrorCount = "CommunicationErrorCount";
        public const string DeviceCategory = "DeviceCategory";
        public const string FirmwareRevision = "FirmwareRevision";
        public const string HoursPoweredCount = "HoursPoweredCount";
        public const string InstallationDate = "InstallationDate";
        public const string Interface = "Interface";
        public const string ManufactureDate = "ManufactureDate";
        public const string ManufacturerName = "ManufacturerName";
        public const string MechanicalRevision = "MechanicalRevision";
        public const string ModelName = "ModelName";
        public const string SerialNumber = "SerialNumber";
        public const string UnifiedPOSVersion = "UnifiedPOSVersion";
    }

    public class Wait
    {
        public const int Forever = -1;
    }

	//
	// Specific Constants
	//

	public class SmartCardInterfaceModes
	{
		public const int Transaction = 1;
		public const int Block = 2;
		public const int Apdu = 4;
		public const int Xml = 8;
	}

	public class SmartCardIsoEmvModes
	{
		public const int Iso = 1;
		public const int Emv = 2;
	}

	public class SmartCardTransmissionProtocols
	{
		public const int T0 = 1;
		public const int T1 = 2;
	}


}
