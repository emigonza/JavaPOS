﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace UnifiedPOS.HardTotals
{
    [ServiceContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/")]
    public interface HardTotals
    {

        //
        // Common Properties
        //

		//[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/GetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/GetAutoDisableResponse")]
		//[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
		//bool GetAutoDisable();

		//[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/SetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/SetAutoDisableResponse")]
		//[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
		//void SetAutoDisable(bool AutoDisable);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/GetCapCompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/GetCapCompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
        bool GetCapCompareFirmwareVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/GetCapPowerReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/GetCapPowerReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
        PowerReporting GetCapPowerReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/GetCapStatisticsReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/GetCapStatisticsReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
        bool GetCapStatisticsReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/GetCapUpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/GetCapUpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
        bool GetCapUpdateFirmware();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/GetCapUpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/GetCapUpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
        bool GetCapUpdateStatistics();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/GetCheckHealthText", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/GetCheckHealthTextResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
        string GetCheckHealthText();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/GetClaimed", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/GetClaimedResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
        bool GetClaimed();

		//[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/GetDataCount", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/GetDataCountResponse")]
		//[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
		//int GetDataCount();

		//[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/GetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/GetDataEventEnabledResponse")]
		//[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
		//bool GetDataEventEnabled();

		//[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/SetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/SetDataEventEnabledResponse")]
		//[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
		//void SetDataEventEnabled(bool DataEventEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/GetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/GetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
        bool GetDeviceEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/SetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/SetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
        void SetDeviceEnabled(bool DeviceEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/GetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/GetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
        bool GetFreezeEvents();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/SetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/SetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
        void SetFreezeEvents(bool FreezeEvents);

		//[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/GetOutputID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/GetOutputIDResponse")]
		//[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
		//int GetOutputID();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/GetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/GetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
        PowerNotification GetPowerNotify();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/SetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/SetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
        void SetPowerNotify(PowerNotification PowerNotify);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/GetPowerState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/GetPowerStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
        PowerState GetPowerState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/GetState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/GetStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
        ControlState GetState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/GetDeviceControlDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/GetDeviceControlDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
        string GetDeviceControlDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/GetDeviceControlVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/GetDeviceControlVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
        UposVersion GetDeviceControlVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/GetDeviceServiceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/GetDeviceServiceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
        string GetDeviceServiceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/GetDeviceServiceVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/GetDeviceServiceVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
        UposVersion GetDeviceServiceVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/GetPhysicalDeviceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/GetPhysicalDeviceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
        string GetPhysicalDeviceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/GetPhysicalDeviceName", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/GetPhysicalDeviceNameResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
        string GetPhysicalDeviceName();

        //
        // Specific Properties			7 Properties
        //

		[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/GetCapErrorDetection", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/GetCapErrorDetectionResponse")]
		[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
		bool GetCapErrorDetection();

		[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/GetCapSingleFile", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/GetCapSingleFileResponse")]
		[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
		bool GetCapSingleFile();

		[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/GetCapTransactions", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/GetCapTransactionsResponse")]
		[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
		bool GetCapTransactions();

		[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/GetFreeData", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/GetFreeDataResponse")]
		[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
		int GetFreeData();

		[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/GetNumberOfFiles", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/GetNumberOfFilesResponse")]
		[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
		int GetNumberOfFiles();

		[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/GetTotalsSize", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/GetTotalsSizeResponse")]
		[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
		int GetTotalsSize();

		[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/GetTransactionInProgress", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/GetTransactionInProgressResponse")]
		[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
		bool GetTransactionInProgress();

        //
        // Common Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/Open", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/OpenResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
        void Open(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/Close", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/CloseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
        void Close(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/Claim", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/ClaimResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
        void Claim(int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/Release", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/ReleaseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
        void Release();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/CheckHealth", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/CheckHealthResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
        void CheckHealth(HealthCheckLevel Level);

		//[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/ClearInput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/ClearInputResponse")]
		//[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
		//void ClearInput();

		//[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/ClearInputProperties", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/ClearInputPropertiesResponse")]
		//[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
		//void ClearInputProperties();

		//[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/ClearOutput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/ClearOutputResponse")]
		//[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
		//void ClearOutput();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/DirectIO", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/DirectIOResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
        DirectIOData DirectIO(int Command, int Data, object Obj);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/CompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/CompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
        CompareFirmwareResult CompareFirmwareVersion(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/ResetStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/ResetStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
        void ResetStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/RetrieveStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/RetrieveStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
        string RetrieveStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
        void UpdateFirmware(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
        void UpdateStatistics(StatisticList StatisticsBuffer);

        //
        // Specific Methods			15 Methods
        //

		[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/BeginTrans", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/BeginTransResponse")]
		[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
		void BeginTrans();

		[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/ClaimFile", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/ClaimFileResponse")]
		[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
		void ClaimFile(int Handle, int Timeout);

		[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/CommitTrans", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/CommitTransResponse")]
		[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
		void CommitTrans();

		[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/Create", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/CreateResponse")]
		[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
		int Create(string FileName, int Size, bool ErrorDetection);

		[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/Delete", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/DeleteResponse")]
		[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
		void Delete(string FileName);

		[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/Find", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/FindResponse")]
		[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
		TotalsFileInfo Find(string FileName);

		[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/FindByIndex", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/FindByIndexResponse")]
		[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
		string FindByIndex(int Index);

		[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/Read", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/ReadResponse")]
		[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
		byte[] Read(int Handle, int Offset, int Count);

		[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/RecalculateValidationData", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/RecalculateValidationDataResponse")]
		[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
		void RecalculateValidationData(int Handle);

		[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/ReleaseFile", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/ReleaseFileResponse")]
		[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
		void ReleaseFile(int Handle);

		[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/Rename", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/RenameResponse")]
		[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
		void Rename(int Handle, string NewName);

		[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/Rollback", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/RollbackResponse")]
		[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
		void Rollback();

		[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/SetAll", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/SetAllResponse")]
		[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
		void SetAll(int Handle, sbyte TargetValue);

		[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/ValidateData", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/ValidateDataResponse")]
		[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
		void ValidateData(int Handle);

		[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/Write", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/WriteResponse")]
		[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/UposException", Name = "UposException")]
		void Write(int Handle, byte[] Data, int Offset);

    }

    //
    // Common Data Types
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/")]
    public class DirectIOData
    {
        [DataMember]
        public int Data { get; set; }
        [DataMember]
        public object Obj { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/")]
    public class UposException
    {
        [DataMember]
        public ErrorCode ErrorCode { get; set; }
        [DataMember]
        public int ErrorCodeExtended { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/")]
    public class UposVersion
    {
        [DataMember]
        public int Major { get; set; }
        [DataMember]
        public int Minor { get; set; }
        [DataMember]
        public int Build { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/")]
    public class Statistic
    {
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public string Value { get; set; }
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/", ItemName = "Statistic")]
    public class StatisticList : List<Statistic>
    {
    }

    //
    // Common Enumerations
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/")]
    public enum CompareFirmwareResult
    {
        [EnumMember]
        Different,
        [EnumMember]
        Newer,
        [EnumMember]
        Older,
        [EnumMember]
        Same,
        [EnumMember]
        Unknown,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/")]
    public enum ControlState
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Closed,
        [EnumMember]
        Error,
        [EnumMember]
        Idle,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/")]
    public enum ErrorCode
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Claimed,
        [EnumMember]
        Closed,
        [EnumMember]
        Deprecated,
        [EnumMember]
        Disabled,
        [EnumMember]
        Exists,
        [EnumMember]
        Extended,
        [EnumMember]
        Failure,
        [EnumMember]
        Illegal,
        [EnumMember]
        NoExist,
        [EnumMember]
        NoHardware,
        [EnumMember]
        NoService,
        [EnumMember]
        NotClaimed,
        [EnumMember]
        Offline,
        [EnumMember]
        Success,
        [EnumMember]
        Timeout,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/")]
    public enum HealthCheckLevel
    {
        [EnumMember]
        External,
        [EnumMember]
        Interactive,
        [EnumMember]
        Internal,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/")]
    public enum PowerNotification
    {
        [EnumMember]
        Disabled,
        [EnumMember]
        Enabled,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/")]
    public enum PowerReporting
    {
        [EnumMember]
        Advanced,
        [EnumMember]
        None,
        [EnumMember]
        Standard,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/")]
    public enum PowerState
    {
        [EnumMember]
        Off,
        [EnumMember]
        Offline,
        [EnumMember]
        OffOffline,
        [EnumMember]
        Online,
        [EnumMember]
        Unknown,
    }

    /*
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/")]
    public enum StatisticCategories
    {
        [EnumMember]
        All,
        [EnumMember]
        Manufacturer,
        [EnumMember]
        Upos,
    }
    */
    public class StatisticCategories
    {
        public const string All = "";
        public const string Manufacturer = "M_";
        public const string Upos = "U_";
    }

    //
    // Specific Data Types
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/HardTotals/")]
    public class TotalsFileInfo
    {
        [DataMember]
        public int Handle { get; set; }
        [DataMember]
        public int Size { get; set; }
    }

    //
    // Specific Enumerations
    //

    //
    // Constants
    //

    public class ExtendedError
    {
        public const int FirmwareBadFile = 281;
        public const int Statistics = 280;
        public const int StatisticsDependency = 282;

		//
		// Specific
		//
		public const int NoRoom = 201;
		public const int Validation = 202;
	}

    public class StatisticProperties
    {
        public const string CommunicationErrorCount = "CommunicationErrorCount";
        public const string DeviceCategory = "DeviceCategory";
        public const string FirmwareRevision = "FirmwareRevision";
        public const string HoursPoweredCount = "HoursPoweredCount";
        public const string InstallationDate = "InstallationDate";
        public const string Interface = "Interface";
        public const string ManufactureDate = "ManufactureDate";
        public const string ManufacturerName = "ManufacturerName";
        public const string MechanicalRevision = "MechanicalRevision";
        public const string ModelName = "ModelName";
        public const string SerialNumber = "SerialNumber";
        public const string UnifiedPOSVersion = "UnifiedPOSVersion";
    }

    public class Wait
    {
        public const int Forever = -1;
    }
}
