/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package wspos;

import java.net.URL;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import jpos.events.DirectIOEvent;
import jpos.events.ErrorEvent;
import jpos.events.OutputCompleteEvent;
import jpos.events.StatusUpdateEvent;
import org.nrf_arts.unifiedpos.posprinter.*;
import javax.jws.WebService;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.namespace.QName;
import javax.xml.ws.Service;

/**
 *
 * @author hideon
 */
@WebService(serviceName = "POSPrinterService", endpointInterface = "org.nrf_arts.unifiedpos.posprinter.POSPrinter", targetNamespace = "http://www.nrf-arts.org/UnifiedPOS/POSPrinter/")
public class POSPrinterService implements POSPrinter, jpos.events.DirectIOListener, jpos.events.ErrorListener, jpos.events.OutputCompleteListener, jpos.events.StatusUpdateListener {

    //
    // POSPrinter Enumration Converter
    //

    private static HashMap<Enum, Integer> jposConst;
    private static HashMap<Integer, PowerReporting> powerReporting;
    private static HashMap<Integer, PowerNotification> powerNotification;
    private static HashMap<Integer, PowerState> powerState;
    private static HashMap<Integer, ControlState> controlState;
    private static HashMap<Integer, HealthCheckLevel> healthCheckLevel;
    private static HashMap<Integer, CompareFirmwareResult> compareFirmwareResult;
    private static HashMap<Integer, ErrorCode> errorCode;
    private static HashMap<Integer, CharacterSetCapability> characterSetCapability;
    private static HashMap<Integer, PrinterCartridgeNotify> printerCartridgeNotify;
    private static HashMap<Integer, PrinterErrorLevel> printerErrorLevel;
    private static HashMap<Integer, PrinterStation> printerStation;
    private static HashMap<Integer, MapMode> mapMode;
    private static HashMap<Integer, PageModePrintDirection> pageModePrintDirection;
    private static HashMap<Integer, Rotation> rotation;
    private static HashMap<String, Rotation> rotationString;
    private static HashMap<Integer, PrinterCartridgeStates> printerCartridgeStates;
    private static HashMap<Integer, PrinterSide> printerSide;
    private static HashMap<Integer, PageModePrintControl> pageModePrintControl;
    private static HashMap<Integer, BarCodeTextPosition> barCodeTextPosition;
    private static HashMap<Integer, PrinterLogoLocation> printerLogoLocation;
    private static HashMap<Integer, PrinterTransactionControl> printerTransactionControl;
    private static HashMap<Integer, BitmapType> bitmapType;

    private static HashMap<Enum, Integer> jposEventConst;
    private static HashMap<Integer, org.nrf_arts.unifiedpos.posprinterevents.ErrorCode> eventErrorCode;
    private static HashMap<Integer, org.nrf_arts.unifiedpos.posprinterevents.ErrorLocus> eventErrorLocus;
    private static HashMap<Integer, org.nrf_arts.unifiedpos.posprinterevents.ErrorResponse> eventErrorResponse;

    static {
        jposConst = new HashMap<Enum, Integer>();
        jposConst.put(PowerReporting.ADVANCED, jpos.POSPrinter.JPOS_PR_ADVANCED);
        jposConst.put(PowerReporting.NONE, jpos.POSPrinter.JPOS_PR_NONE);
        jposConst.put(PowerReporting.STANDARD, jpos.POSPrinter.JPOS_PR_STANDARD);
        jposConst.put(PowerNotification.DISABLED, jpos.POSPrinter.JPOS_PN_DISABLED);
        jposConst.put(PowerNotification.ENABLED, jpos.POSPrinter.JPOS_PN_ENABLED);
        jposConst.put(PowerState.OFF, jpos.POSPrinter.JPOS_PS_OFF);
        jposConst.put(PowerState.OFFLINE, jpos.POSPrinter.JPOS_PS_OFFLINE);
        jposConst.put(PowerState.OFF_OFFLINE, jpos.POSPrinter.JPOS_PS_OFF_OFFLINE);
        jposConst.put(PowerState.ONLINE, jpos.POSPrinter.JPOS_PS_ONLINE);
        jposConst.put(PowerState.UNKNOWN, jpos.POSPrinter.JPOS_PS_UNKNOWN);
        jposConst.put(ControlState.BUSY, jpos.POSPrinter.JPOS_S_BUSY);
        jposConst.put(ControlState.CLOSED, jpos.POSPrinter.JPOS_S_CLOSED);
        jposConst.put(ControlState.ERROR, jpos.POSPrinter.JPOS_S_ERROR);
        jposConst.put(ControlState.IDLE, jpos.POSPrinter.JPOS_S_IDLE);
        jposConst.put(HealthCheckLevel.EXTERNAL, jpos.POSPrinter.JPOS_CH_EXTERNAL);
        jposConst.put(HealthCheckLevel.INTERACTIVE, jpos.POSPrinter.JPOS_CH_INTERACTIVE);
        jposConst.put(HealthCheckLevel.INTERNAL, jpos.POSPrinter.JPOS_CH_INTERNAL);
        jposConst.put(CompareFirmwareResult.DIFFERENT, jpos.POSPrinter.JPOS_CFV_FIRMWARE_DIFFERENT);
        jposConst.put(CompareFirmwareResult.NEWER, jpos.POSPrinter.JPOS_CFV_FIRMWARE_NEWER);
        jposConst.put(CompareFirmwareResult.OLDER, jpos.POSPrinter.JPOS_CFV_FIRMWARE_OLDER);
        jposConst.put(CompareFirmwareResult.SAME, jpos.POSPrinter.JPOS_CFV_FIRMWARE_SAME);
        jposConst.put(CompareFirmwareResult.UNKNOWN, jpos.POSPrinter.JPOS_CFV_FIRMWARE_UNKNOWN);
        jposConst.put(ErrorCode.BUSY, jpos.POSPrinter.JPOS_E_BUSY);
        jposConst.put(ErrorCode.CLAIMED, jpos.POSPrinter.JPOS_E_CLAIMED);
        jposConst.put(ErrorCode.CLOSED, jpos.POSPrinter.JPOS_E_CLOSED);
        jposConst.put(ErrorCode.DEPRECATED, jpos.POSPrinter.JPOS_E_DEPRECATED);
        jposConst.put(ErrorCode.DISABLED, jpos.POSPrinter.JPOS_E_DISABLED);
        jposConst.put(ErrorCode.EXISTS, jpos.POSPrinter.JPOS_E_EXISTS);
        jposConst.put(ErrorCode.EXTENDED, jpos.POSPrinter.JPOS_E_EXTENDED);
        jposConst.put(ErrorCode.FAILURE, jpos.POSPrinter.JPOS_E_FAILURE);
        jposConst.put(ErrorCode.ILLEGAL, jpos.POSPrinter.JPOS_E_ILLEGAL);
        jposConst.put(ErrorCode.NO_EXIST, jpos.POSPrinter.JPOS_E_NOEXIST);
        jposConst.put(ErrorCode.NO_HARDWARE, jpos.POSPrinter.JPOS_E_NOHARDWARE);
        jposConst.put(ErrorCode.NO_SERVICE, jpos.POSPrinter.JPOS_E_NOSERVICE);
        jposConst.put(ErrorCode.NOT_CLAIMED, jpos.POSPrinter.JPOS_E_NOTCLAIMED);
        jposConst.put(ErrorCode.OFFLINE, jpos.POSPrinter.JPOS_E_OFFLINE);
        jposConst.put(ErrorCode.SUCCESS, 0);
        jposConst.put(ErrorCode.TIMEOUT, jpos.POSPrinter.JPOS_E_TIMEOUT);
        jposConst.put(CharacterSetCapability.ALPHA, jpos.POSPrinterConst.PTR_CCS_ALPHA);
        jposConst.put(CharacterSetCapability.ASCII, jpos.POSPrinterConst.PTR_CCS_ASCII);
        jposConst.put(CharacterSetCapability.KANA, jpos.POSPrinterConst.PTR_CCS_KANA);
        jposConst.put(CharacterSetCapability.KANJI, jpos.POSPrinterConst.PTR_CCS_KANJI);
        jposConst.put(CharacterSetCapability.UNICODE, jpos.POSPrinterConst.PTR_CCS_UNICODE);
        jposConst.put(PrinterCartridgeNotify.DISABLED, jpos.POSPrinterConst.PTR_CN_DISABLED);
        jposConst.put(PrinterCartridgeNotify.ENABLED, jpos.POSPrinterConst.PTR_CN_ENABLED);
        jposConst.put(PrinterErrorLevel.FATAL, jpos.POSPrinterConst.PTR_EL_FATAL);
        jposConst.put(PrinterErrorLevel.NONE, jpos.POSPrinterConst.PTR_EL_NONE);
        jposConst.put(PrinterErrorLevel.RECOVERABLE, jpos.POSPrinterConst.PTR_EL_RECOVERABLE);
        jposConst.put(PrinterStation.JOURNAL, jpos.POSPrinterConst.PTR_S_JOURNAL);
        jposConst.put(PrinterStation.NONE, 0);
        jposConst.put(PrinterStation.RECEIPT, jpos.POSPrinterConst.PTR_S_RECEIPT);
        jposConst.put(PrinterStation.SLIP, jpos.POSPrinterConst.PTR_S_SLIP);
        jposConst.put(PrinterStation.TWO_RECEIPT_JOURNAL, jpos.POSPrinterConst.PTR_TWO_RECEIPT_JOURNAL);
        jposConst.put(PrinterStation.TWO_SLIP_JOURNAL, jpos.POSPrinterConst.PTR_TWO_SLIP_JOURNAL);
        jposConst.put(PrinterStation.TWO_SLIP_RECEIPT, jpos.POSPrinterConst.PTR_TWO_SLIP_RECEIPT);
        jposConst.put(MapMode.DOTS, jpos.POSPrinterConst.PTR_MM_DOTS);
        jposConst.put(MapMode.ENGLISH, jpos.POSPrinterConst.PTR_MM_ENGLISH);
        jposConst.put(MapMode.METRIC, jpos.POSPrinterConst.PTR_MM_METRIC);
        jposConst.put(MapMode.TWIPS, jpos.POSPrinterConst.PTR_MM_TWIPS);
        jposConst.put(PageModePrintDirection.BOTTOM_TO_TOP, jpos.POSPrinterConst.PTR_PD_BOTTOM_TO_TOP);
        jposConst.put(PageModePrintDirection.LEFT_TO_RIGHT, jpos.POSPrinterConst.PTR_PD_LEFT_TO_RIGHT);
        jposConst.put(PageModePrintDirection.NONE, 0);
        jposConst.put(PageModePrintDirection.RIGHT_TO_LEFT, jpos.POSPrinterConst.PTR_PD_RIGHT_TO_LEFT);
        jposConst.put(PageModePrintDirection.TOP_TO_BOTTOM, jpos.POSPrinterConst.PTR_PD_TOP_TO_BOTTOM);
        jposConst.put(Rotation.LEFT_90, jpos.POSPrinterConst.PTR_RP_LEFT90);
        jposConst.put(Rotation.NORMAL, jpos.POSPrinterConst.PTR_RP_NORMAL);
        jposConst.put(Rotation.RIGHT_90, jpos.POSPrinterConst.PTR_RP_RIGHT90);
        jposConst.put(Rotation.ROTATE_180, jpos.POSPrinterConst.PTR_RP_ROTATE180);
        jposConst.put(PrinterCartridgeStates.CLEANING, jpos.POSPrinterConst.PTR_CART_CLEANING);
        jposConst.put(PrinterCartridgeStates.EMPTY, jpos.POSPrinterConst.PTR_CART_EMPTY);
        jposConst.put(PrinterCartridgeStates.NEAR_END, jpos.POSPrinterConst.PTR_CART_NEAREND);
        jposConst.put(PrinterCartridgeStates.OK, jpos.POSPrinterConst.PTR_CART_OK);
        jposConst.put(PrinterCartridgeStates.REMOVED, jpos.POSPrinterConst.PTR_CART_REMOVED);
        jposConst.put(PrinterCartridgeStates.UNKNOWN, jpos.POSPrinterConst.PTR_CART_UNKNOWN);
        jposConst.put(PrinterSide.OPPOSITE, jpos.POSPrinterConst.PTR_PS_OPPOSITE);
        jposConst.put(PrinterSide.SIDE_1, jpos.POSPrinterConst.PTR_PS_SIDE1);
        jposConst.put(PrinterSide.SIDE_2, jpos.POSPrinterConst.PTR_PS_SIDE2);
        jposConst.put(PrinterSide.UNKNOWN, jpos.POSPrinterConst.PTR_PS_UNKNOWN);
        jposConst.put(PageModePrintControl.CANCEL, jpos.POSPrinterConst.PTR_PM_CANCEL);
        jposConst.put(PageModePrintControl.NORMAL, jpos.POSPrinterConst.PTR_PM_NORMAL);
        jposConst.put(PageModePrintControl.PAGE_MODE, jpos.POSPrinterConst.PTR_PM_PAGE_MODE);
        jposConst.put(PageModePrintControl.PRINT_SAVE, jpos.POSPrinterConst.PTR_PM_PRINT_SAVE);
        jposConst.put(BarCodeTextPosition.ABOVE, jpos.POSPrinterConst.PTR_BC_TEXT_ABOVE);
        jposConst.put(BarCodeTextPosition.BELOW, jpos.POSPrinterConst.PTR_BC_TEXT_BELOW);
        jposConst.put(BarCodeTextPosition.NONE, jpos.POSPrinterConst.PTR_BC_TEXT_NONE);
        jposConst.put(BitmapType.BMP, jpos.POSPrinterConst.PTR_BMT_BMP);
        jposConst.put(BitmapType.GIF, jpos.POSPrinterConst.PTR_BMT_GIF);
        jposConst.put(BitmapType.JPEG, jpos.POSPrinterConst.PTR_BMT_JPEG);
        jposConst.put(PrinterLogoLocation.BOTTOM, jpos.POSPrinterConst.PTR_L_BOTTOM);
        jposConst.put(PrinterLogoLocation.TOP, jpos.POSPrinterConst.PTR_L_TOP);
        jposConst.put(PrinterTransactionControl.NORMAL, jpos.POSPrinterConst.PTR_TP_NORMAL);
        jposConst.put(PrinterTransactionControl.TRANSACTION, jpos.POSPrinterConst.PTR_TP_TRANSACTION);

        powerReporting = new HashMap<Integer, PowerReporting>();
        powerReporting.put(jpos.POSPrinter.JPOS_PR_ADVANCED, PowerReporting.ADVANCED);
        powerReporting.put(jpos.POSPrinter.JPOS_PR_NONE, PowerReporting.NONE);
        powerReporting.put(jpos.POSPrinter.JPOS_PR_STANDARD, PowerReporting.STANDARD);

        powerNotification = new HashMap<Integer, PowerNotification>();
        powerNotification.put(jpos.POSPrinter.JPOS_PN_DISABLED, PowerNotification.DISABLED);
        powerNotification.put(jpos.POSPrinter.JPOS_PN_ENABLED, PowerNotification.ENABLED);

        powerState = new HashMap<Integer, PowerState>();
        powerState.put(jpos.POSPrinter.JPOS_PS_OFF, PowerState.OFF);
        powerState.put(jpos.POSPrinter.JPOS_PS_OFFLINE, PowerState.OFFLINE);
        powerState.put(jpos.POSPrinter.JPOS_PS_OFF_OFFLINE, PowerState.OFF_OFFLINE);
        powerState.put(jpos.POSPrinter.JPOS_PS_ONLINE, PowerState.ONLINE);
        powerState.put(jpos.POSPrinter.JPOS_PS_UNKNOWN, PowerState.UNKNOWN);

        controlState = new HashMap<Integer, ControlState>();
        controlState.put(jpos.POSPrinter.JPOS_S_BUSY, ControlState.BUSY);
        controlState.put(jpos.POSPrinter.JPOS_S_CLOSED, ControlState.CLOSED);
        controlState.put(jpos.POSPrinter.JPOS_S_ERROR, ControlState.ERROR);
        controlState.put(jpos.POSPrinter.JPOS_S_IDLE, ControlState.IDLE);

        healthCheckLevel = new HashMap<Integer, HealthCheckLevel>();
        healthCheckLevel.put(jpos.POSPrinter.JPOS_CH_EXTERNAL, HealthCheckLevel.EXTERNAL);
        healthCheckLevel.put(jpos.POSPrinter.JPOS_CH_INTERACTIVE, HealthCheckLevel.INTERACTIVE);
        healthCheckLevel.put(jpos.POSPrinter.JPOS_CH_INTERNAL, HealthCheckLevel.INTERNAL);

        compareFirmwareResult = new HashMap<Integer, CompareFirmwareResult>();
        compareFirmwareResult.put(jpos.POSPrinter.JPOS_CFV_FIRMWARE_DIFFERENT, CompareFirmwareResult.DIFFERENT);
        compareFirmwareResult.put(jpos.POSPrinter.JPOS_CFV_FIRMWARE_NEWER, CompareFirmwareResult.NEWER);
        compareFirmwareResult.put(jpos.POSPrinter.JPOS_CFV_FIRMWARE_OLDER, CompareFirmwareResult.OLDER);
        compareFirmwareResult.put(jpos.POSPrinter.JPOS_CFV_FIRMWARE_SAME, CompareFirmwareResult.SAME);
        compareFirmwareResult.put(jpos.POSPrinter.JPOS_CFV_FIRMWARE_UNKNOWN, CompareFirmwareResult.UNKNOWN);

        errorCode = new HashMap<Integer, ErrorCode>();
        errorCode.put(jpos.POSPrinter.JPOS_E_BUSY, ErrorCode.BUSY);
        errorCode.put(jpos.POSPrinter.JPOS_E_CLAIMED, ErrorCode.CLAIMED);
        errorCode.put(jpos.POSPrinter.JPOS_E_CLOSED, ErrorCode.CLOSED);
        errorCode.put(jpos.POSPrinter.JPOS_E_DEPRECATED, ErrorCode.DEPRECATED);
        errorCode.put(jpos.POSPrinter.JPOS_E_DISABLED, ErrorCode.DISABLED);
        errorCode.put(jpos.POSPrinter.JPOS_E_EXISTS, ErrorCode.EXISTS);
        errorCode.put(jpos.POSPrinter.JPOS_E_EXTENDED, ErrorCode.EXTENDED);
        errorCode.put(jpos.POSPrinter.JPOS_E_FAILURE, ErrorCode.FAILURE);
        errorCode.put(jpos.POSPrinter.JPOS_E_ILLEGAL, ErrorCode.ILLEGAL);
        errorCode.put(jpos.POSPrinter.JPOS_E_NOEXIST, ErrorCode.NO_EXIST);
        errorCode.put(jpos.POSPrinter.JPOS_E_NOHARDWARE, ErrorCode.NO_HARDWARE);
        errorCode.put(jpos.POSPrinter.JPOS_E_NOSERVICE, ErrorCode.NO_SERVICE);
        errorCode.put(jpos.POSPrinter.JPOS_E_NOTCLAIMED, ErrorCode.NOT_CLAIMED);
        errorCode.put(jpos.POSPrinter.JPOS_E_OFFLINE, ErrorCode.OFFLINE);
        errorCode.put(0, ErrorCode.SUCCESS);
        errorCode.put(jpos.POSPrinter.JPOS_E_TIMEOUT, ErrorCode.TIMEOUT);

        characterSetCapability = new HashMap<Integer, CharacterSetCapability>();
        characterSetCapability.put(jpos.POSPrinterConst.PTR_CCS_ALPHA, CharacterSetCapability.ALPHA);
        characterSetCapability.put(jpos.POSPrinterConst.PTR_CCS_ASCII, CharacterSetCapability.ASCII);
        characterSetCapability.put(jpos.POSPrinterConst.PTR_CCS_KANA, CharacterSetCapability.KANA);
        characterSetCapability.put(jpos.POSPrinterConst.PTR_CCS_KANJI, CharacterSetCapability.KANJI);
        characterSetCapability.put(jpos.POSPrinterConst.PTR_CCS_UNICODE, CharacterSetCapability.UNICODE);

        printerCartridgeNotify = new HashMap<Integer, PrinterCartridgeNotify>();
        printerCartridgeNotify.put(jpos.POSPrinterConst.PTR_CN_DISABLED, PrinterCartridgeNotify.DISABLED);
        printerCartridgeNotify.put(jpos.POSPrinterConst.PTR_CN_ENABLED, PrinterCartridgeNotify.ENABLED);

        printerErrorLevel = new HashMap<Integer, PrinterErrorLevel>();
        printerErrorLevel.put(jpos.POSPrinterConst.PTR_EL_FATAL, PrinterErrorLevel.FATAL);
        printerErrorLevel.put(jpos.POSPrinterConst.PTR_EL_NONE, PrinterErrorLevel.NONE);
        printerErrorLevel.put(jpos.POSPrinterConst.PTR_EL_RECOVERABLE, PrinterErrorLevel.RECOVERABLE);

        printerStation = new HashMap<Integer, PrinterStation>();
        printerStation.put(jpos.POSPrinterConst.PTR_S_JOURNAL, PrinterStation.JOURNAL);
        printerStation.put(0, PrinterStation.NONE);
        printerStation.put(jpos.POSPrinterConst.PTR_S_RECEIPT, PrinterStation.RECEIPT);
        printerStation.put(jpos.POSPrinterConst.PTR_S_SLIP, PrinterStation.SLIP);
        printerStation.put(jpos.POSPrinterConst.PTR_TWO_RECEIPT_JOURNAL, PrinterStation.TWO_RECEIPT_JOURNAL);
        printerStation.put(jpos.POSPrinterConst.PTR_TWO_SLIP_JOURNAL, PrinterStation.TWO_SLIP_JOURNAL);
        printerStation.put(jpos.POSPrinterConst.PTR_TWO_SLIP_RECEIPT, PrinterStation.TWO_SLIP_RECEIPT);

        mapMode = new HashMap<Integer, MapMode>();
        mapMode.put(jpos.POSPrinterConst.PTR_MM_DOTS, MapMode.DOTS);
        mapMode.put(jpos.POSPrinterConst.PTR_MM_ENGLISH, MapMode.ENGLISH);
        mapMode.put(jpos.POSPrinterConst.PTR_MM_METRIC, MapMode.METRIC);
        mapMode.put(jpos.POSPrinterConst.PTR_MM_TWIPS, MapMode.TWIPS);

        pageModePrintDirection = new HashMap<Integer, PageModePrintDirection>();
        pageModePrintDirection.put(jpos.POSPrinterConst.PTR_PD_BOTTOM_TO_TOP, PageModePrintDirection.BOTTOM_TO_TOP);
        pageModePrintDirection.put(jpos.POSPrinterConst.PTR_PD_LEFT_TO_RIGHT, PageModePrintDirection.LEFT_TO_RIGHT);
        pageModePrintDirection.put(0, PageModePrintDirection.NONE);
        pageModePrintDirection.put(jpos.POSPrinterConst.PTR_PD_RIGHT_TO_LEFT, PageModePrintDirection.RIGHT_TO_LEFT);
        pageModePrintDirection.put(jpos.POSPrinterConst.PTR_PD_TOP_TO_BOTTOM, PageModePrintDirection.TOP_TO_BOTTOM);

        rotation = new HashMap<Integer, Rotation>();
        rotation.put(jpos.POSPrinterConst.PTR_RP_LEFT90, Rotation.LEFT_90);
        rotation.put(jpos.POSPrinterConst.PTR_RP_NORMAL, Rotation.NORMAL);
        rotation.put(jpos.POSPrinterConst.PTR_RP_RIGHT90, Rotation.RIGHT_90);
        rotation.put(jpos.POSPrinterConst.PTR_RP_ROTATE180, Rotation.ROTATE_180);

        rotationString = new HashMap<String, Rotation>();
        rotationString.put("L90", Rotation.LEFT_90);
        rotationString.put("0", Rotation.NORMAL);
        rotationString.put("R90", Rotation.RIGHT_90);
        rotationString.put("180", Rotation.ROTATE_180);

        printerCartridgeStates = new HashMap<Integer, PrinterCartridgeStates>();
        printerCartridgeStates.put(jpos.POSPrinterConst.PTR_CART_CLEANING, PrinterCartridgeStates.CLEANING);
        printerCartridgeStates.put(jpos.POSPrinterConst.PTR_CART_EMPTY, PrinterCartridgeStates.EMPTY);
        printerCartridgeStates.put(jpos.POSPrinterConst.PTR_CART_NEAREND, PrinterCartridgeStates.NEAR_END);
        printerCartridgeStates.put(jpos.POSPrinterConst.PTR_CART_OK, PrinterCartridgeStates.OK);
        printerCartridgeStates.put(jpos.POSPrinterConst.PTR_CART_REMOVED, PrinterCartridgeStates.REMOVED);
        printerCartridgeStates.put(jpos.POSPrinterConst.PTR_CART_UNKNOWN, PrinterCartridgeStates.UNKNOWN);

        printerSide = new HashMap<Integer, PrinterSide>();
        printerSide.put(jpos.POSPrinterConst.PTR_PS_OPPOSITE, PrinterSide.OPPOSITE);
        printerSide.put(jpos.POSPrinterConst.PTR_PS_SIDE1, PrinterSide.SIDE_1);
        printerSide.put(jpos.POSPrinterConst.PTR_PS_SIDE2, PrinterSide.SIDE_2);
        printerSide.put(jpos.POSPrinterConst.PTR_PS_UNKNOWN, PrinterSide.UNKNOWN);

        pageModePrintControl = new HashMap<Integer, PageModePrintControl>();
        pageModePrintControl.put(jpos.POSPrinterConst.PTR_PM_CANCEL, PageModePrintControl.CANCEL);
        pageModePrintControl.put(jpos.POSPrinterConst.PTR_PM_NORMAL, PageModePrintControl.NORMAL);
        pageModePrintControl.put(jpos.POSPrinterConst.PTR_PM_PAGE_MODE, PageModePrintControl.PAGE_MODE);
        pageModePrintControl.put(jpos.POSPrinterConst.PTR_PM_PRINT_SAVE, PageModePrintControl.PRINT_SAVE);

        barCodeTextPosition = new HashMap<Integer, BarCodeTextPosition>();
        barCodeTextPosition.put(jpos.POSPrinterConst.PTR_BC_TEXT_ABOVE, BarCodeTextPosition.ABOVE);
        barCodeTextPosition.put(jpos.POSPrinterConst.PTR_BC_TEXT_BELOW, BarCodeTextPosition.BELOW);
        barCodeTextPosition.put(jpos.POSPrinterConst.PTR_BC_TEXT_NONE, BarCodeTextPosition.NONE);

        bitmapType = new HashMap<Integer, BitmapType>();
        bitmapType.put(jpos.POSPrinterConst.PTR_BMT_BMP, BitmapType.BMP);
        bitmapType.put(jpos.POSPrinterConst.PTR_BMT_GIF, BitmapType.GIF);
        bitmapType.put(jpos.POSPrinterConst.PTR_BMT_JPEG, BitmapType.JPEG);

        printerLogoLocation = new HashMap<Integer, PrinterLogoLocation>();
        printerLogoLocation.put(jpos.POSPrinterConst.PTR_L_BOTTOM, PrinterLogoLocation.BOTTOM);
        printerLogoLocation.put(jpos.POSPrinterConst.PTR_L_TOP, PrinterLogoLocation.TOP);

        printerTransactionControl = new HashMap<Integer, PrinterTransactionControl>();
        printerTransactionControl.put(jpos.POSPrinterConst.PTR_TP_NORMAL, PrinterTransactionControl.NORMAL);
        printerTransactionControl.put(jpos.POSPrinterConst.PTR_TP_TRANSACTION, PrinterTransactionControl.TRANSACTION);

        jposEventConst = new HashMap<Enum, Integer>();
        jposEventConst.put(org.nrf_arts.unifiedpos.posprinterevents.ErrorCode.BUSY, jpos.POSPrinter.JPOS_E_BUSY);
        jposEventConst.put(org.nrf_arts.unifiedpos.posprinterevents.ErrorCode.CLAIMED, jpos.POSPrinter.JPOS_E_CLAIMED);
        jposEventConst.put(org.nrf_arts.unifiedpos.posprinterevents.ErrorCode.CLOSED, jpos.POSPrinter.JPOS_E_CLOSED);
        jposEventConst.put(org.nrf_arts.unifiedpos.posprinterevents.ErrorCode.DEPRECATED, jpos.POSPrinter.JPOS_E_DEPRECATED);
        jposEventConst.put(org.nrf_arts.unifiedpos.posprinterevents.ErrorCode.DISABLED, jpos.POSPrinter.JPOS_E_DISABLED);
        jposEventConst.put(org.nrf_arts.unifiedpos.posprinterevents.ErrorCode.EXISTS, jpos.POSPrinter.JPOS_E_EXISTS);
        jposEventConst.put(org.nrf_arts.unifiedpos.posprinterevents.ErrorCode.EXTENDED, jpos.POSPrinter.JPOS_E_EXTENDED);
        jposEventConst.put(org.nrf_arts.unifiedpos.posprinterevents.ErrorCode.FAILURE, jpos.POSPrinter.JPOS_E_FAILURE);
        jposEventConst.put(org.nrf_arts.unifiedpos.posprinterevents.ErrorCode.ILLEGAL, jpos.POSPrinter.JPOS_E_ILLEGAL);
        jposEventConst.put(org.nrf_arts.unifiedpos.posprinterevents.ErrorCode.NO_EXIST, jpos.POSPrinter.JPOS_E_NOEXIST);
        jposEventConst.put(org.nrf_arts.unifiedpos.posprinterevents.ErrorCode.NO_HARDWARE, jpos.POSPrinter.JPOS_E_NOHARDWARE);
        jposEventConst.put(org.nrf_arts.unifiedpos.posprinterevents.ErrorCode.NO_SERVICE, jpos.POSPrinter.JPOS_E_NOSERVICE);
        jposEventConst.put(org.nrf_arts.unifiedpos.posprinterevents.ErrorCode.NOT_CLAIMED, jpos.POSPrinter.JPOS_E_NOTCLAIMED);
        jposEventConst.put(org.nrf_arts.unifiedpos.posprinterevents.ErrorCode.OFFLINE, jpos.POSPrinter.JPOS_E_OFFLINE);
        jposEventConst.put(org.nrf_arts.unifiedpos.posprinterevents.ErrorCode.SUCCESS, 0);
        jposEventConst.put(org.nrf_arts.unifiedpos.posprinterevents.ErrorCode.TIMEOUT, jpos.POSPrinter.JPOS_E_TIMEOUT);
        jposEventConst.put(org.nrf_arts.unifiedpos.posprinterevents.ErrorLocus.INPUT, jpos.POSPrinter.JPOS_EL_INPUT);
        jposEventConst.put(org.nrf_arts.unifiedpos.posprinterevents.ErrorLocus.INPUT_DATA, jpos.POSPrinter.JPOS_EL_INPUT_DATA);
        jposEventConst.put(org.nrf_arts.unifiedpos.posprinterevents.ErrorLocus.OUTPUT, jpos.POSPrinter.JPOS_EL_OUTPUT);
        jposEventConst.put(org.nrf_arts.unifiedpos.posprinterevents.ErrorResponse.CLEAR, jpos.POSPrinter.JPOS_ER_CLEAR);
        jposEventConst.put(org.nrf_arts.unifiedpos.posprinterevents.ErrorResponse.CONTINUE_INPUT, jpos.POSPrinter.JPOS_ER_CONTINUEINPUT);
        jposEventConst.put(org.nrf_arts.unifiedpos.posprinterevents.ErrorResponse.RETRY, jpos.POSPrinter.JPOS_ER_RETRY);

        eventErrorCode = new HashMap<Integer, org.nrf_arts.unifiedpos.posprinterevents.ErrorCode>();
        eventErrorCode.put(jpos.POSPrinter.JPOS_E_BUSY, org.nrf_arts.unifiedpos.posprinterevents.ErrorCode.BUSY);
        eventErrorCode.put(jpos.POSPrinter.JPOS_E_CLAIMED, org.nrf_arts.unifiedpos.posprinterevents.ErrorCode.CLAIMED);
        eventErrorCode.put(jpos.POSPrinter.JPOS_E_CLOSED, org.nrf_arts.unifiedpos.posprinterevents.ErrorCode.CLOSED);
        eventErrorCode.put(jpos.POSPrinter.JPOS_E_DEPRECATED, org.nrf_arts.unifiedpos.posprinterevents.ErrorCode.DEPRECATED);
        eventErrorCode.put(jpos.POSPrinter.JPOS_E_DISABLED, org.nrf_arts.unifiedpos.posprinterevents.ErrorCode.DISABLED);
        eventErrorCode.put(jpos.POSPrinter.JPOS_E_EXISTS, org.nrf_arts.unifiedpos.posprinterevents.ErrorCode.EXISTS);
        eventErrorCode.put(jpos.POSPrinter.JPOS_E_EXTENDED, org.nrf_arts.unifiedpos.posprinterevents.ErrorCode.EXTENDED);
        eventErrorCode.put(jpos.POSPrinter.JPOS_E_FAILURE, org.nrf_arts.unifiedpos.posprinterevents.ErrorCode.FAILURE);
        eventErrorCode.put(jpos.POSPrinter.JPOS_E_ILLEGAL, org.nrf_arts.unifiedpos.posprinterevents.ErrorCode.ILLEGAL);
        eventErrorCode.put(jpos.POSPrinter.JPOS_E_NOEXIST, org.nrf_arts.unifiedpos.posprinterevents.ErrorCode.NO_EXIST);
        eventErrorCode.put(jpos.POSPrinter.JPOS_E_NOHARDWARE, org.nrf_arts.unifiedpos.posprinterevents.ErrorCode.NO_HARDWARE);
        eventErrorCode.put(jpos.POSPrinter.JPOS_E_NOSERVICE, org.nrf_arts.unifiedpos.posprinterevents.ErrorCode.NO_SERVICE);
        eventErrorCode.put(jpos.POSPrinter.JPOS_E_NOTCLAIMED, org.nrf_arts.unifiedpos.posprinterevents.ErrorCode.NOT_CLAIMED);
        eventErrorCode.put(jpos.POSPrinter.JPOS_E_OFFLINE, org.nrf_arts.unifiedpos.posprinterevents.ErrorCode.OFFLINE);
        eventErrorCode.put(0, org.nrf_arts.unifiedpos.posprinterevents.ErrorCode.SUCCESS);
        eventErrorCode.put(jpos.POSPrinter.JPOS_E_TIMEOUT, org.nrf_arts.unifiedpos.posprinterevents.ErrorCode.TIMEOUT);

        eventErrorLocus = new HashMap<Integer, org.nrf_arts.unifiedpos.posprinterevents.ErrorLocus>();
        eventErrorLocus.put(jpos.POSPrinter.JPOS_EL_INPUT, org.nrf_arts.unifiedpos.posprinterevents.ErrorLocus.INPUT);
        eventErrorLocus.put(jpos.POSPrinter.JPOS_EL_INPUT_DATA, org.nrf_arts.unifiedpos.posprinterevents.ErrorLocus.INPUT_DATA);
        eventErrorLocus.put(jpos.POSPrinter.JPOS_EL_OUTPUT, org.nrf_arts.unifiedpos.posprinterevents.ErrorLocus.OUTPUT);

        eventErrorResponse = new HashMap<Integer, org.nrf_arts.unifiedpos.posprinterevents.ErrorResponse>();
        eventErrorResponse.put(jpos.POSPrinter.JPOS_ER_CLEAR, org.nrf_arts.unifiedpos.posprinterevents.ErrorResponse.CLEAR);
        eventErrorResponse.put(jpos.POSPrinter.JPOS_ER_CONTINUEINPUT, org.nrf_arts.unifiedpos.posprinterevents.ErrorResponse.CONTINUE_INPUT);
        eventErrorResponse.put(jpos.POSPrinter.JPOS_ER_RETRY, org.nrf_arts.unifiedpos.posprinterevents.ErrorResponse.RETRY);
    }

    private String deviceName;
    private UposVersion deviceControlVersion;
    private org.nrf_arts.unifiedpos.posprinterevents.POSPrinterEvent deviceEvent;
    private jpos.POSPrinter device = new jpos.POSPrinter();
    private DatatypeFactory datatypeFactory;
    private Pattern pattern = Pattern.compile("\\\\u([0-9a-fA-F]{4})|(\\\\\\\\)|(\\\\n)|(\\\\r)|(\\\\t)|(\\\\f)|(\\\\b)");

    private String processEscapeSequence(String data) {
        Matcher m = pattern.matcher(data);
        StringBuffer s = new StringBuffer();
        while (m.find()) {
            if (m.group(1) != null) {
                m.appendReplacement(s, String.valueOf((char)Integer.parseInt(m.group(1), 16)));
            }
            else if (m.group(2) != null) {
                m.appendReplacement(s, "\\\\");
            }
            else if (m.group(3) != null) {
                m.appendReplacement(s, "\n");
            }
            else if (m.group(4) != null) {
                m.appendReplacement(s, "\r");
            }
            else if (m.group(5) != null) {
                m.appendReplacement(s, "\t");
            }
            else if (m.group(6) != null) {
                m.appendReplacement(s, "\f");
            }
            else if (m.group(7) != null) {
                m.appendReplacement(s, "\b");
            }
        }
        m.appendTail(s);
        return s.toString();
    }

    public POSPrinterService(String logicalDeviceName) {
        deviceName = logicalDeviceName;
        deviceControlVersion = new UposVersion();
        deviceControlVersion.setMajor(1);
        deviceControlVersion.setMinor(13);
        deviceControlVersion.setBuild(1);
        try {
            datatypeFactory = DatatypeFactory.newInstance();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    //
    // POSPrinter Member
    //

    public void beginInsertion(Integer timeout) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.beginInsertion(timeout);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void beginRemoval(Integer timeout) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.beginRemoval(timeout);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void changePrintSide(PrinterSide side) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.changePrintSide(jposConst.get(side));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void checkHealth(HealthCheckLevel level) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.checkHealth(jposConst.get(level));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void claim(Integer timeout) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.claim(timeout);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void clearOutput() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.clearOutput();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void clearPrintArea() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.clearPrintArea();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void close(String endpointAddress) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            if (deviceEvent != null)
            {
                device.removeDirectIOListener(this);
                device.removeErrorListener(this);
                device.removeOutputCompleteListener(this);
                device.removeStatusUpdateListener(this);
                deviceEvent = null;
            }
            device.close();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public CompareFirmwareResult compareFirmwareVersion(String firmwareFileName) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            int[] param = new int[1];
            device.compareFirmwareVersion(firmwareFileName, param);
            return compareFirmwareResult.get(param[0]);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void cutPaper(Integer percentage) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.cutPaper(percentage);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public DirectIOData directIO(Integer command, Integer data, Object obj) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            DirectIOData res = new DirectIOData();
            int[] param = new int[] { data };
            device.directIO(command, param, obj);
            res.setData(param[0]);
            res.setObj(obj);
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void drawRuledLine(PrinterStation station, PositionList positionList, Integer lineDirection, Integer lineWidth, PrinterLineStyle lineStyle, Integer lineColor) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            StringBuffer s = new StringBuffer();
            switch (lineDirection) {
                case PrinterLineDirection.HORIZONTAL:
                    List<Integer> list = positionList.getPosition();
                    for (int i = 0; i < list.size(); i += 2) {
                        s.append(";").append(list.get(i)).append(",").append(list.get(i + 1));
                    }
                    break;
                case PrinterLineDirection.VERTICAL:
                    for (int position : positionList.getPosition()) {
                        s.append(",").append(position);
                    }
                    break;
                default:
                    throw new jpos.JposException(jpos.POSPrinter.JPOS_E_ILLEGAL);
            }
            device.drawRuledLine(jposConst.get(station), s.substring(1), lineDirection, lineWidth, jposConst.get(lineStyle), lineColor);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void endInsertion() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.endInsertion();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void endRemoval() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.endRemoval();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getAsyncMode() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getAsyncMode();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public CharacterSetCapability getCapCharacterSet() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return characterSetCapability.get(device.getCapCharacterSet());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapCompareFirmwareVersion() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapCompareFirmwareVersion();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapConcurrentJrnRec() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapConcurrentJrnRec();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapConcurrentJrnSlp() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapConcurrentJrnSlp();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapConcurrentPageMode() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapConcurrentPageMode();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapConcurrentRecSlp() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapConcurrentRecSlp();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapCoverSensor() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapCoverSensor();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapJrn2Color() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapJrn2Color();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapJrnBold() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapJrnBold();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getCapJrnCartridgeSensor() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapJrnCartridgeSensor();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getCapJrnColor() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapJrnColor();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapJrnDhigh() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapJrnDhigh();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapJrnDwide() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapJrnDwide();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapJrnDwideDhigh() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapJrnDwideDhigh();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapJrnEmptySensor() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapJrnEmptySensor();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapJrnItalic() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapJrnItalic();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapJrnNearEndSensor() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapJrnNearEndSensor();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapJrnPresent() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapJrnPresent();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapJrnUnderline() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapJrnUnderline();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapMapCharacterSet() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapMapCharacterSet();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public PowerReporting getCapPowerReporting() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return powerReporting.get(device.getCapPowerReporting());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapRec2Color() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapRec2Color();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapRecBarCode() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapRecBarCode();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapRecBitmap() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapRecBitmap();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapRecBold() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapRecBold();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getCapRecCartridgeSensor() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapRecCartridgeSensor();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getCapRecColor() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapRecColor();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapRecDhigh() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapRecDhigh();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapRecDwide() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapRecDwide();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapRecDwideDhigh() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapRecDwideDhigh();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapRecEmptySensor() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapRecEmptySensor();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapRecItalic() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapRecItalic();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapRecLeft90() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapRecLeft90();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getCapRecMarkFeed() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapRecMarkFeed();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapRecNearEndSensor() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapRecNearEndSensor();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapRecPageMode() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapRecPageMode();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapRecPapercut() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapRecPapercut();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapRecPresent() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapRecPresent();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapRecRight90() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapRecRight90();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapRecRotate180() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapRecRotate180();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getCapRecRuledLine() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapRecRuledLine();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapRecStamp() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapRecStamp();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapRecUnderline() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapRecUnderline();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapSlp2Color() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapSlp2Color();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapSlpBarCode() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapSlpBarCode();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapSlpBitmap() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapSlpBitmap();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapSlpBold() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapSlpBold();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapSlpBothSidesPrint() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapSlpBothSidesPrint();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getCapSlpCartridgeSensor() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapSlpCartridgeSensor();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getCapSlpColor() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapSlpColor();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapSlpDhigh() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapSlpDhigh();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapSlpDwide() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapSlpDwide();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapSlpDwideDhigh() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapSlpDwideDhigh();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapSlpEmptySensor() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapSlpEmptySensor();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapSlpFullslip() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapSlpFullslip();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapSlpItalic() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapSlpItalic();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapSlpLeft90() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapSlpLeft90();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapSlpNearEndSensor() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapSlpNearEndSensor();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapSlpPageMode() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapSlpPageMode();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapSlpPresent() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapSlpPresent();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapSlpRight90() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapSlpRight90();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapSlpRotate180() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapSlpRotate180();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getCapSlpRuledLine() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapSlpRuledLine();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapSlpUnderline() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapSlpUnderline();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapStatisticsReporting() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapStatisticsReporting();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapTransaction() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapTransaction();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapUpdateFirmware() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapUpdateFirmware();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapUpdateStatistics() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapUpdateStatistics();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public PrinterCartridgeNotify getCartridgeNotify() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return printerCartridgeNotify.get(device.getCartridgeNotify());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getCharacterSet() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCharacterSet();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public CharacterSetList getCharacterSetList() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            CharacterSetList res = new CharacterSetList();
            List<Integer> list = res.getCharacterSet();
            for (String s : device.getCharacterSetList().split(",")) {
                list.add(Integer.valueOf(s));
            }
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getCheckHealthText() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCheckHealthText();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getClaimed() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getClaimed();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCoverOpen() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCoverOpen();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getDeviceControlDescription() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        return device.getDeviceControlDescription();
    }

    public UposVersion getDeviceControlVersion() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        UposVersion res = new UposVersion();
        int version = device.getDeviceControlVersion();
        res.setMajor(version / 1000000 % 1000);
        res.setMinor(version / 1000 % 1000);
        res.setBuild(version % 1000);
        return res;
    }

    public Boolean getDeviceEnabled() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getDeviceEnabled();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getDeviceServiceDescription() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getDeviceServiceDescription();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public UposVersion getDeviceServiceVersion() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            UposVersion res = new UposVersion();
            int version = device.getDeviceServiceVersion();
            res.setMajor(version / 1000000 % 1000);
            res.setMinor(version / 1000 % 1000);
            res.setBuild(version % 1000);
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public PrinterErrorLevel getErrorLevel() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return printerErrorLevel.get(device.getErrorLevel());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public PrinterStation getErrorStation() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return printerStation.get(device.getErrorStation());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getErrorString() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getErrorString();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getFlagWhenIdle() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getFlagWhenIdle();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public FontTypefaceList getFontTypefaceList() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            FontTypefaceList res = new FontTypefaceList();
            List<String> list = res.getFontTypeface();
            for (String s : device.getFontTypefaceList().split(",")) {
                list.add(s);
            }
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getFreezeEvents() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getFreezeEvents();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public PrinterCartridgeStates getJrnCartridgeState() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return printerCartridgeStates.get(device.getJrnCartridgeState());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getJrnCurrentCartridge() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getJrnCurrentCartridge();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getJrnEmpty() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getJrnEmpty();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getJrnLetterQuality() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getJrnLetterQuality();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getJrnLineChars() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getJrnLineChars();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public LineCharsList getJrnLineCharsList() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            LineCharsList res = new LineCharsList();
            List<Integer> list = res.getLineChars();
            for (String s : device.getJrnLineCharsList().split(",")) {
                list.add(Integer.valueOf(s));
            }
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getJrnLineHeight() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getJrnLineHeight();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getJrnLineSpacing() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getJrnLineSpacing();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getJrnLineWidth() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getJrnLineWidth();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getJrnNearEnd() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getJrnNearEnd();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getMapCharacterSet() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getMapCharacterSet();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public MapMode getMapMode() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return mapMode.get(device.getMapMode());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getOutputID() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getOutputID();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Point getPageModeArea() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            Point res = new Point();
            String[] s = device.getPageModeArea().split(",");
            if (s.length > 1) {
                res.setX(Integer.valueOf(s[0]));
                res.setY(Integer.valueOf(s[1]));
            }
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getPageModeDescriptor() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getPageModeDescriptor();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getPageModeHorizontalPosition() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getPageModeHorizontalPosition();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Rectangle getPageModePrintArea() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            Rectangle res = new Rectangle();
            String[] s = device.getPageModeArea().split(",");
            if (s.length > 3) {
                res.setX(Integer.valueOf(s[0]));
                res.setY(Integer.valueOf(s[1]));
                res.setWidth(Integer.valueOf(s[2]));
                res.setHeight(Integer.valueOf(s[3]));
            }
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public PageModePrintDirection getPageModePrintDirection() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return pageModePrintDirection.get(device.getPageModePrintDirection());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public PrinterStation getPageModeStation() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return printerStation.get(device.getPageModeStation());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getPageModeVerticalPosition() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getPageModeVerticalPosition();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getPhysicalDeviceDescription() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getPhysicalDeviceDescription();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getPhysicalDeviceName() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getPhysicalDeviceName();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public PowerNotification getPowerNotify() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return powerNotification.get(device.getPowerNotify());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public PowerState getPowerState() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return powerState.get(device.getPowerState());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public RotationList getRecBarCodeRotationList() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            RotationList res = new RotationList();
            List<Rotation> list = res.getRotation();
            for (String s : device.getRecBarCodeRotationList().split(",")) {
                list.add(rotationString.get(s));
            }
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public RotationList getRecBitmapRotationList() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            RotationList res = new RotationList();
            List<Rotation> list = res.getRotation();
            for (String s : device.getRecBitmapRotationList().split(",")) {
                list.add(rotationString.get(s));
            }
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public PrinterCartridgeStates getRecCartridgeState() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return printerCartridgeStates.get(device.getRecCartridgeState());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getRecCurrentCartridge() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getRecCurrentCartridge();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getRecEmpty() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getRecEmpty();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getRecLetterQuality() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getRecLetterQuality();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getRecLineChars() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getRecLineChars();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public LineCharsList getRecLineCharsList() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            LineCharsList res = new LineCharsList();
            List<Integer> list = res.getLineChars();
            for (String s : device.getRecLineCharsList().split(",")) {
                list.add(Integer.valueOf(s));
            }
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getRecLineHeight() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getRecLineHeight();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getRecLineSpacing() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getRecLineSpacing();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getRecLineWidth() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getRecLineWidth();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getRecLinesToPaperCut() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getRecLinesToPaperCut();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getRecNearEnd() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getRecNearEnd();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getRecSidewaysMaxChars() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getRecSidewaysMaxChars();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getRecSidewaysMaxLines() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getRecSidewaysMaxLines();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Rotation getRotateSpecial() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return rotation.get(device.getRotateSpecial());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public RotationList getSlpBarCodeRotationList() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            RotationList res = new RotationList();
            List<Rotation> list = res.getRotation();
            for (String s : device.getSlpBarCodeRotationList().split(",")) {
                list.add(rotationString.get(s));
            }
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public RotationList getSlpBitmapRotationList() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            RotationList res = new RotationList();
            List<Rotation> list = res.getRotation();
            for (String s : device.getSlpBitmapRotationList().split(",")) {
                list.add(rotationString.get(s));
            }
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public PrinterCartridgeStates getSlpCartridgeState() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return printerCartridgeStates.get(device.getSlpCartridgeState());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getSlpCurrentCartridge() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getSlpCurrentCartridge();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getSlpEmpty() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getSlpEmpty();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getSlpLetterQuality() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getSlpLetterQuality();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getSlpLineChars() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getSlpLineChars();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public LineCharsList getSlpLineCharsList() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            LineCharsList res = new LineCharsList();
            List<Integer> list = res.getLineChars();
            for (String s : device.getSlpLineCharsList().split(",")) {
                list.add(Integer.valueOf(s));
            }
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getSlpLineHeight() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getSlpLineHeight();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getSlpLineSpacing() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getSlpLineSpacing();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getSlpLineWidth() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getSlpLineWidth();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getSlpLinesNearEndToEnd() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getSlpLinesNearEndToEnd();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getSlpMaxLines() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getSlpMaxLines();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getSlpNearEnd() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getSlpNearEnd();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public PrinterSide getSlpPrintSide() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return printerSide.get(device.getSlpPrintSide());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getSlpSidewaysMaxChars() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getSlpSidewaysMaxChars();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getSlpSidewaysMaxLines() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getSlpSidewaysMaxLines();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public ControlState getState() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        return controlState.get(device.getState());
    }

    public void markFeed(Integer type) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.markFeed(type);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void open(String endpointAddress) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.open(deviceName);
            if (endpointAddress != null)
            {
                try {
                    Service service = Service.create(
                            new URL(endpointAddress + "?wsdl"),
                            new QName("http://www.nrf-arts.org/UnifiedPOS/POSPrinterEvents/", "POSPrinterEventService"));
                    deviceEvent = service.getPort(org.nrf_arts.unifiedpos.posprinterevents.POSPrinterEvent.class);
                    device.addDirectIOListener(this);
                    device.addErrorListener(this);
                    device.addOutputCompleteListener(this);
                    device.addStatusUpdateListener(this);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void pageModePrint(PageModePrintControl control) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.pageModePrint(jposConst.get(control));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void printBarCode(PrinterStation station, String data, Integer symbology, Integer height, Integer width, Integer alignment, BarCodeTextPosition textPosition) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.printBarCode(jposConst.get(station), data, symbology, height, width, alignment, jposConst.get(textPosition));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void printBitmap(PrinterStation station, String fileName, Integer width, Integer alignment) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.printBitmap(jposConst.get(station), fileName, width, alignment);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void printImmediate(PrinterStation station, String data) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.printImmediate(jposConst.get(station), processEscapeSequence(data));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void printMemoryBitmap(PrinterStation station, byte[] data, BitmapType type, Integer width, Integer alignment) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.printMemoryBitmap(jposConst.get(station), data, jposConst.get(type), width, alignment);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void printNormal(PrinterStation station, String data) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.printNormal(jposConst.get(station), processEscapeSequence(data));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void printTwoNormal(PrinterStation station, String data1, String data2) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.printTwoNormal(jposConst.get(station), processEscapeSequence(data1), processEscapeSequence(data2));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void release() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.release();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void resetStatistics(StatisticList statisticsBuffer) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            String param = null;
            List<Statistic> list = statisticsBuffer.getStatistic();
            switch (list.size()) {
                case 0:
                    param = "";
                    break;
                case 1:
                    String name = list.get(0).getName();
                    if (name.equals(StatisticCategories.ALL)) {
                        param = "";
                    }
                    else if (name.equals(StatisticCategories.MANUFACTURER)) {
                        param = "M_";
                    }
                    else if (name.equals(StatisticCategories.UPOS)) {
                        param = "U_";
                    }
                    else {
                        param = name;
                    }
                    break;
                default:
                    StringBuffer buffer = new StringBuffer();
                    for (Statistic statistic : statisticsBuffer.getStatistic()) {
                        buffer.append(",").append(statistic.getName());
                    }
                    param = buffer.substring(1);
                    break;
            }
            device.resetStatistics(param);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String retrieveStatistics(StatisticList statisticsBuffer) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            String[] param = new String[1];
            List<Statistic> list = statisticsBuffer.getStatistic();
            switch (list.size()) {
                case 0:
                    param[0] = "";
                    break;
                case 1:
                    String name = list.get(0).getName();
                    if (name.equals(StatisticCategories.ALL)) {
                        param[0] = "";
                    }
                    else if (name.equals(StatisticCategories.MANUFACTURER)) {
                        param[0] = "M_";
                    }
                    else if (name.equals(StatisticCategories.UPOS)) {
                        param[0] = "U_";
                    }
                    else {
                        param[0] = name;
                    }
                    break;
                default:
                    StringBuffer buffer = new StringBuffer();
                    for (Statistic statistic : statisticsBuffer.getStatistic()) {
                        buffer.append(",").append(statistic.getName());
                    }
                    param[0] = buffer.substring(1);
                    break;
            }
            device.retrieveStatistics(param);
            return param[0];
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void rotatePrint(PrinterStation station, Integer rotation) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.rotatePrint(jposConst.get(station), rotation);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setAsyncMode(Boolean asyncMode) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setAsyncMode(asyncMode);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setBitmap(Integer bitmapNumber, PrinterStation station, String fileName, Integer width, Integer alignment) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setBitmap(bitmapNumber, jposConst.get(station), fileName, width, alignment);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setCartridgeNotify(PrinterCartridgeNotify cartridgeNotify) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setCartridgeNotify(jposConst.get(cartridgeNotify));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setCharacterSet(Integer characterSet) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setCharacterSet(characterSet);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setDeviceEnabled(Boolean deviceEnabled) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setDeviceEnabled(deviceEnabled);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setFlagWhenIdle(Boolean flagWhenIdle) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setFlagWhenIdle(flagWhenIdle);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setFreezeEvents(Boolean freezeEvents) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setFreezeEvents(freezeEvents);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setJrnCurrentCartridge(Integer jrnCurrentCartridge) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setJrnCurrentCartridge(jrnCurrentCartridge);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setJrnLetterQuality(Boolean jrnLetterQuality) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setJrnLetterQuality(jrnLetterQuality);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setJrnLineChars(Integer jrnLineChars) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setJrnLineChars(jrnLineChars);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setJrnLineHeight(Integer jrnLineHeight) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setJrnLineHeight(jrnLineHeight);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setJrnLineSpacing(Integer jrnLineSpacing) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setJrnLineSpacing(jrnLineSpacing);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setLogo(PrinterLogoLocation location, String data) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setLogo(jposConst.get(location), processEscapeSequence(data));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setMapCharacterSet(Boolean mapCharacterSet) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setMapCharacterSet(mapCharacterSet);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setMapMode(MapMode mapMode) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setMapMode(jposConst.get(mapMode));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setPageModeHorizontalPosition(Integer pageModeHorizontalPosition) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setPageModeHorizontalPosition(pageModeHorizontalPosition);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setPageModePrintArea(Rectangle pageModePrintArea) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setPageModePrintArea(
                    pageModePrintArea.getX() + "," +
                    pageModePrintArea.getY() + "," +
                    pageModePrintArea.getWidth() + "," +
                    pageModePrintArea.getHeight());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setPageModePrintDirection(PageModePrintDirection pageModePrintDirection) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setPageModePrintDirection(jposConst.get(pageModePrintDirection));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setPageModeStation(PrinterStation pageModeStation) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setPageModeStation(jposConst.get(pageModeStation));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setPageModeVerticalPosition(Integer pageModeVerticalPosition) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setPageModeVerticalPosition(pageModeVerticalPosition);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setPowerNotify(PowerNotification powerNotify) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setPowerNotify(jposConst.get(powerNotify));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setRecCurrentCartridge(Integer recCurrentCartridge) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setRecCurrentCartridge(recCurrentCartridge);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setRecLetterQuality(Boolean recLetterQuality) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setRecLetterQuality(recLetterQuality);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setRecLineChars(Integer recLineChars) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setRecLineChars(recLineChars);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setRecLineHeight(Integer recLineHeight) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setRecLineHeight(recLineHeight);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setRecLineSpacing(Integer recLineSpacing) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setRecLineSpacing(recLineSpacing);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setRotateSpecial(Rotation rotateSpecial) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setRotateSpecial(jposConst.get(rotateSpecial));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setSlpCurrentCartridge(Integer slpCurrentCartridge) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setSlpCurrentCartridge(slpCurrentCartridge);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setSlpLetterQuality(Boolean slpLetterQuality) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setSlpLetterQuality(slpLetterQuality);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setSlpLineChars(Integer slpLineChars) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setSlpLineChars(slpLineChars);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setSlpLineHeight(Integer slpLineHeight) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setSlpLineHeight(slpLineHeight);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setSlpLineSpacing(Integer slpLineSpacing) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setSlpLineSpacing(slpLineSpacing);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void transactionPrint(PrinterStation station, PrinterTransactionControl control) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.transactionPrint(jposConst.get(station), jposConst.get(control));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void updateFirmware(String firmwareFileName) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.updateFirmware(firmwareFileName);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void updateStatistics(StatisticList statisticsBuffer) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            String param = null;
            List<Statistic> list = statisticsBuffer.getStatistic();
            switch (list.size()) {
                case 0:
                    param = "";
                    break;
                case 1:
                    Statistic s = list.get(0);
                    String name = s.getName();
                    String value = s.getValue();
                    if (name.equals(StatisticCategories.ALL)) {
                        param = "=" + value;
                    }
                    else if (name.equals(StatisticCategories.MANUFACTURER)) {
                        param = "M_=" + value;
                    }
                    else if (name.equals(StatisticCategories.UPOS)) {
                        param = "U_=" + value;
                    }
                    else {
                        param = name + "=" + value;
                    }
                    break;
                default:
                    StringBuffer buffer = new StringBuffer();
                    for (Statistic statistic : statisticsBuffer.getStatistic()) {
                        buffer.append(",").append(statistic.getName()).append("=").append(statistic.getValue());
                    }
                    param = buffer.substring(1);
                    break;
            }
            device.updateStatistics(param);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void validateData(PrinterStation station, String data) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.validateData(jposConst.get(station), processEscapeSequence(data));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    //
    // POSPrinterEvent Member
    //

    public void directIOOccurred(DirectIOEvent dioe) {
        //throw new UnsupportedOperationException("Not supported yet.");
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(new Date(dioe.getWhen()));
        org.nrf_arts.unifiedpos.posprinterevents.DirectIOData value = deviceEvent.directIOEvent(
                dioe.getSource().toString(),
                (int)dioe.getSequenceNumber(),
                datatypeFactory.newXMLGregorianCalendar(cal),
                dioe.getEventNumber(),
                dioe.getData(),
                dioe.getObject());
        dioe.setData(value.getData());
        dioe.setObject(value.getObj());
    }

    public void errorOccurred(ErrorEvent ee) {
        //throw new UnsupportedOperationException("Not supported yet.");
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(new Date(ee.getWhen()));
        org.nrf_arts.unifiedpos.posprinterevents.ErrorResponse value = deviceEvent.errorEvent(
                ee.getSource().toString(),
                (int)ee.getSequenceNumber(),
                datatypeFactory.newXMLGregorianCalendar(cal),
                eventErrorCode.get(ee.getErrorCode()),
                ee.getErrorCodeExtended(),
                eventErrorLocus.get(ee.getErrorLocus()),
                eventErrorResponse.get(ee.getErrorResponse()));
        ee.setErrorResponse(jposEventConst.get(value));
    }

    public void outputCompleteOccurred(OutputCompleteEvent oce) {
        //throw new UnsupportedOperationException("Not supported yet.");
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(new Date(oce.getWhen()));
        deviceEvent.statusUpdateEvent(
                oce.getSource().toString(),
                (int)oce.getSequenceNumber(),
                datatypeFactory.newXMLGregorianCalendar(cal),
                oce.getOutputID());
    }

    public void statusUpdateOccurred(StatusUpdateEvent sue) {
        //throw new UnsupportedOperationException("Not supported yet.");
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(new Date(sue.getWhen()));
        deviceEvent.statusUpdateEvent(
                sue.getSource().toString(),
                (int)sue.getSequenceNumber(),
                datatypeFactory.newXMLGregorianCalendar(cal),
                sue.getStatus());
    }

}
