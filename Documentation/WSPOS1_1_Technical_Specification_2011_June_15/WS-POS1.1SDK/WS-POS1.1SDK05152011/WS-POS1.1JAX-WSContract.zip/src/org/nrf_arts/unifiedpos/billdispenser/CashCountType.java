
package org.nrf_arts.unifiedpos.billdispenser;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for CashCountType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="CashCountType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="Bill"/>
 *     &lt;enumeration value="Coin"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "CashCountType")
@XmlEnum
public enum CashCountType {

    @XmlEnumValue("Bill")
    BILL("Bill"),
    @XmlEnumValue("Coin")
    COIN("Coin");
    private final String value;

    CashCountType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static CashCountType fromValue(String v) {
        for (CashCountType c: CashCountType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
