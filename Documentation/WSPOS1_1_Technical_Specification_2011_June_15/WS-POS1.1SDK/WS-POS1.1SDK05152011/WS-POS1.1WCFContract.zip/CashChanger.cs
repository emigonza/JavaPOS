﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace UnifiedPOS.CashChanger
{
    [ServiceContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/")]
    public interface CashChanger
    {

        //
        // Common Properties
        //

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetAutoDisableResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        // int GetAutoDisable();

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/SetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/SetAutoDisableResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        // void SetAutoDisable(int AutoDisable);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetCapCompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetCapCompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        bool GetCapCompareFirmwareVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetCapPowerReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetCapPowerReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        PowerReporting GetCapPowerReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetCapStatisticsReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetCapStatisticsReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        bool GetCapStatisticsReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetCapUpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetCapUpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        bool GetCapUpdateFirmware();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetCapUpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetCapUpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        bool GetCapUpdateStatistics();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetCheckHealthText", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetCheckHealthTextResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        string GetCheckHealthText();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetClaimed", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetClaimedResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        bool GetClaimed();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetDataCount", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetDataCountResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        int GetDataCount();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetDataEventEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        bool GetDataEventEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/SetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/SetDataEventEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        void SetDataEventEnabled(bool DataEventEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        bool GetDeviceEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/SetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/SetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        void SetDeviceEnabled(bool DeviceEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        bool GetFreezeEvents();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/SetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/SetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        void SetFreezeEvents(bool FreezeEvents);

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetOutputID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetOutputIDResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        // int GetOutputID();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        PowerNotification GetPowerNotify();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/SetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/SetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        void SetPowerNotify(PowerNotification PowerNotify);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetPowerState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetPowerStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        PowerState GetPowerState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        ControlState GetState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetDeviceControlDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetDeviceControlDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        string GetDeviceControlDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetDeviceControlVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetDeviceControlVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        UposVersion GetDeviceControlVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetDeviceServiceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetDeviceServiceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        string GetDeviceServiceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetDeviceServiceVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetDeviceServiceVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        UposVersion GetDeviceServiceVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetPhysicalDeviceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetPhysicalDeviceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        string GetPhysicalDeviceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetPhysicalDeviceName", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetPhysicalDeviceNameResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        string GetPhysicalDeviceName();

        //
        // Specific Properties
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetCapDeposit", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetCapDepositResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        bool GetCapDeposit();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetCapDepositDataEvent", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetCapDepositDataEventResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        bool GetCapDepositDataEvent();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetCapDiscrepancy", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetCapDiscrepancyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        bool GetCapDiscrepancy();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetCapEmptySensor", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetCapEmptySensorResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        bool GetCapEmptySensor();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetCapFullSensor", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetCapFullSensorResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        bool GetCapFullSensor();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetCapJamSensor", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetCapJamSensorResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        bool GetCapJamSensor();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetCapNearEmptySensor", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetCapNearEmptySensorResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        bool GetCapNearEmptySensor();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetCapNearFullSensor", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetCapNearFullSensorResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        bool GetCapNearFullSensor();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetCapPauseDeposit", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetCapPauseDepositResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        bool GetCapPauseDeposit();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetCapRealTimeData", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetCapRealTimeDataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        bool GetCapRealTimeData();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetCapRepayDeposit", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetCapRepayDepositResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        bool GetCapRepayDeposit();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetAsyncMode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetAsyncModeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        bool GetAsyncMode();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/SetAsyncMode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/SetAsyncModeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        void SetAsyncMode(bool AsyncMode);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetAsyncResultCode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetAsyncResultCodeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        int GetAsyncResultCode();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetAsyncResultCodeExtended", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetAsyncResultCodeExtendedResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        int GetAsyncResultCodeExtended();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetCurrencyCashList", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetCurrencyCashListResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        CashUnits GetCurrencyCashList();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetCurrencyCode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetCurrencyCodeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        string GetCurrencyCode();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/SetCurrencyCode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/SetCurrencyCodeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        void SetCurrencyCode(string CurrencyCode);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetCurrencyCodeList", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetCurrencyCodeListResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        CurrencyCodeList GetCurrencyCodeList();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetCurrentExit", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetCurrentExitResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        int GetCurrentExit();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/SetCurrentExit", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/SetCurrentExitResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        void SetCurrentExit(int CurrentExit);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetCurrentService", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetCurrentServiceResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        int GetCurrentService();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/SetCurrentService", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/SetCurrentServiceResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        void SetCurrentService(int CurrentService);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetDepositAmount", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetDepositAmountResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        int GetDepositAmount();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetDepositCashList", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetDepositCashListResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        CashUnits GetDepositCashList();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetDepositCodeList", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetDepositCodeListResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        DepositCodeList GetDepositCodeList();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetDepositCounts", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetDepositCountsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        CashCountList GetDepositCounts();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetDepositStatus", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetDepositStatusResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        CashDepositStatus GetDepositStatus();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetDeviceExits", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetDeviceExitsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        int GetDeviceExits();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetDeviceStatus", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetDeviceStatusResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        CashChangerStatus GetDeviceStatus();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetExitCashList", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetExitCashListResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        CashUnits GetExitCashList();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetFullStatus", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetFullStatusResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        CashChangerFullStatus GetFullStatus();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetRealTimeDataEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetRealTimeDataEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        bool GetRealTimeDataEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/SetRealTimeDataEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/SetRealTimeDataEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        void SetRealTimeDataEnabled(bool RealTimeDataEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetServiceCount", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetServiceCountResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        int GetServiceCount();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetServiceIndex", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/GetServiceIndexResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        ServiceIndex GetServiceIndex();

        //
        // Common Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/Open", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/OpenResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        void Open(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/Close", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/CloseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        void Close(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/Claim", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/ClaimResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        void Claim(int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/Release", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/ReleaseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        void Release();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/CheckHealth", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/CheckHealthResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        void CheckHealth(HealthCheckLevel Level);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/ClearInput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/ClearInputResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        void ClearInput();

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/ClearInputProperties", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/ClearInputPropertiesResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        // void ClearInputProperties();

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/ClearOutput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/ClearOutputResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        // void ClearOutput();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/DirectIO", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/DirectIOResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        DirectIOData DirectIO(int Command, int Data, object Obj);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/CompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/CompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        CompareFirmwareResult CompareFirmwareVersion(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/ResetStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/ResetStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        void ResetStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/RetrieveStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/RetrieveStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        string RetrieveStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        void UpdateFirmware(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        void UpdateStatistics(StatisticList StatisticsBuffer);

        //
        // Specific Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/AdjustCashCounts", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/AdjustCashCountsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        void AdjustCashCounts(CashCountList CashCounts);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/BeginDeposit", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/BeginDepositResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        void BeginDeposit();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/DispenseCash", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/DispenseCashResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        void DispenseCash(CashCountList CashCounts);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/DispenseChange", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/DispenseChangeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        void DispenseChange(int Amount);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/EndDeposit", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/EndDepositResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        void EndDeposit(CashDepositAction Success);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/FixDeposit", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/FixDepositResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        void FixDeposit();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/PauseDeposit", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/PauseDepositResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        void PauseDeposit(CashDepositPause Control);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/ReadCashCounts", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/ReadCashCountsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/UposException", Name = "UposException")]
        CashCounts ReadCashCounts();
    }

    //
    // Common Data Types
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/")]
    public class DirectIOData
    {
        [DataMember]
        public int Data { get; set; }
        [DataMember]
        public object Obj { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/")]
    public class UposException
    {
        [DataMember]
        public ErrorCode ErrorCode { get; set; }
        [DataMember]
        public int ErrorCodeExtended { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/")]
    public class UposVersion
    {
        [DataMember]
        public int Major { get; set; }
        [DataMember]
        public int Minor { get; set; }
        [DataMember]
        public int Build { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/")]
    public class Statistic
    {
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public string Value { get; set; }
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/", ItemName = "Statistic")]
    public class StatisticList : List<Statistic>
    {
    }

    //
    // Common Enumerations
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/")]
    public enum CompareFirmwareResult
    {
        [EnumMember]
        Different,
        [EnumMember]
        Newer,
        [EnumMember]
        Older,
        [EnumMember]
        Same,
        [EnumMember]
        Unknown,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/")]
    public enum ControlState
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Closed,
        [EnumMember]
        Error,
        [EnumMember]
        Idle,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/")]
    public enum ErrorCode
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Claimed,
        [EnumMember]
        Closed,
        [EnumMember]
        Deprecated,
        [EnumMember]
        Disabled,
        [EnumMember]
        Exists,
        [EnumMember]
        Extended,
        [EnumMember]
        Failure,
        [EnumMember]
        Illegal,
        [EnumMember]
        NoExist,
        [EnumMember]
        NoHardware,
        [EnumMember]
        NoService,
        [EnumMember]
        NotClaimed,
        [EnumMember]
        Offline,
        [EnumMember]
        Success,
        [EnumMember]
        Timeout,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/")]
    public enum HealthCheckLevel
    {
        [EnumMember]
        External,
        [EnumMember]
        Interactive,
        [EnumMember]
        Internal,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/")]
    public enum PowerNotification
    {
        [EnumMember]
        Disabled,
        [EnumMember]
        Enabled,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/")]
    public enum PowerReporting
    {
        [EnumMember]
        Advanced,
        [EnumMember]
        None,
        [EnumMember]
        Standard,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/")]
    public enum PowerState
    {
        [EnumMember]
        Off,
        [EnumMember]
        Offline,
        [EnumMember]
        OffOffline,
        [EnumMember]
        Online,
        [EnumMember]
        Unknown,
    }

    /*
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/")]
    public enum StatisticCategories
    {
        [EnumMember]
        All,
        [EnumMember]
        Manufacturer,
        [EnumMember]
        Upos,
    }
    */
    public class StatisticCategories
    {
        public const string All = "";
        public const string Manufacturer = "M_";
        public const string Upos = "U_";
    }

    //
    // Specific Data Types
    //

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/", ItemName = "Bill")]
    public class BillList : List<int>
    {
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/")]
    public class CashCount
    {
        [DataMember]
        public int Count { get; set; }
        [DataMember]
        public int NominalValue { get; set; }
        [DataMember]
        public CashCountType Type { get; set; }
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/", ItemName = "CashCount")]
    public class CashCountList : List<CashCount>
    {
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/")]
    public class CashCounts
    {
        [DataMember]
        public CashCountList Counts { get; set; }
        [DataMember]
        public bool Discrepancy { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/")]
    public class CashUnits
    {
        [DataMember]
        public BillList Bills { get; set; }
        [DataMember]
        public CoinList Coins { get; set; }
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/", ItemName = "Coin")]
    public class CoinList : List<int>
    {
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/", ItemName = "CurrencyCode")]
    public class CurrencyCodeList : List<string>
    {
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/", ItemName = "DepositCode")]
    public class DepositCodeList : List<string>
    {
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/")]
    public class ServiceIndex
    {
        [DataMember]
        public int BillDispenser { get; set; }
        [DataMember]
        public int BillAcceptor { get; set; }
        [DataMember]
        public int CoinDispenser { get; set; }
        [DataMember]
        public int CoinAcceptor { get; set; }
    }

    //
    // Specific Enumerations
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/")]
    public enum CashChangerFullStatus
    {
        [EnumMember]
        Full,
        [EnumMember]
        NearFull,
        [EnumMember]
        OK,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/")]
    public enum CashChangerStatus
    {
        [EnumMember]
        Empty,
        [EnumMember]
        Jam,
        [EnumMember]
        NearEmpty,
        [EnumMember]
        OK,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/")]
    public enum CashCountType
    {
        [EnumMember]
        Bill,
        [EnumMember]
        Coin,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/")]
    public enum CashDepositAction
    {
        [EnumMember]
        Change,
        [EnumMember]
        NoChange,
        [EnumMember]
        Repay,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/")]
    public enum CashDepositPause
    {
        [EnumMember]
        Pause,
        [EnumMember]
        Restart,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/CashChanger/")]
    public enum CashDepositStatus
    {
        [EnumMember]
        Count,
        [EnumMember]
        End,
        [EnumMember]
        Jam,
        [EnumMember]
        None,
        [EnumMember]
        Start,
    }

    //
    // Constants
    //

    /*
    public class Constants
    {
        public const int ExtendedErrorFirmwareBadFile = 281;
        public const int ExtendedErrorOverDispense = 201;
        public const int ExtendedErrorStatistics = 280;
        public const int ExtendedErrorStatisticsDependency = 282;
        public const string StatisticCommunicationErrorCount = "CommunicationErrorCount";
        public const string StatisticDeviceCategory = "DeviceCategory";
        public const string StatisticFirmwareRevision = "FirmwareRevision";
        public const string StatisticHoursPoweredCount = "HoursPoweredCount";
        public const string StatisticInstallationDate = "InstallationDate";
        public const string StatisticInterface = "Interface";
        public const string StatisticManufactureDate = "ManufactureDate";
        public const string StatisticManufacturerName = "ManufacturerName";
        public const string StatisticMechanicalRevision = "MechanicalRevision";
        public const string StatisticModelName = "ModelName";
        public const string StatisticSerialNumber = "SerialNumber";
        public const string StatisticUnifiedPOSVersion = "UnifiedPOSVersion";
        public const int WaitForever = -1;
    }
    */

    public class ExtendedError
    {
        public const int FirmwareBadFile = 281;
        public const int OverDispense = 201;
        public const int Statistics = 280;
        public const int StatisticsDependency = 282;
    }

    public class StatisticProperties
    {
        public const string CommunicationErrorCount = "CommunicationErrorCount";
        public const string DeviceCategory = "DeviceCategory";
        public const string FirmwareRevision = "FirmwareRevision";
        public const string HoursPoweredCount = "HoursPoweredCount";
        public const string InstallationDate = "InstallationDate";
        public const string Interface = "Interface";
        public const string ManufactureDate = "ManufactureDate";
        public const string ManufacturerName = "ManufacturerName";
        public const string MechanicalRevision = "MechanicalRevision";
        public const string ModelName = "ModelName";
        public const string SerialNumber = "SerialNumber";
        public const string UnifiedPOSVersion = "UnifiedPOSVersion";
    }

    public class Wait
    {
        public const int Forever = -1;
    }
}
