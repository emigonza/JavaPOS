/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package wspos;

import java.net.URL;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import jpos.events.DataEvent;
import jpos.events.DirectIOEvent;
import jpos.events.ErrorEvent;
import jpos.events.StatusUpdateEvent;
import org.nrf_arts.unifiedpos.scanner.*;
import javax.jws.WebService;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.namespace.QName;
import javax.xml.ws.Service;

/**
 *
 * @author hideon
 */
@WebService(serviceName = "ScannerService", endpointInterface = "org.nrf_arts.unifiedpos.scanner.Scanner", targetNamespace = "http://www.nrf-arts.org/UnifiedPOS/Scanner/")
public class ScannerService implements Scanner, jpos.events.DataListener, jpos.events.DirectIOListener, jpos.events.ErrorListener, jpos.events.StatusUpdateListener {

    //
    // Scanner Enumration Converter
    //

    private static HashMap<Enum, Integer> jposConst;
    private static HashMap<Integer, PowerReporting> powerReporting;
    private static HashMap<Integer, PowerNotification> powerNotification;
    private static HashMap<Integer, PowerState> powerState;
    private static HashMap<Integer, ControlState> controlState;
    private static HashMap<Integer, HealthCheckLevel> healthCheckLevel;
    private static HashMap<Integer, CompareFirmwareResult> compareFirmwareResult;
    private static HashMap<Integer, ErrorCode> errorCode;

    private static HashMap<Enum, Integer> jposEventConst;
    private static HashMap<Integer, org.nrf_arts.unifiedpos.scannerevents.ErrorCode> eventErrorCode;
    private static HashMap<Integer, org.nrf_arts.unifiedpos.scannerevents.ErrorLocus> eventErrorLocus;
    private static HashMap<Integer, org.nrf_arts.unifiedpos.scannerevents.ErrorResponse> eventErrorResponse;

    static {
        jposConst = new HashMap<Enum, Integer>();
        jposConst.put(PowerReporting.ADVANCED, jpos.Scanner.JPOS_PR_ADVANCED);
        jposConst.put(PowerReporting.NONE, jpos.Scanner.JPOS_PR_NONE);
        jposConst.put(PowerReporting.STANDARD, jpos.Scanner.JPOS_PR_STANDARD);
        jposConst.put(PowerNotification.DISABLED, jpos.Scanner.JPOS_PN_DISABLED);
        jposConst.put(PowerNotification.ENABLED, jpos.Scanner.JPOS_PN_ENABLED);
        jposConst.put(PowerState.OFF, jpos.Scanner.JPOS_PS_OFF);
        jposConst.put(PowerState.OFFLINE, jpos.Scanner.JPOS_PS_OFFLINE);
        jposConst.put(PowerState.OFF_OFFLINE, jpos.Scanner.JPOS_PS_OFF_OFFLINE);
        jposConst.put(PowerState.ONLINE, jpos.Scanner.JPOS_PS_ONLINE);
        jposConst.put(PowerState.UNKNOWN, jpos.Scanner.JPOS_PS_UNKNOWN);
        jposConst.put(ControlState.BUSY, jpos.Scanner.JPOS_S_BUSY);
        jposConst.put(ControlState.CLOSED, jpos.Scanner.JPOS_S_CLOSED);
        jposConst.put(ControlState.ERROR, jpos.Scanner.JPOS_S_ERROR);
        jposConst.put(ControlState.IDLE, jpos.Scanner.JPOS_S_IDLE);
        jposConst.put(HealthCheckLevel.EXTERNAL, jpos.Scanner.JPOS_CH_EXTERNAL);
        jposConst.put(HealthCheckLevel.INTERACTIVE, jpos.Scanner.JPOS_CH_INTERACTIVE);
        jposConst.put(HealthCheckLevel.INTERNAL, jpos.Scanner.JPOS_CH_INTERNAL);
        jposConst.put(CompareFirmwareResult.DIFFERENT, jpos.Scanner.JPOS_CFV_FIRMWARE_DIFFERENT);
        jposConst.put(CompareFirmwareResult.NEWER, jpos.Scanner.JPOS_CFV_FIRMWARE_NEWER);
        jposConst.put(CompareFirmwareResult.OLDER, jpos.Scanner.JPOS_CFV_FIRMWARE_OLDER);
        jposConst.put(CompareFirmwareResult.SAME, jpos.Scanner.JPOS_CFV_FIRMWARE_SAME);
        jposConst.put(CompareFirmwareResult.UNKNOWN, jpos.Scanner.JPOS_CFV_FIRMWARE_UNKNOWN);
        jposConst.put(ErrorCode.BUSY, jpos.Scanner.JPOS_E_BUSY);
        jposConst.put(ErrorCode.CLAIMED, jpos.Scanner.JPOS_E_CLAIMED);
        jposConst.put(ErrorCode.CLOSED, jpos.Scanner.JPOS_E_CLOSED);
        jposConst.put(ErrorCode.DEPRECATED, jpos.Scanner.JPOS_E_DEPRECATED);
        jposConst.put(ErrorCode.DISABLED, jpos.Scanner.JPOS_E_DISABLED);
        jposConst.put(ErrorCode.EXISTS, jpos.Scanner.JPOS_E_EXISTS);
        jposConst.put(ErrorCode.EXTENDED, jpos.Scanner.JPOS_E_EXTENDED);
        jposConst.put(ErrorCode.FAILURE, jpos.Scanner.JPOS_E_FAILURE);
        jposConst.put(ErrorCode.ILLEGAL, jpos.Scanner.JPOS_E_ILLEGAL);
        jposConst.put(ErrorCode.NO_EXIST, jpos.Scanner.JPOS_E_NOEXIST);
        jposConst.put(ErrorCode.NO_HARDWARE, jpos.Scanner.JPOS_E_NOHARDWARE);
        jposConst.put(ErrorCode.NO_SERVICE, jpos.Scanner.JPOS_E_NOSERVICE);
        jposConst.put(ErrorCode.NOT_CLAIMED, jpos.Scanner.JPOS_E_NOTCLAIMED);
        jposConst.put(ErrorCode.OFFLINE, jpos.Scanner.JPOS_E_OFFLINE);
        jposConst.put(ErrorCode.SUCCESS, 0);
        jposConst.put(ErrorCode.TIMEOUT, jpos.Scanner.JPOS_E_TIMEOUT);

        powerReporting = new HashMap<Integer, PowerReporting>();
        powerReporting.put(jpos.Scanner.JPOS_PR_ADVANCED, PowerReporting.ADVANCED);
        powerReporting.put(jpos.Scanner.JPOS_PR_NONE, PowerReporting.NONE);
        powerReporting.put(jpos.Scanner.JPOS_PR_STANDARD, PowerReporting.STANDARD);

        powerNotification = new HashMap<Integer, PowerNotification>();
        powerNotification.put(jpos.Scanner.JPOS_PN_DISABLED, PowerNotification.DISABLED);
        powerNotification.put(jpos.Scanner.JPOS_PN_ENABLED, PowerNotification.ENABLED);

        powerState = new HashMap<Integer, PowerState>();
        powerState.put(jpos.Scanner.JPOS_PS_OFF, PowerState.OFF);
        powerState.put(jpos.Scanner.JPOS_PS_OFFLINE, PowerState.OFFLINE);
        powerState.put(jpos.Scanner.JPOS_PS_OFF_OFFLINE, PowerState.OFF_OFFLINE);
        powerState.put(jpos.Scanner.JPOS_PS_ONLINE, PowerState.ONLINE);
        powerState.put(jpos.Scanner.JPOS_PS_UNKNOWN, PowerState.UNKNOWN);

        controlState = new HashMap<Integer, ControlState>();
        controlState.put(jpos.Scanner.JPOS_S_BUSY, ControlState.BUSY);
        controlState.put(jpos.Scanner.JPOS_S_CLOSED, ControlState.CLOSED);
        controlState.put(jpos.Scanner.JPOS_S_ERROR, ControlState.ERROR);
        controlState.put(jpos.Scanner.JPOS_S_IDLE, ControlState.IDLE);

        healthCheckLevel = new HashMap<Integer, HealthCheckLevel>();
        healthCheckLevel.put(jpos.Scanner.JPOS_CH_EXTERNAL, HealthCheckLevel.EXTERNAL);
        healthCheckLevel.put(jpos.Scanner.JPOS_CH_INTERACTIVE, HealthCheckLevel.INTERACTIVE);
        healthCheckLevel.put(jpos.Scanner.JPOS_CH_INTERNAL, HealthCheckLevel.INTERNAL);

        compareFirmwareResult = new HashMap<Integer, CompareFirmwareResult>();
        compareFirmwareResult.put(jpos.Scanner.JPOS_CFV_FIRMWARE_DIFFERENT, CompareFirmwareResult.DIFFERENT);
        compareFirmwareResult.put(jpos.Scanner.JPOS_CFV_FIRMWARE_NEWER, CompareFirmwareResult.NEWER);
        compareFirmwareResult.put(jpos.Scanner.JPOS_CFV_FIRMWARE_OLDER, CompareFirmwareResult.OLDER);
        compareFirmwareResult.put(jpos.Scanner.JPOS_CFV_FIRMWARE_SAME, CompareFirmwareResult.SAME);
        compareFirmwareResult.put(jpos.Scanner.JPOS_CFV_FIRMWARE_UNKNOWN, CompareFirmwareResult.UNKNOWN);

        errorCode = new HashMap<Integer, ErrorCode>();
        errorCode.put(jpos.Scanner.JPOS_E_BUSY, ErrorCode.BUSY);
        errorCode.put(jpos.Scanner.JPOS_E_CLAIMED, ErrorCode.CLAIMED);
        errorCode.put(jpos.Scanner.JPOS_E_CLOSED, ErrorCode.CLOSED);
        errorCode.put(jpos.Scanner.JPOS_E_DEPRECATED, ErrorCode.DEPRECATED);
        errorCode.put(jpos.Scanner.JPOS_E_DISABLED, ErrorCode.DISABLED);
        errorCode.put(jpos.Scanner.JPOS_E_EXISTS, ErrorCode.EXISTS);
        errorCode.put(jpos.Scanner.JPOS_E_EXTENDED, ErrorCode.EXTENDED);
        errorCode.put(jpos.Scanner.JPOS_E_FAILURE, ErrorCode.FAILURE);
        errorCode.put(jpos.Scanner.JPOS_E_ILLEGAL, ErrorCode.ILLEGAL);
        errorCode.put(jpos.Scanner.JPOS_E_NOEXIST, ErrorCode.NO_EXIST);
        errorCode.put(jpos.Scanner.JPOS_E_NOHARDWARE, ErrorCode.NO_HARDWARE);
        errorCode.put(jpos.Scanner.JPOS_E_NOSERVICE, ErrorCode.NO_SERVICE);
        errorCode.put(jpos.Scanner.JPOS_E_NOTCLAIMED, ErrorCode.NOT_CLAIMED);
        errorCode.put(jpos.Scanner.JPOS_E_OFFLINE, ErrorCode.OFFLINE);
        errorCode.put(0, ErrorCode.SUCCESS);
        errorCode.put(jpos.Scanner.JPOS_E_TIMEOUT, ErrorCode.TIMEOUT);

        jposEventConst = new HashMap<Enum, Integer>();
        jposEventConst.put(org.nrf_arts.unifiedpos.scannerevents.ErrorCode.BUSY, jpos.Scanner.JPOS_E_BUSY);
        jposEventConst.put(org.nrf_arts.unifiedpos.scannerevents.ErrorCode.CLAIMED, jpos.Scanner.JPOS_E_CLAIMED);
        jposEventConst.put(org.nrf_arts.unifiedpos.scannerevents.ErrorCode.CLOSED, jpos.Scanner.JPOS_E_CLOSED);
        jposEventConst.put(org.nrf_arts.unifiedpos.scannerevents.ErrorCode.DEPRECATED, jpos.Scanner.JPOS_E_DEPRECATED);
        jposEventConst.put(org.nrf_arts.unifiedpos.scannerevents.ErrorCode.DISABLED, jpos.Scanner.JPOS_E_DISABLED);
        jposEventConst.put(org.nrf_arts.unifiedpos.scannerevents.ErrorCode.EXISTS, jpos.Scanner.JPOS_E_EXISTS);
        jposEventConst.put(org.nrf_arts.unifiedpos.scannerevents.ErrorCode.EXTENDED, jpos.Scanner.JPOS_E_EXTENDED);
        jposEventConst.put(org.nrf_arts.unifiedpos.scannerevents.ErrorCode.FAILURE, jpos.Scanner.JPOS_E_FAILURE);
        jposEventConst.put(org.nrf_arts.unifiedpos.scannerevents.ErrorCode.ILLEGAL, jpos.Scanner.JPOS_E_ILLEGAL);
        jposEventConst.put(org.nrf_arts.unifiedpos.scannerevents.ErrorCode.NO_EXIST, jpos.Scanner.JPOS_E_NOEXIST);
        jposEventConst.put(org.nrf_arts.unifiedpos.scannerevents.ErrorCode.NO_HARDWARE, jpos.Scanner.JPOS_E_NOHARDWARE);
        jposEventConst.put(org.nrf_arts.unifiedpos.scannerevents.ErrorCode.NO_SERVICE, jpos.Scanner.JPOS_E_NOSERVICE);
        jposEventConst.put(org.nrf_arts.unifiedpos.scannerevents.ErrorCode.NOT_CLAIMED, jpos.Scanner.JPOS_E_NOTCLAIMED);
        jposEventConst.put(org.nrf_arts.unifiedpos.scannerevents.ErrorCode.OFFLINE, jpos.Scanner.JPOS_E_OFFLINE);
        jposEventConst.put(org.nrf_arts.unifiedpos.scannerevents.ErrorCode.SUCCESS, 0);
        jposEventConst.put(org.nrf_arts.unifiedpos.scannerevents.ErrorCode.TIMEOUT, jpos.Scanner.JPOS_E_TIMEOUT);
        jposEventConst.put(org.nrf_arts.unifiedpos.scannerevents.ErrorLocus.INPUT, jpos.Scanner.JPOS_EL_INPUT);
        jposEventConst.put(org.nrf_arts.unifiedpos.scannerevents.ErrorLocus.INPUT_DATA, jpos.Scanner.JPOS_EL_INPUT_DATA);
        jposEventConst.put(org.nrf_arts.unifiedpos.scannerevents.ErrorLocus.OUTPUT, jpos.Scanner.JPOS_EL_OUTPUT);
        jposEventConst.put(org.nrf_arts.unifiedpos.scannerevents.ErrorResponse.CLEAR, jpos.Scanner.JPOS_ER_CLEAR);
        jposEventConst.put(org.nrf_arts.unifiedpos.scannerevents.ErrorResponse.CONTINUE_INPUT, jpos.Scanner.JPOS_ER_CONTINUEINPUT);
        jposEventConst.put(org.nrf_arts.unifiedpos.scannerevents.ErrorResponse.RETRY, jpos.Scanner.JPOS_ER_RETRY);

        eventErrorCode = new HashMap<Integer, org.nrf_arts.unifiedpos.scannerevents.ErrorCode>();
        eventErrorCode.put(jpos.Scanner.JPOS_E_BUSY, org.nrf_arts.unifiedpos.scannerevents.ErrorCode.BUSY);
        eventErrorCode.put(jpos.Scanner.JPOS_E_CLAIMED, org.nrf_arts.unifiedpos.scannerevents.ErrorCode.CLAIMED);
        eventErrorCode.put(jpos.Scanner.JPOS_E_CLOSED, org.nrf_arts.unifiedpos.scannerevents.ErrorCode.CLOSED);
        eventErrorCode.put(jpos.Scanner.JPOS_E_DEPRECATED, org.nrf_arts.unifiedpos.scannerevents.ErrorCode.DEPRECATED);
        eventErrorCode.put(jpos.Scanner.JPOS_E_DISABLED, org.nrf_arts.unifiedpos.scannerevents.ErrorCode.DISABLED);
        eventErrorCode.put(jpos.Scanner.JPOS_E_EXISTS, org.nrf_arts.unifiedpos.scannerevents.ErrorCode.EXISTS);
        eventErrorCode.put(jpos.Scanner.JPOS_E_EXTENDED, org.nrf_arts.unifiedpos.scannerevents.ErrorCode.EXTENDED);
        eventErrorCode.put(jpos.Scanner.JPOS_E_FAILURE, org.nrf_arts.unifiedpos.scannerevents.ErrorCode.FAILURE);
        eventErrorCode.put(jpos.Scanner.JPOS_E_ILLEGAL, org.nrf_arts.unifiedpos.scannerevents.ErrorCode.ILLEGAL);
        eventErrorCode.put(jpos.Scanner.JPOS_E_NOEXIST, org.nrf_arts.unifiedpos.scannerevents.ErrorCode.NO_EXIST);
        eventErrorCode.put(jpos.Scanner.JPOS_E_NOHARDWARE, org.nrf_arts.unifiedpos.scannerevents.ErrorCode.NO_HARDWARE);
        eventErrorCode.put(jpos.Scanner.JPOS_E_NOSERVICE, org.nrf_arts.unifiedpos.scannerevents.ErrorCode.NO_SERVICE);
        eventErrorCode.put(jpos.Scanner.JPOS_E_NOTCLAIMED, org.nrf_arts.unifiedpos.scannerevents.ErrorCode.NOT_CLAIMED);
        eventErrorCode.put(jpos.Scanner.JPOS_E_OFFLINE, org.nrf_arts.unifiedpos.scannerevents.ErrorCode.OFFLINE);
        eventErrorCode.put(0, org.nrf_arts.unifiedpos.scannerevents.ErrorCode.SUCCESS);
        eventErrorCode.put(jpos.Scanner.JPOS_E_TIMEOUT, org.nrf_arts.unifiedpos.scannerevents.ErrorCode.TIMEOUT);

        eventErrorLocus = new HashMap<Integer, org.nrf_arts.unifiedpos.scannerevents.ErrorLocus>();
        eventErrorLocus.put(jpos.Scanner.JPOS_EL_INPUT, org.nrf_arts.unifiedpos.scannerevents.ErrorLocus.INPUT);
        eventErrorLocus.put(jpos.Scanner.JPOS_EL_INPUT_DATA, org.nrf_arts.unifiedpos.scannerevents.ErrorLocus.INPUT_DATA);
        eventErrorLocus.put(jpos.Scanner.JPOS_EL_OUTPUT, org.nrf_arts.unifiedpos.scannerevents.ErrorLocus.OUTPUT);

        eventErrorResponse = new HashMap<Integer, org.nrf_arts.unifiedpos.scannerevents.ErrorResponse>();
        eventErrorResponse.put(jpos.Scanner.JPOS_ER_CLEAR, org.nrf_arts.unifiedpos.scannerevents.ErrorResponse.CLEAR);
        eventErrorResponse.put(jpos.Scanner.JPOS_ER_CONTINUEINPUT, org.nrf_arts.unifiedpos.scannerevents.ErrorResponse.CONTINUE_INPUT);
        eventErrorResponse.put(jpos.Scanner.JPOS_ER_RETRY, org.nrf_arts.unifiedpos.scannerevents.ErrorResponse.RETRY);
    }

    private String deviceName;
    private UposVersion deviceControlVersion;
    private org.nrf_arts.unifiedpos.scannerevents.ScannerEvent deviceEvent;
    private jpos.Scanner device = new jpos.Scanner();
    private DatatypeFactory datatypeFactory;

    public ScannerService(String logicalDeviceName) {
        deviceName = logicalDeviceName;
        deviceControlVersion = new UposVersion();
        deviceControlVersion.setMajor(1);
        deviceControlVersion.setMinor(13);
        deviceControlVersion.setBuild(1);
        try {
            datatypeFactory = DatatypeFactory.newInstance();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    //
    // Scanner Member
    //

    public void checkHealth(HealthCheckLevel level) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.checkHealth(jposConst.get(level));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void claim(Integer timeout) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.claim(timeout);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void clearInput() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.clearInput();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void clearInputProperties() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.clearInputProperties();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void close(String endpointAddress) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            if (deviceEvent != null)
            {
                device.removeDataListener(this);
                device.removeDirectIOListener(this);
                device.removeErrorListener(this);
                device.removeStatusUpdateListener(this);
                deviceEvent = null;
            }
            device.close();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public CompareFirmwareResult compareFirmwareVersion(String firmwareFileName) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            int[] param = new int[1];
            device.compareFirmwareVersion(firmwareFileName, param);
            return compareFirmwareResult.get(param[0]);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public DirectIOData directIO(Integer command, Integer data, Object obj) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            DirectIOData res = new DirectIOData();
            int[] param = new int[] { data };
            device.directIO(command, param, obj);
            res.setData(param[0]);
            res.setObj(obj);
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getAutoDisable() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getAutoDisable();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapCompareFirmwareVersion() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapCompareFirmwareVersion();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public PowerReporting getCapPowerReporting() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return powerReporting.get(device.getCapPowerReporting());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapStatisticsReporting() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapStatisticsReporting();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapUpdateFirmware() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapUpdateFirmware();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapUpdateStatistics() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapUpdateStatistics();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getCheckHealthText() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCheckHealthText();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getClaimed() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getClaimed();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getDataCount() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getDataCount();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getDataEventEnabled() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getDataEventEnabled();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getDecodeData() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getDecodeData();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getDeviceControlDescription() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        return device.getDeviceControlDescription();
    }

    public UposVersion getDeviceControlVersion() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        UposVersion res = new UposVersion();
        int version = device.getDeviceControlVersion();
        res.setMajor(version / 1000000 % 1000);
        res.setMinor(version / 1000 % 1000);
        res.setBuild(version % 1000);
        return res;
    }

    public Boolean getDeviceEnabled() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getDeviceEnabled();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getDeviceServiceDescription() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getDeviceServiceDescription();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public UposVersion getDeviceServiceVersion() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            UposVersion res = new UposVersion();
            int version = device.getDeviceServiceVersion();
            res.setMajor(version / 1000000 % 1000);
            res.setMinor(version / 1000 % 1000);
            res.setBuild(version % 1000);
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getFreezeEvents() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getFreezeEvents();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getPhysicalDeviceDescription() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getPhysicalDeviceDescription();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getPhysicalDeviceName() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getPhysicalDeviceName();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public PowerNotification getPowerNotify() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return powerNotification.get(device.getPowerNotify());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public PowerState getPowerState() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return powerState.get(device.getPowerState());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public byte[] getScanData() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getScanData();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public byte[] getScanDataLabel() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getScanDataLabel();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getScanDataType() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getScanDataType();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public ControlState getState() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        return controlState.get(device.getState());
    }

    public void open(String endpointAddress) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.open(deviceName);
            if (endpointAddress != null)
            {
                try {
                    Service service = Service.create(
                            new URL(endpointAddress + "?wsdl"),
                            new QName("http://www.nrf-arts.org/UnifiedPOS/ScannerEvents/", "ScannerEventService"));
                    deviceEvent = service.getPort(org.nrf_arts.unifiedpos.scannerevents.ScannerEvent.class);
                    device.addDataListener(this);
                    device.addDirectIOListener(this);
                    device.addErrorListener(this);
                    device.addStatusUpdateListener(this);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void release() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.release();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void resetStatistics(StatisticList statisticsBuffer) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            String param = null;
            List<Statistic> list = statisticsBuffer.getStatistic();
            switch (list.size()) {
                case 0:
                    param = "";
                    break;
                case 1:
                    String name = list.get(0).getName();
                    if (name.equals(StatisticCategories.ALL)) {
                        param = "";
                    }
                    else if (name.equals(StatisticCategories.MANUFACTURER)) {
                        param = "M_";
                    }
                    else if (name.equals(StatisticCategories.UPOS)) {
                        param = "U_";
                    }
                    else {
                        param = name;
                    }
                    break;
                default:
                    StringBuffer buffer = new StringBuffer();
                    for (Statistic statistic : statisticsBuffer.getStatistic()) {
                        buffer.append(",").append(statistic.getName());
                    }
                    param = buffer.substring(1);
                    break;
            }
            device.resetStatistics(param);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String retrieveStatistics(StatisticList statisticsBuffer) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            String[] param = new String[1];
            List<Statistic> list = statisticsBuffer.getStatistic();
            switch (list.size()) {
                case 0:
                    param[0] = "";
                    break;
                case 1:
                    String name = list.get(0).getName();
                    if (name.equals(StatisticCategories.ALL)) {
                        param[0] = "";
                    }
                    else if (name.equals(StatisticCategories.MANUFACTURER)) {
                        param[0] = "M_";
                    }
                    else if (name.equals(StatisticCategories.UPOS)) {
                        param[0] = "U_";
                    }
                    else {
                        param[0] = name;
                    }
                    break;
                default:
                    StringBuffer buffer = new StringBuffer();
                    for (Statistic statistic : statisticsBuffer.getStatistic()) {
                        buffer.append(",").append(statistic.getName());
                    }
                    param[0] = buffer.substring(1);
                    break;
            }
            device.retrieveStatistics(param);
            return param[0];
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setAutoDisable(Boolean autoDisable) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setAutoDisable(autoDisable);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setDataEventEnabled(Boolean dataEventEnabled) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setDataEventEnabled(dataEventEnabled);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setDecodeData(Boolean decodeData) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setDecodeData(decodeData);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setDeviceEnabled(Boolean deviceEnabled) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setDeviceEnabled(deviceEnabled);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setFreezeEvents(Boolean freezeEvents) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setFreezeEvents(freezeEvents);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setPowerNotify(PowerNotification powerNotify) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setPowerNotify(jposConst.get(powerNotify));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void updateFirmware(String firmwareFileName) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.updateFirmware(firmwareFileName);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void updateStatistics(StatisticList statisticsBuffer) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            String param = null;
            List<Statistic> list = statisticsBuffer.getStatistic();
            switch (list.size()) {
                case 0:
                    param = "";
                    break;
                case 1:
                    Statistic s = list.get(0);
                    String name = s.getName();
                    String value = s.getValue();
                    if (name.equals(StatisticCategories.ALL)) {
                        param = "=" + value;
                    }
                    else if (name.equals(StatisticCategories.MANUFACTURER)) {
                        param = "M_=" + value;
                    }
                    else if (name.equals(StatisticCategories.UPOS)) {
                        param = "U_=" + value;
                    }
                    else {
                        param = name + "=" + value;
                    }
                    break;
                default:
                    StringBuffer buffer = new StringBuffer();
                    for (Statistic statistic : statisticsBuffer.getStatistic()) {
                        buffer.append(",").append(statistic.getName()).append("=").append(statistic.getValue());
                    }
                    param = buffer.substring(1);
                    break;
            }
            device.updateStatistics(param);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    //
    // ScannerEvent Member
    //

    public void dataOccurred(DataEvent de) {
        //throw new UnsupportedOperationException("Not supported yet.");
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(new Date(de.getWhen()));
        deviceEvent.dataEvent(
                de.getSource().toString(),
                (int)de.getSequenceNumber(),
                datatypeFactory.newXMLGregorianCalendar(cal),
                de.getStatus());
    }

    public void directIOOccurred(DirectIOEvent dioe) {
        //throw new UnsupportedOperationException("Not supported yet.");
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(new Date(dioe.getWhen()));
        org.nrf_arts.unifiedpos.scannerevents.DirectIOData value = deviceEvent.directIOEvent(
                dioe.getSource().toString(),
                (int)dioe.getSequenceNumber(),
                datatypeFactory.newXMLGregorianCalendar(cal),
                dioe.getEventNumber(),
                dioe.getData(),
                dioe.getObject());
        dioe.setData(value.getData());
        dioe.setObject(value.getObj());
    }

    public void errorOccurred(ErrorEvent ee) {
        //throw new UnsupportedOperationException("Not supported yet.");
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(new Date(ee.getWhen()));
        org.nrf_arts.unifiedpos.scannerevents.ErrorResponse value = deviceEvent.errorEvent(
                ee.getSource().toString(),
                (int)ee.getSequenceNumber(),
                datatypeFactory.newXMLGregorianCalendar(cal),
                eventErrorCode.get(ee.getErrorCode()),
                ee.getErrorCodeExtended(),
                eventErrorLocus.get(ee.getErrorLocus()),
                eventErrorResponse.get(ee.getErrorResponse()));
        ee.setErrorResponse(jposEventConst.get(value));
    }

    public void statusUpdateOccurred(StatusUpdateEvent sue) {
        //throw new UnsupportedOperationException("Not supported yet.");
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(new Date(sue.getWhen()));
        deviceEvent.statusUpdateEvent(
                sue.getSource().toString(),
                (int)sue.getSequenceNumber(),
                datatypeFactory.newXMLGregorianCalendar(cal),
                sue.getStatus());
    }

}
