﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace UnifiedPOS.POSPower
{
    [ServiceContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPower/")]
    public interface POSPower
    {

        //
        // Common Properties
        //

        //[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetAutoDisableResponse")]
        //[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        //bool GetAutoDisable();

        //[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/SetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/SetAutoDisableResponse")]
        //[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        //void SetAutoDisable(bool AutoDisable);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetCapCompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetCapCompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        bool GetCapCompareFirmwareVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetCapPowerReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetCapPowerReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        PowerReporting GetCapPowerReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetCapStatisticsReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetCapStatisticsReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        bool GetCapStatisticsReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetCapUpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetCapUpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        bool GetCapUpdateFirmware();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetCapUpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetCapUpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        bool GetCapUpdateStatistics();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetCheckHealthText", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetCheckHealthTextResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        string GetCheckHealthText();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetClaimed", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetClaimedResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        bool GetClaimed();

        //[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetDataCount", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetDataCountResponse")]
        //[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        //int GetDataCount();

        //[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetDataEventEnabledResponse")]
        //[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        //bool GetDataEventEnabled();

        //[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/SetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/SetDataEventEnabledResponse")]
        //[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        //void SetDataEventEnabled(bool DataEventEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        bool GetDeviceEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/SetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/SetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        void SetDeviceEnabled(bool DeviceEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        bool GetFreezeEvents();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/SetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/SetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        void SetFreezeEvents(bool FreezeEvents);

        //[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetOutputID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetOutputIDResponse")]
        //[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        //int GetOutputID();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        PowerNotification GetPowerNotify();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/SetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/SetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        void SetPowerNotify(PowerNotification PowerNotify);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetPowerState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetPowerStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        PowerState GetPowerState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        ControlState GetState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetDeviceControlDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetDeviceControlDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        string GetDeviceControlDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetDeviceControlVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetDeviceControlVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        UposVersion GetDeviceControlVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetDeviceServiceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetDeviceServiceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        string GetDeviceServiceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetDeviceServiceVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetDeviceServiceVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        UposVersion GetDeviceServiceVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetPhysicalDeviceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetPhysicalDeviceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        string GetPhysicalDeviceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetPhysicalDeviceName", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetPhysicalDeviceNameResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        string GetPhysicalDeviceName();

        //
        // Specific Properties
        //
        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetBatteryCapacityRemaining", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetBatteryCapacityRemainingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        int GetBatteryCapacityRemaining();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetBatteryCriticallyLowThreshold", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetBatteryCriticallyLowThresholdResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        int GetBatteryCriticallyLowThreshold();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/SetBatteryCriticallyLowThreshold", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/SetBatteryCriticallyLowThresholdResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        void SetBatteryCriticallyLowThreshold(int BatteryCriticallyLowThreshold);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetBatteryLowThreshold", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetBatteryLowThresholdResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        int GetBatteryLowThreshold();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/SetBatteryLowThreshold", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/SetBatteryLowThresholdResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        void SetBatteryLowThreshold(int BatteryLowThreshold);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetCapBatteryCapacityRemaining", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetCapBatteryCapacityRemainingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        bool GetCapBatteryCapacityRemaining();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetCapRestartPOS", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetCapRestartPOSResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        bool GetCapRestartPOS();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetCapStandbyPOS", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetCapStandbyPOSResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        bool GetCapStandbyPOS();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetCapSuspendPOS", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetCapSuspendPOSResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        bool GetCapSuspendPOS();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetCapVariableBatteryCriticallyLowThreshold", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetCapVariableBatteryCriticallyLowThresholdResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        bool GetCapVariableBatteryCriticallyLowThreshold();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetCapVariableBatteryLowThreshold", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetCapVariableBatteryLowThresholdResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        bool GetCapVariableBatteryLowThreshold();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetPowerSource", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetPowerSourceResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        PowerSource GetPowerSource();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetCapFanAlarm", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetCapFanAlarmResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        bool GetCapFanAlarm();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetCapHeatAlarm", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetCapHeatAlarmResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        bool GetCapHeatAlarm();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetCapQuickCharge", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetCapQuickChargeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        bool GetCapQuickCharge();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetCapShutdownPOS", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetCapShutdownPOSResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        bool GetCapShutdownPOS();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetCapUPSChargeState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetCapUPSChargeStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        int GetCapUPSChargeState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetEnforcedShutdownDelayTime", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetEnforcedShutdownDelayTimeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        int GetEnforcedShutdownDelayTime();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/SetEnforcedShutdownDelayTime", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/SetEnforcedShutdownDelayTimeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        void SetEnforcedShutdownDelayTime(int EnforcedShutdownDelayTime);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetPowerFailDelayTime", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetPowerFailDelayTimeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        int GetPowerFailDelayTime();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetQuickChargeMode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetQuickChargeModeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        bool GetQuickChargeMode();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetQuickChargeTime", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetQuickChargeTimeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        int GetQuickChargeTime();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetUPSChargeState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/GetUPSChargeStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        int GetUPSChargeState();

        //
        // Common Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/Open", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/OpenResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        void Open(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/Close", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/CloseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        void Close(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/Claim", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/ClaimResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        void Claim(int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/Release", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/ReleaseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        void Release();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/CheckHealth", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/CheckHealthResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        void CheckHealth(HealthCheckLevel Level);

        //[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/ClearInput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/ClearInputResponse")]
        //[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        //void ClearInput();

        //[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/ClearInputProperties", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/ClearInputPropertiesResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        //void ClearInputProperties();

        //[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/ClearOutput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/ClearOutputResponse")]
        //[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        //void ClearOutput();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/DirectIO", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/DirectIOResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        DirectIOData DirectIO(int Command, int Data, object Obj);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/CompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/CompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        CompareFirmwareResult CompareFirmwareVersion(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/ResetStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/ResetStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        void ResetStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/RetrieveStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/RetrieveStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        string RetrieveStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        void UpdateFirmware(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        void UpdateStatistics(StatisticList StatisticsBuffer);

        //
        // Specific Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/RestartPOS", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/RestartPOSResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        void RestartPOS();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/ShutdownPOS", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/ShutdownPOSResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        void ShutdownPOS();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/StandbyPOS", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/StandbyPOSResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        void StandbyPOS(SystemStateChangeReason Reason);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/SuspendPOS", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/POSPower/SuspendPOSResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/POSPower/UposException", Name = "UposException")]
        void SuspendPOS(SystemStateChangeReason Reason);

    }

    //
    // Common Data Types
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPower/")]
    public class DirectIOData
    {
        [DataMember]
        public int Data { get; set; }
        [DataMember]
        public object Obj { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPower/")]
    public class UposException
    {
        [DataMember]
        public ErrorCode ErrorCode { get; set; }
        [DataMember]
        public int ErrorCodeExtended { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPower/")]
    public class UposVersion
    {
        [DataMember]
        public int Major { get; set; }
        [DataMember]
        public int Minor { get; set; }
        [DataMember]
        public int Build { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPower/")]
    public class Statistic
    {
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public string Value { get; set; }
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPower/", ItemName = "Statistic")]
    public class StatisticList : List<Statistic>
    {
    }

    //
    // Common Enumerations
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPower/")]
    public enum CompareFirmwareResult
    {
        [EnumMember]
        Different,
        [EnumMember]
        Newer,
        [EnumMember]
        Older,
        [EnumMember]
        Same,
        [EnumMember]
        Unknown,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPower/")]
    public enum ControlState
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Closed,
        [EnumMember]
        Error,
        [EnumMember]
        Idle,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPower/")]
    public enum ErrorCode
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Claimed,
        [EnumMember]
        Closed,
        [EnumMember]
        Deprecated,
        [EnumMember]
        Disabled,
        [EnumMember]
        Exists,
        [EnumMember]
        Extended,
        [EnumMember]
        Failure,
        [EnumMember]
        Illegal,
        [EnumMember]
        NoExist,
        [EnumMember]
        NoHardware,
        [EnumMember]
        NoService,
        [EnumMember]
        NotClaimed,
        [EnumMember]
        Offline,
        [EnumMember]
        Success,
        [EnumMember]
        Timeout,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPower/")]
    public enum HealthCheckLevel
    {
        [EnumMember]
        External,
        [EnumMember]
        Interactive,
        [EnumMember]
        Internal,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPower/")]
    public enum PowerNotification
    {
        [EnumMember]
        Disabled,
        [EnumMember]
        Enabled,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPower/")]
    public enum PowerReporting
    {
        [EnumMember]
        Advanced,
        [EnumMember]
        None,
        [EnumMember]
        Standard,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPower/")]
    public enum PowerState
    {
        [EnumMember]
        Off,
        [EnumMember]
        Offline,
        [EnumMember]
        OffOffline,
        [EnumMember]
        Online,
        [EnumMember]
        Unknown,
    }

    /*
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPower/")]
    public enum StatisticCategories
    {
        [EnumMember]
        All,
        [EnumMember]
        Manufacturer,
        [EnumMember]
        Upos,
    }
    */
    public class StatisticCategories
    {
        public const string All = "";
        public const string Manufacturer = "M_";
        public const string Upos = "U_";
    }

    //
    // Specific Data Types
    //

    //
    // Specific Enumerations
    //
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPower/")]
    public enum PowerSource
    {
        [EnumMember]
        NotAvailable,
        [EnumMember]
        AC,
        [EnumMember]
        Battery,
        [EnumMember]
        Backup,
    }

    /*
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPower/")]
    public enum UPSChargeStates
    {
        [EnumMember]
        Critical,
        [EnumMember]
        Full,
        [EnumMember]
        Low,
        [EnumMember]
        Warning,
    }
    */

    public class UPSChargeStates
    {
        public const int Full = 1;
        public const int Warning = 2;
        public const int Low = 4;
        public const int Critical = 8;
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/POSPower/")]
    public enum SystemStateChangeReason
    {
        [EnumMember]
        Request,
        [EnumMember]
        Allow,
        [EnumMember]
        Deny,
    }

    //
    // Constants
    //

    public class ExtendedError
    {
        public const int FirmwareBadFile = 281;
        public const int Statistics = 280;
        public const int StatisticsDependency = 282;
    }

    public class StatisticProperties
    {
        public const string CommunicationErrorCount = "CommunicationErrorCount";
        public const string DeviceCategory = "DeviceCategory";
        public const string FirmwareRevision = "FirmwareRevision";
        public const string HoursPoweredCount = "HoursPoweredCount";
        public const string InstallationDate = "InstallationDate";
        public const string Interface = "Interface";
        public const string ManufactureDate = "ManufactureDate";
        public const string ManufacturerName = "ManufacturerName";
        public const string MechanicalRevision = "MechanicalRevision";
        public const string ModelName = "ModelName";
        public const string SerialNumber = "SerialNumber";
        public const string UnifiedPOSVersion = "UnifiedPOSVersion";
    }

    public class Wait
    {
        public const int Forever = -1;
    }
}
