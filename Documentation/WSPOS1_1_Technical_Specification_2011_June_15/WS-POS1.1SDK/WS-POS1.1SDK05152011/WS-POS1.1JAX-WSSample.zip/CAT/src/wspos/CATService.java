/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package wspos;

import java.math.BigDecimal;
import java.net.URL;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import jpos.events.DirectIOEvent;
import jpos.events.ErrorEvent;
import jpos.events.OutputCompleteEvent;
import jpos.events.StatusUpdateEvent;
import org.nrf_arts.unifiedpos.cat.*;
import javax.jws.WebService;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.namespace.QName;
import javax.xml.ws.Service;

/**
 *
 * @author hideon
 */
@WebService(serviceName = "CATService", endpointInterface = "org.nrf_arts.unifiedpos.cat.CAT", targetNamespace = "http://www.nrf-arts.org/UnifiedPOS/CAT/")
public class CATService implements CAT, jpos.events.DirectIOListener, jpos.events.ErrorListener, jpos.events.OutputCompleteListener, jpos.events.StatusUpdateListener {

    //
    // CAT Enumration Converter
    //

    private static HashMap<Enum, Integer> jposConst;
    private static HashMap<Integer, PowerReporting> powerReporting;
    private static HashMap<Integer, PowerNotification> powerNotification;
    private static HashMap<Integer, PowerState> powerState;
    private static HashMap<Integer, ControlState> controlState;
    private static HashMap<Integer, HealthCheckLevel> healthCheckLevel;
    private static HashMap<Integer, CompareFirmwareResult> compareFirmwareResult;
    private static HashMap<Integer, ErrorCode> errorCode;
    private static HashMap<Integer, CATLogs> catLogs;
    private static HashMap<Integer, DealingLogStatus> dealingLogStatus;
    private static HashMap<Integer, PaymentCondition> paymentCondition;
    private static HashMap<Integer, PaymentMedia> paymentMedia;
    private static HashMap<Integer, CreditTransactionType> creditTransactionType;

    private static HashMap<Enum, Integer> jposEventConst;
    private static HashMap<Integer, org.nrf_arts.unifiedpos.catevents.ErrorCode> eventErrorCode;
    private static HashMap<Integer, org.nrf_arts.unifiedpos.catevents.ErrorLocus> eventErrorLocus;
    private static HashMap<Integer, org.nrf_arts.unifiedpos.catevents.ErrorResponse> eventErrorResponse;

    static {
        jposConst = new HashMap<Enum, Integer>();
        jposConst.put(PowerReporting.ADVANCED, jpos.CAT.JPOS_PR_ADVANCED);
        jposConst.put(PowerReporting.NONE, jpos.CAT.JPOS_PR_NONE);
        jposConst.put(PowerReporting.STANDARD, jpos.CAT.JPOS_PR_STANDARD);
        jposConst.put(PowerNotification.DISABLED, jpos.CAT.JPOS_PN_DISABLED);
        jposConst.put(PowerNotification.ENABLED, jpos.CAT.JPOS_PN_ENABLED);
        jposConst.put(PowerState.OFF, jpos.CAT.JPOS_PS_OFF);
        jposConst.put(PowerState.OFFLINE, jpos.CAT.JPOS_PS_OFFLINE);
        jposConst.put(PowerState.OFF_OFFLINE, jpos.CAT.JPOS_PS_OFF_OFFLINE);
        jposConst.put(PowerState.ONLINE, jpos.CAT.JPOS_PS_ONLINE);
        jposConst.put(PowerState.UNKNOWN, jpos.CAT.JPOS_PS_UNKNOWN);
        jposConst.put(ControlState.BUSY, jpos.CAT.JPOS_S_BUSY);
        jposConst.put(ControlState.CLOSED, jpos.CAT.JPOS_S_CLOSED);
        jposConst.put(ControlState.ERROR, jpos.CAT.JPOS_S_ERROR);
        jposConst.put(ControlState.IDLE, jpos.CAT.JPOS_S_IDLE);
        jposConst.put(HealthCheckLevel.EXTERNAL, jpos.CAT.JPOS_CH_EXTERNAL);
        jposConst.put(HealthCheckLevel.INTERACTIVE, jpos.CAT.JPOS_CH_INTERACTIVE);
        jposConst.put(HealthCheckLevel.INTERNAL, jpos.CAT.JPOS_CH_INTERNAL);
        jposConst.put(CompareFirmwareResult.DIFFERENT, jpos.CAT.JPOS_CFV_FIRMWARE_DIFFERENT);
        jposConst.put(CompareFirmwareResult.NEWER, jpos.CAT.JPOS_CFV_FIRMWARE_NEWER);
        jposConst.put(CompareFirmwareResult.OLDER, jpos.CAT.JPOS_CFV_FIRMWARE_OLDER);
        jposConst.put(CompareFirmwareResult.SAME, jpos.CAT.JPOS_CFV_FIRMWARE_SAME);
        jposConst.put(CompareFirmwareResult.UNKNOWN, jpos.CAT.JPOS_CFV_FIRMWARE_UNKNOWN);
        jposConst.put(ErrorCode.BUSY, jpos.CAT.JPOS_E_BUSY);
        jposConst.put(ErrorCode.CLAIMED, jpos.CAT.JPOS_E_CLAIMED);
        jposConst.put(ErrorCode.CLOSED, jpos.CAT.JPOS_E_CLOSED);
        jposConst.put(ErrorCode.DEPRECATED, jpos.CAT.JPOS_E_DEPRECATED);
        jposConst.put(ErrorCode.DISABLED, jpos.CAT.JPOS_E_DISABLED);
        jposConst.put(ErrorCode.EXISTS, jpos.CAT.JPOS_E_EXISTS);
        jposConst.put(ErrorCode.EXTENDED, jpos.CAT.JPOS_E_EXTENDED);
        jposConst.put(ErrorCode.FAILURE, jpos.CAT.JPOS_E_FAILURE);
        jposConst.put(ErrorCode.ILLEGAL, jpos.CAT.JPOS_E_ILLEGAL);
        jposConst.put(ErrorCode.NO_EXIST, jpos.CAT.JPOS_E_NOEXIST);
        jposConst.put(ErrorCode.NO_HARDWARE, jpos.CAT.JPOS_E_NOHARDWARE);
        jposConst.put(ErrorCode.NO_SERVICE, jpos.CAT.JPOS_E_NOSERVICE);
        jposConst.put(ErrorCode.NOT_CLAIMED, jpos.CAT.JPOS_E_NOTCLAIMED);
        jposConst.put(ErrorCode.OFFLINE, jpos.CAT.JPOS_E_OFFLINE);
        jposConst.put(ErrorCode.SUCCESS, 0);
        jposConst.put(ErrorCode.TIMEOUT, jpos.CAT.JPOS_E_TIMEOUT);
        jposConst.put(CATLogs.NONE, jpos.CATConst.CAT_DL_NONE);
        jposConst.put(CATLogs.REPORTING, jpos.CATConst.CAT_DL_REPORTING);
        jposConst.put(CATLogs.REPORTING_AND_SETTLEMENT, jpos.CATConst.CAT_DL_REPORTING_SETTLEMENT);
        jposConst.put(CATLogs.SETTLEMENT, jpos.CATConst.CAT_DL_SETTLEMENT);
        jposConst.put(DealingLogStatus.FULL, jpos.CATConst.CAT_LOGSTATUS_FULL);
        jposConst.put(DealingLogStatus.NEAR_FULL, jpos.CATConst.CAT_LOGSTATUS_NEARFULL);
        jposConst.put(DealingLogStatus.OK, jpos.CATConst.CAT_LOGSTATUS_OK);
        jposConst.put(PaymentCondition.BONUS_1, jpos.CATConst.CAT_PAYMENT_BONUS_1);
        jposConst.put(PaymentCondition.BONUS_2, jpos.CATConst.CAT_PAYMENT_BONUS_2);
        jposConst.put(PaymentCondition.BONUS_3, jpos.CATConst.CAT_PAYMENT_BONUS_3);
        jposConst.put(PaymentCondition.BONUS_4, jpos.CATConst.CAT_PAYMENT_BONUS_4);
        jposConst.put(PaymentCondition.BONUS_5, jpos.CATConst.CAT_PAYMENT_BONUS_5);
        jposConst.put(PaymentCondition.BONUS_COMBINATION_1, jpos.CATConst.CAT_PAYMENT_BONUS_COMBINATION_1);
        jposConst.put(PaymentCondition.BONUS_COMBINATION_2, jpos.CATConst.CAT_PAYMENT_BONUS_COMBINATION_2);
        jposConst.put(PaymentCondition.BONUS_COMBINATION_3, jpos.CATConst.CAT_PAYMENT_BONUS_COMBINATION_3);
        jposConst.put(PaymentCondition.BONUS_COMBINATION_4, jpos.CATConst.CAT_PAYMENT_BONUS_COMBINATION_4);
        jposConst.put(PaymentCondition.DEBIT, jpos.CATConst.CAT_PAYMENT_DEBIT);
        jposConst.put(PaymentCondition.ELECTRONIC_MONEY, jpos.CATConst.CAT_PAYMENT_ELECTRONIC_MONEY);
        jposConst.put(PaymentCondition.INSTALLMENT_1, jpos.CATConst.CAT_PAYMENT_INSTALLMENT_1);
        jposConst.put(PaymentCondition.INSTALLMENT_2, jpos.CATConst.CAT_PAYMENT_INSTALLMENT_2);
        jposConst.put(PaymentCondition.INSTALLMENT_3, jpos.CATConst.CAT_PAYMENT_INSTALLMENT_3);
        jposConst.put(PaymentCondition.LUMP, jpos.CATConst.CAT_PAYMENT_LUMP);
        jposConst.put(PaymentCondition.REVOLVING, jpos.CATConst.CAT_PAYMENT_REVOLVING);
        jposConst.put(PaymentMedia.CREDIT, jpos.CATConst.CAT_MEDIA_CREDIT);
        jposConst.put(PaymentMedia.DEBIT, jpos.CATConst.CAT_MEDIA_DEBIT);
        jposConst.put(PaymentMedia.ELECTRONIC_MONEY, jpos.CATConst.CAT_MEDIA_ELECTRONIC_MONEY);
        jposConst.put(PaymentMedia.UNSPECIFIED, jpos.CATConst.CAT_MEDIA_UNSPECIFIED);
        jposConst.put(CreditTransactionType.CASH_DEPOSIT, jpos.CATConst.CAT_TRANSACTION_CASHDEPOSIT);
        jposConst.put(CreditTransactionType.CHECK_CARD, jpos.CATConst.CAT_TRANSACTION_CHECKCARD);
        jposConst.put(CreditTransactionType.COMPLETION, jpos.CATConst.CAT_TRANSACTION_COMPLETION);
        jposConst.put(CreditTransactionType.PRE_SALES, jpos.CATConst.CAT_TRANSACTION_PRESALES);
        jposConst.put(CreditTransactionType.REFUND, jpos.CATConst.CAT_TRANSACTION_REFUND);
        jposConst.put(CreditTransactionType.SALES, jpos.CATConst.CAT_TRANSACTION_SALES);
        jposConst.put(CreditTransactionType.VOID, jpos.CATConst.CAT_TRANSACTION_VOID);
        jposConst.put(CreditTransactionType.VOID_PRE_SALES, jpos.CATConst.CAT_TRANSACTION_VOIDPRESALES);

        powerReporting = new HashMap<Integer, PowerReporting>();
        powerReporting.put(jpos.CAT.JPOS_PR_ADVANCED, PowerReporting.ADVANCED);
        powerReporting.put(jpos.CAT.JPOS_PR_NONE, PowerReporting.NONE);
        powerReporting.put(jpos.CAT.JPOS_PR_STANDARD, PowerReporting.STANDARD);

        powerNotification = new HashMap<Integer, PowerNotification>();
        powerNotification.put(jpos.CAT.JPOS_PN_DISABLED, PowerNotification.DISABLED);
        powerNotification.put(jpos.CAT.JPOS_PN_ENABLED, PowerNotification.ENABLED);

        powerState = new HashMap<Integer, PowerState>();
        powerState.put(jpos.CAT.JPOS_PS_OFF, PowerState.OFF);
        powerState.put(jpos.CAT.JPOS_PS_OFFLINE, PowerState.OFFLINE);
        powerState.put(jpos.CAT.JPOS_PS_OFF_OFFLINE, PowerState.OFF_OFFLINE);
        powerState.put(jpos.CAT.JPOS_PS_ONLINE, PowerState.ONLINE);
        powerState.put(jpos.CAT.JPOS_PS_UNKNOWN, PowerState.UNKNOWN);

        controlState = new HashMap<Integer, ControlState>();
        controlState.put(jpos.CAT.JPOS_S_BUSY, ControlState.BUSY);
        controlState.put(jpos.CAT.JPOS_S_CLOSED, ControlState.CLOSED);
        controlState.put(jpos.CAT.JPOS_S_ERROR, ControlState.ERROR);
        controlState.put(jpos.CAT.JPOS_S_IDLE, ControlState.IDLE);

        healthCheckLevel = new HashMap<Integer, HealthCheckLevel>();
        healthCheckLevel.put(jpos.CAT.JPOS_CH_EXTERNAL, HealthCheckLevel.EXTERNAL);
        healthCheckLevel.put(jpos.CAT.JPOS_CH_INTERACTIVE, HealthCheckLevel.INTERACTIVE);
        healthCheckLevel.put(jpos.CAT.JPOS_CH_INTERNAL, HealthCheckLevel.INTERNAL);

        compareFirmwareResult = new HashMap<Integer, CompareFirmwareResult>();
        compareFirmwareResult.put(jpos.CAT.JPOS_CFV_FIRMWARE_DIFFERENT, CompareFirmwareResult.DIFFERENT);
        compareFirmwareResult.put(jpos.CAT.JPOS_CFV_FIRMWARE_NEWER, CompareFirmwareResult.NEWER);
        compareFirmwareResult.put(jpos.CAT.JPOS_CFV_FIRMWARE_OLDER, CompareFirmwareResult.OLDER);
        compareFirmwareResult.put(jpos.CAT.JPOS_CFV_FIRMWARE_SAME, CompareFirmwareResult.SAME);
        compareFirmwareResult.put(jpos.CAT.JPOS_CFV_FIRMWARE_UNKNOWN, CompareFirmwareResult.UNKNOWN);

        errorCode = new HashMap<Integer, ErrorCode>();
        errorCode.put(jpos.CAT.JPOS_E_BUSY, ErrorCode.BUSY);
        errorCode.put(jpos.CAT.JPOS_E_CLAIMED, ErrorCode.CLAIMED);
        errorCode.put(jpos.CAT.JPOS_E_CLOSED, ErrorCode.CLOSED);
        errorCode.put(jpos.CAT.JPOS_E_DEPRECATED, ErrorCode.DEPRECATED);
        errorCode.put(jpos.CAT.JPOS_E_DISABLED, ErrorCode.DISABLED);
        errorCode.put(jpos.CAT.JPOS_E_EXISTS, ErrorCode.EXISTS);
        errorCode.put(jpos.CAT.JPOS_E_EXTENDED, ErrorCode.EXTENDED);
        errorCode.put(jpos.CAT.JPOS_E_FAILURE, ErrorCode.FAILURE);
        errorCode.put(jpos.CAT.JPOS_E_ILLEGAL, ErrorCode.ILLEGAL);
        errorCode.put(jpos.CAT.JPOS_E_NOEXIST, ErrorCode.NO_EXIST);
        errorCode.put(jpos.CAT.JPOS_E_NOHARDWARE, ErrorCode.NO_HARDWARE);
        errorCode.put(jpos.CAT.JPOS_E_NOSERVICE, ErrorCode.NO_SERVICE);
        errorCode.put(jpos.CAT.JPOS_E_NOTCLAIMED, ErrorCode.NOT_CLAIMED);
        errorCode.put(jpos.CAT.JPOS_E_OFFLINE, ErrorCode.OFFLINE);
        errorCode.put(0, ErrorCode.SUCCESS);
        errorCode.put(jpos.CAT.JPOS_E_TIMEOUT, ErrorCode.TIMEOUT);

        catLogs = new HashMap<Integer, CATLogs>();
        catLogs.put(jpos.CATConst.CAT_DL_NONE, CATLogs.NONE);
        catLogs.put(jpos.CATConst.CAT_DL_REPORTING, CATLogs.REPORTING);
        catLogs.put(jpos.CATConst.CAT_DL_REPORTING_SETTLEMENT, CATLogs.REPORTING_AND_SETTLEMENT);
        catLogs.put(jpos.CATConst.CAT_DL_SETTLEMENT, CATLogs.SETTLEMENT);

        dealingLogStatus = new HashMap<Integer, DealingLogStatus>();
        dealingLogStatus.put(jpos.CATConst.CAT_LOGSTATUS_FULL, DealingLogStatus.FULL);
        dealingLogStatus.put(jpos.CATConst.CAT_LOGSTATUS_NEARFULL, DealingLogStatus.NEAR_FULL);
        dealingLogStatus.put(jpos.CATConst.CAT_LOGSTATUS_OK, DealingLogStatus.OK);

        paymentCondition = new HashMap<Integer, PaymentCondition>();
        paymentCondition.put(jpos.CATConst.CAT_PAYMENT_BONUS_1, PaymentCondition.BONUS_1);
        paymentCondition.put(jpos.CATConst.CAT_PAYMENT_BONUS_2, PaymentCondition.BONUS_2);
        paymentCondition.put(jpos.CATConst.CAT_PAYMENT_BONUS_3, PaymentCondition.BONUS_3);
        paymentCondition.put(jpos.CATConst.CAT_PAYMENT_BONUS_4, PaymentCondition.BONUS_4);
        paymentCondition.put(jpos.CATConst.CAT_PAYMENT_BONUS_5, PaymentCondition.BONUS_5);
        paymentCondition.put(jpos.CATConst.CAT_PAYMENT_BONUS_COMBINATION_1, PaymentCondition.BONUS_COMBINATION_1);
        paymentCondition.put(jpos.CATConst.CAT_PAYMENT_BONUS_COMBINATION_2, PaymentCondition.BONUS_COMBINATION_2);
        paymentCondition.put(jpos.CATConst.CAT_PAYMENT_BONUS_COMBINATION_3, PaymentCondition.BONUS_COMBINATION_3);
        paymentCondition.put(jpos.CATConst.CAT_PAYMENT_BONUS_COMBINATION_4, PaymentCondition.BONUS_COMBINATION_4);
        paymentCondition.put(jpos.CATConst.CAT_PAYMENT_DEBIT, PaymentCondition.DEBIT);
        paymentCondition.put(jpos.CATConst.CAT_PAYMENT_ELECTRONIC_MONEY, PaymentCondition.ELECTRONIC_MONEY);
        paymentCondition.put(jpos.CATConst.CAT_PAYMENT_INSTALLMENT_1, PaymentCondition.INSTALLMENT_1);
        paymentCondition.put(jpos.CATConst.CAT_PAYMENT_INSTALLMENT_2, PaymentCondition.INSTALLMENT_2);
        paymentCondition.put(jpos.CATConst.CAT_PAYMENT_INSTALLMENT_3, PaymentCondition.INSTALLMENT_3);
        paymentCondition.put(jpos.CATConst.CAT_PAYMENT_LUMP, PaymentCondition.LUMP);
        paymentCondition.put(jpos.CATConst.CAT_PAYMENT_REVOLVING, PaymentCondition.REVOLVING);

        paymentMedia = new HashMap<Integer, PaymentMedia>();
        paymentMedia.put(jpos.CATConst.CAT_MEDIA_CREDIT, PaymentMedia.CREDIT);
        paymentMedia.put(jpos.CATConst.CAT_MEDIA_DEBIT, PaymentMedia.DEBIT);
        paymentMedia.put(jpos.CATConst.CAT_MEDIA_ELECTRONIC_MONEY, PaymentMedia.ELECTRONIC_MONEY);
        paymentMedia.put(jpos.CATConst.CAT_MEDIA_UNSPECIFIED, PaymentMedia.UNSPECIFIED);

        creditTransactionType = new HashMap<Integer, CreditTransactionType>();
        creditTransactionType.put(jpos.CATConst.CAT_TRANSACTION_CASHDEPOSIT, CreditTransactionType.CASH_DEPOSIT);
        creditTransactionType.put(jpos.CATConst.CAT_TRANSACTION_CHECKCARD, CreditTransactionType.CHECK_CARD);
        creditTransactionType.put(jpos.CATConst.CAT_TRANSACTION_COMPLETION, CreditTransactionType.COMPLETION);
        creditTransactionType.put(jpos.CATConst.CAT_TRANSACTION_PRESALES, CreditTransactionType.PRE_SALES);
        creditTransactionType.put(jpos.CATConst.CAT_TRANSACTION_REFUND, CreditTransactionType.REFUND);
        creditTransactionType.put(jpos.CATConst.CAT_TRANSACTION_SALES, CreditTransactionType.SALES);
        creditTransactionType.put(jpos.CATConst.CAT_TRANSACTION_VOID, CreditTransactionType.VOID);
        creditTransactionType.put(jpos.CATConst.CAT_TRANSACTION_VOIDPRESALES, CreditTransactionType.VOID_PRE_SALES);

        jposEventConst = new HashMap<Enum, Integer>();
        jposEventConst.put(org.nrf_arts.unifiedpos.catevents.ErrorCode.BUSY, jpos.CAT.JPOS_E_BUSY);
        jposEventConst.put(org.nrf_arts.unifiedpos.catevents.ErrorCode.CLAIMED, jpos.CAT.JPOS_E_CLAIMED);
        jposEventConst.put(org.nrf_arts.unifiedpos.catevents.ErrorCode.CLOSED, jpos.CAT.JPOS_E_CLOSED);
        jposEventConst.put(org.nrf_arts.unifiedpos.catevents.ErrorCode.DEPRECATED, jpos.CAT.JPOS_E_DEPRECATED);
        jposEventConst.put(org.nrf_arts.unifiedpos.catevents.ErrorCode.DISABLED, jpos.CAT.JPOS_E_DISABLED);
        jposEventConst.put(org.nrf_arts.unifiedpos.catevents.ErrorCode.EXISTS, jpos.CAT.JPOS_E_EXISTS);
        jposEventConst.put(org.nrf_arts.unifiedpos.catevents.ErrorCode.EXTENDED, jpos.CAT.JPOS_E_EXTENDED);
        jposEventConst.put(org.nrf_arts.unifiedpos.catevents.ErrorCode.FAILURE, jpos.CAT.JPOS_E_FAILURE);
        jposEventConst.put(org.nrf_arts.unifiedpos.catevents.ErrorCode.ILLEGAL, jpos.CAT.JPOS_E_ILLEGAL);
        jposEventConst.put(org.nrf_arts.unifiedpos.catevents.ErrorCode.NO_EXIST, jpos.CAT.JPOS_E_NOEXIST);
        jposEventConst.put(org.nrf_arts.unifiedpos.catevents.ErrorCode.NO_HARDWARE, jpos.CAT.JPOS_E_NOHARDWARE);
        jposEventConst.put(org.nrf_arts.unifiedpos.catevents.ErrorCode.NO_SERVICE, jpos.CAT.JPOS_E_NOSERVICE);
        jposEventConst.put(org.nrf_arts.unifiedpos.catevents.ErrorCode.NOT_CLAIMED, jpos.CAT.JPOS_E_NOTCLAIMED);
        jposEventConst.put(org.nrf_arts.unifiedpos.catevents.ErrorCode.OFFLINE, jpos.CAT.JPOS_E_OFFLINE);
        jposEventConst.put(org.nrf_arts.unifiedpos.catevents.ErrorCode.SUCCESS, 0);
        jposEventConst.put(org.nrf_arts.unifiedpos.catevents.ErrorCode.TIMEOUT, jpos.CAT.JPOS_E_TIMEOUT);
        jposEventConst.put(org.nrf_arts.unifiedpos.catevents.ErrorLocus.INPUT, jpos.CAT.JPOS_EL_INPUT);
        jposEventConst.put(org.nrf_arts.unifiedpos.catevents.ErrorLocus.INPUT_DATA, jpos.CAT.JPOS_EL_INPUT_DATA);
        jposEventConst.put(org.nrf_arts.unifiedpos.catevents.ErrorLocus.OUTPUT, jpos.CAT.JPOS_EL_OUTPUT);
        jposEventConst.put(org.nrf_arts.unifiedpos.catevents.ErrorResponse.CLEAR, jpos.CAT.JPOS_ER_CLEAR);
        jposEventConst.put(org.nrf_arts.unifiedpos.catevents.ErrorResponse.CONTINUE_INPUT, jpos.CAT.JPOS_ER_CONTINUEINPUT);
        jposEventConst.put(org.nrf_arts.unifiedpos.catevents.ErrorResponse.RETRY, jpos.CAT.JPOS_ER_RETRY);

        eventErrorCode = new HashMap<Integer, org.nrf_arts.unifiedpos.catevents.ErrorCode>();
        eventErrorCode.put(jpos.CAT.JPOS_E_BUSY, org.nrf_arts.unifiedpos.catevents.ErrorCode.BUSY);
        eventErrorCode.put(jpos.CAT.JPOS_E_CLAIMED, org.nrf_arts.unifiedpos.catevents.ErrorCode.CLAIMED);
        eventErrorCode.put(jpos.CAT.JPOS_E_CLOSED, org.nrf_arts.unifiedpos.catevents.ErrorCode.CLOSED);
        eventErrorCode.put(jpos.CAT.JPOS_E_DEPRECATED, org.nrf_arts.unifiedpos.catevents.ErrorCode.DEPRECATED);
        eventErrorCode.put(jpos.CAT.JPOS_E_DISABLED, org.nrf_arts.unifiedpos.catevents.ErrorCode.DISABLED);
        eventErrorCode.put(jpos.CAT.JPOS_E_EXISTS, org.nrf_arts.unifiedpos.catevents.ErrorCode.EXISTS);
        eventErrorCode.put(jpos.CAT.JPOS_E_EXTENDED, org.nrf_arts.unifiedpos.catevents.ErrorCode.EXTENDED);
        eventErrorCode.put(jpos.CAT.JPOS_E_FAILURE, org.nrf_arts.unifiedpos.catevents.ErrorCode.FAILURE);
        eventErrorCode.put(jpos.CAT.JPOS_E_ILLEGAL, org.nrf_arts.unifiedpos.catevents.ErrorCode.ILLEGAL);
        eventErrorCode.put(jpos.CAT.JPOS_E_NOEXIST, org.nrf_arts.unifiedpos.catevents.ErrorCode.NO_EXIST);
        eventErrorCode.put(jpos.CAT.JPOS_E_NOHARDWARE, org.nrf_arts.unifiedpos.catevents.ErrorCode.NO_HARDWARE);
        eventErrorCode.put(jpos.CAT.JPOS_E_NOSERVICE, org.nrf_arts.unifiedpos.catevents.ErrorCode.NO_SERVICE);
        eventErrorCode.put(jpos.CAT.JPOS_E_NOTCLAIMED, org.nrf_arts.unifiedpos.catevents.ErrorCode.NOT_CLAIMED);
        eventErrorCode.put(jpos.CAT.JPOS_E_OFFLINE, org.nrf_arts.unifiedpos.catevents.ErrorCode.OFFLINE);
        eventErrorCode.put(0, org.nrf_arts.unifiedpos.catevents.ErrorCode.SUCCESS);
        eventErrorCode.put(jpos.CAT.JPOS_E_TIMEOUT, org.nrf_arts.unifiedpos.catevents.ErrorCode.TIMEOUT);

        eventErrorLocus = new HashMap<Integer, org.nrf_arts.unifiedpos.catevents.ErrorLocus>();
        eventErrorLocus.put(jpos.CAT.JPOS_EL_INPUT, org.nrf_arts.unifiedpos.catevents.ErrorLocus.INPUT);
        eventErrorLocus.put(jpos.CAT.JPOS_EL_INPUT_DATA, org.nrf_arts.unifiedpos.catevents.ErrorLocus.INPUT_DATA);
        eventErrorLocus.put(jpos.CAT.JPOS_EL_OUTPUT, org.nrf_arts.unifiedpos.catevents.ErrorLocus.OUTPUT);

        eventErrorResponse = new HashMap<Integer, org.nrf_arts.unifiedpos.catevents.ErrorResponse>();
        eventErrorResponse.put(jpos.CAT.JPOS_ER_CLEAR, org.nrf_arts.unifiedpos.catevents.ErrorResponse.CLEAR);
        eventErrorResponse.put(jpos.CAT.JPOS_ER_CONTINUEINPUT, org.nrf_arts.unifiedpos.catevents.ErrorResponse.CONTINUE_INPUT);
        eventErrorResponse.put(jpos.CAT.JPOS_ER_RETRY, org.nrf_arts.unifiedpos.catevents.ErrorResponse.RETRY);
    }

    private String deviceName;
    private UposVersion deviceControlVersion;
    private org.nrf_arts.unifiedpos.catevents.CATEvent deviceEvent;
    private jpos.CAT device = new jpos.CAT();
    private DatatypeFactory datatypeFactory;

    public CATService(String logicalDeviceName) {
        deviceName = logicalDeviceName;
        deviceControlVersion = new UposVersion();
        deviceControlVersion.setMajor(1);
        deviceControlVersion.setMinor(13);
        deviceControlVersion.setBuild(1);
        try {
            datatypeFactory = DatatypeFactory.newInstance();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    //
    // CAT Member
    //

    public void accessDailyLog(Integer sequenceNumber, CATLogs type, Integer timeout) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.accessDailyLog(sequenceNumber, jposConst.get(type), timeout);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void authorizeCompletion(Integer sequenceNumber, BigDecimal amount, BigDecimal taxOthers, Integer timeout) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.authorizeCompletion(sequenceNumber, amount.scaleByPowerOfTen(4).longValue(), taxOthers.scaleByPowerOfTen(4).longValue(), timeout);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void authorizePreSales(Integer sequenceNumber, BigDecimal amount, BigDecimal taxOthers, Integer timeout) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.authorizePreSales(sequenceNumber, amount.scaleByPowerOfTen(4).longValue(), taxOthers.scaleByPowerOfTen(4).longValue(), timeout);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void authorizeRefund(Integer sequenceNumber, BigDecimal amount, BigDecimal taxOthers, Integer timeout) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.authorizeRefund(sequenceNumber, amount.scaleByPowerOfTen(4).longValue(), taxOthers.scaleByPowerOfTen(4).longValue(), timeout);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void authorizeSales(Integer sequenceNumber, BigDecimal amount, BigDecimal taxOthers, Integer timeout) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.authorizeRefund(sequenceNumber, amount.scaleByPowerOfTen(4).longValue(), taxOthers.scaleByPowerOfTen(4).longValue(), timeout);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void authorizeVoid(Integer sequenceNumber, BigDecimal amount, BigDecimal taxOthers, Integer timeout) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.authorizeVoid(sequenceNumber, amount.scaleByPowerOfTen(4).longValue(), taxOthers.scaleByPowerOfTen(4).longValue(), timeout);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void authorizeVoidPreSales(Integer sequenceNumber, BigDecimal amount, BigDecimal taxOthers, Integer timeout) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.authorizeVoidPreSales(sequenceNumber, amount.scaleByPowerOfTen(4).longValue(), taxOthers.scaleByPowerOfTen(4).longValue(), timeout);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void cashDeposit(Integer sequenceNumber, BigDecimal amount, Integer timeout) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.cashDeposit(sequenceNumber, amount.scaleByPowerOfTen(4).longValue(), timeout);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void checkCard(Integer sequenceNumber, Integer timeout) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.checkCard(sequenceNumber, timeout);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void checkHealth(HealthCheckLevel level) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.checkHealth(jposConst.get(level));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void claim(Integer timeout) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.claim(timeout);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void clearOutput() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.clearOutput();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void close(String endpointAddress) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            if (deviceEvent != null)
            {
                device.removeDirectIOListener(this);
                device.removeErrorListener(this);
                device.removeOutputCompleteListener(this);
                device.removeStatusUpdateListener(this);
                deviceEvent = null;
            }
            device.close();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public CompareFirmwareResult compareFirmwareVersion(String firmwareFileName) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            int[] param = new int[1];
            device.compareFirmwareVersion(firmwareFileName, param);
            return compareFirmwareResult.get(param[0]);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public DirectIOData directIO(Integer command, Integer data, Object obj) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            DirectIOData res = new DirectIOData();
            int[] param = new int[] { data };
            device.directIO(command, param, obj);
            res.setData(param[0]);
            res.setObj(obj);
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getAccountNumber() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getAccountNumber();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getAdditionalSecurityInformation() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getAdditionalSecurityInformation();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getApprovalCode() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getApprovalCode();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getAsyncMode() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getAsyncMode();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public BigDecimal getBalance() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return BigDecimal.valueOf(device.getBalance()).scaleByPowerOfTen(-4);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapAdditionalSecurityInformation() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapAdditionalSecurityInformation();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapAuthorizeCompletion() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapAuthorizeCompletion();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapAuthorizePreSales() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapAuthorizePreSales();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapAuthorizeRefund() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapAuthorizeRefund();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapAuthorizeVoid() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapAuthorizeVoid();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapAuthorizeVoidPreSales() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapAuthorizeVoidPreSales();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapCashDeposit() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapCashDeposit();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapCenterResultCode() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapCenterResultCode();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapCheckCard() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapCheckCard();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapCompareFirmwareVersion() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapCompareFirmwareVersion();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public CATLogs getCapDailyLog() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return catLogs.get(device.getCapDailyLog());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapInstallments() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapInstallments();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapLockTerminal() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapLockTerminal();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapLogStatus() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapLogStatus();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapPaymentDetail() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapPaymentDetail();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public PowerReporting getCapPowerReporting() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return powerReporting.get(device.getCapPowerReporting());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapStatisticsReporting() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapStatisticsReporting();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapTaxOthers() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapTaxOthers();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapTrainingMode() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapTrainingMode();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapTransactionNumber() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapTransactionNumber();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapUnlockTerminal() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapUnlockTerminal();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapUpdateFirmware() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapUpdateFirmware();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getCapUpdateStatistics() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCapUpdateStatistics();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getCardCompanyID() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCardCompanyID();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getCenterResultCode() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCenterResultCode();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getCheckHealthText() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getCheckHealthText();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getClaimed() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getClaimed();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getDailyLog() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getDailyLog();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getDeviceControlDescription() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        return device.getDeviceControlDescription();
    }

    public UposVersion getDeviceControlVersion() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        UposVersion res = new UposVersion();
        int version = device.getDeviceControlVersion();
        res.setMajor(version / 1000000 % 1000);
        res.setMinor(version / 1000 % 1000);
        res.setBuild(version % 1000);
        return res;
    }

    public Boolean getDeviceEnabled() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getDeviceEnabled();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getDeviceServiceDescription() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getDeviceServiceDescription();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public UposVersion getDeviceServiceVersion() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            UposVersion res = new UposVersion();
            int version = device.getDeviceServiceVersion();
            res.setMajor(version / 1000000 % 1000);
            res.setMinor(version / 1000 % 1000);
            res.setBuild(version % 1000);
            return res;
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Boolean getFreezeEvents() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getFreezeEvents();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public DealingLogStatus getLogStatus() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return dealingLogStatus.get(device.getLogStatus());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getOutputID() throws FaultException {
        throw new UnsupportedOperationException("Not supported yet.");
        /*
        try {
            return device.getOutputID();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
        */
    }

    public PaymentCondition getPaymentCondition() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return paymentCondition.get(device.getPaymentCondition());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getPaymentDetail() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getPaymentDetail();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public PaymentMedia getPaymentMedia() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return paymentMedia.get(device.getPaymentMedia());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getPhysicalDeviceDescription() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getPhysicalDeviceDescription();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getPhysicalDeviceName() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getPhysicalDeviceName();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public PowerNotification getPowerNotify() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return powerNotification.get(device.getPowerNotify());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public PowerState getPowerState() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return powerState.get(device.getPowerState());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public Integer getSequenceNumber() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getSequenceNumber();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public BigDecimal getSettledAmount() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return BigDecimal.valueOf(device.getSettledAmount()).scaleByPowerOfTen(-4);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getSlipNumber() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getSlipNumber();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public ControlState getState() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        return controlState.get(device.getState());
    }

    public Boolean getTrainingMode() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getTrainingMode();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String getTransactionNumber() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            return device.getTransactionNumber();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public CreditTransactionType getTransactionType() throws FaultException {
        throw new UnsupportedOperationException("Not supported yet.");
        /*
        try {
            return creditTransactionType.get(device.getTransactionType());
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
        */
    }

    public void lockTerminal() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.lockTerminal();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void open(String endpointAddress) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.open(deviceName);
            if (endpointAddress != null)
            {
                try {
                    Service service = Service.create(
                            new URL(endpointAddress + "?wsdl"),
                            new QName("http://www.nrf-arts.org/UnifiedPOS/CATEvents/", "CATEventService"));
                    deviceEvent = service.getPort(org.nrf_arts.unifiedpos.catevents.CATEvent.class);
                    device.addDirectIOListener(this);
                    device.addErrorListener(this);
                    device.addOutputCompleteListener(this);
                    device.addStatusUpdateListener(this);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void release() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.release();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void resetStatistics(StatisticList statisticsBuffer) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            String param = null;
            List<Statistic> list = statisticsBuffer.getStatistic();
            switch (list.size()) {
                case 0:
                    param = "";
                    break;
                case 1:
                    String name = list.get(0).getName();
                    if (name.equals(StatisticCategories.ALL)) {
                        param = "";
                    }
                    else if (name.equals(StatisticCategories.MANUFACTURER)) {
                        param = "M_";
                    }
                    else if (name.equals(StatisticCategories.UPOS)) {
                        param = "U_";
                    }
                    else {
                        param = name;
                    }
                    break;
                default:
                    StringBuffer buffer = new StringBuffer();
                    for (Statistic statistic : statisticsBuffer.getStatistic()) {
                        buffer.append(",").append(statistic.getName());
                    }
                    param = buffer.substring(1);
                    break;
            }
            device.resetStatistics(param);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public String retrieveStatistics(StatisticList statisticsBuffer) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            String[] param = new String[1];
            List<Statistic> list = statisticsBuffer.getStatistic();
            switch (list.size()) {
                case 0:
                    param[0] = "";
                    break;
                case 1:
                    String name = list.get(0).getName();
                    if (name.equals(StatisticCategories.ALL)) {
                        param[0] = "";
                    }
                    else if (name.equals(StatisticCategories.MANUFACTURER)) {
                        param[0] = "M_";
                    }
                    else if (name.equals(StatisticCategories.UPOS)) {
                        param[0] = "U_";
                    }
                    else {
                        param[0] = name;
                    }
                    break;
                default:
                    StringBuffer buffer = new StringBuffer();
                    for (Statistic statistic : statisticsBuffer.getStatistic()) {
                        buffer.append(",").append(statistic.getName());
                    }
                    param[0] = buffer.substring(1);
                    break;
            }
            device.retrieveStatistics(param);
            return param[0];
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setAdditionalSecurityInformation(String additionalSecurityInformation) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setAdditionalSecurityInformation(additionalSecurityInformation);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setAsyncMode(Boolean asyncMode) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setAsyncMode(asyncMode);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setDeviceEnabled(Boolean deviceEnabled) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setDeviceEnabled(deviceEnabled);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setFreezeEvents(Boolean freezeEvents) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setFreezeEvents(freezeEvents);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setPaymentMedia(PaymentMedia paymentMedia) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setPaymentMedia(jposConst.get(paymentMedia));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setPowerNotify(PowerNotification powerNotify) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setPowerNotify(jposConst.get(powerNotify));
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void setTrainingMode(Boolean trainingMode) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.setTrainingMode(trainingMode);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void unlockTerminal() throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.unlockTerminal();
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void updateFirmware(String firmwareFileName) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            device.updateFirmware(firmwareFileName);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    public void updateStatistics(StatisticList statisticsBuffer) throws FaultException {
        //throw new UnsupportedOperationException("Not supported yet.");
        try {
            String param = null;
            List<Statistic> list = statisticsBuffer.getStatistic();
            switch (list.size()) {
                case 0:
                    param = "";
                    break;
                case 1:
                    Statistic s = list.get(0);
                    String name = s.getName();
                    String value = s.getValue();
                    if (name.equals(StatisticCategories.ALL)) {
                        param = "=" + value;
                    }
                    else if (name.equals(StatisticCategories.MANUFACTURER)) {
                        param = "M_=" + value;
                    }
                    else if (name.equals(StatisticCategories.UPOS)) {
                        param = "U_=" + value;
                    }
                    else {
                        param = name + "=" + value;
                    }
                    break;
                default:
                    StringBuffer buffer = new StringBuffer();
                    for (Statistic statistic : statisticsBuffer.getStatistic()) {
                        buffer.append(",").append(statistic.getName()).append("=").append(statistic.getValue());
                    }
                    param = buffer.substring(1);
                    break;
            }
            device.updateStatistics(param);
        }
        catch (jpos.JposException e) {
            UposException faultInfo = new UposException();
            faultInfo.setErrorCode(errorCode.get(e.getErrorCode()));
            faultInfo.setErrorCodeExtended(e.getErrorCodeExtended());
            throw new FaultException(e.getMessage(), faultInfo, e);
        }
    }

    //
    // CATEvent Member
    //

    public void directIOOccurred(DirectIOEvent dioe) {
        //throw new UnsupportedOperationException("Not supported yet.");
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(new Date(dioe.getWhen()));
        org.nrf_arts.unifiedpos.catevents.DirectIOData value = deviceEvent.directIOEvent(
                dioe.getSource().toString(),
                (int)dioe.getSequenceNumber(),
                datatypeFactory.newXMLGregorianCalendar(cal),
                dioe.getEventNumber(),
                dioe.getData(),
                dioe.getObject());
        dioe.setData(value.getData());
        dioe.setObject(value.getObj());
    }

    public void errorOccurred(ErrorEvent ee) {
        //throw new UnsupportedOperationException("Not supported yet.");
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(new Date(ee.getWhen()));
        org.nrf_arts.unifiedpos.catevents.ErrorResponse value = deviceEvent.errorEvent(
                ee.getSource().toString(),
                (int)ee.getSequenceNumber(),
                datatypeFactory.newXMLGregorianCalendar(cal),
                eventErrorCode.get(ee.getErrorCode()),
                ee.getErrorCodeExtended(),
                eventErrorLocus.get(ee.getErrorLocus()),
                eventErrorResponse.get(ee.getErrorResponse()));
        ee.setErrorResponse(jposEventConst.get(value));
    }

    public void outputCompleteOccurred(OutputCompleteEvent oce) {
        //throw new UnsupportedOperationException("Not supported yet.");
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(new Date(oce.getWhen()));
        deviceEvent.statusUpdateEvent(
                oce.getSource().toString(),
                (int)oce.getSequenceNumber(),
                datatypeFactory.newXMLGregorianCalendar(cal),
                oce.getOutputID());
    }

    public void statusUpdateOccurred(StatusUpdateEvent sue) {
        //throw new UnsupportedOperationException("Not supported yet.");
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(new Date(sue.getWhen()));
        deviceEvent.statusUpdateEvent(
                sue.getSource().toString(),
                (int)sue.getSequenceNumber(),
                datatypeFactory.newXMLGregorianCalendar(cal),
                sue.getStatus());
    }

}
