﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace UnifiedPOS.Scanner
{
    [ServiceContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Scanner/")]
    public interface Scanner
    {

        //
        // Common Properties
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/GetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scanner/GetAutoDisableResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/UposException", Name = "UposException")]
        bool GetAutoDisable();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/SetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scanner/SetAutoDisableResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/UposException", Name = "UposException")]
        void SetAutoDisable(bool AutoDisable);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/GetCapCompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scanner/GetCapCompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/UposException", Name = "UposException")]
        bool GetCapCompareFirmwareVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/GetCapPowerReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scanner/GetCapPowerReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/UposException", Name = "UposException")]
        PowerReporting GetCapPowerReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/GetCapStatisticsReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scanner/GetCapStatisticsReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/UposException", Name = "UposException")]
        bool GetCapStatisticsReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/GetCapUpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scanner/GetCapUpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/UposException", Name = "UposException")]
        bool GetCapUpdateFirmware();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/GetCapUpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scanner/GetCapUpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/UposException", Name = "UposException")]
        bool GetCapUpdateStatistics();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/GetCheckHealthText", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scanner/GetCheckHealthTextResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/UposException", Name = "UposException")]
        string GetCheckHealthText();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/GetClaimed", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scanner/GetClaimedResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/UposException", Name = "UposException")]
        bool GetClaimed();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/GetDataCount", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scanner/GetDataCountResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/UposException", Name = "UposException")]
        int GetDataCount();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/GetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scanner/GetDataEventEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/UposException", Name = "UposException")]
        bool GetDataEventEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/SetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scanner/SetDataEventEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/UposException", Name = "UposException")]
        void SetDataEventEnabled(bool DataEventEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/GetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scanner/GetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/UposException", Name = "UposException")]
        bool GetDeviceEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/SetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scanner/SetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/UposException", Name = "UposException")]
        void SetDeviceEnabled(bool DeviceEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/GetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scanner/GetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/UposException", Name = "UposException")]
        bool GetFreezeEvents();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/SetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scanner/SetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/UposException", Name = "UposException")]
        void SetFreezeEvents(bool FreezeEvents);

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/GetOutputID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scanner/GetOutputIDResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/UposException", Name = "UposException")]
        // int GetOutputID();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/GetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scanner/GetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/UposException", Name = "UposException")]
        PowerNotification GetPowerNotify();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/SetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scanner/SetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/UposException", Name = "UposException")]
        void SetPowerNotify(PowerNotification PowerNotify);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/GetPowerState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scanner/GetPowerStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/UposException", Name = "UposException")]
        PowerState GetPowerState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/GetState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scanner/GetStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/UposException", Name = "UposException")]
        ControlState GetState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/GetDeviceControlDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scanner/GetDeviceControlDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/UposException", Name = "UposException")]
        string GetDeviceControlDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/GetDeviceControlVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scanner/GetDeviceControlVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/UposException", Name = "UposException")]
        UposVersion GetDeviceControlVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/GetDeviceServiceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scanner/GetDeviceServiceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/UposException", Name = "UposException")]
        string GetDeviceServiceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/GetDeviceServiceVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scanner/GetDeviceServiceVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/UposException", Name = "UposException")]
        UposVersion GetDeviceServiceVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/GetPhysicalDeviceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scanner/GetPhysicalDeviceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/UposException", Name = "UposException")]
        string GetPhysicalDeviceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/GetPhysicalDeviceName", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scanner/GetPhysicalDeviceNameResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/UposException", Name = "UposException")]
        string GetPhysicalDeviceName();

        //
        // Specific Properties
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/GetDecodeData", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scanner/GetDecodeDataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/UposException", Name = "UposException")]
        bool GetDecodeData();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/SetDecodeData", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scanner/SetDecodeDataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/UposException", Name = "UposException")]
        void SetDecodeData(bool DecodeData);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/GetScanData", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scanner/GetScanDataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/UposException", Name = "UposException")]
        byte[] GetScanData();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/GetScanDataLabel", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scanner/GetScanDataLabelResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/UposException", Name = "UposException")]
        byte[] GetScanDataLabel();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/GetScanDataType", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scanner/GetScanDataTypeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/UposException", Name = "UposException")]
        int GetScanDataType();

        //
        // Common Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/Open", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scanner/OpenResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/UposException", Name = "UposException")]
        void Open(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/Close", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scanner/CloseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/UposException", Name = "UposException")]
        void Close(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/Claim", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scanner/ClaimResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/UposException", Name = "UposException")]
        void Claim(int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/Release", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scanner/ReleaseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/UposException", Name = "UposException")]
        void Release();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/CheckHealth", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scanner/CheckHealthResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/UposException", Name = "UposException")]
        void CheckHealth(HealthCheckLevel Level);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/ClearInput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scanner/ClearInputResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/UposException", Name = "UposException")]
        void ClearInput();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/ClearInputProperties", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scanner/ClearInputPropertiesResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/UposException", Name = "UposException")]
        void ClearInputProperties();

        // [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/ClearOutput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scanner/ClearOutputResponse")]
        // [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/UposException", Name = "UposException")]
        // void ClearOutput();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/DirectIO", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scanner/DirectIOResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/UposException", Name = "UposException")]
        DirectIOData DirectIO(int Command, int Data, object Obj);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/CompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scanner/CompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/UposException", Name = "UposException")]
        CompareFirmwareResult CompareFirmwareVersion(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/ResetStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scanner/ResetStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/UposException", Name = "UposException")]
        void ResetStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/RetrieveStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scanner/RetrieveStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/UposException", Name = "UposException")]
        string RetrieveStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/UpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scanner/UpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/UposException", Name = "UposException")]
        void UpdateFirmware(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/UpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/Scanner/UpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/Scanner/UposException", Name = "UposException")]
        void UpdateStatistics(StatisticList StatisticsBuffer);

        //
        // Specific Methods
        //

    }

    //
    // Common Data Types
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Scanner/")]
    public class DirectIOData
    {
        [DataMember]
        public int Data { get; set; }
        [DataMember]
        public object Obj { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Scanner/")]
    public class UposException
    {
        [DataMember]
        public ErrorCode ErrorCode { get; set; }
        [DataMember]
        public int ErrorCodeExtended { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Scanner/")]
    public class UposVersion
    {
        [DataMember]
        public int Major { get; set; }
        [DataMember]
        public int Minor { get; set; }
        [DataMember]
        public int Build { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Scanner/")]
    public class Statistic
    {
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public string Value { get; set; }
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Scanner/", ItemName = "Statistic")]
    public class StatisticList : List<Statistic>
    {
    }

    //
    // Common Enumerations
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Scanner/")]
    public enum CompareFirmwareResult
    {
        [EnumMember]
        Different,
        [EnumMember]
        Newer,
        [EnumMember]
        Older,
        [EnumMember]
        Same,
        [EnumMember]
        Unknown,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Scanner/")]
    public enum ControlState
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Closed,
        [EnumMember]
        Error,
        [EnumMember]
        Idle,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Scanner/")]
    public enum ErrorCode
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Claimed,
        [EnumMember]
        Closed,
        [EnumMember]
        Deprecated,
        [EnumMember]
        Disabled,
        [EnumMember]
        Exists,
        [EnumMember]
        Extended,
        [EnumMember]
        Failure,
        [EnumMember]
        Illegal,
        [EnumMember]
        NoExist,
        [EnumMember]
        NoHardware,
        [EnumMember]
        NoService,
        [EnumMember]
        NotClaimed,
        [EnumMember]
        Offline,
        [EnumMember]
        Success,
        [EnumMember]
        Timeout,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Scanner/")]
    public enum HealthCheckLevel
    {
        [EnumMember]
        External,
        [EnumMember]
        Interactive,
        [EnumMember]
        Internal,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Scanner/")]
    public enum PowerNotification
    {
        [EnumMember]
        Disabled,
        [EnumMember]
        Enabled,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Scanner/")]
    public enum PowerReporting
    {
        [EnumMember]
        Advanced,
        [EnumMember]
        None,
        [EnumMember]
        Standard,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Scanner/")]
    public enum PowerState
    {
        [EnumMember]
        Off,
        [EnumMember]
        Offline,
        [EnumMember]
        OffOffline,
        [EnumMember]
        Online,
        [EnumMember]
        Unknown,
    }

    /*
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Scanner/")]
    public enum StatisticCategories
    {
        [EnumMember]
        All,
        [EnumMember]
        Manufacturer,
        [EnumMember]
        Upos,
    }
    */
    public class StatisticCategories
    {
        public const string All = "";
        public const string Manufacturer = "M_";
        public const string Upos = "U_";
    }

    //
    // Specific Data Types
    //

    //
    // Specific Enumerations
    //

    /*
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/Scanner/")]
    public enum BarCodeSymbology
    {
        [EnumMember]
        Aztec,
        [EnumMember]
        Cca,
        [EnumMember]
        Ccb,
        [EnumMember]
        Ccc,
        [EnumMember]
        Codabar,
        [EnumMember]
        Code128,
        [EnumMember]
        Code128Parsed,
        [EnumMember]
        Code39,
        [EnumMember]
        Code93,
        [EnumMember]
        DataMatrix,
        [EnumMember]
        Ean128,
        [EnumMember]
        Ean13S,
        [EnumMember]
        Ean8S,
        [EnumMember]
        EanJan13,
        [EnumMember]
        EanJan8,
        [EnumMember]
        Gs1DataBar,
        [EnumMember]
        Gs1DataBarExpanded,
        [EnumMember]
        Gs1DataBarExpandedStacked,
        [EnumMember]
        Gs1DataBarStackedOmnidirectional,
        [EnumMember]
        Itf,
        [EnumMember]
        Maxicode,
        [EnumMember]
        MicroPDF417,
        [EnumMember]
        MicroQRCode,
        [EnumMember]
        Ocra,
        [EnumMember]
        Ocrb,
        [EnumMember]
        Other,
        [EnumMember]
        Pdf417,
        [EnumMember]
        QRCode,
        [EnumMember]
        Rss14,
        [EnumMember]
        RssExpanded,
        [EnumMember]
        TF,
        [EnumMember]
        Unknown,
        [EnumMember]
        Upca,
        [EnumMember]
        Upcas,
        [EnumMember]
        Upcd1,
        [EnumMember]
        Upcd2,
        [EnumMember]
        Upcd3,
        [EnumMember]
        Upcd4,
        [EnumMember]
        Upcd5,
        [EnumMember]
        Upce,
        [EnumMember]
        Upces,
    }
    */
    public class BarCodeSymbology
    {
        public const int Aztec = 206;
        public const int Cca = 151;
        public const int Ccb = 152;
        public const int Ccc = 153;
        public const int Codabar = 107;
        public const int Code128 = 110;
        public const int Code128Parsed = 123;
        public const int Code39 = 108;
        public const int Code93 = 109;
        public const int DataMatrix = 203;
        public const int Ean128 = 120;
        public const int Ean13S = 119;
        public const int Ean8S = 118;
        public const int EanJan13 = 104;
        public const int EanJan8 = 103;
        public const int Gs1DataBar = 131;
        public const int Gs1DataBarExpanded = 132;
        public const int Gs1DataBarExpandedStacked = 134;
        public const int Gs1DataBarStackedOmnidirectional = 133;
        public const int Itf = 106;
        public const int Maxicode = 202;
        public const int MicroPDF417 = 207;
        public const int MicroQRCode = 205;
        public const int Ocra = 121;
        public const int Ocrb = 122;
        public const int Other = 501;
        public const int Pdf417 = 201;
        public const int QRCode = 204;
        public const int Rss14 = 131;
        public const int RssExpanded = 132;
        public const int TF = 105;
        public const int Unknown = 0;
        public const int Upca = 101;
        public const int Upcas = 111;
        public const int Upcd1 = 113;
        public const int Upcd2 = 114;
        public const int Upcd3 = 115;
        public const int Upcd4 = 116;
        public const int Upcd5 = 117;
        public const int Upce = 102;
        public const int Upces = 112;
    }

    //
    // Constants
    //

    /*
    public class Constants
    {
        public const int ExtendedErrorFirmwareBadFile = 281;
        public const int ExtendedErrorStatistics = 280;
        public const int ExtendedErrorStatisticsDependency = 282;
        public const string StatisticCommunicationErrorCount = "CommunicationErrorCount";
        public const string StatisticDeviceCategory = "DeviceCategory";
        public const string StatisticFirmwareRevision = "FirmwareRevision";
        public const string StatisticGoodScanCount = "GoodScanCount";
        public const string StatisticHoursPoweredCount = "HoursPoweredCount";
        public const string StatisticInstallationDate = "InstallationDate";
        public const string StatisticInterface = "Interface";
        public const string StatisticManufactureDate = "ManufactureDate";
        public const string StatisticManufacturerName = "ManufacturerName";
        public const string StatisticMechanicalRevision = "MechanicalRevision";
        public const string StatisticModelName = "ModelName";
        public const string StatisticSerialNumber = "SerialNumber";
        public const string StatisticUnifiedPOSVersion = "UnifiedPOSVersion";
        public const int WaitForever = -1;
    }
    */

    public class ExtendedError
    {
        public const int FirmwareBadFile = 281;
        public const int Statistics = 280;
        public const int StatisticsDependency = 282;
    }

    public class StatisticProperties
    {
        public const string CommunicationErrorCount = "CommunicationErrorCount";
        public const string DeviceCategory = "DeviceCategory";
        public const string FirmwareRevision = "FirmwareRevision";
        public const string GoodScanCount = "GoodScanCount";
        public const string HoursPoweredCount = "HoursPoweredCount";
        public const string InstallationDate = "InstallationDate";
        public const string Interface = "Interface";
        public const string ManufactureDate = "ManufactureDate";
        public const string ManufacturerName = "ManufacturerName";
        public const string MechanicalRevision = "MechanicalRevision";
        public const string ModelName = "ModelName";
        public const string SerialNumber = "SerialNumber";
        public const string UnifiedPOSVersion = "UnifiedPOSVersion";
    }

    public class Wait
    {
        public const int Forever = -1;
    }
}
