/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package wspos;

import javax.xml.ws.Endpoint;

/**
 *
 * @author hideon
 */
public class CashDrawerServiceHost {

    public void start() {
        System.out.println("WS-POS 1.1 JAX-WS Service");
        Endpoint.publish("http://localhost:8000/CashDrawer", new CashDrawerService("CashDrawer1"));

        System.out.println("Press [Ctrl-C] to close.");
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        CashDrawerServiceHost program = new CashDrawerServiceHost();
        program.start();
    }

}
