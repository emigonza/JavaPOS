
package org.nrf_arts.unifiedpos.billdispenser;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="GetAsyncResultCodeExtendedResult" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "getAsyncResultCodeExtendedResult"
})
@XmlRootElement(name = "GetAsyncResultCodeExtendedResponse")
public class GetAsyncResultCodeExtendedResponse {

    @XmlElement(name = "GetAsyncResultCodeExtendedResult")
    protected Integer getAsyncResultCodeExtendedResult;

    /**
     * Gets the value of the getAsyncResultCodeExtendedResult property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getGetAsyncResultCodeExtendedResult() {
        return getAsyncResultCodeExtendedResult;
    }

    /**
     * Sets the value of the getAsyncResultCodeExtendedResult property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setGetAsyncResultCodeExtendedResult(Integer value) {
        this.getAsyncResultCodeExtendedResult = value;
    }

}
