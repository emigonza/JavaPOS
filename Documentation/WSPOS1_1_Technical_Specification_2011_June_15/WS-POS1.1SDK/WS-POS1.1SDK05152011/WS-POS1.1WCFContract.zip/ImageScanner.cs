﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace UnifiedPOS.ImageScanner
{
    [ServiceContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/")]
    public interface ImageScanner
    {

        //
        // Common Properties
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetAutoDisableResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        bool GetAutoDisable();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/SetAutoDisable", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/SetAutoDisableResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        void SetAutoDisable(bool AutoDisable);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetCapCompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetCapCompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        bool GetCapCompareFirmwareVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetCapPowerReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetCapPowerReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        PowerReporting GetCapPowerReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetCapStatisticsReporting", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetCapStatisticsReportingResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        bool GetCapStatisticsReporting();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetCapUpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetCapUpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        bool GetCapUpdateFirmware();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetCapUpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetCapUpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        bool GetCapUpdateStatistics();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetCheckHealthText", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetCheckHealthTextResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        string GetCheckHealthText();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetClaimed", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetClaimedResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        bool GetClaimed();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetDataCount", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetDataCountResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        int GetDataCount();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetDataEventEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        bool GetDataEventEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/SetDataEventEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/SetDataEventEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        void SetDataEventEnabled(bool DataEventEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        bool GetDeviceEnabled();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/SetDeviceEnabled", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/SetDeviceEnabledResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        void SetDeviceEnabled(bool DeviceEnabled);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        bool GetFreezeEvents();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/SetFreezeEvents", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/SetFreezeEventsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        void SetFreezeEvents(bool FreezeEvents);

        //[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetOutputID", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetOutputIDResponse")]
        //[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        //int GetOutputID();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        PowerNotification GetPowerNotify();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/SetPowerNotify", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/SetPowerNotifyResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        void SetPowerNotify(PowerNotification PowerNotify);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetPowerState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetPowerStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        PowerState GetPowerState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetState", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetStateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        ControlState GetState();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetDeviceControlDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetDeviceControlDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        string GetDeviceControlDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetDeviceControlVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetDeviceControlVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        UposVersion GetDeviceControlVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetDeviceServiceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetDeviceServiceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        string GetDeviceServiceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetDeviceServiceVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetDeviceServiceVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        UposVersion GetDeviceServiceVersion();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetPhysicalDeviceDescription", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetPhysicalDeviceDescriptionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        string GetPhysicalDeviceDescription();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetPhysicalDeviceName", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetPhysicalDeviceNameResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        string GetPhysicalDeviceName();

        //
        // Specific Properties
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetCapAim", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetCapAimResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        bool GetCapAim();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetCapDecodeData", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetCapDecodeDataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        bool GetCapDecodeData();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetCapHostTriggered", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetCapHostTriggeredResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        bool GetCapHostTriggered();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetCapIlluminate", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetCapIlluminateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        bool GetCapIlluminate();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetCapImageData", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetCapImageDataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        bool GetCapImageData();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetCapImageQuality", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetCapImageQualityResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        bool GetCapImageQuality();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetCapVideoData", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetCapVideoDataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        bool GetCapVideoData();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetAimMode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetAimModeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        bool GetAimMode();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/SetAimMode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/SetAimModeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        void SetAimMode(bool AimMode);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetBitsPerPixel", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetBitsPerPixelResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        int GetBitsPerPixel();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetFrameData", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetFrameDataResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        byte[] GetFrameData();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetFrameType", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetFrameTypeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        FrameType GetFrameType();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetIlluminateMode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetIlluminateModeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        bool GetIlluminateMode();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/SetIlluminateMode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/SetIlluminateModeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        void SetIlluminateMode(bool IlluminateMode);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetImageHeight", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetImageHeightResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        int GetImageHeight();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetImageLength", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetImageLengthResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        int GetImageLength();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetImageMode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetImageModeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        ImageMode GetImageMode();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/SetImageMode", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/SetImageModeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        void SetImageMode(ImageMode ImageMode);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetImageQuality", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetImageQualityResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        ImageQuality GetImageQuality();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/SetImageQuality", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/SetImageQualityResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        void SetImageQuality(ImageQuality ImageQuality);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetImageType", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetImageTypeResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        ImageType GetImageType();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetImageWidth", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetImageWidthResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        int GetImageWidth();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetVideoCount", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetVideoCountResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        int GetVideoCount();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/SetVideoCount", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/SetVideoCountResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        void SetVideoCount(int VideoCount);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetVideoRate", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/GetVideoRateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        int GetVideoRate();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/SetVideoRate", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/SetVideoRateResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        void SetVideoRate(int VideoRate);

        //
        // Common Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/Open", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/OpenResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        void Open(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/Close", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/CloseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        void Close(string EndpointAddress);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/Claim", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/ClaimResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        void Claim(int Timeout);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/Release", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/ReleaseResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        void Release();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/CheckHealth", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/CheckHealthResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        void CheckHealth(HealthCheckLevel Level);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/ClearInput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/ClearInputResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        void ClearInput();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/ClearInputProperties", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/ClearInputPropertiesResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        void ClearInputProperties();

        //[OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/ClearOutput", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/ClearOutputResponse")]
        //[FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        //void ClearOutput();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/DirectIO", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/DirectIOResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        DirectIOData DirectIO(int Command, int Data, object Obj);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/CompareFirmwareVersion", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/CompareFirmwareVersionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        CompareFirmwareResult CompareFirmwareVersion(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/ResetStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/ResetStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        void ResetStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/RetrieveStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/RetrieveStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        string RetrieveStatistics(StatisticList StatisticsBuffer);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UpdateFirmware", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UpdateFirmwareResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        void UpdateFirmware(string FirmwareFileName);

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UpdateStatistics", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UpdateStatisticsResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        void UpdateStatistics(StatisticList StatisticsBuffer);

        //
        // Specific Methods
        //

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/StartSession", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/StartSessionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        void StartSession();

        [OperationContract(Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/StopSession", ReplyAction = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/StopSessionResponse")]
        [FaultContract(typeof(UposException), Action = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/UposException", Name = "UposException")]
        void StopSession();

    }

    //
    // Common Data Types
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/")]
    public class DirectIOData
    {
        [DataMember]
        public int Data { get; set; }
        [DataMember]
        public object Obj { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/")]
    public class UposException
    {
        [DataMember]
        public ErrorCode ErrorCode { get; set; }
        [DataMember]
        public int ErrorCodeExtended { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/")]
    public class UposVersion
    {
        [DataMember]
        public int Major { get; set; }
        [DataMember]
        public int Minor { get; set; }
        [DataMember]
        public int Build { get; set; }
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/")]
    public class Statistic
    {
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public string Value { get; set; }
    }

    [CollectionDataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/", ItemName = "Statistic")]
    public class StatisticList : List<Statistic>
    {
    }

    //
    // Common Enumerations
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/")]
    public enum CompareFirmwareResult
    {
        [EnumMember]
        Different,
        [EnumMember]
        Newer,
        [EnumMember]
        Older,
        [EnumMember]
        Same,
        [EnumMember]
        Unknown,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/")]
    public enum ControlState
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Closed,
        [EnumMember]
        Error,
        [EnumMember]
        Idle,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/")]
    public enum ErrorCode
    {
        [EnumMember]
        Busy,
        [EnumMember]
        Claimed,
        [EnumMember]
        Closed,
        [EnumMember]
        Deprecated,
        [EnumMember]
        Disabled,
        [EnumMember]
        Exists,
        [EnumMember]
        Extended,
        [EnumMember]
        Failure,
        [EnumMember]
        Illegal,
        [EnumMember]
        NoExist,
        [EnumMember]
        NoHardware,
        [EnumMember]
        NoService,
        [EnumMember]
        NotClaimed,
        [EnumMember]
        Offline,
        [EnumMember]
        Success,
        [EnumMember]
        Timeout,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/")]
    public enum HealthCheckLevel
    {
        [EnumMember]
        External,
        [EnumMember]
        Interactive,
        [EnumMember]
        Internal,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/")]
    public enum PowerNotification
    {
        [EnumMember]
        Disabled,
        [EnumMember]
        Enabled,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/")]
    public enum PowerReporting
    {
        [EnumMember]
        Advanced,
        [EnumMember]
        None,
        [EnumMember]
        Standard,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/")]
    public enum PowerState
    {
        [EnumMember]
        Off,
        [EnumMember]
        Offline,
        [EnumMember]
        OffOffline,
        [EnumMember]
        Online,
        [EnumMember]
        Unknown,
    }

    /*
    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/")]
    public enum StatisticCategories
    {
        [EnumMember]
        All,
        [EnumMember]
        Manufacturer,
        [EnumMember]
        Upos,
    }
    */
    public class StatisticCategories
    {
        public const string All = "";
        public const string Manufacturer = "M_";
        public const string Upos = "U_";
    }

    //
    // Specific Data Types
    //

    //
    // Specific Enumerations
    //

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/")]
    public enum FrameType
    {
        [EnumMember]
        Still,
        [EnumMember]
        Video,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/")]
    public enum ImageMode
    {
        [EnumMember]
        DecodeOnly,
        [EnumMember]
        StillOnly,
        [EnumMember]
        StillAndDecode,
        [EnumMember]
        VideoAndDecode,
        [EnumMember]
        VideoAndStill,
        [EnumMember]
        All,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/")]
    public enum ImageQuality
    {
        [EnumMember]
        Low,
        [EnumMember]
        Medium,
        [EnumMember]
        High,
    }

    [DataContract(Namespace = "http://www.nrf-arts.org/UnifiedPOS/ImageScanner/")]
    public enum ImageType
    {
        [EnumMember]
        Bmp,
        [EnumMember]
        Jpeg,
        [EnumMember]
        Gif,
        [EnumMember]
        Png,
        [EnumMember]
        Tiff,
    }

    //
    // Constants
    //

    public class ExtendedError
    {
        public const int FirmwareBadFile = 281;
        public const int Statistics = 280;
        public const int StatisticsDependency = 282;
    }

    public class StatisticProperties
    {
        public const string CommunicationErrorCount = "CommunicationErrorCount";
        public const string DeviceCategory = "DeviceCategory";
        public const string FirmwareRevision = "FirmwareRevision";
        public const string HoursPoweredCount = "HoursPoweredCount";
        public const string InstallationDate = "InstallationDate";
        public const string Interface = "Interface";
        public const string ManufactureDate = "ManufactureDate";
        public const string ManufacturerName = "ManufacturerName";
        public const string MechanicalRevision = "MechanicalRevision";
        public const string ModelName = "ModelName";
        public const string SerialNumber = "SerialNumber";
        public const string UnifiedPOSVersion = "UnifiedPOSVersion";
        public const string GoodReadCount = "GoodReadCount";
        public const string NoReadCount = "NoReadCount";
        public const string SessionCount = "SessionCount";
    }

    public class Wait
    {
        public const int Forever = -1;
    }
}
