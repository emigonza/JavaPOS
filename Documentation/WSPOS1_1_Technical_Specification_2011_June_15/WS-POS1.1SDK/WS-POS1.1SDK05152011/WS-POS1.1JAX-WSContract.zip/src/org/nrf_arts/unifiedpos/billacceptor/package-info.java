@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.nrf-arts.org/UnifiedPOS/BillAcceptor/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package org.nrf_arts.unifiedpos.billacceptor;
